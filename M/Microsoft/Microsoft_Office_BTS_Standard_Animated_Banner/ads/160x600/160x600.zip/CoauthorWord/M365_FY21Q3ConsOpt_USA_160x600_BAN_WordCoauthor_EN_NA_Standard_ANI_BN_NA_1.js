(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1", frames: [[0,0,604,384],[606,235,268,215],[634,452,168,106],[284,386,177,130],[560,623,102,86],[804,558,156,76],[107,579,104,86],[463,386,122,39],[664,623,104,82],[804,452,151,104],[0,579,105,86],[876,345,112,90],[606,0,350,233],[463,452,169,106],[0,386,282,191],[284,518,120,111],[406,560,152,63],[560,560,152,61],[876,235,138,108]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.basicUI = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.girllefticon = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticon = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.guylefticon = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.secondimage = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.titleshadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.tile_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.text03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,0,88.5,65), null);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.secondimage_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.secondimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage_1, new cjs.Rectangle(0,0,84.5,53), null);


(lib.screenBG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.basicUI();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(0,0,302,192), null);


(lib.screenshadowpicture = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.screenshadow();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.roundshadowshape = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.roundshadow1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45), null);


(lib.Outlook_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.image01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(0,0,75.5,52), null);


(lib.firstimage_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(0,0,84,53), null);


(lib.fill = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlrighticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girllefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(0,0,51,43), null);


(lib.face02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guylefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52,41), null);


(lib.face01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyrighticon1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,0,52.5,43), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.boxshadowpicture = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150.0023,124.9924,1,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.WordUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(0,0,302,192), null);


(lib.squareshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-31.6,-11.15,416.5,277.25,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(176.6,127.45,1,1,0,0,0,208.2,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-31.6,-11.1,416.5,277.20000000000005), null);


(lib.roundshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0,56,45), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(73.1,908.7,0.1944,0.1944,0,0,0,-39.9,1.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.2168,scaleY:3.2168,x:73},13,cjs.Ease.quadOut).to({x:-105.8},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgVfBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_15 = new cjs.Graphics().p("EgVrBJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_16 = new cjs.Graphics().p("EgWRBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_17 = new cjs.Graphics().p("EgXPBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_18 = new cjs.Graphics().p("EgYmBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_19 = new cjs.Graphics().p("EgaWBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_20 = new cjs.Graphics().p("EgceBJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_21 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_22 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_23 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_24 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_25 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_26 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:245.2711,y:471.6178}).wait(1).to({graphics:mask_graphics_15,x:244.0282,y:471.6178}).wait(1).to({graphics:mask_graphics_16,x:240.2997,y:471.6178}).wait(1).to({graphics:mask_graphics_17,x:234.0854,y:471.6178}).wait(1).to({graphics:mask_graphics_18,x:225.3854,y:471.6178}).wait(1).to({graphics:mask_graphics_19,x:214.1996,y:471.6178}).wait(1).to({graphics:mask_graphics_20,x:200.5282,y:471.6178}).wait(1).to({graphics:mask_graphics_21,x:182.2746,y:471.6178}).wait(1).to({graphics:mask_graphics_22,x:159.9031,y:471.6178}).wait(1).to({graphics:mask_graphics_23,x:142.5031,y:471.6178}).wait(1).to({graphics:mask_graphics_24,x:130.0745,y:471.6178}).wait(1).to({graphics:mask_graphics_25,x:122.6174,y:471.6178}).wait(1).to({graphics:mask_graphics_26,x:120.2033,y:471.6178}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-207.9,904.85,3.2168,3.2168,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:23.25},12,cjs.Ease.quadInOut).wait(33).to({regY:0.4,scaleY:3.2175},0).to({regX:-0.1,scaleX:2.408,scaleY:2.408,x:-12,y:7.9},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(69,896.7,0.611,2.4487,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-1.2,regY:0.1,scaleX:0.6109,x:70.2,y:910.25},59).to({regX:0,regY:0,scaleX:0.611,x:66,y:899,alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-234,-104.9,605,2014.9);


(lib.iconcache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(14,0,1.6738,1.6738);

	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(127.4,117.7,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconcache, new cjs.Rectangle(0,0,254.6,219.9), null);


(lib.icon_teams = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.guyrighticon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,0,52.5,43), null);


(lib.guyrightcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution_1, new cjs.Rectangle(0,0,75.5,52), null);


(lib.guylefticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon_1, new cjs.Rectangle(0,0,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.girlrigthcontribution = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon_1, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon_1, new cjs.Rectangle(0,0,51,43), null);


(lib.girlleftcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution_1, new cjs.Rectangle(0,0,88.5,65), null);


(lib.BG_gray = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.WordIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.iconcache.cache(-260,-230,520,460,0.8);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.iconcache = new lib.iconcache();
	this.iconcache.name = "iconcache";
	this.iconcache.setTransform(225.3,236.4,1,1,0,0,0,127.3,109.9);

	this.timeline.addTween(cjs.Tween.get(this.iconcache).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(98,126.5,254.60000000000002,219.89999999999998), null);


(lib.logo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.screenanimation = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_81 = function() {
		exportRoot.tl1.play();
	}
	this.frame_140 = function() {
		exportRoot.tl1.pause();
	}
	this.frame_157 = function() {
		exportRoot.tl1.play();
	}
	this.frame_218 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(81).call(this.frame_81).wait(59).call(this.frame_140).wait(17).call(this.frame_157).wait(61).call(this.frame_218).wait(1));

	// guy right icon.png
	this.instance = new lib.guyrighticon();
	this.instance.setTransform(222.3,-24.35,1,1,0,0,0,26.4,21.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({x:181.1,y:75.5,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:26.2,x:180.9},0).wait(11).to({regX:26.4,x:181.1},0).wait(1).to({regX:26.2,scaleX:0.9967,scaleY:0.9967,y:75.8},0).wait(1).to({scaleX:0.9931,scaleY:0.9931,x:181.35,y:76.1},0).wait(1).to({scaleX:0.9892,scaleY:0.9892,x:181.65,y:76.45},0).wait(1).to({scaleX:0.985,scaleY:0.985,x:182,y:76.85},0).wait(1).to({scaleX:0.9804,scaleY:0.9804,x:182.35,y:77.3},0).wait(1).to({scaleX:0.9756,scaleY:0.9756,x:182.7,y:77.7},0).wait(1).to({scaleX:0.9704,scaleY:0.9704,x:183.1,y:78.15},0).wait(1).to({scaleX:0.965,scaleY:0.965,x:183.5,y:78.65},0).wait(1).to({scaleX:0.9592,scaleY:0.9592,x:183.95,y:79.15},0).wait(1).to({scaleX:0.9532,scaleY:0.9532,x:184.35,y:79.75},0).wait(1).to({scaleX:0.9468,scaleY:0.9468,x:184.85,y:80.3},0).wait(1).to({scaleX:0.9402,scaleY:0.9402,x:185.4,y:80.9},0).wait(1).to({scaleX:0.9333,scaleY:0.9333,x:185.9,y:81.55},0).wait(1).to({scaleX:0.9261,scaleY:0.9261,x:186.4,y:82.2},0).wait(1).to({scaleX:0.9187,scaleY:0.9187,x:186.95,y:82.9},0).wait(1).to({scaleX:0.9111,scaleY:0.9111,x:187.55,y:83.6},0).wait(1).to({scaleX:0.9033,scaleY:0.9033,x:188.1,y:84.25},0).wait(1).to({scaleX:0.8953,scaleY:0.8953,x:188.75,y:85},0).wait(1).to({scaleX:0.8871,scaleY:0.8871,x:189.35,y:85.75},0).wait(1).to({scaleX:0.8788,scaleY:0.8788,x:189.95,y:86.5},0).wait(1).to({scaleX:0.8703,scaleY:0.8703,x:190.6,y:87.25},0).wait(1).to({scaleX:0.8618,scaleY:0.8618,x:191.25,y:88.1},0).wait(1).to({scaleX:0.8533,scaleY:0.8533,x:191.9,y:88.85},0).wait(1).to({scaleX:0.8447,scaleY:0.8447,x:192.55,y:89.6},0).wait(1).to({scaleX:0.8361,scaleY:0.8361,x:193.15,y:90.45},0).wait(1).to({scaleX:0.8276,scaleY:0.8276,x:193.85,y:91.2},0).wait(1).to({scaleX:0.8191,scaleY:0.8191,x:194.45,y:91.95},0).wait(1).to({scaleX:0.8107,scaleY:0.8107,x:195.1,y:92.75},0).wait(1).to({scaleX:0.8025,scaleY:0.8025,x:195.7,y:93.45},0).wait(1).to({scaleX:0.7944,scaleY:0.7944,x:196.3,y:94.25},0).wait(1).to({scaleX:0.7864,scaleY:0.7864,x:196.9,y:94.9},0).wait(1).to({scaleX:0.7787,scaleY:0.7787,x:197.5,y:95.65},0).wait(1).to({scaleX:0.7711,scaleY:0.7711,x:198.05,y:96.35},0).wait(1).to({scaleX:0.7639,scaleY:0.7639,x:198.6,y:96.95},0).wait(1).to({scaleX:0.7568,scaleY:0.7568,x:199.15,y:97.6},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:199.65,y:98.25},0).wait(1).to({scaleX:0.7435,scaleY:0.7435,x:200.15,y:98.85},0).wait(1).to({scaleX:0.7373,scaleY:0.7373,x:200.55,y:99.4},0).wait(1).to({scaleX:0.7314,scaleY:0.7314,x:201,y:99.95},0).wait(1).to({scaleX:0.7258,scaleY:0.7258,x:201.45,y:100.45},0).wait(1).to({scaleX:0.7205,scaleY:0.7205,x:201.9,y:100.95},0).wait(1).to({scaleX:0.7155,scaleY:0.7155,x:202.25,y:101.4},0).wait(1).to({scaleX:0.7108,scaleY:0.7108,x:202.55,y:101.85},0).wait(1).to({scaleX:0.7064,scaleY:0.7064,x:202.9,y:102.2},0).wait(1).to({scaleX:0.7024,scaleY:0.7024,x:203.2,y:102.6},0).wait(1).to({scaleX:0.6986,scaleY:0.6986,x:203.5,y:102.9},0).wait(1).to({scaleX:0.6952,scaleY:0.6952,x:203.75,y:103.25},0).wait(1).to({scaleX:0.692,scaleY:0.692,x:204,y:103.55},0).wait(1).to({scaleX:0.6892,scaleY:0.6892,x:204.2,y:103.75},0).wait(1).to({scaleX:0.6867,scaleY:0.6867,x:204.4,y:104},0).wait(1).to({scaleX:0.6844,scaleY:0.6844,x:204.6,y:104.2},0).wait(1).to({scaleX:0.6824,scaleY:0.6824,x:204.75,y:104.4},0).wait(1).to({scaleX:0.6808,scaleY:0.6808,x:204.85,y:104.55},0).wait(1).to({scaleX:0.6793,scaleY:0.6793,x:204.95,y:104.65},0).wait(1).to({scaleX:0.6782,scaleY:0.6782,x:205,y:104.8},0).wait(1).to({scaleX:0.6773,scaleY:0.6773,x:205.1,y:104.85},0).wait(1).to({scaleX:0.6767,scaleY:0.6767,x:205.15,y:104.9},0).wait(1).to({scaleX:0.6763,scaleY:0.6763,y:104.95},0).wait(1).to({regX:26.6,regY:21.7,scaleX:0.6762,scaleY:0.6762,x:205.35,y:105},0).wait(1).to({regX:26.2,regY:21.5,x:205.05,y:104.9},0).wait(15).to({regX:26.6,regY:21.7,x:205.35,y:105},0).wait(1).to({regX:26.2,regY:21.5,scaleX:0.6761,scaleY:0.6761,x:205.05,y:104.85},0).wait(1).to({scaleX:0.6759,scaleY:0.6759},0).wait(1).to({scaleX:0.6756,scaleY:0.6756},0).wait(1).to({scaleX:0.6753,scaleY:0.6753,x:205.1,y:104.75},0).wait(1).to({scaleX:0.6748,scaleY:0.6748},0).wait(1).to({scaleX:0.6742,scaleY:0.6742,y:104.7},0).wait(1).to({scaleX:0.6735,scaleY:0.6735,x:205.15,y:104.65},0).wait(1).to({scaleX:0.6727,scaleY:0.6727,y:104.55},0).wait(1).to({scaleX:0.6717,scaleY:0.6717,x:205.2,y:104.5},0).wait(1).to({scaleX:0.6706,scaleY:0.6706,y:104.4},0).wait(1).to({scaleX:0.6693,scaleY:0.6693,x:205.25,y:104.35},0).wait(1).to({scaleX:0.6678,scaleY:0.6678,x:205.3,y:104.2},0).wait(1).to({scaleX:0.6662,scaleY:0.6662,x:205.35,y:104.05},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,x:205.4,y:103.95},0).wait(1).to({scaleX:0.6622,scaleY:0.6622,x:205.45,y:103.75},0).wait(1).to({scaleX:0.6597,scaleY:0.6597,x:205.55,y:103.6},0).wait(1).to({scaleX:0.657,scaleY:0.657,x:205.6,y:103.35},0).wait(1).to({scaleX:0.6539,scaleY:0.6539,x:205.75,y:103.1},0).wait(1).to({scaleX:0.6504,scaleY:0.6504,x:205.85,y:102.85},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:205.95,y:102.5},0).wait(1).to({scaleX:0.6416,scaleY:0.6416,x:206.05,y:102.15},0).wait(1).to({scaleX:0.6362,scaleY:0.6362,x:206.2,y:101.7},0).wait(1).to({scaleX:0.6299,scaleY:0.6299,x:206.45,y:101.2},0).wait(1).to({scaleX:0.6224,scaleY:0.6224,x:206.65,y:100.65},0).wait(1).to({scaleX:0.6134,scaleY:0.6134,x:206.9,y:99.9},0).wait(1).to({scaleX:0.6023,scaleY:0.6023,x:207.3,y:99},0).wait(1).to({scaleX:0.5886,scaleY:0.5886,x:207.65,y:97.95},0).wait(1).to({scaleX:0.5718,scaleY:0.5718,x:208.2,y:96.6},0).wait(1).to({scaleX:0.5522,scaleY:0.5522,x:208.75,y:95.05},0).wait(1).to({scaleX:0.5326,scaleY:0.5326,x:209.35,y:93.5},0).wait(1).to({scaleX:0.5154,scaleY:0.5154,x:209.85,y:92.15},0).wait(1).to({scaleX:0.5014,scaleY:0.5014,x:210.3,y:91.05},0).wait(1).to({scaleX:0.49,scaleY:0.49,x:210.65,y:90.15},0).wait(1).to({scaleX:0.4806,scaleY:0.4806,x:210.9,y:89.4},0).wait(1).to({scaleX:0.4728,scaleY:0.4728,x:211.15,y:88.75},0).wait(1).to({scaleX:0.4661,scaleY:0.4661,x:211.35,y:88.25},0).wait(1).to({scaleX:0.4604,scaleY:0.4604,x:211.5,y:87.8},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:211.7,y:87.4},0).wait(1).to({scaleX:0.4511,scaleY:0.4511,x:211.8,y:87.05},0).wait(1).to({scaleX:0.4473,scaleY:0.4473,x:211.9,y:86.75},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:212.05,y:86.5},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:212.1,y:86.3},0).wait(1).to({scaleX:0.4382,scaleY:0.4382,x:212.2,y:86},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:212.25,y:85.85},0).wait(1).to({scaleX:0.4337,scaleY:0.4337,x:212.3,y:85.65},0).wait(1).to({scaleX:0.4318,scaleY:0.4318,x:212.35,y:85.55},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:212.4,y:85.4},0).wait(1).to({scaleX:0.4286,scaleY:0.4286,x:212.5,y:85.25},0).wait(1).to({scaleX:0.4272,scaleY:0.4272,x:212.55,y:85.2},0).wait(1).to({scaleX:0.426,scaleY:0.426,y:85.05},0).wait(1).to({scaleX:0.4249,scaleY:0.4249,x:212.6,y:85},0).wait(1).to({scaleX:0.424,scaleY:0.424,y:84.9},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,x:212.65,y:84.85},0).wait(1).to({scaleX:0.4225,scaleY:0.4225,y:84.8},0).wait(1).to({scaleX:0.4219,scaleY:0.4219,x:212.7,y:84.75},0).wait(1).to({scaleX:0.4214,scaleY:0.4214,y:84.7},0).wait(1).to({scaleX:0.421,scaleY:0.421,x:212.75},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:212.7,y:84.65},0).wait(1).to({scaleX:0.4204,scaleY:0.4204},0).wait(1).to({scaleX:0.4203,scaleY:0.4203},0).wait(1).to({scaleX:0.4202,scaleY:0.4202},0).wait(1).to({regX:26.6,regY:21.6,scaleX:0.4201,scaleY:0.4201,x:212.95,y:84.7},0).wait(1));

	// guy left icon.png
	this.instance_1 = new lib.guylefticon_1();
	this.instance_1.setTransform(-84.7,115.9,1,1,0,0,0,25.9,20.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({x:59.55,y:57,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:26,regY:20.5,x:59.65,y:57.1},0).wait(12).to({regX:25.9,regY:20.4,x:59.55,y:57},0).wait(1).to({regX:26,regY:20.5,scaleX:0.995,scaleY:0.995,x:60.85,y:57.8},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:62.3,y:58.6},0).wait(1).to({scaleX:0.9834,scaleY:0.9834,x:63.75,y:59.45},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:65.35,y:60.4},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:67.05,y:61.4},0).wait(1).to({scaleX:0.9626,scaleY:0.9626,x:68.95,y:62.45},0).wait(1).to({scaleX:0.9547,scaleY:0.9547,x:70.9,y:63.55},0).wait(1).to({scaleX:0.9464,scaleY:0.9464,x:73,y:64.75},0).wait(1).to({scaleX:0.9375,scaleY:0.9375,x:75.2,y:66},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:77.5,y:67.4},0).wait(1).to({scaleX:0.9185,scaleY:0.9185,x:79.95,y:68.8},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:82.4,y:70.2},0).wait(1).to({scaleX:0.8978,scaleY:0.8978,x:85.05,y:71.75},0).wait(1).to({scaleX:0.8869,scaleY:0.8869,x:87.8,y:73.35},0).wait(1).to({scaleX:0.8755,scaleY:0.8755,x:90.6,y:74.95},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:93.5,y:76.6},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:96.5,y:78.3},0).wait(1).to({scaleX:0.8396,scaleY:0.8396,x:99.6,y:80.1},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,x:102.7,y:81.9},0).wait(1).to({scaleX:0.8143,scaleY:0.8143,x:105.85,y:83.7},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,x:109.1,y:85.6},0).wait(1).to({scaleX:0.7884,scaleY:0.7884,x:112.3,y:87.4},0).wait(1).to({scaleX:0.7753,scaleY:0.7753,x:115.55,y:89.3},0).wait(1).to({scaleX:0.7621,scaleY:0.7621,x:118.85,y:91.2},0).wait(1).to({scaleX:0.749,scaleY:0.749,x:122.1,y:93.1},0).wait(1).to({scaleX:0.7359,scaleY:0.7359,x:125.4,y:94.95},0).wait(1).to({scaleX:0.723,scaleY:0.723,x:128.6,y:96.8},0).wait(1).to({scaleX:0.7101,scaleY:0.7101,x:131.8,y:98.65},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:134.95,y:100.5},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:138.05,y:102.25},0).wait(1).to({scaleX:0.6729,scaleY:0.6729,x:141.05,y:104},0).wait(1).to({scaleX:0.661,scaleY:0.661,x:144.05,y:105.7},0).wait(1).to({scaleX:0.6495,scaleY:0.6495,x:146.9,y:107.35},0).wait(1).to({scaleX:0.6384,scaleY:0.6384,x:149.65,y:108.95},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:152.35,y:110.5},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:154.95,y:112},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:157.45,y:113.4},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:159.8,y:114.8},0).wait(1).to({scaleX:0.5887,scaleY:0.5887,x:162.05,y:116.05},0).wait(1).to({scaleX:0.5801,scaleY:0.5801,x:164.2,y:117.35},0).wait(1).to({scaleX:0.5719,scaleY:0.5719,x:166.2,y:118.45},0).wait(1).to({scaleX:0.5643,scaleY:0.5643,x:168.1,y:119.55},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:169.9,y:120.6},0).wait(1).to({scaleX:0.5504,scaleY:0.5504,x:171.55,y:121.6},0).wait(1).to({scaleX:0.5442,scaleY:0.5442,x:173.1,y:122.45},0).wait(1).to({scaleX:0.5385,scaleY:0.5385,x:174.55,y:123.3},0).wait(1).to({scaleX:0.5332,scaleY:0.5332,x:175.85,y:124.05},0).wait(1).to({scaleX:0.5284,scaleY:0.5284,x:177.05,y:124.75},0).wait(1).to({scaleX:0.524,scaleY:0.524,x:178.1,y:125.35},0).wait(1).to({scaleX:0.5201,scaleY:0.5201,x:179.1,y:125.9},0).wait(1).to({scaleX:0.5167,scaleY:0.5167,x:180,y:126.4},0).wait(1).to({scaleX:0.5137,scaleY:0.5137,x:180.7,y:126.85},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:181.35,y:127.25},0).wait(1).to({scaleX:0.5089,scaleY:0.5089,x:181.9,y:127.55},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:182.35,y:127.8},0).wait(1).to({scaleX:0.5058,scaleY:0.5058,x:182.65,y:127.95},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:182.9,y:128.1},0).wait(1).to({scaleX:0.5043,scaleY:0.5043,x:183.05,y:128.2},0).wait(1).to({regX:26.2,regY:20.7,scaleX:0.5042,scaleY:0.5042,y:128.25},0).wait(1).to({regX:26,regY:20.5,x:182.95,y:128.15},0).wait(15).to({regX:26.2,regY:20.7,x:183.05,y:128.25},0).wait(1).to({regX:26,regY:20.5,scaleX:0.5041,scaleY:0.5041,x:182.9,y:128.1},0).wait(1).to({scaleX:0.504,scaleY:0.504,x:182.85},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,x:182.8,y:128.05},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,x:182.75,y:128},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:182.65,y:127.9},0).wait(1).to({scaleX:0.5034,scaleY:0.5034,x:182.55,y:127.85},0).wait(1).to({scaleX:0.5032,scaleY:0.5032,x:182.4,y:127.75},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:182.25,y:127.65},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:182,y:127.5},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:181.75,y:127.35},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:181.5,y:127.2},0).wait(1).to({scaleX:0.5011,scaleY:0.5011,x:181.2,y:126.95},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:180.8,y:126.75},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:180.4,y:126.5},0).wait(1).to({scaleX:0.4989,scaleY:0.4989,x:179.9,y:126.2},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:179.35,y:125.8},0).wait(1).to({scaleX:0.4968,scaleY:0.4968,x:178.65,y:125.35},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:177.9,y:124.85},0).wait(1).to({scaleX:0.4938,scaleY:0.4938,x:176.95,y:124.25},0).wait(1).to({scaleX:0.4918,scaleY:0.4918,x:175.85,y:123.55},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:174.4,y:122.65},0).wait(1).to({scaleX:0.4864,scaleY:0.4864,x:172.7,y:121.5},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:170.45,y:120.05},0).wait(1).to({scaleX:0.4776,scaleY:0.4776,x:167.6,y:118.2},0).wait(1).to({scaleX:0.4718,scaleY:0.4718,x:164.3,y:116.05},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:161.15,y:114.05},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:158.55,y:112.35},0).wait(1).to({scaleX:0.4584,scaleY:0.4584,x:156.55,y:111.1},0).wait(1).to({scaleX:0.4557,scaleY:0.4557,x:154.95,y:110.05},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:153.7,y:109.2},0).wait(1).to({scaleX:0.4516,scaleY:0.4516,x:152.6,y:108.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:151.7,y:107.9},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:150.9,y:107.45},0).wait(1).to({scaleX:0.4475,scaleY:0.4475,x:150.3,y:107},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:149.7,y:106.65},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:149.2,y:106.35},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:148.75,y:106.05},0).wait(1).to({scaleX:0.4443,scaleY:0.4443,x:148.35,y:105.8},0).wait(1).to({scaleX:0.4437,scaleY:0.4437,x:148.05,y:105.6},0).wait(1).to({scaleX:0.4432,scaleY:0.4432,x:147.7,y:105.4},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:147.5,y:105.25},0).wait(1).to({scaleX:0.4423,scaleY:0.4423,x:147.25,y:105.05},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:147.1,y:104.95},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:146.9,y:104.85},0).wait(1).to({scaleX:0.4415,scaleY:0.4415,x:146.8,y:104.75},0).wait(1).to({scaleX:0.4412,scaleY:0.4412,x:146.6,y:104.7},0).wait(1).to({scaleX:0.4411,scaleY:0.4411,x:146.5,y:104.6},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:146.45,y:104.55},0).wait(1).to({scaleX:0.4408,scaleY:0.4408,x:146.4},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:146.35,y:104.5},0).wait(1).to({x:146.3},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,y:104.45},0).wait(1).to({regX:26.2,regY:20.8,x:146.4,y:104.55},0).wait(8));

	// girl right icon.png
	this.instance_2 = new lib.girlrighticon_1();
	this.instance_2.setTransform(212.4,302.25,1,1,0,0,0,25.9,21.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({x:154.7,y:299.55,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:26,x:154.8},0).wait(16).to({regX:25.9,x:154.7},0).wait(1).to({regX:26,scaleX:0.9965,scaleY:0.9965,x:155.15,y:298.3},0).wait(1).to({scaleX:0.9927,scaleY:0.9927,x:155.6,y:297.05},0).wait(1).to({scaleX:0.9885,scaleY:0.9885,x:156.05,y:295.65},0).wait(1).to({scaleX:0.984,scaleY:0.984,x:156.55,y:294.15},0).wait(1).to({scaleX:0.9792,scaleY:0.9792,x:157.05,y:292.55},0).wait(1).to({scaleX:0.9741,scaleY:0.9741,x:157.7,y:290.8},0).wait(1).to({scaleX:0.9686,scaleY:0.9686,x:158.3,y:288.95},0).wait(1).to({scaleX:0.9628,scaleY:0.9628,x:158.9,y:287.05},0).wait(1).to({scaleX:0.9567,scaleY:0.9567,x:159.55,y:284.95},0).wait(1).to({scaleX:0.9502,scaleY:0.9502,x:160.3,y:282.85},0).wait(1).to({scaleX:0.9435,scaleY:0.9435,x:161.05,y:280.55},0).wait(1).to({scaleX:0.9364,scaleY:0.9364,x:161.85,y:278.2},0).wait(1).to({scaleX:0.9291,scaleY:0.9291,x:162.65,y:275.75},0).wait(1).to({scaleX:0.9215,scaleY:0.9215,x:163.5,y:273.15},0).wait(1).to({scaleX:0.9136,scaleY:0.9136,x:164.35,y:270.55},0).wait(1).to({scaleX:0.9055,scaleY:0.9055,x:165.25,y:267.8},0).wait(1).to({scaleX:0.8972,scaleY:0.8972,x:166.2,y:265},0).wait(1).to({scaleX:0.8887,scaleY:0.8887,x:167.1,y:262.15},0).wait(1).to({scaleX:0.88,scaleY:0.88,x:168.1,y:259.2},0).wait(1).to({scaleX:0.8711,scaleY:0.8711,x:169.05,y:256.3},0).wait(1).to({scaleX:0.8622,scaleY:0.8622,x:170.05,y:253.25},0).wait(1).to({scaleX:0.8531,scaleY:0.8531,x:171.1,y:250.25},0).wait(1).to({scaleX:0.844,scaleY:0.844,x:172.1,y:247.15},0).wait(1).to({scaleX:0.8349,scaleY:0.8349,x:173.1,y:244.1},0).wait(1).to({scaleX:0.8258,scaleY:0.8258,x:174.05,y:241.05},0).wait(1).to({scaleX:0.8167,scaleY:0.8167,x:175.1,y:238},0).wait(1).to({scaleX:0.8077,scaleY:0.8077,x:176.1,y:234.95},0).wait(1).to({scaleX:0.7988,scaleY:0.7988,x:177.05,y:231.95},0).wait(1).to({scaleX:0.79,scaleY:0.79,x:178.05,y:229.05},0).wait(1).to({scaleX:0.7814,scaleY:0.7814,x:179,y:226.15},0).wait(1).to({scaleX:0.773,scaleY:0.773,x:179.95,y:223.3},0).wait(1).to({scaleX:0.7647,scaleY:0.7647,x:180.9,y:220.55},0).wait(1).to({scaleX:0.7567,scaleY:0.7567,x:181.75,y:217.85},0).wait(1).to({scaleX:0.749,scaleY:0.749,x:182.6,y:215.25},0).wait(1).to({scaleX:0.7415,scaleY:0.7415,x:183.45,y:212.75},0).wait(1).to({scaleX:0.7343,scaleY:0.7343,x:184.25,y:210.35},0).wait(1).to({scaleX:0.7274,scaleY:0.7274,x:185,y:208},0).wait(1).to({scaleX:0.7208,scaleY:0.7208,x:185.75,y:205.8},0).wait(1).to({scaleX:0.7145,scaleY:0.7145,x:186.45,y:203.65},0).wait(1).to({scaleX:0.7085,scaleY:0.7085,x:187.05,y:201.7},0).wait(1).to({scaleX:0.7029,scaleY:0.7029,x:187.75,y:199.75},0).wait(1).to({scaleX:0.6976,scaleY:0.6976,x:188.3,y:198},0).wait(1).to({scaleX:0.6926,scaleY:0.6926,x:188.85,y:196.35},0).wait(1).to({scaleX:0.688,scaleY:0.688,x:189.4,y:194.8},0).wait(1).to({scaleX:0.6836,scaleY:0.6836,x:189.85,y:193.3},0).wait(1).to({scaleX:0.6797,scaleY:0.6797,x:190.3,y:191.95},0).wait(1).to({scaleX:0.676,scaleY:0.676,x:190.75,y:190.75},0).wait(1).to({scaleX:0.6727,scaleY:0.6727,x:191.1,y:189.6},0).wait(1).to({scaleX:0.6696,scaleY:0.6696,x:191.4,y:188.6},0).wait(1).to({scaleX:0.6669,scaleY:0.6669,x:191.7,y:187.7},0).wait(1).to({scaleX:0.6645,scaleY:0.6645,x:192,y:186.9},0).wait(1).to({scaleX:0.6624,scaleY:0.6624,x:192.2,y:186.2},0).wait(1).to({scaleX:0.6607,scaleY:0.6607,x:192.45,y:185.6},0).wait(1).to({scaleX:0.6592,scaleY:0.6592,x:192.6,y:185.1},0).wait(1).to({scaleX:0.6579,scaleY:0.6579,x:192.7,y:184.7},0).wait(1).to({scaleX:0.657,scaleY:0.657,x:192.85,y:184.4},0).wait(1).to({scaleX:0.6564,scaleY:0.6564,y:184.15},0).wait(1).to({scaleX:0.656,scaleY:0.656,x:192.9,y:184.05},0).wait(1).to({regX:26.2,regY:21.8,scaleX:0.6558,scaleY:0.6558,x:192.95},0).wait(1).to({regX:26,regY:21.5,x:192.8,y:183.85},0).wait(15).to({regX:26.2,regY:21.8,x:192.95,y:184.05},0).wait(1).to({regX:26,regY:21.5,scaleX:0.6557,scaleY:0.6557,x:192.75,y:183.8},0).wait(1).to({scaleX:0.6555,scaleY:0.6555,y:183.7},0).wait(1).to({scaleX:0.6552,scaleY:0.6552,y:183.6},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:192.7,y:183.5},0).wait(1).to({scaleX:0.6543,scaleY:0.6543,x:192.6,y:183.25},0).wait(1).to({scaleX:0.6537,scaleY:0.6537,x:192.55,y:183.05},0).wait(1).to({scaleX:0.6529,scaleY:0.6529,x:192.5,y:182.8},0).wait(1).to({scaleX:0.652,scaleY:0.652,x:192.4,y:182.45},0).wait(1).to({scaleX:0.651,scaleY:0.651,x:192.3,y:182.1},0).wait(1).to({scaleX:0.6498,scaleY:0.6498,x:192.15,y:181.6},0).wait(1).to({scaleX:0.6484,scaleY:0.6484,x:192,y:181.15},0).wait(1).to({scaleX:0.6468,scaleY:0.6468,x:191.85,y:180.55},0).wait(1).to({scaleX:0.6449,scaleY:0.6449,x:191.65,y:179.85},0).wait(1).to({scaleX:0.6428,scaleY:0.6428,x:191.45,y:179.1},0).wait(1).to({scaleX:0.6404,scaleY:0.6404,x:191.2,y:178.25},0).wait(1).to({scaleX:0.6376,scaleY:0.6376,x:190.95,y:177.25},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:190.65,y:176.15},0).wait(1).to({scaleX:0.6309,scaleY:0.6309,x:190.25,y:174.8},0).wait(1).to({scaleX:0.6267,scaleY:0.6267,x:189.85,y:173.3},0).wait(1).to({scaleX:0.6218,scaleY:0.6218,x:189.35,y:171.55},0).wait(1).to({scaleX:0.6161,scaleY:0.6161,x:188.75,y:169.5},0).wait(1).to({scaleX:0.6092,scaleY:0.6092,x:188.1,y:167},0).wait(1).to({scaleX:0.601,scaleY:0.601,x:187.25,y:164},0).wait(1).to({scaleX:0.5908,scaleY:0.5908,x:186.2,y:160.35},0).wait(1).to({scaleX:0.5781,scaleY:0.5781,x:184.95,y:155.8},0).wait(1).to({scaleX:0.562,scaleY:0.562,x:183.3,y:150},0).wait(1).to({scaleX:0.5429,scaleY:0.5429,x:181.35,y:143.05},0).wait(1).to({scaleX:0.5232,scaleY:0.5232,x:179.4,y:136},0).wait(1).to({scaleX:0.506,scaleY:0.506,x:177.65,y:129.8},0).wait(1).to({scaleX:0.4922,scaleY:0.4922,x:176.25,y:124.8},0).wait(1).to({scaleX:0.481,scaleY:0.481,x:175.15,y:120.8},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:174.2,y:117.5},0).wait(1).to({scaleX:0.4645,scaleY:0.4645,x:173.5,y:114.8},0).wait(1).to({scaleX:0.4582,scaleY:0.4582,x:172.85,y:112.55},0).wait(1).to({scaleX:0.4528,scaleY:0.4528,x:172.3,y:110.6},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:171.85,y:108.95},0).wait(1).to({scaleX:0.4441,scaleY:0.4441,x:171.45,y:107.45},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,x:171.05,y:106.15},0).wait(1).to({scaleX:0.4374,scaleY:0.4374,x:170.75,y:105.05},0).wait(1).to({scaleX:0.4347,scaleY:0.4347,x:170.45,y:104.05},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:170.25,y:103.2},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:170.05,y:102.4},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:169.85,y:101.7},0).wait(1).to({scaleX:0.4265,scaleY:0.4265,x:169.65,y:101.05},0).wait(1).to({scaleX:0.425,scaleY:0.425,x:169.5,y:100.55},0).wait(1).to({scaleX:0.4236,scaleY:0.4236,x:169.35,y:100.05},0).wait(1).to({scaleX:0.4225,scaleY:0.4225,x:169.25,y:99.65},0).wait(1).to({scaleX:0.4215,scaleY:0.4215,x:169.15,y:99.25},0).wait(1).to({scaleX:0.4206,scaleY:0.4206,x:169.05,y:98.95},0).wait(1).to({scaleX:0.4198,scaleY:0.4198,x:168.95,y:98.7},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:168.9,y:98.45},0).wait(1).to({scaleX:0.4186,scaleY:0.4186,x:168.85,y:98.25},0).wait(1).to({scaleX:0.4182,scaleY:0.4182,x:168.8,y:98.1},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,x:168.75,y:98},0).wait(1).to({scaleX:0.4176,scaleY:0.4176,y:97.9},0).wait(1).to({scaleX:0.4174,scaleY:0.4174,y:97.8},0).wait(1).to({scaleX:0.4173,scaleY:0.4173,x:168.7,y:97.75},0).wait(1).to({regX:26.2,regY:21.8,x:168.8,y:97.9},0).wait(1));

	// girl left icon.png
	this.instance_3 = new lib.girllefticon_1();
	this.instance_3.setTransform(-95.95,220,1,1,0,0,0,25.3,21.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({x:70.85,y:227.5,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:25.5,regY:21.5,x:71.05,y:227.7},0).wait(19).to({regX:25.3,regY:21.3,x:70.85,y:227.5},0).wait(1).to({regX:25.5,regY:21.5,scaleX:0.995,scaleY:0.995,x:72.15,y:226.9},0).wait(1).to({scaleX:0.9895,scaleY:0.9895,x:73.45,y:226.05},0).wait(1).to({scaleX:0.9835,scaleY:0.9835,x:74.85,y:225.15},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:76.3,y:224.15},0).wait(1).to({scaleX:0.9701,scaleY:0.9701,x:77.9,y:223.1},0).wait(1).to({scaleX:0.9627,scaleY:0.9627,x:79.6,y:221.95},0).wait(1).to({scaleX:0.9548,scaleY:0.9548,x:81.4,y:220.8},0).wait(1).to({scaleX:0.9465,scaleY:0.9465,x:83.3,y:219.5},0).wait(1).to({scaleX:0.9377,scaleY:0.9377,x:85.3,y:218.15},0).wait(1).to({scaleX:0.9285,scaleY:0.9285,x:87.5,y:216.7},0).wait(1).to({scaleX:0.9188,scaleY:0.9188,x:89.7,y:215.25},0).wait(1).to({scaleX:0.9086,scaleY:0.9086,x:92,y:213.7},0).wait(1).to({scaleX:0.8981,scaleY:0.8981,x:94.4,y:212.05},0).wait(1).to({scaleX:0.8872,scaleY:0.8872,x:96.9,y:210.4},0).wait(1).to({scaleX:0.8759,scaleY:0.8759,x:99.55,y:208.7},0).wait(1).to({scaleX:0.8642,scaleY:0.8642,x:102.2,y:206.9},0).wait(1).to({scaleX:0.8523,scaleY:0.8523,x:104.95,y:205.05},0).wait(1).to({scaleX:0.84,scaleY:0.84,x:107.75,y:203.15},0).wait(1).to({scaleX:0.8275,scaleY:0.8275,x:110.6,y:201.3},0).wait(1).to({scaleX:0.8148,scaleY:0.8148,x:113.55,y:199.3},0).wait(1).to({scaleX:0.802,scaleY:0.802,x:116.5,y:197.35},0).wait(1).to({scaleX:0.789,scaleY:0.789,x:119.45,y:195.35},0).wait(1).to({scaleX:0.7759,scaleY:0.7759,x:122.5,y:193.4},0).wait(1).to({scaleX:0.7628,scaleY:0.7628,x:125.5,y:191.35},0).wait(1).to({scaleX:0.7497,scaleY:0.7497,x:128.5,y:189.35},0).wait(1).to({scaleX:0.7367,scaleY:0.7367,x:131.5,y:187.35},0).wait(1).to({scaleX:0.7237,scaleY:0.7237,x:134.45,y:185.35},0).wait(1).to({scaleX:0.7109,scaleY:0.7109,x:137.4,y:183.45},0).wait(1).to({scaleX:0.6983,scaleY:0.6983,x:140.3,y:181.45},0).wait(1).to({scaleX:0.6859,scaleY:0.6859,x:143.15,y:179.6},0).wait(1).to({scaleX:0.6738,scaleY:0.6738,x:145.95,y:177.75},0).wait(1).to({scaleX:0.662,scaleY:0.662,x:148.65,y:175.95},0).wait(1).to({scaleX:0.6505,scaleY:0.6505,x:151.3,y:174.2},0).wait(1).to({scaleX:0.6394,scaleY:0.6394,x:153.85,y:172.45},0).wait(1).to({scaleX:0.6286,scaleY:0.6286,x:156.35,y:170.8},0).wait(1).to({scaleX:0.6183,scaleY:0.6183,x:158.65,y:169.25},0).wait(1).to({scaleX:0.6083,scaleY:0.6083,x:160.95,y:167.75},0).wait(1).to({scaleX:0.5988,scaleY:0.5988,x:163.1,y:166.25},0).wait(1).to({scaleX:0.5898,scaleY:0.5898,x:165.2,y:164.9},0).wait(1).to({scaleX:0.5812,scaleY:0.5812,x:167.15,y:163.55},0).wait(1).to({scaleX:0.5731,scaleY:0.5731,x:169.05,y:162.3},0).wait(1).to({scaleX:0.5655,scaleY:0.5655,x:170.75,y:161.15},0).wait(1).to({scaleX:0.5583,scaleY:0.5583,x:172.45,y:160.05},0).wait(1).to({scaleX:0.5517,scaleY:0.5517,x:173.95,y:159},0).wait(1).to({scaleX:0.5455,scaleY:0.5455,x:175.4,y:158.1},0).wait(1).to({scaleX:0.5397,scaleY:0.5397,x:176.7,y:157.2},0).wait(1).to({scaleX:0.5345,scaleY:0.5345,x:177.95,y:156.4},0).wait(1).to({scaleX:0.5297,scaleY:0.5297,x:179,y:155.7},0).wait(1).to({scaleX:0.5253,scaleY:0.5253,x:180,y:155},0).wait(1).to({scaleX:0.5215,scaleY:0.5215,x:180.9,y:154.4},0).wait(1).to({scaleX:0.518,scaleY:0.518,x:181.7,y:153.9},0).wait(1).to({scaleX:0.515,scaleY:0.515,x:182.4,y:153.4},0).wait(1).to({scaleX:0.5124,scaleY:0.5124,x:182.95,y:153},0).wait(1).to({scaleX:0.5103,scaleY:0.5103,x:183.45,y:152.7},0).wait(1).to({scaleX:0.5086,scaleY:0.5086,x:183.85,y:152.45},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:184.2,y:152.2},0).wait(1).to({scaleX:0.5063,scaleY:0.5063,x:184.4,y:152.1},0).wait(1).to({scaleX:0.5057,scaleY:0.5057,x:184.55,y:152},0).wait(1).to({regX:25.3,regY:21.6,scaleX:0.5055,scaleY:0.5055,x:184.5,y:151.9},0).wait(1).to({regX:25.5,regY:21.5,x:184.6,y:151.85},0).wait(15).to({regX:25.3,regY:21.6,x:184.5,y:151.9},0).wait(1).to({regX:25.5,regY:21.5,x:184.6,y:151.8},0).wait(1).to({scaleX:0.5054,scaleY:0.5054,y:151.75},0).wait(1).to({scaleX:0.5053,scaleY:0.5053,y:151.65},0).wait(1).to({scaleX:0.5051,scaleY:0.5051,y:151.55},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:184.65,y:151.4},0).wait(1).to({scaleX:0.5047,scaleY:0.5047,x:184.6,y:151.25},0).wait(1).to({scaleX:0.5044,scaleY:0.5044,x:184.65,y:151.05},0).wait(1).to({scaleX:0.504,scaleY:0.504,y:150.8},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:184.7,y:150.55},0).wait(1).to({scaleX:0.5031,scaleY:0.5031,x:184.75,y:150.15},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,y:149.8},0).wait(1).to({scaleX:0.5019,scaleY:0.5019,x:184.8,y:149.35},0).wait(1).to({scaleX:0.5012,scaleY:0.5012,x:184.9,y:148.85},0).wait(1).to({scaleX:0.5003,scaleY:0.5003,x:184.95,y:148.2},0).wait(1).to({scaleX:0.4994,scaleY:0.4994,x:185,y:147.55},0).wait(1).to({scaleX:0.4983,scaleY:0.4983,x:185.1,y:146.75},0).wait(1).to({scaleX:0.497,scaleY:0.497,x:185.15,y:145.9},0).wait(1).to({scaleX:0.4955,scaleY:0.4955,x:185.3,y:144.8},0).wait(1).to({scaleX:0.4937,scaleY:0.4937,x:185.4,y:143.6},0).wait(1).to({scaleX:0.4917,scaleY:0.4917,x:185.55,y:142.15},0).wait(1).to({scaleX:0.4892,scaleY:0.4892,x:185.7,y:140.45},0).wait(1).to({scaleX:0.4862,scaleY:0.4862,x:185.95,y:138.35},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:186.2,y:135.75},0).wait(1).to({scaleX:0.4779,scaleY:0.4779,x:186.55,y:132.55},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:186.95,y:128.45},0).wait(1).to({scaleX:0.4649,scaleY:0.4649,x:187.45,y:123.45},0).wait(1).to({scaleX:0.4575,scaleY:0.4575,x:188,y:118.3},0).wait(1).to({scaleX:0.451,scaleY:0.451,x:188.45,y:113.75},0).wait(1).to({scaleX:0.4458,scaleY:0.4458,x:188.8,y:110.1},0).wait(1).to({scaleX:0.4416,scaleY:0.4416,x:189.1,y:107.2},0).wait(1).to({scaleX:0.4383,scaleY:0.4383,x:189.4,y:104.85},0).wait(1).to({scaleX:0.4355,scaleY:0.4355,x:189.55,y:102.95},0).wait(1).to({scaleX:0.4332,scaleY:0.4332,x:189.75,y:101.3},0).wait(1).to({scaleX:0.4312,scaleY:0.4312,x:189.85,y:99.95},0).wait(1).to({scaleX:0.4295,scaleY:0.4295,x:190,y:98.8},0).wait(1).to({scaleX:0.4281,scaleY:0.4281,x:190.1,y:97.75},0).wait(1).to({scaleX:0.4268,scaleY:0.4268,x:190.2,y:96.85},0).wait(1).to({scaleX:0.4257,scaleY:0.4257,x:190.25,y:96.05},0).wait(1).to({scaleX:0.4247,scaleY:0.4247,x:190.35,y:95.4},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:190.4,y:94.75},0).wait(1).to({scaleX:0.423,scaleY:0.423,x:190.45,y:94.25},0).wait(1).to({scaleX:0.4223,scaleY:0.4223,x:190.5,y:93.75},0).wait(1).to({scaleX:0.4217,scaleY:0.4217,x:190.55,y:93.3},0).wait(1).to({scaleX:0.4212,scaleY:0.4212,x:190.6,y:92.95},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:190.65,y:92.65},0).wait(1).to({scaleX:0.4203,scaleY:0.4203,y:92.35},0).wait(1).to({scaleX:0.42,scaleY:0.42,y:92.15},0).wait(1).to({scaleX:0.4197,scaleY:0.4197,x:190.7,y:91.9},0).wait(1).to({scaleX:0.4194,scaleY:0.4194,y:91.7},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:190.75,y:91.55},0).wait(1).to({scaleX:0.4191,scaleY:0.4191,y:91.45},0).wait(1).to({scaleX:0.4189,scaleY:0.4189,y:91.35},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,x:190.8,y:91.3},0).wait(1).to({scaleX:0.4187,scaleY:0.4187,y:91.25},0).wait(1).to({y:91.2},0).wait(1).to({regX:25.4,regY:21.6,x:190.7,y:91.25},0).wait(2));

	// guy right contribution
	this.instance_4 = new lib.guyrightcontribution_1();
	this.instance_4.setTransform(264.05,-17.4,1,1,0,0,0,38.1,26.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).to({x:222.85,y:82.45,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:37.7,regY:26,x:222.45,y:82.25},0).wait(11).to({regX:38.1,regY:26.2,x:222.85,y:82.45},0).wait(1).to({regX:37.7,regY:26,scaleX:0.9963,scaleY:0.9958,x:222.45,y:82.55},0).wait(1).to({scaleX:0.9922,scaleY:0.9911,skewY:-0.0571,x:222.5,y:82.85},0).wait(1).to({scaleX:0.9878,scaleY:0.9861,skewY:-0.0894,x:222.55,y:83.25},0).wait(1).to({scaleX:0.9831,scaleY:0.9806,skewY:-0.1243,y:83.6},0).wait(1).to({scaleX:0.978,scaleY:0.9748,skewY:-0.1617,x:222.6,y:84.05},0).wait(1).to({scaleX:0.9726,scaleY:0.9686,skewY:-0.2017,x:222.65,y:84.5},0).wait(1).to({scaleX:0.9668,scaleY:0.9619,skewY:-0.2443,x:222.75,y:85},0).wait(1).to({scaleX:0.9607,scaleY:0.9549,skewY:-0.2893,y:85.5},0).wait(1).to({scaleX:0.9542,scaleY:0.9475,skewY:-0.3369,x:222.85,y:86.05},0).wait(1).to({scaleX:0.9474,scaleY:0.9397,skewY:-0.3869,x:222.9,y:86.6},0).wait(1).to({scaleX:0.9402,scaleY:0.9315,skewY:-0.4394,x:223,y:87.2},0).wait(1).to({scaleX:0.9328,scaleY:0.923,skewY:-0.4941,x:223.05,y:87.8},0).wait(1).to({scaleX:0.925,scaleY:0.9141,skewY:-0.5511,x:223.1,y:88.4},0).wait(1).to({scaleX:0.917,scaleY:0.9049,skewY:-0.6102,x:223.15,y:89.15},0).wait(1).to({scaleX:0.9087,scaleY:0.8953,skewY:-0.6714,x:223.25,y:89.8},0).wait(1).to({scaleX:0.9001,scaleY:0.8855,skewY:-0.7343,x:223.35,y:90.45},0).wait(1).to({scaleX:0.8913,scaleY:0.8754,skewY:-0.799,x:223.45,y:91.25},0).wait(1).to({scaleX:0.8823,scaleY:0.8651,skewY:-0.8652,x:223.5,y:92},0).wait(1).to({scaleX:0.8731,scaleY:0.8546,skewY:-0.9328,x:223.6,y:92.7},0).wait(1).to({scaleX:0.8637,scaleY:0.8439,skewY:-1.0015,x:223.65,y:93.55},0).wait(1).to({scaleX:0.8543,scaleY:0.833,skewY:-1.071,x:223.75,y:94.3},0).wait(1).to({scaleX:0.8447,scaleY:0.8221,skewY:-1.1413,x:223.85,y:95.05},0).wait(1).to({scaleX:0.8351,scaleY:0.811,skewY:-1.212,x:223.95,y:95.95},0).wait(1).to({scaleX:0.8254,scaleY:0.8,skewY:-1.2829,x:224,y:96.7},0).wait(1).to({scaleX:0.8158,scaleY:0.7889,skewY:-1.3537,x:224.1,y:97.45},0).wait(1).to({scaleX:0.8062,scaleY:0.7779,skewY:-1.4243,x:224.2,y:98.35},0).wait(1).to({scaleX:0.7967,scaleY:0.767,skewY:-1.4942,x:224.25,y:99.1},0).wait(1).to({scaleX:0.7873,scaleY:0.7562,skewY:-1.5635,x:224.35,y:99.85},0).wait(1).to({scaleX:0.778,scaleY:0.7456,skewY:-1.6317,x:224.45,y:100.65},0).wait(1).to({scaleX:0.7688,scaleY:0.7352,skewY:-1.6986,x:224.55,y:101.4},0).wait(1).to({scaleX:0.7599,scaleY:0.7249,skewY:-1.7642,x:224.65,y:102.1},0).wait(1).to({scaleX:0.7512,scaleY:0.715,skewY:-1.8281,x:224.7,y:102.85},0).wait(1).to({scaleX:0.7428,scaleY:0.7053,skewY:-1.8903,x:224.8,y:103.6},0).wait(1).to({scaleX:0.7346,scaleY:0.6959,skewY:-1.9505,x:224.9,y:104.25},0).wait(1).to({scaleX:0.7267,scaleY:0.6868,skewY:-2.0087,x:224.95,y:104.9},0).wait(1).to({scaleX:0.7191,scaleY:0.6781,skewY:-2.0646,x:225,y:105.5},0).wait(1).to({scaleX:0.7117,scaleY:0.6697,skewY:-2.1183,x:225.05,y:106.1},0).wait(1).to({scaleX:0.7048,scaleY:0.6617,skewY:-2.1696,x:225.15,y:106.7},0).wait(1).to({scaleX:0.6981,scaleY:0.6541,skewY:-2.2185,x:225.2,y:107.25},0).wait(1).to({scaleX:0.6918,scaleY:0.6469,skewY:-2.2648,x:225.25,y:107.75},0).wait(1).to({scaleX:0.6858,scaleY:0.64,skewY:-2.3087,x:225.35,y:108.3},0).wait(1).to({scaleX:0.6802,scaleY:0.6336,skewY:-2.35,y:108.7},0).wait(1).to({scaleX:0.675,scaleY:0.6276,skewY:-2.3886,x:225.4,y:109.15},0).wait(1).to({scaleX:0.67,scaleY:0.6219,skewY:-2.4248,x:225.45,y:109.6},0).wait(1).to({scaleX:0.6655,scaleY:0.6167,skewY:-2.4583,x:225.5,y:109.95},0).wait(1).to({scaleX:0.6613,scaleY:0.6119,skewY:-2.4893,x:225.55,y:110.3},0).wait(1).to({scaleX:0.6574,scaleY:0.6074,skewY:-2.5178,y:110.65},0).wait(1).to({scaleX:0.6538,scaleY:0.6034,skewY:-2.5437,x:225.65,y:110.95},0).wait(1).to({scaleX:0.6507,scaleY:0.5997,skewY:-2.5671,y:111.2},0).wait(1).to({scaleX:0.6478,scaleY:0.5965,skewY:-2.5881,y:111.4},0).wait(1).to({scaleX:0.6453,scaleY:0.5936,skewY:-2.6067,x:225.7,y:111.65},0).wait(1).to({scaleX:0.6431,scaleY:0.591,skewY:-2.623,y:111.8},0).wait(1).to({scaleX:0.6412,scaleY:0.5889,skewY:-2.6369,x:225.75,y:112},0).wait(1).to({scaleX:0.6396,scaleY:0.587,skewY:-2.6485,y:112.1},0).wait(1).to({scaleX:0.6383,scaleY:0.5856,skewY:-2.658,y:112.2},0).wait(1).to({scaleX:0.6373,scaleY:0.5844,skewY:-2.6652,y:112.3},0).wait(1).to({scaleX:0.6366,scaleY:0.5837,skewY:-2.6703,y:112.35},0).wait(1).to({scaleX:0.6362,scaleY:0.5832,skewY:-2.6733,y:112.4},0).wait(1).to({regX:38.4,regY:26.4,scaleX:0.6361,scaleY:0.583,skewY:-2.6743,x:226.05,y:112.5},0).wait(79));

	// guy left contribution
	this.instance_5 = new lib.guyleftcontribution_1();
	this.instance_5.setTransform(-36.35,126.65,1,1,0,0,0,30.4,9.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({x:107.9,y:67.75,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:30.5,regY:9.7,x:108,y:67.65},0).wait(12).to({regX:30.4,regY:9.8,x:107.9,y:67.75},0).wait(1).to({regX:30.5,regY:9.7,scaleX:0.9947,scaleY:0.9948,skewX:-0.08,skewY:-0.0135,x:108.9,y:68.4},0).wait(1).to({scaleX:0.989,scaleY:0.9891,skewX:-0.1674,skewY:-0.0283,x:109.9,y:69.25},0).wait(1).to({scaleX:0.9827,scaleY:0.9829,skewX:-0.2621,skewY:-0.0443,x:110.95,y:70.15},0).wait(1).to({scaleX:0.976,scaleY:0.9763,skewX:-0.3644,skewY:-0.0616,x:112.15,y:71.05},0).wait(1).to({scaleX:0.9687,scaleY:0.9691,skewX:-0.4741,skewY:-0.0802,x:113.45,y:72.1},0).wait(1).to({scaleX:0.961,scaleY:0.9615,skewX:-0.5913,skewY:-0.1,x:114.75,y:73.25},0).wait(1).to({scaleX:0.9528,scaleY:0.9533,skewX:-0.716,skewY:-0.1211,x:116.15,y:74.45},0).wait(1).to({scaleX:0.944,scaleY:0.9447,skewX:-0.8482,skewY:-0.1435,x:117.7,y:75.7},0).wait(1).to({scaleX:0.9348,scaleY:0.9356,skewX:-0.9876,skewY:-0.1671,x:119.3,y:76.95},0).wait(1).to({scaleX:0.9252,scaleY:0.926,skewX:-1.1343,skewY:-0.1919,x:121,y:78.4},0).wait(1).to({scaleX:0.915,scaleY:0.916,skewX:-1.2879,skewY:-0.2179,x:122.75,y:79.85},0).wait(1).to({scaleX:0.9044,scaleY:0.9055,skewX:-1.4484,skewY:-0.2451,x:124.6,y:81.4},0).wait(1).to({scaleX:0.8934,scaleY:0.8946,skewX:-1.6155,skewY:-0.2733,x:126.5,y:82.9},0).wait(1).to({scaleX:0.882,scaleY:0.8833,skewX:-1.7888,skewY:-0.3026,x:128.45,y:84.55},0).wait(1).to({scaleX:0.8701,scaleY:0.8716,skewX:-1.9679,skewY:-0.3329,x:130.55,y:86.3},0).wait(1).to({scaleX:0.858,scaleY:0.8596,skewX:-2.1526,skewY:-0.3642,x:132.65,y:88.05},0).wait(1).to({scaleX:0.8454,scaleY:0.8472,skewX:-2.3422,skewY:-0.3963,x:134.85,y:89.8},0).wait(1).to({scaleX:0.8326,scaleY:0.8345,skewX:-2.5363,skewY:-0.4291,x:137.05,y:91.65},0).wait(1).to({scaleX:0.8196,scaleY:0.8216,skewX:-2.7343,skewY:-0.4626,x:139.35,y:93.55},0).wait(1).to({scaleX:0.8063,scaleY:0.8085,skewX:-2.9356,skewY:-0.4966,x:141.65,y:95.5},0).wait(1).to({scaleX:0.7928,scaleY:0.7952,skewX:-3.1395,skewY:-0.5312,x:144,y:97.4},0).wait(1).to({scaleX:0.7792,scaleY:0.7818,skewX:-3.3455,skewY:-0.566,x:146.35,y:99.3},0).wait(1).to({scaleX:0.7655,scaleY:0.7682,skewX:-3.5527,skewY:-0.6011,x:148.7,y:101.3},0).wait(1).to({scaleX:0.7518,scaleY:0.7547,skewX:-3.7605,skewY:-0.6362,x:151.15,y:103.3},0).wait(1).to({scaleX:0.7381,scaleY:0.7411,skewX:-3.9682,skewY:-0.6713,x:153.45,y:105.25},0).wait(1).to({scaleX:0.7245,scaleY:0.7276,skewX:-4.1749,skewY:-0.7063,x:155.85,y:107.25},0).wait(1).to({scaleX:0.7109,scaleY:0.7142,skewX:-4.3801,skewY:-0.741,x:158.25,y:109.1},0).wait(1).to({scaleX:0.6975,scaleY:0.701,skewX:-4.583,skewY:-0.7754,x:160.5,y:111.1},0).wait(1).to({scaleX:0.6843,scaleY:0.688,skewX:-4.7829,skewY:-0.8092,x:162.8,y:112.95},0).wait(1).to({scaleX:0.6714,scaleY:0.6752,skewX:-4.9793,skewY:-0.8424,x:165.05,y:114.8},0).wait(1).to({scaleX:0.6587,scaleY:0.6626,skewX:-5.1714,skewY:-0.8749,x:167.3,y:116.65},0).wait(1).to({scaleX:0.6463,scaleY:0.6504,skewX:-5.3589,skewY:-0.9066,x:169.45,y:118.45},0).wait(1).to({scaleX:0.6343,scaleY:0.6385,skewX:-5.5411,skewY:-0.9375,x:171.55,y:120.15},0).wait(1).to({scaleX:0.6226,scaleY:0.627,skewX:-5.7176,skewY:-0.9673,x:173.55,y:121.85},0).wait(1).to({scaleX:0.6114,scaleY:0.6159,skewX:-5.8881,skewY:-0.9962,x:175.5,y:123.5},0).wait(1).to({scaleX:0.6005,scaleY:0.6052,skewX:-6.0521,skewY:-1.0239,x:177.35,y:125},0).wait(1).to({scaleX:0.5902,scaleY:0.5949,skewX:-6.2095,skewY:-1.0505,x:179.15,y:126.5},0).wait(1).to({scaleX:0.5802,scaleY:0.5851,skewX:-6.3598,skewY:-1.076,x:180.95,y:127.9},0).wait(1).to({scaleX:0.5708,scaleY:0.5757,skewX:-6.5031,skewY:-1.1002,x:182.55,y:129.25},0).wait(1).to({scaleX:0.5618,scaleY:0.5669,skewX:-6.639,skewY:-1.1232,x:184.15,y:130.55},0).wait(1).to({scaleX:0.5533,scaleY:0.5585,skewX:-6.7675,skewY:-1.1449,x:185.55,y:131.8},0).wait(1).to({scaleX:0.5454,scaleY:0.5506,skewX:-6.8884,skewY:-1.1654,x:187,y:132.9},0).wait(1).to({scaleX:0.5379,scaleY:0.5432,skewX:-7.0019,skewY:-1.1846,x:188.3,y:134},0).wait(1).to({scaleX:0.5309,scaleY:0.5363,skewX:-7.1078,skewY:-1.2025,x:189.5,y:135},0).wait(1).to({scaleX:0.5244,scaleY:0.5299,skewX:-7.2061,skewY:-1.2192,x:190.65,y:135.95},0).wait(1).to({scaleX:0.5184,scaleY:0.5239,skewX:-7.2969,skewY:-1.2345,x:191.65,y:136.8},0).wait(1).to({scaleX:0.5129,scaleY:0.5185,skewX:-7.3803,skewY:-1.2486,x:192.65,y:137.6},0).wait(1).to({scaleX:0.5079,scaleY:0.5135,skewX:-7.4563,skewY:-1.2615,x:193.5,y:138.3},0).wait(1).to({scaleX:0.5033,scaleY:0.5091,skewX:-7.5251,skewY:-1.2731,x:194.3,y:138.95},0).wait(1).to({scaleX:0.4993,scaleY:0.505,skewX:-7.5867,skewY:-1.2835,x:194.95,y:139.55},0).wait(1).to({scaleX:0.4957,scaleY:0.5015,skewX:-7.6412,skewY:-1.2928,x:195.6,y:140.05},0).wait(1).to({scaleX:0.4925,scaleY:0.4984,skewX:-7.6888,skewY:-1.3008,x:196.15,y:140.5},0).wait(1).to({scaleX:0.4898,scaleY:0.4957,skewX:-7.7296,skewY:-1.3077,x:196.65,y:140.9},0).wait(1).to({scaleX:0.4876,scaleY:0.4935,skewX:-7.7637,skewY:-1.3135,x:197,y:141.25},0).wait(1).to({scaleX:0.4858,scaleY:0.4917,skewX:-7.7913,skewY:-1.3182,x:197.3,y:141.5},0).wait(1).to({scaleX:0.4844,scaleY:0.4903,skewX:-7.8125,skewY:-1.3217,x:197.55,y:141.65},0).wait(1).to({scaleX:0.4834,scaleY:0.4893,skewX:-7.8275,skewY:-1.3243,x:197.75,y:141.8},0).wait(1).to({scaleX:0.4828,scaleY:0.4887,skewX:-7.8364,skewY:-1.3258,x:197.85,y:141.9},0).wait(1).to({regX:30.8,regY:10.1,scaleX:0.4826,scaleY:0.4885,skewX:-7.8393,skewY:-1.3263,y:142},0).wait(77));

	// girl left contribution
	this.instance_6 = new lib.girlleftcontribution_1();
	this.instance_6.setTransform(-47.7,231.85,1,1,0,0,0,44,32.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({x:119.1,y:239.35,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:44.2,regY:32.5,x:119.3,y:239.55},0).wait(18).to({regX:44,regY:32.3,x:119.1,y:239.35},0).wait(1).to({regX:44.2,regY:32.5,scaleX:0.9939,scaleY:0.9939,x:120.2,y:238.7},0).wait(1).to({scaleX:0.9872,scaleY:0.9872,x:121.2,y:237.8},0).wait(1).to({scaleX:0.98,scaleY:0.98,x:122.2,y:236.85},0).wait(1).to({scaleX:0.9722,scaleY:0.9722,x:123.35,y:235.8},0).wait(1).to({scaleX:0.9638,scaleY:0.9638,x:124.6,y:234.65},0).wait(1).to({scaleX:0.9548,scaleY:0.9548,x:125.95,y:233.5},0).wait(1).to({scaleX:0.9453,scaleY:0.9453,x:127.35,y:232.15},0).wait(1).to({scaleX:0.9352,scaleY:0.9352,x:128.85,y:230.85},0).wait(1).to({scaleX:0.9246,scaleY:0.9246,x:130.4,y:229.4},0).wait(1).to({scaleX:0.9134,scaleY:0.9134,x:132.05,y:227.9},0).wait(1).to({scaleX:0.9016,scaleY:0.9016,x:133.8,y:226.3},0).wait(1).to({scaleX:0.8894,scaleY:0.8894,x:135.6,y:224.65},0).wait(1).to({scaleX:0.8766,scaleY:0.8766,x:137.5,y:222.95},0).wait(1).to({scaleX:0.8634,scaleY:0.8634,x:139.45,y:221.15},0).wait(1).to({scaleX:0.8497,scaleY:0.8497,x:141.45,y:219.3},0).wait(1).to({scaleX:0.8356,scaleY:0.8356,x:143.55,y:217.45},0).wait(1).to({scaleX:0.8211,scaleY:0.8211,x:145.7,y:215.5},0).wait(1).to({scaleX:0.8063,scaleY:0.8063,x:147.9,y:213.5},0).wait(1).to({scaleX:0.7912,scaleY:0.7912,x:150.1,y:211.45},0).wait(1).to({scaleX:0.7758,scaleY:0.7758,x:152.4,y:209.4},0).wait(1).to({scaleX:0.7602,scaleY:0.7602,x:154.7,y:207.3},0).wait(1).to({scaleX:0.7445,scaleY:0.7445,x:157,y:205.2},0).wait(1).to({scaleX:0.7287,scaleY:0.7287,x:159.35,y:203.1},0).wait(1).to({scaleX:0.7128,scaleY:0.7128,x:161.65,y:200.95},0).wait(1).to({scaleX:0.6969,scaleY:0.6969,x:164,y:198.8},0).wait(1).to({scaleX:0.6811,scaleY:0.6811,x:166.35,y:196.7},0).wait(1).to({scaleX:0.6655,scaleY:0.6655,x:168.65,y:194.6},0).wait(1).to({scaleX:0.65,scaleY:0.65,x:170.95,y:192.5},0).wait(1).to({scaleX:0.6347,scaleY:0.6347,x:173.2,y:190.5},0).wait(1).to({scaleX:0.6197,scaleY:0.6197,x:175.45,y:188.45},0).wait(1).to({scaleX:0.605,scaleY:0.605,x:177.6,y:186.45},0).wait(1).to({scaleX:0.5907,scaleY:0.5907,x:179.7,y:184.55},0).wait(1).to({scaleX:0.5768,scaleY:0.5768,x:181.75,y:182.7},0).wait(1).to({scaleX:0.5633,scaleY:0.5633,x:183.75,y:180.85},0).wait(1).to({scaleX:0.5503,scaleY:0.5503,x:185.65,y:179.15},0).wait(1).to({scaleX:0.5378,scaleY:0.5378,x:187.5,y:177.45},0).wait(1).to({scaleX:0.5257,scaleY:0.5257,x:189.3,y:175.85},0).wait(1).to({scaleX:0.5142,scaleY:0.5142,x:191,y:174.25},0).wait(1).to({scaleX:0.5033,scaleY:0.5033,x:192.6,y:172.8},0).wait(1).to({scaleX:0.4929,scaleY:0.4929,x:194.15,y:171.4},0).wait(1).to({scaleX:0.4831,scaleY:0.4831,x:195.6,y:170.1},0).wait(1).to({scaleX:0.4739,scaleY:0.4739,x:196.95,y:168.85},0).wait(1).to({scaleX:0.4652,scaleY:0.4652,x:198.2,y:167.65},0).wait(1).to({scaleX:0.4571,scaleY:0.4571,x:199.4,y:166.6},0).wait(1).to({scaleX:0.4496,scaleY:0.4496,x:200.5,y:165.6},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:201.55,y:164.65},0).wait(1).to({scaleX:0.4363,scaleY:0.4363,x:202.5,y:163.85},0).wait(1).to({scaleX:0.4305,scaleY:0.4305,x:203.35,y:163.05},0).wait(1).to({scaleX:0.4252,scaleY:0.4252,x:204.15,y:162.3},0).wait(1).to({scaleX:0.4205,scaleY:0.4205,x:204.85,y:161.65},0).wait(1).to({scaleX:0.4164,scaleY:0.4164,x:205.45,y:161.15},0).wait(1).to({scaleX:0.4127,scaleY:0.4127,x:206,y:160.65},0).wait(1).to({scaleX:0.4096,scaleY:0.4096,x:206.45,y:160.2},0).wait(1).to({scaleX:0.407,scaleY:0.407,x:206.85,y:159.9},0).wait(1).to({scaleX:0.4049,scaleY:0.4049,x:207.15,y:159.6},0).wait(1).to({scaleX:0.4033,scaleY:0.4033,x:207.4,y:159.35},0).wait(1).to({scaleX:0.4021,scaleY:0.4021,x:207.5,y:159.2},0).wait(1).to({scaleX:0.4015,scaleY:0.4015,x:207.65,y:159.15},0).wait(1).to({regX:44.4,regY:32.8,scaleX:0.4012,scaleY:0.4012,x:207.6,y:159.05},0).wait(75));

	// girl rigth contribution
	this.instance_7 = new lib.girlrigthcontribution();
	this.instance_7.setTransform(276.95,303.5,1,1,0,0,0,39.1,19.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(14).to({_off:false},0).to({x:219.25,y:300.8,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:219.15,y:300.7},0).wait(17).to({regX:39.1,regY:19.1,x:219.25,y:300.8},0).wait(1).to({regX:39,regY:19,scaleX:0.9942,scaleY:0.9942,x:219.05,y:299.4},0).wait(1).to({scaleX:0.9879,scaleY:0.9879,x:219.1,y:298},0).wait(1).to({scaleX:0.981,scaleY:0.981,x:219,y:296.5},0).wait(1).to({scaleX:0.9736,scaleY:0.9736,x:218.95,y:294.9},0).wait(1).to({scaleX:0.9657,scaleY:0.9657,y:293.15},0).wait(1).to({scaleX:0.9572,scaleY:0.9572,x:218.9,y:291.3},0).wait(1).to({scaleX:0.9481,scaleY:0.9481,x:218.85,y:289.25},0).wait(1).to({scaleX:0.9386,scaleY:0.9386,x:218.8,y:287.2},0).wait(1).to({scaleX:0.9285,scaleY:0.9285,x:218.7,y:284.95},0).wait(1).to({scaleX:0.9178,scaleY:0.9178,y:282.65},0).wait(1).to({scaleX:0.9067,scaleY:0.9067,x:218.6,y:280.2},0).wait(1).to({scaleX:0.8951,scaleY:0.8951,x:218.55,y:277.6},0).wait(1).to({scaleX:0.883,scaleY:0.883,x:218.5,y:275},0).wait(1).to({scaleX:0.8704,scaleY:0.8704,x:218.4,y:272.2},0).wait(1).to({scaleX:0.8574,scaleY:0.8574,x:218.35,y:269.35},0).wait(1).to({scaleX:0.844,scaleY:0.844,x:218.25,y:266.45},0).wait(1).to({scaleX:0.8303,scaleY:0.8303,x:218.2,y:263.4},0).wait(1).to({scaleX:0.8162,scaleY:0.8162,x:218.15,y:260.3},0).wait(1).to({scaleX:0.8019,scaleY:0.8019,x:218,y:257.15},0).wait(1).to({scaleX:0.7873,scaleY:0.7873,x:217.95,y:253.95},0).wait(1).to({scaleX:0.7725,scaleY:0.7725,x:217.9,y:250.75},0).wait(1).to({scaleX:0.7576,scaleY:0.7576,x:217.8,y:247.45},0).wait(1).to({scaleX:0.7426,scaleY:0.7426,x:217.7,y:244.1},0).wait(1).to({scaleX:0.7275,scaleY:0.7275,x:217.6,y:240.8},0).wait(1).to({scaleX:0.7125,scaleY:0.7125,x:217.55,y:237.55},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:217.45,y:234.2},0).wait(1).to({scaleX:0.6826,scaleY:0.6826,x:217.35,y:230.95},0).wait(1).to({scaleX:0.6679,scaleY:0.6679,x:217.3,y:227.75},0).wait(1).to({scaleX:0.6534,scaleY:0.6534,x:217.25,y:224.55},0).wait(1).to({scaleX:0.6392,scaleY:0.6392,x:217.15,y:221.45},0).wait(1).to({scaleX:0.6253,scaleY:0.6253,x:217.1,y:218.4},0).wait(1).to({scaleX:0.6117,scaleY:0.6117,x:217,y:215.35},0).wait(1).to({scaleX:0.5985,scaleY:0.5985,x:216.95,y:212.45},0).wait(1).to({scaleX:0.5857,scaleY:0.5857,x:216.85,y:209.7},0).wait(1).to({scaleX:0.5734,scaleY:0.5734,x:216.75,y:206.95},0).wait(1).to({scaleX:0.5615,scaleY:0.5615,x:216.7,y:204.35},0).wait(1).to({scaleX:0.5501,scaleY:0.5501,x:216.65,y:201.85},0).wait(1).to({scaleX:0.5392,scaleY:0.5392,x:216.6,y:199.45},0).wait(1).to({scaleX:0.5288,scaleY:0.5288,x:216.5,y:197.15},0).wait(1).to({scaleX:0.5189,scaleY:0.5189,y:195},0).wait(1).to({scaleX:0.5096,scaleY:0.5096,x:216.45,y:193},0).wait(1).to({scaleX:0.5009,scaleY:0.5009,x:216.4,y:191},0).wait(1).to({scaleX:0.4926,scaleY:0.4926,x:216.35,y:189.2},0).wait(1).to({scaleX:0.485,scaleY:0.485,x:216.3,y:187.55},0).wait(1).to({scaleX:0.4778,scaleY:0.4778,x:216.25,y:186},0).wait(1).to({scaleX:0.4713,scaleY:0.4713,y:184.55},0).wait(1).to({scaleX:0.4652,scaleY:0.4652,x:216.2,y:183.2},0).wait(1).to({scaleX:0.4597,scaleY:0.4597,y:182},0).wait(1).to({scaleX:0.4547,scaleY:0.4547,x:216.15,y:180.9},0).wait(1).to({scaleX:0.4503,scaleY:0.4503,x:216.1,y:179.9},0).wait(1).to({scaleX:0.4463,scaleY:0.4463,y:179.1},0).wait(1).to({scaleX:0.4429,scaleY:0.4429,x:216.05,y:178.3},0).wait(1).to({scaleX:0.4399,scaleY:0.4399,y:177.65},0).wait(1).to({scaleX:0.4374,scaleY:0.4374,y:177.1},0).wait(1).to({scaleX:0.4354,scaleY:0.4354,y:176.65},0).wait(1).to({scaleX:0.4339,scaleY:0.4339,x:216,y:176.35},0).wait(1).to({scaleX:0.4328,scaleY:0.4328,x:216.05,y:176.05},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:216,y:175.95},0).wait(1).to({regX:39.2,regY:19.1,scaleX:0.432,scaleY:0.432,x:216.05},0).wait(74));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:178.45,y:155.025}).wait(210));

	// r guy i shadow
	this.instance_8 = new lib.roundshadow();
	this.instance_8.setTransform(212.15,-11.85,1,1,0,0,0,28.2,22.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(19).to({_off:false},0).to({x:175.15,y:93.15,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:174.95,y:92.85},0).wait(11).to({regX:28.2,regY:22.8,x:175.15,y:93.15},0).wait(1).to({regX:28,regY:22.5,scaleX:0.9967,scaleY:0.9967,x:175.2,y:92.95},0).wait(1).to({scaleX:0.993,scaleY:0.993,x:175.55,y:93.2},0).wait(1).to({scaleX:0.989,scaleY:0.989,x:175.9,y:93.4},0).wait(1).to({scaleX:0.9847,scaleY:0.9847,x:176.25,y:93.6},0).wait(1).to({scaleX:0.9801,scaleY:0.9801,x:176.7,y:93.85},0).wait(1).to({scaleX:0.9752,scaleY:0.9752,x:177.1,y:94.1},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:177.6,y:94.35},0).wait(1).to({scaleX:0.9644,scaleY:0.9644,x:178.1,y:94.65},0).wait(1).to({scaleX:0.9586,scaleY:0.9586,x:178.6,y:94.95},0).wait(1).to({scaleX:0.9524,scaleY:0.9524,x:179.15,y:95.3},0).wait(1).to({scaleX:0.946,scaleY:0.946,x:179.75,y:95.6},0).wait(1).to({scaleX:0.9393,scaleY:0.9393,x:180.35,y:95.95},0).wait(1).to({scaleX:0.9322,scaleY:0.9322,x:180.95,y:96.35},0).wait(1).to({scaleX:0.925,scaleY:0.925,x:181.6,y:96.7},0).wait(1).to({scaleX:0.9175,scaleY:0.9175,x:182.25,y:97.1},0).wait(1).to({scaleX:0.9097,scaleY:0.9097,x:182.95,y:97.45},0).wait(1).to({scaleX:0.9018,scaleY:0.9018,x:183.65,y:97.9},0).wait(1).to({scaleX:0.8936,scaleY:0.8936,x:184.35,y:98.3},0).wait(1).to({scaleX:0.8853,scaleY:0.8853,x:185.15,y:98.7},0).wait(1).to({scaleX:0.8769,scaleY:0.8769,x:185.85,y:99.2},0).wait(1).to({scaleX:0.8683,scaleY:0.8683,x:186.6,y:99.6},0).wait(1).to({scaleX:0.8597,scaleY:0.8597,x:187.4,y:100.05},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:188.2,y:100.5},0).wait(1).to({scaleX:0.8423,scaleY:0.8423,x:188.95,y:100.95},0).wait(1).to({scaleX:0.8336,scaleY:0.8336,x:189.75,y:101.4},0).wait(1).to({scaleX:0.8249,scaleY:0.8249,x:190.5,y:101.85},0).wait(1).to({scaleX:0.8163,scaleY:0.8163,x:191.25,y:102.25},0).wait(1).to({scaleX:0.8078,scaleY:0.8078,x:192,y:102.7},0).wait(1).to({scaleX:0.7994,scaleY:0.7994,x:192.75,y:103.15},0).wait(1).to({scaleX:0.7911,scaleY:0.7911,x:193.5,y:103.6},0).wait(1).to({scaleX:0.7831,scaleY:0.7831,x:194.25,y:104},0).wait(1).to({scaleX:0.7752,scaleY:0.7752,x:194.9,y:104.4},0).wait(1).to({scaleX:0.7676,scaleY:0.7676,x:195.6,y:104.8},0).wait(1).to({scaleX:0.7602,scaleY:0.7602,x:196.25,y:105.15},0).wait(1).to({scaleX:0.753,scaleY:0.753,x:196.9,y:105.55},0).wait(1).to({scaleX:0.7461,scaleY:0.7461,x:197.5,y:105.9},0).wait(1).to({scaleX:0.7395,scaleY:0.7395,x:198.05,y:106.25},0).wait(1).to({scaleX:0.7332,scaleY:0.7332,x:198.65,y:106.55},0).wait(1).to({scaleX:0.7272,scaleY:0.7272,x:199.15,y:106.85},0).wait(1).to({scaleX:0.7215,scaleY:0.7215,x:199.65,y:107.2},0).wait(1).to({scaleX:0.7161,scaleY:0.7161,x:200.15,y:107.45},0).wait(1).to({scaleX:0.711,scaleY:0.711,x:200.6,y:107.7},0).wait(1).to({scaleX:0.7063,scaleY:0.7063,x:201.05,y:107.95},0).wait(1).to({scaleX:0.7018,scaleY:0.7018,x:201.4,y:108.2},0).wait(1).to({scaleX:0.6977,scaleY:0.6977,x:201.8,y:108.4},0).wait(1).to({scaleX:0.6939,scaleY:0.6939,x:202.15,y:108.6},0).wait(1).to({scaleX:0.6904,scaleY:0.6904,x:202.45,y:108.8},0).wait(1).to({scaleX:0.6872,scaleY:0.6872,x:202.75,y:108.9},0).wait(1).to({scaleX:0.6843,scaleY:0.6843,x:202.95,y:109.1},0).wait(1).to({scaleX:0.6818,scaleY:0.6818,x:203.2,y:109.2},0).wait(1).to({scaleX:0.6795,scaleY:0.6795,x:203.4,y:109.35},0).wait(1).to({scaleX:0.6775,scaleY:0.6775,x:203.55,y:109.45},0).wait(1).to({scaleX:0.6758,scaleY:0.6758,x:203.7,y:109.5},0).wait(1).to({scaleX:0.6743,scaleY:0.6743,x:203.9,y:109.55},0).wait(1).to({scaleX:0.6732,scaleY:0.6732,x:203.95,y:109.65},0).wait(1).to({scaleX:0.6723,scaleY:0.6723,x:204.05,y:109.75},0).wait(1).to({scaleX:0.6717,scaleY:0.6717,x:204.1,y:109.7},0).wait(1).to({scaleX:0.6713,scaleY:0.6713,x:204.15,y:109.75},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.6712,scaleY:0.6712,x:204.3,y:109.9},0).wait(1).to({regX:28,regY:22.5,x:204.05,y:109.65},0).wait(15).to({regX:28.4,regY:22.9,x:204.3,y:109.9},0).wait(1).to({regX:28,regY:22.5,scaleX:0.671,scaleY:0.671,x:204.05,y:109.6},0).wait(1).to({scaleX:0.6708,scaleY:0.6708},0).wait(1).to({scaleX:0.6706,scaleY:0.6706},0).wait(1).to({scaleX:0.6702,scaleY:0.6702,y:109.55},0).wait(1).to({scaleX:0.6697,scaleY:0.6697,y:109.5},0).wait(1).to({scaleX:0.6691,scaleY:0.6691,x:204.1,y:109.45},0).wait(1).to({scaleX:0.6684,scaleY:0.6684,y:109.4},0).wait(1).to({scaleX:0.6676,scaleY:0.6676,x:204.15,y:109.3},0).wait(1).to({scaleX:0.6667,scaleY:0.6667,y:109.25},0).wait(1).to({scaleX:0.6656,scaleY:0.6656,x:204.2,y:109.1},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,x:204.25,y:109.05},0).wait(1).to({scaleX:0.6628,scaleY:0.6628,y:108.9},0).wait(1).to({scaleX:0.6612,scaleY:0.6612,x:204.3,y:108.8},0).wait(1).to({scaleX:0.6593,scaleY:0.6593,x:204.4,y:108.6},0).wait(1).to({scaleX:0.6572,scaleY:0.6572,x:204.45,y:108.45},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:204.55,y:108.2},0).wait(1).to({scaleX:0.6521,scaleY:0.6521,x:204.6,y:107.95},0).wait(1).to({scaleX:0.649,scaleY:0.649,x:204.7,y:107.7},0).wait(1).to({scaleX:0.6455,scaleY:0.6455,x:204.8,y:107.35},0).wait(1).to({scaleX:0.6415,scaleY:0.6415,x:204.95,y:107.05},0).wait(1).to({scaleX:0.6368,scaleY:0.6368,x:205.1,y:106.65},0).wait(1).to({scaleX:0.6315,scaleY:0.6315,x:205.3,y:106.15},0).wait(1).to({scaleX:0.6252,scaleY:0.6252,x:205.45,y:105.6},0).wait(1).to({scaleX:0.6178,scaleY:0.6178,x:205.7,y:105},0).wait(1).to({scaleX:0.6088,scaleY:0.6088,x:206,y:104.2},0).wait(1).to({scaleX:0.5978,scaleY:0.5978,x:206.35,y:103.25},0).wait(1).to({scaleX:0.5842,scaleY:0.5842,x:206.75,y:102.05},0).wait(1).to({scaleX:0.5675,scaleY:0.5675,x:207.3,y:100.6},0).wait(1).to({scaleX:0.5481,scaleY:0.5481,x:207.9,y:98.95},0).wait(1).to({scaleX:0.5286,scaleY:0.5286,x:208.55,y:97.25},0).wait(1).to({scaleX:0.5116,scaleY:0.5116,x:209.05,y:95.75},0).wait(1).to({scaleX:0.4976,scaleY:0.4976,x:209.5,y:94.55},0).wait(1).to({scaleX:0.4863,scaleY:0.4863,x:209.85,y:93.55},0).wait(1).to({scaleX:0.477,scaleY:0.477,x:210.15,y:92.75},0).wait(1).to({scaleX:0.4692,scaleY:0.4692,x:210.4,y:92.05},0).wait(1).to({scaleX:0.4627,scaleY:0.4627,x:210.6,y:91.5},0).wait(1).to({scaleX:0.457,scaleY:0.457,x:210.8,y:91},0).wait(1).to({scaleX:0.4521,scaleY:0.4521,x:210.95,y:90.55},0).wait(1).to({scaleX:0.4477,scaleY:0.4477,x:211.1,y:90.2},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:211.25,y:89.9},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,x:211.35,y:89.55},0).wait(1).to({scaleX:0.4376,scaleY:0.4376,x:211.4,y:89.3},0).wait(1).to({scaleX:0.4349,scaleY:0.4349,x:211.5,y:89.1},0).wait(1).to({scaleX:0.4326,scaleY:0.4326,x:211.55,y:88.9},0).wait(1).to({scaleX:0.4304,scaleY:0.4304,x:211.65,y:88.7},0).wait(1).to({scaleX:0.4285,scaleY:0.4285,x:211.7,y:88.55},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:211.75,y:88.4},0).wait(1).to({scaleX:0.4253,scaleY:0.4253,x:211.8,y:88.25},0).wait(1).to({scaleX:0.424,scaleY:0.424,y:88.15},0).wait(1).to({scaleX:0.4228,scaleY:0.4228,x:211.9,y:88},0).wait(1).to({scaleX:0.4218,scaleY:0.4218,y:87.95},0).wait(1).to({scaleX:0.4208,scaleY:0.4208,x:211.95,y:87.85},0).wait(1).to({scaleX:0.42,scaleY:0.42,y:87.8},0).wait(1).to({scaleX:0.4193,scaleY:0.4193,x:212,y:87.75},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,y:87.65},0).wait(1).to({scaleX:0.4183,scaleY:0.4183},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,x:212.05,y:87.6},0).wait(1).to({scaleX:0.4175,scaleY:0.4175},0).wait(1).to({scaleX:0.4173,scaleY:0.4173,y:87.55},0).wait(1).to({scaleX:0.4171,scaleY:0.4171,x:212.1},0).wait(1).to({scaleX:0.417,scaleY:0.417},0).wait(1).to({regX:28.3,regY:23,x:212.25,y:87.75},0).wait(1));

	// l guy i shadow
	this.instance_9 = new lib.roundshadow();
	this.instance_9.setTransform(-92.55,143.1,1,1,0,0,0,28.2,22.8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(25).to({_off:false},0).to({x:53.65,y:77.45,alpha:0.1602},45,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:53.45,y:77.15},0).wait(12).to({regX:28.2,regY:22.8,x:53.65,y:77.45},0).wait(1).to({regX:28,regY:22.5,scaleX:0.995,scaleY:0.995,x:54.75,y:77.7},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:56.15,y:78.25},0).wait(1).to({scaleX:0.9834,scaleY:0.9834,x:57.75,y:78.95},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:59.4,y:79.65},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:61.2,y:80.45},0).wait(1).to({scaleX:0.9626,scaleY:0.9626,x:63.15,y:81.2},0).wait(1).to({scaleX:0.9547,scaleY:0.9547,x:65.2,y:82.1},0).wait(1).to({scaleX:0.9464,scaleY:0.9464,x:67.35,y:83},0).wait(1).to({scaleX:0.9375,scaleY:0.9375,x:69.65,y:84},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:72.1,y:85},0).wait(1).to({scaleX:0.9185,scaleY:0.9185,x:74.55,y:86.05},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:77.25,y:87.2},0).wait(1).to({scaleX:0.8978,scaleY:0.8978,x:80,y:88.35},0).wait(1).to({scaleX:0.8869,scaleY:0.8869,x:82.85,y:89.55},0).wait(1).to({scaleX:0.8755,scaleY:0.8755,x:85.75,y:90.75},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:88.8,y:92.05},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:91.9,y:93.35},0).wait(1).to({scaleX:0.8396,scaleY:0.8396,x:95.1,y:94.7},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,x:98.35,y:96.1},0).wait(1).to({scaleX:0.8143,scaleY:0.8143,x:101.65,y:97.45},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,x:105.05,y:98.9},0).wait(1).to({scaleX:0.7884,scaleY:0.7884,x:108.4,y:100.35},0).wait(1).to({scaleX:0.7753,scaleY:0.7753,x:111.8,y:101.75},0).wait(1).to({scaleX:0.7621,scaleY:0.7621,x:115.25,y:103.2},0).wait(1).to({scaleX:0.749,scaleY:0.749,x:118.6,y:104.65},0).wait(1).to({scaleX:0.7359,scaleY:0.7359,x:122.05,y:106.05},0).wait(1).to({scaleX:0.723,scaleY:0.723,x:125.4,y:107.5},0).wait(1).to({scaleX:0.7101,scaleY:0.7101,x:128.75,y:108.95},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:132.05,y:110.3},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:135.3,y:111.65},0).wait(1).to({scaleX:0.6729,scaleY:0.6729,x:138.45,y:113},0).wait(1).to({scaleX:0.661,scaleY:0.661,x:141.5,y:114.25},0).wait(1).to({scaleX:0.6495,scaleY:0.6495,x:144.5,y:115.55},0).wait(1).to({scaleX:0.6384,scaleY:0.6384,x:147.35,y:116.75},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:150.2,y:117.95},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:152.9,y:119.1},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:155.5,y:120.2},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:157.95,y:121.25},0).wait(1).to({scaleX:0.5887,scaleY:0.5887,x:160.3,y:122.25},0).wait(1).to({scaleX:0.5801,scaleY:0.5801,x:162.55,y:123.15},0).wait(1).to({scaleX:0.5719,scaleY:0.5719,x:164.65,y:124.05},0).wait(1).to({scaleX:0.5643,scaleY:0.5643,x:166.65,y:124.9},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:168.5,y:125.7},0).wait(1).to({scaleX:0.5504,scaleY:0.5504,x:170.25,y:126.45},0).wait(1).to({scaleX:0.5442,scaleY:0.5442,x:171.85,y:127.1},0).wait(1).to({scaleX:0.5385,scaleY:0.5385,x:173.4,y:127.7},0).wait(1).to({scaleX:0.5332,scaleY:0.5332,x:174.75,y:128.3},0).wait(1).to({scaleX:0.5284,scaleY:0.5284,x:176,y:128.85},0).wait(1).to({scaleX:0.524,scaleY:0.524,x:177.1,y:129.3},0).wait(1).to({scaleX:0.5201,scaleY:0.5201,x:178.1,y:129.75},0).wait(1).to({scaleX:0.5167,scaleY:0.5167,x:179,y:130.15},0).wait(1).to({scaleX:0.5137,scaleY:0.5137,x:179.8,y:130.45},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:180.45,y:130.75},0).wait(1).to({scaleX:0.5089,scaleY:0.5089,x:181,y:130.95},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:181.5,y:131.15},0).wait(1).to({scaleX:0.5058,scaleY:0.5058,x:181.8,y:131.35},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:182.1,y:131.4},0).wait(1).to({scaleX:0.5043,scaleY:0.5043,x:182.2,y:131.5},0).wait(1).to({regX:28.2,regY:22.9,scaleX:0.5042,scaleY:0.5042,x:182.35,y:131.65},0).wait(1).to({regX:28,regY:22.5,x:182.25,y:131.45},0).wait(15).to({regX:28.2,regY:22.9,x:182.35,y:131.65},0).wait(1).to({regX:28,regY:22.5,scaleX:0.5041,scaleY:0.5041,x:182.2,y:131.4},0).wait(1).to({scaleX:0.504,scaleY:0.504,x:182.15},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,x:182.1,y:131.35},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,x:182.05,y:131.3},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:181.95,y:131.25},0).wait(1).to({scaleX:0.5034,scaleY:0.5034,x:181.85,y:131.15},0).wait(1).to({scaleX:0.5032,scaleY:0.5032,x:181.7,y:131.05},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:181.55,y:130.95},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:181.3,y:130.8},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:181.1,y:130.65},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:180.8,y:130.5},0).wait(1).to({scaleX:0.5011,scaleY:0.5011,x:180.5,y:130.3},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:180.1,y:130},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:179.7,y:129.75},0).wait(1).to({scaleX:0.4989,scaleY:0.4989,x:179.2,y:129.45},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:178.65,y:129.05},0).wait(1).to({scaleX:0.4968,scaleY:0.4968,x:178,y:128.65},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:177.2,y:128.1},0).wait(1).to({scaleX:0.4938,scaleY:0.4938,x:176.3,y:127.5},0).wait(1).to({scaleX:0.4918,scaleY:0.4918,x:175.15,y:126.75},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:173.75,y:125.85},0).wait(1).to({scaleX:0.4864,scaleY:0.4864,x:172,y:124.7},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:169.8,y:123.2},0).wait(1).to({scaleX:0.4776,scaleY:0.4776,x:166.95,y:121.35},0).wait(1).to({scaleX:0.4718,scaleY:0.4718,x:163.65,y:119.15},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:160.5,y:117.1},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:158,y:115.45},0).wait(1).to({scaleX:0.4584,scaleY:0.4584,x:156,y:114.1},0).wait(1).to({scaleX:0.4557,scaleY:0.4557,x:154.35,y:113.05},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:153.1,y:112.2},0).wait(1).to({scaleX:0.4516,scaleY:0.4516,x:152,y:111.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:151.1,y:110.9},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:150.35,y:110.4},0).wait(1).to({scaleX:0.4475,scaleY:0.4475,x:149.7,y:109.95},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:149.1,y:109.6},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:148.65,y:109.3},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:148.2,y:108.95},0).wait(1).to({scaleX:0.4443,scaleY:0.4443,x:147.8,y:108.75},0).wait(1).to({scaleX:0.4437,scaleY:0.4437,x:147.45,y:108.55},0).wait(1).to({scaleX:0.4432,scaleY:0.4432,x:147.15,y:108.3},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:146.95,y:108.15},0).wait(1).to({scaleX:0.4423,scaleY:0.4423,x:146.7,y:108},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:146.55,y:107.9},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:146.3,y:107.75},0).wait(1).to({scaleX:0.4415,scaleY:0.4415,x:146.2,y:107.7},0).wait(1).to({scaleX:0.4412,scaleY:0.4412,x:146.05,y:107.6},0).wait(1).to({scaleX:0.4411,scaleY:0.4411,x:146,y:107.5},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:145.9,y:107.45},0).wait(1).to({scaleX:0.4408,scaleY:0.4408,x:145.85,y:107.4},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:145.8},0).wait(1).to({x:145.75,y:107.35},0).wait(1).to({scaleX:0.4406,scaleY:0.4406},0).wait(1).to({regX:28.5,regY:23.1,x:145.85,y:107.6},0).wait(8));

	// r girl i shadow
	this.instance_10 = new lib.roundshadow();
	this.instance_10.setTransform(221.7,324.1,1,1,0,0,0,28.2,22.8);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(14).to({_off:false},0).to({x:144.95,y:313.55,alpha:0.1602},53,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:144.75,y:313.25},0).wait(17).to({regX:28.2,regY:22.8,x:144.95,y:313.55},0).wait(1).to({regX:28,regY:22.5,scaleX:0.9966,scaleY:0.9966,x:145.2,y:311.9},0).wait(1).to({scaleX:0.9929,scaleY:0.9929,x:145.75,y:310.55},0).wait(1).to({scaleX:0.9888,scaleY:0.9888,x:146.35,y:309.05},0).wait(1).to({scaleX:0.9844,scaleY:0.9844,x:146.9,y:307.4},0).wait(1).to({scaleX:0.9797,scaleY:0.9797,x:147.6,y:305.65},0).wait(1).to({scaleX:0.9747,scaleY:0.9747,x:148.3,y:303.8},0).wait(1).to({scaleX:0.9694,scaleY:0.9694,x:149.05,y:301.75},0).wait(1).to({scaleX:0.9637,scaleY:0.9637,x:149.9,y:299.7},0).wait(1).to({scaleX:0.9578,scaleY:0.9578,x:150.7,y:297.45},0).wait(1).to({scaleX:0.9515,scaleY:0.9515,x:151.6,y:295.1},0).wait(1).to({scaleX:0.9449,scaleY:0.9449,x:152.55,y:292.65},0).wait(1).to({scaleX:0.9381,scaleY:0.9381,x:153.5,y:290.05},0).wait(1).to({scaleX:0.9309,scaleY:0.9309,x:154.5,y:287.4},0).wait(1).to({scaleX:0.9235,scaleY:0.9235,x:155.55,y:284.65},0).wait(1).to({scaleX:0.9158,scaleY:0.9158,x:156.65,y:281.75},0).wait(1).to({scaleX:0.9079,scaleY:0.9079,x:157.75,y:278.85},0).wait(1).to({scaleX:0.8998,scaleY:0.8998,x:158.95,y:275.8},0).wait(1).to({scaleX:0.8915,scaleY:0.8915,x:160.1,y:272.7},0).wait(1).to({scaleX:0.8831,scaleY:0.8831,x:161.35,y:269.5},0).wait(1).to({scaleX:0.8745,scaleY:0.8745,x:162.55,y:266.35},0).wait(1).to({scaleX:0.8657,scaleY:0.8657,x:163.75,y:263.1},0).wait(1).to({scaleX:0.8569,scaleY:0.8569,x:165,y:259.8},0).wait(1).to({scaleX:0.8481,scaleY:0.8481,x:166.25,y:256.5},0).wait(1).to({scaleX:0.8392,scaleY:0.8392,x:167.55,y:253.15},0).wait(1).to({scaleX:0.8303,scaleY:0.8303,x:168.8,y:249.85},0).wait(1).to({scaleX:0.8214,scaleY:0.8214,x:170.05,y:246.55},0).wait(1).to({scaleX:0.8127,scaleY:0.8127,x:171.3,y:243.25},0).wait(1).to({scaleX:0.804,scaleY:0.804,x:172.5,y:240},0).wait(1).to({scaleX:0.7954,scaleY:0.7954,x:173.7,y:236.8},0).wait(1).to({scaleX:0.787,scaleY:0.787,x:174.95,y:233.65},0).wait(1).to({scaleX:0.7788,scaleY:0.7788,x:176.05,y:230.55},0).wait(1).to({scaleX:0.7708,scaleY:0.7708,x:177.25,y:227.6},0).wait(1).to({scaleX:0.763,scaleY:0.763,x:178.3,y:224.65},0).wait(1).to({scaleX:0.7555,scaleY:0.7555,x:179.4,y:221.85},0).wait(1).to({scaleX:0.7482,scaleY:0.7482,x:180.4,y:219.15},0).wait(1).to({scaleX:0.7411,scaleY:0.7411,x:181.4,y:216.55},0).wait(1).to({scaleX:0.7344,scaleY:0.7344,x:182.35,y:214},0).wait(1).to({scaleX:0.728,scaleY:0.728,x:183.3,y:211.6},0).wait(1).to({scaleX:0.7219,scaleY:0.7219,x:184.15,y:209.3},0).wait(1).to({scaleX:0.716,scaleY:0.716,x:185,y:207.15},0).wait(1).to({scaleX:0.7106,scaleY:0.7106,x:185.75,y:205.1},0).wait(1).to({scaleX:0.7054,scaleY:0.7054,x:186.5,y:203.15},0).wait(1).to({scaleX:0.7005,scaleY:0.7005,x:187.15,y:201.35},0).wait(1).to({scaleX:0.696,scaleY:0.696,x:187.85,y:199.65},0).wait(1).to({scaleX:0.6918,scaleY:0.6918,x:188.4,y:198.05},0).wait(1).to({scaleX:0.6879,scaleY:0.6879,x:188.95,y:196.65},0).wait(1).to({scaleX:0.6843,scaleY:0.6843,x:189.45,y:195.3},0).wait(1).to({scaleX:0.6811,scaleY:0.6811,x:189.9,y:194.05},0).wait(1).to({scaleX:0.6781,scaleY:0.6781,x:190.35,y:193},0).wait(1).to({scaleX:0.6755,scaleY:0.6755,x:190.7,y:192},0).wait(1).to({scaleX:0.6732,scaleY:0.6732,x:191.05,y:191.15},0).wait(1).to({scaleX:0.6711,scaleY:0.6711,x:191.35,y:190.35},0).wait(1).to({scaleX:0.6694,scaleY:0.6694,x:191.6,y:189.7},0).wait(1).to({scaleX:0.6679,scaleY:0.6679,x:191.8,y:189.2},0).wait(1).to({scaleX:0.6668,scaleY:0.6668,x:191.95,y:188.75},0).wait(1).to({scaleX:0.6658,scaleY:0.6658,x:192.1,y:188.4},0).wait(1).to({scaleX:0.6652,scaleY:0.6652,x:192.2,y:188.15},0).wait(1).to({scaleX:0.6648,scaleY:0.6648,y:188},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.6647,scaleY:0.6647,x:192.4,y:188.1},0).wait(1).to({regX:28,regY:22.5,x:192.2,y:187.85},0).wait(15).to({regX:28.3,regY:22.9,x:192.4,y:188.1},0).wait(1).to({regX:28,regY:22.5,scaleX:0.6646,scaleY:0.6646,x:192.15,y:187.8},0).wait(1).to({scaleX:0.6644,scaleY:0.6644,y:187.7},0).wait(1).to({scaleX:0.6641,scaleY:0.6641,y:187.6},0).wait(1).to({scaleX:0.6637,scaleY:0.6637,x:192.1,y:187.45},0).wait(1).to({scaleX:0.6632,scaleY:0.6632,x:192,y:187.25},0).wait(1).to({scaleX:0.6625,scaleY:0.6625,x:191.95,y:187.05},0).wait(1).to({scaleX:0.6618,scaleY:0.6618,x:191.9,y:186.75},0).wait(1).to({scaleX:0.6608,scaleY:0.6608,x:191.8,y:186.4},0).wait(1).to({scaleX:0.6598,scaleY:0.6598,x:191.7,y:186.05},0).wait(1).to({scaleX:0.6586,scaleY:0.6586,x:191.6,y:185.6},0).wait(1).to({scaleX:0.6571,scaleY:0.6571,x:191.45,y:185.1},0).wait(1).to({scaleX:0.6555,scaleY:0.6555,x:191.25,y:184.5},0).wait(1).to({scaleX:0.6536,scaleY:0.6536,x:191.1,y:183.8},0).wait(1).to({scaleX:0.6515,scaleY:0.6515,x:190.9,y:183.05},0).wait(1).to({scaleX:0.6491,scaleY:0.6491,x:190.6,y:182.15},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:190.35,y:181.15},0).wait(1).to({scaleX:0.6431,scaleY:0.6431,x:190.05,y:180},0).wait(1).to({scaleX:0.6394,scaleY:0.6394,x:189.7,y:178.7},0).wait(1).to({scaleX:0.6352,scaleY:0.6352,x:189.3,y:177.15},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:188.8,y:175.35},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:188.2,y:173.25},0).wait(1).to({scaleX:0.6175,scaleY:0.6175,x:187.55,y:170.75},0).wait(1).to({scaleX:0.6091,scaleY:0.6091,x:186.7,y:167.7},0).wait(1).to({scaleX:0.5988,scaleY:0.5988,x:185.65,y:163.95},0).wait(1).to({scaleX:0.5859,scaleY:0.5859,x:184.4,y:159.3},0).wait(1).to({scaleX:0.5696,scaleY:0.5696,x:182.8,y:153.4},0).wait(1).to({scaleX:0.5502,scaleY:0.5502,x:180.85,y:146.45},0).wait(1).to({scaleX:0.5303,scaleY:0.5303,x:178.9,y:139.2},0).wait(1).to({scaleX:0.5129,scaleY:0.5129,x:177.15,y:132.9},0).wait(1).to({scaleX:0.4988,scaleY:0.4988,x:175.8,y:127.8},0).wait(1).to({scaleX:0.4875,scaleY:0.4875,x:174.7,y:123.7},0).wait(1).to({scaleX:0.4784,scaleY:0.4784,x:173.8,y:120.4},0).wait(1).to({scaleX:0.4708,scaleY:0.4708,x:173.05,y:117.65},0).wait(1).to({scaleX:0.4644,scaleY:0.4644,x:172.4,y:115.35},0).wait(1).to({scaleX:0.4589,scaleY:0.4589,x:171.85,y:113.4},0).wait(1).to({scaleX:0.4542,scaleY:0.4542,x:171.35,y:111.65},0).wait(1).to({scaleX:0.4501,scaleY:0.4501,x:171,y:110.2},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:170.65,y:108.9},0).wait(1).to({scaleX:0.4433,scaleY:0.4433,x:170.3,y:107.7},0).wait(1).to({scaleX:0.4405,scaleY:0.4405,x:170.05,y:106.7},0).wait(1).to({scaleX:0.4381,scaleY:0.4381,x:169.8,y:105.85},0).wait(1).to({scaleX:0.4359,scaleY:0.4359,x:169.55,y:105.05},0).wait(1).to({scaleX:0.4339,scaleY:0.4339,x:169.4,y:104.35},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:169.2,y:103.7},0).wait(1).to({scaleX:0.4307,scaleY:0.4307,x:169.05,y:103.15},0).wait(1).to({scaleX:0.4293,scaleY:0.4293,x:168.9,y:102.65},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:168.85,y:102.25},0).wait(1).to({scaleX:0.4271,scaleY:0.4271,x:168.7,y:101.85},0).wait(1).to({scaleX:0.4262,scaleY:0.4262,x:168.65,y:101.55},0).wait(1).to({scaleX:0.4255,scaleY:0.4255,x:168.55,y:101.25},0).wait(1).to({scaleX:0.4248,scaleY:0.4248,x:168.5,y:101.05},0).wait(1).to({scaleX:0.4243,scaleY:0.4243,x:168.45,y:100.85},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:168.35,y:100.7},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,y:100.6},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,y:100.45},0).wait(1).to({scaleX:0.423,scaleY:0.423,x:168.3,y:100.35},0).wait(1).to({scaleX:0.4229,scaleY:0.4229},0).wait(1).to({regX:28.2,regY:22.9,x:168.4,y:100.55},0).wait(1));

	// l girl i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(-105.9,239.95,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({x:65.6,y:244.55,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:65.4,y:244.25},0).wait(19).to({regX:28.2,regY:22.8,x:65.6,y:244.55},0).wait(1).to({regX:28,regY:22.5,scaleX:0.995,scaleY:0.995,x:66.6,y:243.35},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:67.9,y:242.3},0).wait(1).to({scaleX:0.9834,scaleY:0.9834,x:69.35,y:241.25},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:70.9,y:240.1},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:72.55,y:238.85},0).wait(1).to({scaleX:0.9626,scaleY:0.9626,x:74.3,y:237.5},0).wait(1).to({scaleX:0.9547,scaleY:0.9547,x:76.2,y:236.1},0).wait(1).to({scaleX:0.9464,scaleY:0.9464,x:78.2,y:234.6},0).wait(1).to({scaleX:0.9375,scaleY:0.9375,x:80.3,y:233},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:82.5,y:231.35},0).wait(1).to({scaleX:0.9185,scaleY:0.9185,x:84.8,y:229.55},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:87.25,y:227.75},0).wait(1).to({scaleX:0.8978,scaleY:0.8978,x:89.8,y:225.85},0).wait(1).to({scaleX:0.8869,scaleY:0.8869,x:92.4,y:223.85},0).wait(1).to({scaleX:0.8755,scaleY:0.8755,x:95.1,y:221.85},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:97.9,y:219.75},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:100.75,y:217.55},0).wait(1).to({scaleX:0.8396,scaleY:0.8396,x:103.7,y:215.35},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,x:106.7,y:213.1},0).wait(1).to({scaleX:0.8143,scaleY:0.8143,x:109.75,y:210.8},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,x:112.8,y:208.5},0).wait(1).to({scaleX:0.7884,scaleY:0.7884,x:115.9,y:206.15},0).wait(1).to({scaleX:0.7753,scaleY:0.7753,x:119.05,y:203.8},0).wait(1).to({scaleX:0.7621,scaleY:0.7621,x:122.2,y:201.4},0).wait(1).to({scaleX:0.749,scaleY:0.749,x:125.3,y:199.05},0).wait(1).to({scaleX:0.7359,scaleY:0.7359,x:128.45,y:196.7},0).wait(1).to({scaleX:0.723,scaleY:0.723,x:131.55,y:194.35},0).wait(1).to({scaleX:0.7101,scaleY:0.7101,x:134.65,y:192.1},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:137.65,y:189.8},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:140.6,y:187.55},0).wait(1).to({scaleX:0.6729,scaleY:0.6729,x:143.5,y:185.35},0).wait(1).to({scaleX:0.661,scaleY:0.661,x:146.35,y:183.2},0).wait(1).to({scaleX:0.6495,scaleY:0.6495,x:149.1,y:181.15},0).wait(1).to({scaleX:0.6384,scaleY:0.6384,x:151.75,y:179.15},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:154.3,y:177.2},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:156.85,y:175.35},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:159.2,y:173.55},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:161.5,y:171.85},0).wait(1).to({scaleX:0.5887,scaleY:0.5887,x:163.65,y:170.2},0).wait(1).to({scaleX:0.5801,scaleY:0.5801,x:165.7,y:168.65},0).wait(1).to({scaleX:0.5719,scaleY:0.5719,x:167.6,y:167.2},0).wait(1).to({scaleX:0.5643,scaleY:0.5643,x:169.45,y:165.8},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:171.15,y:164.55},0).wait(1).to({scaleX:0.5504,scaleY:0.5504,x:172.75,y:163.35},0).wait(1).to({scaleX:0.5442,scaleY:0.5442,x:174.25,y:162.2},0).wait(1).to({scaleX:0.5385,scaleY:0.5385,x:175.65,y:161.15},0).wait(1).to({scaleX:0.5332,scaleY:0.5332,x:176.9,y:160.2},0).wait(1).to({scaleX:0.5284,scaleY:0.5284,x:178.05,y:159.35},0).wait(1).to({scaleX:0.524,scaleY:0.524,x:179.05,y:158.6},0).wait(1).to({scaleX:0.5201,scaleY:0.5201,x:180,y:157.85},0).wait(1).to({scaleX:0.5167,scaleY:0.5167,x:180.8,y:157.25},0).wait(1).to({scaleX:0.5137,scaleY:0.5137,x:181.55,y:156.7},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:182.15,y:156.25},0).wait(1).to({scaleX:0.5089,scaleY:0.5089,x:182.65,y:155.85},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:183.1,y:155.55},0).wait(1).to({scaleX:0.5058,scaleY:0.5058,x:183.4,y:155.3},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:183.65,y:155.1},0).wait(1).to({scaleX:0.5043,scaleY:0.5043,x:183.75,y:155.05},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.5042,scaleY:0.5042,x:183.9,y:155.15},0).wait(1).to({regX:28,regY:22.5,x:183.7,y:154.95},0).wait(15).to({regX:28.4,regY:22.9,x:183.9,y:155.15},0).wait(1).to({regX:28,regY:22.5,scaleX:0.5041,scaleY:0.5041,x:183.7,y:154.9},0).wait(1).to({scaleX:0.504,scaleY:0.504,y:154.85},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,y:154.75},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,y:154.65},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:183.75,y:154.5},0).wait(1).to({scaleX:0.5033,scaleY:0.5033,y:154.3},0).wait(1).to({scaleX:0.503,scaleY:0.503,x:183.8,y:154.1},0).wait(1).to({scaleX:0.5027,scaleY:0.5027,x:183.75,y:153.85},0).wait(1).to({scaleX:0.5022,scaleY:0.5022,x:183.8,y:153.6},0).wait(1).to({scaleX:0.5018,scaleY:0.5018,x:183.85,y:153.25},0).wait(1).to({scaleX:0.5012,scaleY:0.5012,x:183.9,y:152.85},0).wait(1).to({scaleX:0.5006,scaleY:0.5006,x:183.95,y:152.4},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:184,y:151.85},0).wait(1).to({scaleX:0.499,scaleY:0.499,x:184.05,y:151.3},0).wait(1).to({scaleX:0.498,scaleY:0.498,x:184.15,y:150.6},0).wait(1).to({scaleX:0.4969,scaleY:0.4969,x:184.2,y:149.8},0).wait(1).to({scaleX:0.4956,scaleY:0.4956,x:184.35,y:148.9},0).wait(1).to({scaleX:0.4941,scaleY:0.4941,x:184.45,y:147.8},0).wait(1).to({scaleX:0.4924,scaleY:0.4924,x:184.55,y:146.65},0).wait(1).to({scaleX:0.4903,scaleY:0.4903,x:184.7,y:145.15},0).wait(1).to({scaleX:0.4879,scaleY:0.4879,x:184.85,y:143.45},0).wait(1).to({scaleX:0.4849,scaleY:0.4849,x:185.1,y:141.3},0).wait(1).to({scaleX:0.4812,scaleY:0.4812,x:185.35,y:138.75},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:185.7,y:135.45},0).wait(1).to({scaleX:0.4707,scaleY:0.4707,x:186.15,y:131.3},0).wait(1).to({scaleX:0.4636,scaleY:0.4636,x:186.65,y:126.3},0).wait(1).to({scaleX:0.4562,scaleY:0.4562,x:187.15,y:121.05},0).wait(1).to({scaleX:0.4497,scaleY:0.4497,x:187.65,y:116.45},0).wait(1).to({scaleX:0.4445,scaleY:0.4445,x:188.05,y:112.8},0).wait(1).to({scaleX:0.4404,scaleY:0.4404,x:188.35,y:109.9},0).wait(1).to({scaleX:0.4371,scaleY:0.4371,x:188.6,y:107.55},0).wait(1).to({scaleX:0.4343,scaleY:0.4343,x:188.75,y:105.6},0).wait(1).to({scaleX:0.432,scaleY:0.432,x:188.95,y:103.95},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:189.1,y:102.6},0).wait(1).to({scaleX:0.4284,scaleY:0.4284,x:189.2,y:101.4},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:189.3,y:100.35},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,x:189.4,y:99.5},0).wait(1).to({scaleX:0.4245,scaleY:0.4245,x:189.5,y:98.65},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,x:189.55,y:98},0).wait(1).to({scaleX:0.4226,scaleY:0.4226,x:189.65,y:97.35},0).wait(1).to({scaleX:0.4219,scaleY:0.4219,y:96.8},0).wait(1).to({scaleX:0.4212,scaleY:0.4212,x:189.75,y:96.35},0).wait(1).to({scaleX:0.4206,scaleY:0.4206,x:189.8,y:95.9},0).wait(1).to({scaleX:0.4201,scaleY:0.4201,y:95.55},0).wait(1).to({scaleX:0.4196,scaleY:0.4196,x:189.85,y:95.2},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:189.9,y:94.95},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,y:94.65},0).wait(1).to({scaleX:0.4185,scaleY:0.4185,y:94.45},0).wait(1).to({scaleX:0.4183,scaleY:0.4183,x:189.95,y:94.25},0).wait(1).to({scaleX:0.4181,scaleY:0.4181,y:94.15},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,y:94},0).wait(1).to({scaleX:0.4178,scaleY:0.4178,x:190,y:93.9},0).wait(1).to({scaleX:0.4177,scaleY:0.4177,y:93.85},0).wait(1).to({scaleX:0.4176,scaleY:0.4176,y:93.8},0).wait(1).to({y:93.75},0).wait(1).to({regX:28.4,regY:23.1,scaleX:0.4175,scaleY:0.4175,x:190.2,y:93.95},0).wait(2));

	// l girl box shadow
	this.instance_12 = new lib.squareshadow();
	this.instance_12.setTransform(-54.5,241.45,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(9).to({_off:false},0).to({x:121.35,y:252.55,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:121.2},0).wait(19).to({regX:70.8,x:121.35},0).wait(1).to({regX:70.6,scaleX:0.6759,scaleY:0.6759,x:122.05,y:251.6,alpha:0.1585},0).wait(1).to({scaleX:0.6713,scaleY:0.6713,x:123.05,y:250.55,alpha:0.1567},0).wait(1).to({scaleX:0.6664,scaleY:0.6664,x:124.1,y:249.45,alpha:0.1548},0).wait(1).to({scaleX:0.6611,scaleY:0.6611,x:125.2,y:248.25,alpha:0.1527},0).wait(1).to({scaleX:0.6554,scaleY:0.6554,x:126.4,y:247,alpha:0.1505},0).wait(1).to({scaleX:0.6493,scaleY:0.6493,x:127.75,y:245.6,alpha:0.1481},0).wait(1).to({scaleX:0.6428,scaleY:0.6428,x:129.1,y:244.15,alpha:0.1455},0).wait(1).to({scaleX:0.636,scaleY:0.636,x:130.55,y:242.55,alpha:0.1428},0).wait(1).to({scaleX:0.6287,scaleY:0.6287,x:132.1,y:240.9,alpha:0.14},0).wait(1).to({scaleX:0.6211,scaleY:0.6211,x:133.75,y:239.2,alpha:0.137},0).wait(1).to({scaleX:0.6131,scaleY:0.6131,x:135.45,y:237.35,alpha:0.1338},0).wait(1).to({scaleX:0.6048,scaleY:0.6048,x:137.2,y:235.5,alpha:0.1306},0).wait(1).to({scaleX:0.5961,scaleY:0.5961,x:139.05,y:233.55,alpha:0.1272},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:141,y:231.5,alpha:0.1236},0).wait(1).to({scaleX:0.5778,scaleY:0.5778,x:142.95,y:229.35,alpha:0.12},0).wait(1).to({scaleX:0.5682,scaleY:0.5682,x:145,y:227.2,alpha:0.1162},0).wait(1).to({scaleX:0.5584,scaleY:0.5584,x:147.1,y:225,alpha:0.1123},0).wait(1).to({scaleX:0.5483,scaleY:0.5483,x:149.25,y:222.7,alpha:0.1083},0).wait(1).to({scaleX:0.538,scaleY:0.538,x:151.45,y:220.35,alpha:0.1043},0).wait(1).to({scaleX:0.5276,scaleY:0.5276,x:153.65,y:218,alpha:0.1002},0).wait(1).to({scaleX:0.517,scaleY:0.517,x:155.95,y:215.6,alpha:0.096},0).wait(1).to({scaleX:0.5063,scaleY:0.5063,x:158.2,y:213.2,alpha:0.0918},0).wait(1).to({scaleX:0.4955,scaleY:0.4955,x:160.5,y:210.75,alpha:0.0876},0).wait(1).to({scaleX:0.4847,scaleY:0.4847,x:162.8,y:208.3,alpha:0.0833},0).wait(1).to({scaleX:0.4739,scaleY:0.4739,x:165.1,y:205.85,alpha:0.0791},0).wait(1).to({scaleX:0.4632,scaleY:0.4632,x:167.4,y:203.45,alpha:0.0749},0).wait(1).to({scaleX:0.4525,scaleY:0.4525,x:169.65,y:201.05,alpha:0.0707},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:171.9,y:198.65,alpha:0.0665},0).wait(1).to({scaleX:0.4316,scaleY:0.4316,x:174.1,y:196.3,alpha:0.0624},0).wait(1).to({scaleX:0.4214,scaleY:0.4214,x:176.3,y:193.95,alpha:0.0584},0).wait(1).to({scaleX:0.4114,scaleY:0.4114,x:178.4,y:191.7,alpha:0.0545},0).wait(1).to({scaleX:0.4017,scaleY:0.4017,x:180.45,y:189.5,alpha:0.0507},0).wait(1).to({scaleX:0.3922,scaleY:0.3922,x:182.5,y:187.35,alpha:0.047},0).wait(1).to({scaleX:0.383,scaleY:0.383,x:184.45,y:185.25,alpha:0.0433},0).wait(1).to({scaleX:0.3742,scaleY:0.3742,x:186.3,y:183.3,alpha:0.0399},0).wait(1).to({scaleX:0.3657,scaleY:0.3657,x:188.15,y:181.35,alpha:0.0365},0).wait(1).to({scaleX:0.3575,scaleY:0.3575,x:189.9,y:179.5,alpha:0.0333},0).wait(1).to({scaleX:0.3497,scaleY:0.3497,x:191.55,y:177.7,alpha:0.0302},0).wait(1).to({scaleX:0.3423,scaleY:0.3423,x:193.15,y:176.05,alpha:0.0273},0).wait(1).to({scaleX:0.3352,scaleY:0.3352,x:194.65,y:174.4,alpha:0.0245},0).wait(1).to({scaleX:0.3285,scaleY:0.3285,x:196.1,y:172.95,alpha:0.0219},0).wait(1).to({scaleX:0.3222,scaleY:0.3222,x:197.4,y:171.5,alpha:0.0194},0).wait(1).to({scaleX:0.3163,scaleY:0.3163,x:198.7,y:170.15,alpha:0.0171},0).wait(1).to({scaleX:0.3108,scaleY:0.3108,x:199.85,y:168.9,alpha:0.0149},0).wait(1).to({scaleX:0.3057,scaleY:0.3057,x:200.95,y:167.75,alpha:0.0129},0).wait(1).to({scaleX:0.301,scaleY:0.301,x:201.95,y:166.7,alpha:0.0111},0).wait(1).to({scaleX:0.2967,scaleY:0.2967,x:202.85,y:165.75,alpha:0.0094},0).wait(1).to({scaleX:0.2927,scaleY:0.2927,x:203.65,y:164.85,alpha:0.0078},0).wait(1).to({scaleX:0.2892,scaleY:0.2892,x:204.45,y:164,alpha:0.0064},0).wait(1).to({scaleX:0.286,scaleY:0.286,x:205.15,y:163.3,alpha:0.0052},0).wait(1).to({scaleX:0.2831,scaleY:0.2831,x:205.75,y:162.65,alpha:0.004},0).wait(1).to({scaleX:0.2807,scaleY:0.2807,x:206.25,y:162.1,alpha:0.0031},0).wait(1).to({scaleX:0.2785,scaleY:0.2785,x:206.7,y:161.6,alpha:0.0022},0).wait(1).to({scaleX:0.2768,scaleY:0.2768,x:207.1,y:161.25,alpha:0.0015},0).wait(1).to({scaleX:0.2753,scaleY:0.2753,x:207.4,y:160.9,alpha:0.001},0).wait(1).to({scaleX:0.2742,scaleY:0.2742,x:207.6,y:160.65,alpha:0.0005},0).wait(1).to({scaleX:0.2735,scaleY:0.2735,x:207.8,y:160.45,alpha:0.0002},0).wait(1).to({scaleX:0.273,scaleY:0.273,x:207.85,y:160.35,alpha:0.0001},0).wait(1).to({regX:71.5,regY:48.2,scaleX:0.2728,scaleY:0.2728,x:208,alpha:0},0).wait(74));

	// r girl box shadow
	this.instance_13 = new lib.fill();
	this.instance_13.setTransform(208.3,160.35,0.8066,0.8066,0,0,0,32.6,30.2);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(124).to({_off:false},0).to({regX:32.7,regY:30.4,scaleX:0.8549,scaleY:0.8274,x:209.95,y:159.85,alpha:1},16).wait(79));

	// r guy box shadow
	this.instance_14 = new lib.squareshadow();
	this.instance_14.setTransform(249.5,5.2,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(19).to({_off:false},0).to({x:220.75,y:90.1,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:220.65},0).wait(11).to({regX:70.7,x:220.75},0).wait(1).to({regX:70.6,scaleX:0.5437,scaleY:0.5435,x:220.7,y:90.3},0).wait(1).to({scaleX:0.5416,scaleY:0.5411,x:220.75,y:90.55},0).wait(1).to({scaleX:0.5394,scaleY:0.5386,x:220.85,y:90.85},0).wait(1).to({scaleX:0.5369,scaleY:0.5358,x:220.9,y:91.1},0).wait(1).to({scaleX:0.5343,scaleY:0.5329,x:220.95,y:91.4},0).wait(1).to({scaleX:0.5315,scaleY:0.5297,x:221,y:91.75},0).wait(1).to({scaleX:0.5285,scaleY:0.5263,x:221.1,y:92.15},0).wait(1).to({scaleX:0.5253,scaleY:0.5228,x:221.25,y:92.55},0).wait(1).to({scaleX:0.522,scaleY:0.519,x:221.3,y:92.95},0).wait(1).to({scaleX:0.5184,scaleY:0.515,x:221.4,y:93.35},0).wait(1).to({scaleX:0.5148,scaleY:0.5109,x:221.5,y:93.8},0).wait(1).to({scaleX:0.5109,scaleY:0.5065,x:221.6,y:94.3},0).wait(1).to({scaleX:0.5069,scaleY:0.502,x:221.75,y:94.8},0).wait(1).to({scaleX:0.5027,scaleY:0.4974,x:221.85,y:95.25},0).wait(1).to({scaleX:0.4984,scaleY:0.4925,x:221.95,y:95.8},0).wait(1).to({scaleX:0.494,scaleY:0.4875,x:222.1,y:96.35},0).wait(1).to({scaleX:0.4895,scaleY:0.4824,x:222.2,y:96.9},0).wait(1).to({scaleX:0.4848,scaleY:0.4772,x:222.35,y:97.45},0).wait(1).to({scaleX:0.4801,scaleY:0.4718,x:222.5,y:98.05},0).wait(1).to({scaleX:0.4752,scaleY:0.4664,x:222.6,y:98.65},0).wait(1).to({scaleX:0.4703,scaleY:0.4609,x:222.75,y:99.25},0).wait(1).to({scaleX:0.4654,scaleY:0.4553,x:222.85,y:99.85},0).wait(1).to({scaleX:0.4604,scaleY:0.4497,x:223,y:100.45},0).wait(1).to({scaleX:0.4554,scaleY:0.4441,x:223.15,y:101.1},0).wait(1).to({scaleX:0.4505,scaleY:0.4385,x:223.3,y:101.65},0).wait(1).to({scaleX:0.4455,scaleY:0.4329,x:223.4,y:102.3},0).wait(1).to({scaleX:0.4406,scaleY:0.4274,x:223.55,y:102.9},0).wait(1).to({scaleX:0.4357,scaleY:0.4219,x:223.7,y:103.45},0).wait(1).to({scaleX:0.4309,scaleY:0.4165,x:223.8,y:104.05},0).wait(1).to({scaleX:0.4262,scaleY:0.4112,x:223.95,y:104.6},0).wait(1).to({scaleX:0.4216,scaleY:0.406,x:224.05,y:105.2},0).wait(1).to({scaleX:0.4171,scaleY:0.401,x:224.2,y:105.7},0).wait(1).to({scaleX:0.4127,scaleY:0.396,x:224.35,y:106.3},0).wait(1).to({scaleX:0.4085,scaleY:0.3913,x:224.45,y:106.8},0).wait(1).to({scaleX:0.4044,scaleY:0.3867,x:224.55,y:107.3},0).wait(1).to({scaleX:0.4005,scaleY:0.3822,x:224.65,y:107.75},0).wait(1).to({scaleX:0.3967,scaleY:0.378,x:224.75,y:108.2},0).wait(1).to({scaleX:0.3931,scaleY:0.3739,x:224.9,y:108.65},0).wait(1).to({scaleX:0.3897,scaleY:0.3701,x:224.95,y:109.1},0).wait(1).to({scaleX:0.3864,scaleY:0.3664,x:225.1,y:109.45},0).wait(1).to({scaleX:0.3833,scaleY:0.3629,x:225.15,y:109.85},0).wait(1).to({scaleX:0.3804,scaleY:0.3597,x:225.2,y:110.2},0).wait(1).to({scaleX:0.3777,scaleY:0.3566,x:225.3,y:110.55},0).wait(1).to({scaleX:0.3752,scaleY:0.3537,x:225.4,y:110.85},0).wait(1).to({scaleX:0.3728,scaleY:0.3511,y:111.15},0).wait(1).to({scaleX:0.3706,scaleY:0.3486,x:225.5,y:111.4},0).wait(1).to({scaleX:0.3686,scaleY:0.3464,x:225.55,y:111.65},0).wait(1).to({scaleX:0.3668,scaleY:0.3443,x:225.6,y:111.85},0).wait(1).to({scaleX:0.3651,scaleY:0.3425,x:225.7,y:112.05},0).wait(1).to({scaleX:0.3637,scaleY:0.3408,x:225.65,y:112.25},0).wait(1).to({scaleX:0.3624,scaleY:0.3393,x:225.75,y:112.4},0).wait(1).to({scaleX:0.3612,scaleY:0.338,y:112.55},0).wait(1).to({scaleX:0.3602,scaleY:0.3369,x:225.8,y:112.65},0).wait(1).to({scaleX:0.3594,scaleY:0.336,y:112.75},0).wait(1).to({scaleX:0.3588,scaleY:0.3353,x:225.85,y:112.85},0).wait(1).to({scaleX:0.3582,scaleY:0.3347,y:112.9},0).wait(1).to({scaleX:0.3579,scaleY:0.3343,y:113},0).wait(1).to({scaleX:0.3577,scaleY:0.3341,y:112.95},0).wait(1).to({regX:71,regY:48.4,scaleX:0.3576,scaleY:0.334,x:225.9,y:113},0).wait(79));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(54.35,135.65,0.2637,0.2637,0,0,0,225.1,236.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(70).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(11).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(1).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(58).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(79));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(125.4,140.2,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(17).to({regY:15.2,scaleX:0.7599,scaleY:0.7599,x:107.45,y:147.55},28,cjs.Ease.quadInOut).wait(25).to({regX:38,x:107.55},0).wait(11).to({regX:37.9,x:107.45},0).wait(1).to({regX:38,x:107.55},0).wait(58).to({regX:37.9,x:107.45},0).wait(79));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(120.3,143.35,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(17).to({regX:37.7,regY:15.7,scaleX:0.7718,scaleY:0.7718,x:107.45,y:147.55},28,cjs.Ease.quadInOut).to({alpha:0},24,cjs.Ease.quadOut).to({_off:true},1).wait(149));

	// first image
	this.instance_15 = new lib.firstimage_1();
	this.instance_15.setTransform(234.9,125.55,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(23).to({regX:42,regY:26.6,scaleX:0.576,scaleY:0.576,x:238.05,y:134.35},30,cjs.Ease.quadInOut).wait(17).to({regY:26.5,y:134.3},0).wait(11).to({regY:26.6,y:134.35},0).wait(1).to({regY:26.5,y:134.3},0).wait(58).to({regY:26.6,y:134.35},0).wait(79));

	// square shadow
	this.instance_16 = new lib.squareshadow();
	this.instance_16.setTransform(233.35,129.15,0.4651,0.4621,0,0,0,71,48);
	this.instance_16.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(23).to({regX:71.2,regY:48.2,scaleX:0.325,scaleY:0.3131,x:237.85,y:134.45},30,cjs.Ease.quadInOut).to({_off:true},1).wait(165));

	// second image
	this.instance_17 = new lib.secondimage_1();
	this.instance_17.setTransform(249.4,152.25,0.7473,0.7473,0,0,0,41.9,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(27).to({regX:42,regY:26.4,scaleX:0.5752,scaleY:0.5752,y:155.4},30,cjs.Ease.quadInOut).wait(13).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(11).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(1).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(58).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(79));

	// square shadow
	this.instance_18 = new lib.squareshadow();
	this.instance_18.setTransform(248.05,156.75,0.4651,0.4621,0,0,0,70.9,48.1);
	this.instance_18.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(27).to({regX:71.2,regY:48.4,scaleX:0.3475,scaleY:0.2831,x:249.5,y:156},30,cjs.Ease.quadInOut).to({_off:true},1).wait(161));

	// screen
	this.instance_19 = new lib.WordUI();
	this.instance_19.setTransform(178.55,155.6,0.8368,0.8368,0,0,0,151,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(70).to({regY:96,y:155.7},0).wait(11).to({regY:95.9,y:155.6},0).wait(1).to({regY:96,y:155.7},0).wait(58).to({regY:95.9,y:155.6},0).wait(79));

	// screen shadow
	this.instance_20 = new lib.shadow_1();
	this.instance_20.setTransform(179.9,132.35,0.888,0.888,0,0,0,180.6,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(70).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(11).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(1).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(58).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(79));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.9,-72.1,1909.3000000000002,395.9);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-30.5,2.6,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Am6B7IAAj1IN1AAIAAD1g");
	this.shape.setTransform(-59.375,2.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-10.1,88.7,24.6), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(123.05,286,0.77,0.77,0,0,0,196.9,130.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(146.1,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(100.7,569.9,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(177.7,567.3,1.136,1.136,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(80.1,719.15,0.5342,2.3964,0,0,0,150,300.1);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-601,-11.4,1458.1,617.3), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		//var ribbon = mc.ribbon;
		
		
		
		this.runBanner = function() {
			
			this.tl1 = gsap.timeline();
						
				exportRoot.tl1.from(screen, 1, { alpha: 0, x: "+=129",y: "+=250", ease:Power3.easeOut,
					onStart: function() {screen.gotoAndPlay(1);},
					onComplete: function() {exportRoot.tl1.pause();}
				}, "+=0.5");
				
				
				exportRoot.tl1.to(screen, 1.475, {x: "-=0",y: "-=0",scaleX: 0.77,scaleY: 0.77, ease:Power1.easeInOut}, "+=0");
				exportRoot.tl1.to(screen, 1.5, {x: "-=0",y: "+=0",scaleX: 0.77,scaleY: 0.77, ease:Power3.easeInOut}, "+=0.1");
		
			
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.pause();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(45,288.6,204.7,317.29999999999995);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1.png?1613665710530", id:"M365_FY21Q3ConsOpt_USA_160x600_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;