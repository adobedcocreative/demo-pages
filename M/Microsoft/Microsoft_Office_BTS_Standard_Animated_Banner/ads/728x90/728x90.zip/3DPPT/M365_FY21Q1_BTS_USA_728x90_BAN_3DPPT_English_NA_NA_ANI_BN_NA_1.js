(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[895,202,100,147],[0,212,100,147],[102,212,100,147],[204,212,100,147],[306,212,100,147],[408,212,100,147],[510,212,100,147],[895,351,100,147],[0,361,100,147],[102,361,100,147],[204,361,100,147],[306,361,100,147],[408,361,100,147],[510,361,100,147],[779,385,100,147],[612,390,100,147],[779,202,114,181],[0,0,625,210],[0,510,100,80],[627,202,150,186],[881,500,110,109],[627,0,300,200]]}
];


// symbols:



(lib._0090 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._0092 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._0094 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._0096 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._0098 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._0100 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._0102 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._0104 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib._0106 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib._0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib._0110 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib._0112 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib._0114 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib._0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib._0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib._0120 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.bodyResize = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.grass = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Icon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.leafA = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.LeafB = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4OAWyMAAAgtjMFwdAAAMAAAAtjg");
	this.shape.setTransform(0.0046,0.0301);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1179.1,-145.7,2358.3,291.5);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.shdw_test = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A//s6ImaABIADvVIPFgCIABIpMA9fgAFMAALAvzMhGnAAKg");
	this.shape.setTransform(245.825,180.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shdw_test, new cjs.Rectangle(0,0,491.7,361.8), null);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AFQhgICzg9IDjKTIizA+g");
	var mask_graphics_69 = new cjs.Graphics().p("AhQhgIP2ldIDjKUIv2Fcg");
	var mask_graphics_70 = new cjs.Graphics().p("AmkglIagpIIDjKTI6gJIg");
	var mask_graphics_71 = new cjs.Graphics().p("Aq1A4MAjEgMDIDjKUMgjEAMDg");
	var mask_graphics_72 = new cjs.Graphics().p("AuJCBMAptgOWIDjKVMgptAOWg");
	var mask_graphics_73 = new cjs.Graphics().p("AwpC5MAuugQFIDjKUMguuAQFg");
	var mask_graphics_74 = new cjs.Graphics().p("AybDgMAyTgRTIDjKUMgyTARTg");
	var mask_graphics_75 = new cjs.Graphics().p("AzoD7MA0tgSJIDjKUMg0tASJg");
	var mask_graphics_76 = new cjs.Graphics().p("A0XELMA2LgSpIDjKUMg2KASpg");
	var mask_graphics_77 = new cjs.Graphics().p("A0uETMA26gS5IDjKUMg26AS5g");
	var mask_graphics_78 = new cjs.Graphics().p("A03EWMA3LgS/IDkKUMg3MAS/g");
	var mask_graphics_79 = new cjs.Graphics().p("A02EWMA3OgTAIDjKVMg3OATAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:74.2362,y:56.3603}).wait(1).to({graphics:mask_graphics_69,x:116.0844,y:56.3321}).wait(1).to({graphics:mask_graphics_70,x:150.3449,y:50.4122}).wait(1).to({graphics:mask_graphics_71,x:177.7773,y:40.9569}).wait(1).to({graphics:mask_graphics_72,x:199.1409,y:33.5907}).wait(1).to({graphics:mask_graphics_73,x:215.1947,y:28.0538}).wait(1).to({graphics:mask_graphics_74,x:226.6976,y:24.0857}).wait(1).to({graphics:mask_graphics_75,x:234.4082,y:21.4254}).wait(1).to({graphics:mask_graphics_76,x:239.085,y:19.8116}).wait(1).to({graphics:mask_graphics_77,x:241.4867,y:18.9829}).wait(1).to({graphics:mask_graphics_78,x:242.3715,y:18.6776}).wait(1).to({graphics:mask_graphics_79,x:242.7278,y:18.4102}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(224.297,66.8157,0.8028,0.8028);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_68 = new cjs.Graphics().p("AFQhgICzg9IDjKTIizA+g");
	var mask_1_graphics_69 = new cjs.Graphics().p("AhQhgIP2ldIDjKUIv2Fcg");
	var mask_1_graphics_70 = new cjs.Graphics().p("AmkglIagpIIDjKTI6gJIg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Aq1A4MAjEgMDIDjKUMgjEAMDg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AuJCBMAptgOWIDjKVMgptAOWg");
	var mask_1_graphics_73 = new cjs.Graphics().p("AwpC5MAuugQFIDjKUMguuAQFg");
	var mask_1_graphics_74 = new cjs.Graphics().p("AybDgMAyTgRTIDjKUMgyTARTg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AzoD7MA0tgSJIDjKUMg0tASJg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A0XELMA2LgSpIDjKUMg2KASpg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A0uETMA26gS5IDjKUMg26AS5g");
	var mask_1_graphics_78 = new cjs.Graphics().p("A03EWMA3LgS/IDkKUMg3MAS/g");
	var mask_1_graphics_79 = new cjs.Graphics().p("A02EWMA3OgTAIDjKVMg3OATAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_1_graphics_68,x:74.2362,y:56.3603}).wait(1).to({graphics:mask_1_graphics_69,x:116.0844,y:56.3321}).wait(1).to({graphics:mask_1_graphics_70,x:150.3449,y:50.4122}).wait(1).to({graphics:mask_1_graphics_71,x:177.7773,y:40.9569}).wait(1).to({graphics:mask_1_graphics_72,x:199.1409,y:33.5907}).wait(1).to({graphics:mask_1_graphics_73,x:215.1947,y:28.0538}).wait(1).to({graphics:mask_1_graphics_74,x:226.6976,y:24.0857}).wait(1).to({graphics:mask_1_graphics_75,x:234.4082,y:21.4254}).wait(1).to({graphics:mask_1_graphics_76,x:239.085,y:19.8116}).wait(1).to({graphics:mask_1_graphics_77,x:241.4867,y:18.9829}).wait(1).to({graphics:mask_1_graphics_78,x:242.3715,y:18.6776}).wait(1).to({graphics:mask_1_graphics_79,x:242.7278,y:18.4102}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(298.4807,12.7041,0.8037,0.8037);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_58 = new cjs.Graphics().p("AdGHzIACq5IApAAIgDK5g");
	var mask_2_graphics_59 = new cjs.Graphics().p("Ac/HzIACq5IAwAAIgDK5g");
	var mask_2_graphics_60 = new cjs.Graphics().p("AcNHzIACq5IBhAAIgCK5g");
	var mask_2_graphics_61 = new cjs.Graphics().p("AaGHzIACq5IDoAAIgCK5g");
	var mask_2_graphics_62 = new cjs.Graphics().p("AV/HyIADq5IHtABIgDK5g");
	var mask_2_graphics_63 = new cjs.Graphics().p("APOHxIACq5IOdACIgCK5g");
	var mask_2_graphics_64 = new cjs.Graphics().p("AGCHvIACq5IXnAEIgDK5g");
	var mask_2_graphics_65 = new cjs.Graphics().p("AgvHuIADq6IeVAGIgCK5g");
	var mask_2_graphics_66 = new cjs.Graphics().p("Ak1HsIACq5MAibAAHIgCK5g");
	var mask_2_graphics_67 = new cjs.Graphics().p("Am8HsIACq6MAkhAAIIgCK5g");
	var mask_2_graphics_68 = new cjs.Graphics().p("AnuHrIACq5MAlTAAIIgCK5g");
	var mask_2_graphics_69 = new cjs.Graphics().p("AnvHrIACq5MAlaAAIIgCK5g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_2_graphics_58,x:190.4696,y:49.925}).wait(1).to({graphics:mask_2_graphics_59,x:190.4668,y:49.9252}).wait(1).to({graphics:mask_2_graphics_60,x:190.4468,y:49.9253}).wait(1).to({graphics:mask_2_graphics_61,x:190.3926,y:49.9256}).wait(1).to({graphics:mask_2_graphics_62,x:190.2871,y:49.9263}).wait(1).to({graphics:mask_2_graphics_63,x:190.1131,y:49.9272}).wait(1).to({graphics:mask_2_graphics_64,x:189.8772,y:49.9282}).wait(1).to({graphics:mask_2_graphics_65,x:189.7032,y:49.9288}).wait(1).to({graphics:mask_2_graphics_66,x:189.5977,y:49.9291}).wait(1).to({graphics:mask_2_graphics_67,x:189.5435,y:49.9293}).wait(1).to({graphics:mask_2_graphics_68,x:189.5235,y:49.9293}).wait(1).to({graphics:mask_2_graphics_69,x:190.1196,y:49.9}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(295.2858,66.9767,0.8037,0.8037);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_58 = new cjs.Graphics().p("AdGHzIACq5IApAAIgDK5g");
	var mask_3_graphics_59 = new cjs.Graphics().p("Ac/HzIACq5IAwAAIgDK5g");
	var mask_3_graphics_60 = new cjs.Graphics().p("AcNHzIACq5IBhAAIgCK5g");
	var mask_3_graphics_61 = new cjs.Graphics().p("AaGHzIACq5IDoAAIgCK5g");
	var mask_3_graphics_62 = new cjs.Graphics().p("AV/HyIADq5IHtABIgDK5g");
	var mask_3_graphics_63 = new cjs.Graphics().p("APOHxIACq5IOdACIgCK5g");
	var mask_3_graphics_64 = new cjs.Graphics().p("AGCHvIACq5IXnAEIgDK5g");
	var mask_3_graphics_65 = new cjs.Graphics().p("AgvHuIADq6IeVAGIgCK5g");
	var mask_3_graphics_66 = new cjs.Graphics().p("Ak1HsIACq5MAibAAHIgCK5g");
	var mask_3_graphics_67 = new cjs.Graphics().p("Am8HsIACq6MAkhAAIIgCK5g");
	var mask_3_graphics_68 = new cjs.Graphics().p("AnuHrIACq5MAlTAAIIgCK5g");
	var mask_3_graphics_69 = new cjs.Graphics().p("AnvHrIACq5MAlaAAIIgCK5g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_3_graphics_58,x:190.4696,y:49.925}).wait(1).to({graphics:mask_3_graphics_59,x:190.4668,y:49.9252}).wait(1).to({graphics:mask_3_graphics_60,x:190.4468,y:49.9253}).wait(1).to({graphics:mask_3_graphics_61,x:190.3926,y:49.9256}).wait(1).to({graphics:mask_3_graphics_62,x:190.2871,y:49.9263}).wait(1).to({graphics:mask_3_graphics_63,x:190.1131,y:49.9272}).wait(1).to({graphics:mask_3_graphics_64,x:189.8772,y:49.9282}).wait(1).to({graphics:mask_3_graphics_65,x:189.7032,y:49.9288}).wait(1).to({graphics:mask_3_graphics_66,x:189.5977,y:49.9291}).wait(1).to({graphics:mask_3_graphics_67,x:189.5435,y:49.9293}).wait(1).to({graphics:mask_3_graphics_68,x:189.5235,y:49.9293}).wait(1).to({graphics:mask_3_graphics_69,x:190.1196,y:49.9}).wait(11));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(259.4792,66.9767,0.8037,0.8037);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_29 = new cjs.Graphics().p("An8JNIMVkQIDkKUIsVEQg");
	var mask_4_graphics_30 = new cjs.Graphics().p("Ap1JNIQIlkIDjKUIwIFkg");
	var mask_4_graphics_31 = new cjs.Graphics().p("ArtJNIT4m3IDjKUIz4G3g");
	var mask_4_graphics_32 = new cjs.Graphics().p("AtjJMIXkoHIDjKUI3kIIg");
	var mask_4_graphics_33 = new cjs.Graphics().p("AvWJMIbKpVIDjKTI7KJWg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AxEJMIemqhIDjKTI+mKig");
	var mask_4_graphics_35 = new cjs.Graphics().p("AytJMMAh4gLqIDjKTMgh4ALrg");
	var mask_4_graphics_36 = new cjs.Graphics().p("A0QJMMAk+gMuIDjKTMgk+AMvg");
	var mask_4_graphics_37 = new cjs.Graphics().p("A1tJMMAn4gNuIDjKTMgn4ANvg");
	var mask_4_graphics_38 = new cjs.Graphics().p("A3EJMMAqmgOqIDjKTMgqmAOrg");
	var mask_4_graphics_39 = new cjs.Graphics().p("A4UJLMAtGgPgIDjKTMgtGAPig");
	var mask_4_graphics_40 = new cjs.Graphics().p("A5eJLMAvZgQTIDkKTMgvZAQVg");
	var mask_4_graphics_41 = new cjs.Graphics().p("A6hJLMAxggRCIDjKTMgxgARDg");
	var mask_4_graphics_42 = new cjs.Graphics().p("A7gJLMAzdgRtIDkKUMgzdARtg");
	var mask_4_graphics_43 = new cjs.Graphics().p("A8YJLMA1OgSUIDjKTMg1OASVg");
	var mask_4_graphics_44 = new cjs.Graphics().p("A9NJLMA23gS4IDkKTMg23AS5g");
	var mask_4_graphics_45 = new cjs.Graphics().p("A98JLMA4WgTZIDjKTMg4WATag");
	var mask_4_graphics_46 = new cjs.Graphics().p("A+oJLMA5tgT3IDkKUMg5tAT3g");
	var mask_4_graphics_47 = new cjs.Graphics().p("A/PJLMA68gUSIDjKUMg68AUSg");
	var mask_4_graphics_48 = new cjs.Graphics().p("A/0JLMA8FgUrIDkKUMg8FAUrg");
	var mask_4_graphics_49 = new cjs.Graphics().p("EggVAJLMA9IgVCIDjKUMg9IAVCg");
	var mask_4_graphics_50 = new cjs.Graphics().p("EggzAJLMA+EgVXIDjKUMg+EAVXg");
	var mask_4_graphics_51 = new cjs.Graphics().p("EghPAJLMA+7gVqIDkKUMg+7AVqg");
	var mask_4_graphics_52 = new cjs.Graphics().p("EghoAJLMA/tgV7IDkKUMg/tAV7g");
	var mask_4_graphics_53 = new cjs.Graphics().p("Egh+AJLMBAagWLIDjKUMhAaAWLg");
	var mask_4_graphics_54 = new cjs.Graphics().p("EgiTAJLMBBEgWZIDjKUMhBEAWZg");
	var mask_4_graphics_55 = new cjs.Graphics().p("EgimAJLMBBqgWmIDjKUMhBqAWmg");
	var mask_4_graphics_56 = new cjs.Graphics().p("Egi3AJLMBCMgWyIDjKUMhCMAWyg");
	var mask_4_graphics_57 = new cjs.Graphics().p("EgjGAJLMBCqgW8IDjKUMhCqAW8g");
	var mask_4_graphics_58 = new cjs.Graphics().p("EgjUAJLMBDGgXGIDjKUMhDGAXGg");
	var mask_4_graphics_59 = new cjs.Graphics().p("EgjhAJLMBDfgXPIDkKVMhDfAXOg");
	var mask_4_graphics_60 = new cjs.Graphics().p("EgjsAJLMBD1gXWIDkKUMhD1AXWg");
	var mask_4_graphics_61 = new cjs.Graphics().p("Egj1AJLMBEIgXcIDjKUMhEIAXcg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_4_graphics_29,x:-18.5744,y:124.9103}).wait(1).to({graphics:mask_4_graphics_30,x:-6.3428,y:124.8939}).wait(1).to({graphics:mask_4_graphics_31,x:5.7744,y:124.8777}).wait(1).to({graphics:mask_4_graphics_32,x:17.6657,y:124.8618}).wait(1).to({graphics:mask_4_graphics_33,x:29.2192,y:124.8463}).wait(1).to({graphics:mask_4_graphics_34,x:40.3317,y:124.8315}).wait(1).to({graphics:mask_4_graphics_35,x:50.9165,y:124.8173}).wait(1).to({graphics:mask_4_graphics_36,x:60.9089,y:124.804}).wait(1).to({graphics:mask_4_graphics_37,x:70.2687,y:124.7915}).wait(1).to({graphics:mask_4_graphics_38,x:78.9787,y:124.7798}).wait(1).to({graphics:mask_4_graphics_39,x:87.0416,y:124.769}).wait(1).to({graphics:mask_4_graphics_40,x:94.4751,y:124.7591}).wait(1).to({graphics:mask_4_graphics_41,x:101.3077,y:124.75}).wait(1).to({graphics:mask_4_graphics_42,x:107.5743,y:124.7416}).wait(1).to({graphics:mask_4_graphics_43,x:113.3129,y:124.7339}).wait(1).to({graphics:mask_4_graphics_44,x:118.5627,y:124.7269}).wait(1).to({graphics:mask_4_graphics_45,x:123.3619,y:124.7205}).wait(1).to({graphics:mask_4_graphics_46,x:127.747,y:124.7146}).wait(1).to({graphics:mask_4_graphics_47,x:131.7522,y:124.7093}).wait(1).to({graphics:mask_4_graphics_48,x:135.409,y:124.7044}).wait(1).to({graphics:mask_4_graphics_49,x:138.7463,y:124.6999}).wait(1).to({graphics:mask_4_graphics_50,x:141.7906,y:124.6958}).wait(1).to({graphics:mask_4_graphics_51,x:144.5656,y:124.6921}).wait(1).to({graphics:mask_4_graphics_52,x:147.0929,y:124.6887}).wait(1).to({graphics:mask_4_graphics_53,x:149.3921,y:124.6857}).wait(1).to({graphics:mask_4_graphics_54,x:151.4809,y:124.6829}).wait(1).to({graphics:mask_4_graphics_55,x:153.375,y:124.6803}).wait(1).to({graphics:mask_4_graphics_56,x:155.089,y:124.6781}).wait(1).to({graphics:mask_4_graphics_57,x:156.6358,y:124.676}).wait(1).to({graphics:mask_4_graphics_58,x:158.0273,y:124.6741}).wait(1).to({graphics:mask_4_graphics_59,x:159.2743,y:124.6725}).wait(1).to({graphics:mask_4_graphics_60,x:160.3864,y:124.671}).wait(1).to({graphics:mask_4_graphics_61,x:161.1379,y:124.7103}).wait(19));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.008)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_4.setTransform(266.9194,-0.1638,1.2468,1.2468);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_5.setTransform(173.6597,138.7307,0.8037,0.8037);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_5}]},29).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-156,480,392.6);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bodyResize();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(0,0,114,181), null);


(lib.mscopy_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mscopy_white, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mountain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384449").s().p("EglVASTIAA/QQAXgeAigIQAVgGAMAOQAHAKAMAEQAJAEAOgBIAegBQARAAAMgCQAhgEAaAJQAPAGAZgCQAkgEAFABQAWAAAmgIQApgIATAAQAWAAAngGQAsgHARgBQAKAAAPAEQAuANAlgLQAZgIAYAaQAHAJAJAEQAHAFAMACQAZAGAgANIA4AYQAIADAHAJIAMASQAtBIA8AkIAfAVQASAOAOAGIAQAJQAJAGAIACQAFABAFAJIAJAQIAFAHIAFAIQAJAJAIABQAJABAJgIIAZgUQAPgMAIgKQAFgGAOgIIAbgOQATgIAIgGQASgLASAEQAPAEARAOIAiAbQAXARAMAKQAGAGAGABQAHABAHgFQAHgFAIABQAHABAIAFQATALAOACQASABAPgMQAIgHAIADQANADATgDIAggGIAVgCQAMAAAJADQAIACAFgCQAegNAiADQAZACAnAMQAMADAKgCQALgDAHgIQAIgJANgMIAWgVQALgMAPgFQAPgFAQADQAgAGA8ABQBAABAeAEQAIACANgGQAZgMAYAWQANALAFAHQAKANALAGQAMAHAPgBQANgBAOAPQAOAMAIAGQAOAJANACQADABACACQANANAUAJIAmANQAOAFAOAUQALAOANAGQAuAWAmAHQAtAIAqgMQAIgCAIACIAPADQASAFAMgEQAOgEAMgPQANgRArg0QAlgqASgcIADgEQAUgMALgbIARgwQAKgXAPgPQARgSAZgNQATgLAdgLQAogPAcgYQAIgHANgOIAUgVQAYgWAfgCQAYgBARACQAVACASAHQAHADAGgDIAJgJIAfgiQATgTARgLQAhgVAegIQAPgEATgKIAfgQQAGgDAFgIQAUgeApgfIAlghIAlggQARgNAKgBQALgBAQAKQAIAGARAGQARAIAJAFQAKAGANgKQAVgRAQgJQAWgLAWgDQAEAAAGgDIAJgGQAZgNAWAHQAOAFASgBQAZgBAYAJQAYAJAQgLQAMgIANgBQALgBAQABQAiAEAcgDQAzgHAvAXQAmATAlgIQATgDASABQASAAAVAGQAxAMApABQAyABAqgOQAdgKAkgHQAcgFAngEQAHgBAIgDIAQgHQARgHAKgBQAPgBALALMAAAAkag");
	this.shape.setTransform(238.95,117.0458);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain, new cjs.Rectangle(0,0,477.9,234.1), null);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(149.3963,50.3104,2.1141,2.1192);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(149.396,50.2624,2.1141,2.1192);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],7.6,44.8,0,7.6,44.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(149.3963,67.5819,2.1141,2.1192);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(-214.6,-84.1,728.1,286.1), null);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LeafB();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110,109), null);


(lib.leafA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA();
	this.instance.setTransform(0,0,1.32,1.32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA_1, new cjs.Rectangle(0,0,198,245.5), null);


(lib.Icon_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon();
	this.instance.setTransform(1.1,-6.45,1.6,1.6,0.0005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon_1, new cjs.Rectangle(1.1,-6.4,160,128), null);


(lib.grass_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.grass();
	this.instance.setTransform(-191.6,-181.5,1.1655,1.1655);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass_1, new cjs.Rectangle(-191.6,-181.5,728.5,244.8), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DinoHead copy
	this.instance = new lib._0090();
	this.instance.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_1 = new lib._0092();
	this.instance_1.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_2 = new lib._0094();
	this.instance_2.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_3 = new lib._0096();
	this.instance_3.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_4 = new lib._0098();
	this.instance_4.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_5 = new lib._0100();
	this.instance_5.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_6 = new lib._0102();
	this.instance_6.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_7 = new lib._0104();
	this.instance_7.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_8 = new lib._0106();
	this.instance_8.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_9 = new lib._0108();
	this.instance_9.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_10 = new lib._0110();
	this.instance_10.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_11 = new lib._0112();
	this.instance_11.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_12 = new lib._0114();
	this.instance_12.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_13 = new lib._0116();
	this.instance_13.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_14 = new lib._0118();
	this.instance_14.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_15 = new lib._0120();
	this.instance_15.setTransform(1.95,42.35,0.8906,0.8906);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_15}]},24).to({state:[]},1).to({state:[{t:this.instance_15}]},4).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_10}]},3).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[]},1).to({state:[{t:this.instance_15}]},7).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(30).to({_off:false},0).wait(24).to({_off:true},1).wait(4).to({_off:false},0).wait(1).to({_off:true},2).wait(35).to({_off:false},0).wait(7));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2,42.4,89,130.9);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(363.9999,44.9936,2.4267,0.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,728,90), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.screenshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// shadow
	this.instance = new lib.shdw_test();
	this.instance.setTransform(109.45,222.95,0.4665,0.4275,0,0,0,245.6,181.1);
	this.instance.alpha = 0.3008;
	this.instance.filters = [new cjs.BlurFilter(40, 40, 3)];
	this.instance.cache(-2,-2,496,366);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(-59.1,91.6,341,267), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim_White = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.mscopy_white();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_White, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// WhiteLogo
	this.msoftLogoWhite = new lib.MSFT_Logo_anim_White();
	this.msoftLogoWhite.name = "msoftLogoWhite";
	this.msoftLogoWhite.setTransform(222.05,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.msoftLogoWhite.alpha = 0;
	this.msoftLogoWhite._off = true;

	this.timeline.addTween(cjs.Tween.get(this.msoftLogoWhite).wait(59).to({_off:false},0).to({regX:-0.1,regY:0.5,scaleX:2.3379,scaleY:2.3379,x:-709.25,y:265.7,alpha:1},41,cjs.Ease.quadInOut).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.5,scaleX:2.3379,scaleY:2.3379,x:-709.25,y:265.7},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.3,337.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-879.8,-68.3,2358.3,813);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg_mountain
	this.mountain = new lib.mountain();
	this.mountain.name = "mountain";
	this.mountain.setTransform(155.4,95.45,1,1,0,0,0,239,117);

	this.timeline.addTween(cjs.Tween.get(this.mountain).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(-83.6,-21.5,477.9,234.1), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,728,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,728,90), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-32.25,2.6,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Am6CCIAAkEIN1AAIAAEEg");
	this.shape.setTransform(-59.375,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-10.8,88.7,26.1), null);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_graphics_79 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_graphics_80 = new cjs.Graphics().p("Eg46AfSMAAAg+jMBx1AAAMAAAA+jg");
	var mask_graphics_81 = new cjs.Graphics().p("Eg4zAfOMAAAg+bMBxnAAAMAAAA+bg");
	var mask_graphics_82 = new cjs.Graphics().p("Eg4pAfIMAAAg+PMBxTAAAMAAAA+Pg");
	var mask_graphics_83 = new cjs.Graphics().p("Eg4cAfBMAAAg+BMBw5AAAMAAAA+Bg");
	var mask_graphics_84 = new cjs.Graphics().p("Eg4MAe3MAAAg9tMBwZAAAMAAAA9tg");
	var mask_graphics_85 = new cjs.Graphics().p("Eg35AerMAAAg9VMBvzAAAMAAAA9Vg");
	var mask_graphics_86 = new cjs.Graphics().p("Eg3iAeeMAAAg87MBvFAAAMAAAA87g");
	var mask_graphics_87 = new cjs.Graphics().p("Eg3IAeOMAAAg8bMBuRAAAMAAAA8bg");
	var mask_graphics_88 = new cjs.Graphics().p("Eg2qAd8MAAAg73MBtVAAAMAAAA73g");
	var mask_graphics_89 = new cjs.Graphics().p("Eg2IAdoMAAAg7PMBsRAAAMAAAA7Pg");
	var mask_graphics_90 = new cjs.Graphics().p("Eg1iAdRMAAAg6hMBrFAAAMAAAA6hg");
	var mask_graphics_91 = new cjs.Graphics().p("Eg04Ac4MAAAg5vMBpxAAAMAAAA5vg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg0KAcdMAAAg45MBoVAAAMAAAA45g");
	var mask_graphics_93 = new cjs.Graphics().p("EgzYAb/MAAAg39MBmxAAAMAAAA39g");
	var mask_graphics_94 = new cjs.Graphics().p("EgyhAbeMAAAg27MBlDAAAMAAAA27g");
	var mask_graphics_95 = new cjs.Graphics().p("EgxnAa7MAAAg11MBjPAAAMAAAA11g");
	var mask_graphics_96 = new cjs.Graphics().p("EgwoAaWMAAAg0rMBhRAAAMAAAA0rg");
	var mask_graphics_97 = new cjs.Graphics().p("EgvlAZuMAAAgzbMBfLAAAMAAAAzbg");
	var mask_graphics_98 = new cjs.Graphics().p("EgufAZEMAAAgyHMBc/AAAMAAAAyHg");
	var mask_graphics_99 = new cjs.Graphics().p("EgtWAYYMAAAgwvMBatAAAMAAAAwvg");
	var mask_graphics_100 = new cjs.Graphics().p("EgsKAXrMAAAgvVMBYVAAAMAAAAvVg");
	var mask_graphics_101 = new cjs.Graphics().p("Egq7AW8MAAAgt3MBV3AAAMAAAAt3g");
	var mask_graphics_102 = new cjs.Graphics().p("EgprAWMMAAAgsXMBTXAAAMAAAAsXg");
	var mask_graphics_103 = new cjs.Graphics().p("EgoaAVbMAAAgq1MBQ1AAAMAAAAq1g");
	var mask_graphics_104 = new cjs.Graphics().p("EgnIAUqMAAAgpTMBORAAAMAAAApTg");
	var mask_graphics_105 = new cjs.Graphics().p("Egl2AT5MAAAgnxMBLtAAAMAAAAnxg");
	var mask_graphics_106 = new cjs.Graphics().p("EgklATJMAAAgmRMBJLAAAMAAAAmRg");
	var mask_graphics_107 = new cjs.Graphics().p("EgjWASaMAAAgkzMBGtAAAMAAAAkzg");
	var mask_graphics_108 = new cjs.Graphics().p("EgiJARsMAAAgjXMBETAAAMAAAAjXg");
	var mask_graphics_109 = new cjs.Graphics().p("Egg+AQ/MAAAgh9MBB9AAAMAAAAh9g");
	var mask_graphics_110 = new cjs.Graphics().p("A/3QUMAAAggnMA/vAAAMAAAAgng");
	var mask_graphics_111 = new cjs.Graphics().p("A+yPrIAA/VMA9lAAAIAAfVg");
	var mask_graphics_112 = new cjs.Graphics().p("A9xPFIAA+JMA7jAAAIAAeJg");
	var mask_graphics_113 = new cjs.Graphics().p("A80PBIAA8/MA5pAAAIAAc/g");
	var mask_graphics_114 = new cjs.Graphics().p("A77PAIAA77MA33AAAIAAb7g");
	var mask_graphics_115 = new cjs.Graphics().p("A7FO+IAA66MA2LAAAIAAa6g");
	var mask_graphics_116 = new cjs.Graphics().p("A6UO9IAA5/MA0pAAAIAAZ/g");
	var mask_graphics_117 = new cjs.Graphics().p("A5MO8IAA5JMAzMAAAIAAZJg");
	var mask_graphics_118 = new cjs.Graphics().p("A4KO7IAA4WMAx5AAAIAAYWg");
	var mask_graphics_119 = new cjs.Graphics().p("A3NO6IAA3pMAwsAAAIAAXpg");
	var mask_graphics_120 = new cjs.Graphics().p("A2XO5IAA2/MAvnAAAIAAW/g");
	var mask_graphics_121 = new cjs.Graphics().p("A1lO5IAA2aMAuoAAAIAAWag");
	var mask_graphics_122 = new cjs.Graphics().p("A05O4IAA15MAtwAAAIAAV5g");
	var mask_graphics_123 = new cjs.Graphics().p("A0TO3IAA1bMAtAAAAIAAVbg");
	var mask_graphics_124 = new cjs.Graphics().p("AzxO3IAA1CMAsVAAAIAAVCg");
	var mask_graphics_125 = new cjs.Graphics().p("AzTO2IAA0rMArvAAAIAAUrg");
	var mask_graphics_126 = new cjs.Graphics().p("Ay7O2IAA0ZMArQAAAIAAUZg");
	var mask_graphics_127 = new cjs.Graphics().p("AymO2IAA0KMAq2AAAIAAUKg");
	var mask_graphics_128 = new cjs.Graphics().p("AyWO1IAAz9MAqiAAAIAAT9g");
	var mask_graphics_130 = new cjs.Graphics().p("AyMO1IAAz1MAqTAAAIAAT1g");
	var mask_graphics_189 = new cjs.Graphics().p("AyMO1IAAz1MAqTAAAIAAT1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:137.3118,y:0.5517}).wait(79).to({graphics:mask_graphics_79,x:137.3118,y:0.5517}).wait(1).to({graphics:mask_graphics_80,x:137.3797,y:0.7878}).wait(1).to({graphics:mask_graphics_81,x:137.491,y:1.1746}).wait(1).to({graphics:mask_graphics_82,x:137.6476,y:1.719}).wait(1).to({graphics:mask_graphics_83,x:137.8517,y:2.4286}).wait(1).to({graphics:mask_graphics_84,x:138.1055,y:3.3108}).wait(1).to({graphics:mask_graphics_85,x:138.4111,y:4.3734}).wait(1).to({graphics:mask_graphics_86,x:138.7709,y:5.6241}).wait(1).to({graphics:mask_graphics_87,x:139.187,y:7.0707}).wait(1).to({graphics:mask_graphics_88,x:139.6616,y:8.7207}).wait(1).to({graphics:mask_graphics_89,x:140.1969,y:10.5813}).wait(1).to({graphics:mask_graphics_90,x:140.7945,y:12.659}).wait(1).to({graphics:mask_graphics_91,x:141.4562,y:14.9594}).wait(1).to({graphics:mask_graphics_92,x:142.1832,y:17.4867}).wait(1).to({graphics:mask_graphics_93,x:142.9762,y:20.2434}).wait(1).to({graphics:mask_graphics_94,x:143.8352,y:23.2298}).wait(1).to({graphics:mask_graphics_95,x:144.7596,y:26.4433}).wait(1).to({graphics:mask_graphics_96,x:145.7476,y:29.8782}).wait(1).to({graphics:mask_graphics_97,x:146.7966,y:33.5246}).wait(1).to({graphics:mask_graphics_98,x:147.9023,y:37.3687}).wait(1).to({graphics:mask_graphics_99,x:149.0595,y:41.3916}).wait(1).to({graphics:mask_graphics_100,x:150.2615,y:45.5703}).wait(1).to({graphics:mask_graphics_101,x:151.5003,y:49.877}).wait(1).to({graphics:mask_graphics_102,x:152.7669,y:54.2799}).wait(1).to({graphics:mask_graphics_103,x:154.0512,y:58.7447}).wait(1).to({graphics:mask_graphics_104,x:155.3427,y:63.2347}).wait(1).to({graphics:mask_graphics_105,x:156.6309,y:67.7129}).wait(1).to({graphics:mask_graphics_106,x:157.9053,y:72.1433}).wait(1).to({graphics:mask_graphics_107,x:159.1561,y:76.4917}).wait(1).to({graphics:mask_graphics_108,x:160.3745,y:80.7272}).wait(1).to({graphics:mask_graphics_109,x:161.5527,y:84.8231}).wait(1).to({graphics:mask_graphics_110,x:162.6841,y:88.7566}).wait(1).to({graphics:mask_graphics_111,x:163.7638,y:92.5098}).wait(1).to({graphics:mask_graphics_112,x:164.7876,y:96.0691}).wait(1).to({graphics:mask_graphics_113,x:165.7529,y:96.114}).wait(1).to({graphics:mask_graphics_114,x:166.6579,y:95.9736}).wait(1).to({graphics:mask_graphics_115,x:167.5018,y:95.8426}).wait(1).to({graphics:mask_graphics_116,x:168.2846,y:95.7212}).wait(1).to({graphics:mask_graphics_117,x:166.4433,y:95.6092}).wait(1).to({graphics:mask_graphics_118,x:164.6753,y:95.5064}).wait(1).to({graphics:mask_graphics_119,x:163.063,y:95.4126}).wait(1).to({graphics:mask_graphics_120,x:161.6021,y:95.3277}).wait(1).to({graphics:mask_graphics_121,x:160.2878,y:95.2513}).wait(1).to({graphics:mask_graphics_122,x:159.1151,y:95.1832}).wait(1).to({graphics:mask_graphics_123,x:158.0788,y:95.1229}).wait(1).to({graphics:mask_graphics_124,x:157.1736,y:95.0703}).wait(1).to({graphics:mask_graphics_125,x:156.3941,y:95.025}).wait(1).to({graphics:mask_graphics_126,x:155.7353,y:94.9867}).wait(1).to({graphics:mask_graphics_127,x:155.192,y:94.9551}).wait(1).to({graphics:mask_graphics_128,x:154.7593,y:94.9299}).wait(1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_130,x:154.3375,y:94.8626}).wait(59).to({graphics:mask_graphics_189,x:154.3375,y:94.8626}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// LeafA
	this.instance = new lib.leafA_1();
	this.instance.setTransform(-149.5,-100.95,0.8081,0.8081,0,0,0,99,122.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(80).to({scaleX:0.8075,scaleY:0.8075,x:-149.05,y:-100.55},0).wait(1).to({scaleX:0.8066,scaleY:0.8066,x:-148.3,y:-99.8},0).wait(1).to({scaleX:0.8053,scaleY:0.8053,x:-147.3,y:-98.85},0).wait(1).to({scaleX:0.8036,scaleY:0.8036,x:-145.95,y:-97.55},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,x:-144.3,y:-96},0).wait(1).to({scaleX:0.7989,scaleY:0.7989,x:-142.3,y:-94.1},0).wait(1).to({scaleX:0.7959,scaleY:0.7959,x:-139.95,y:-91.8},0).wait(1).to({scaleX:0.7924,scaleY:0.7924,x:-137.25,y:-89.25},0).wait(1).to({scaleX:0.7884,scaleY:0.7884,x:-134.15,y:-86.3},0).wait(1).to({scaleX:0.7839,scaleY:0.7839,x:-130.65,y:-82.95},0).wait(1).to({scaleX:0.7789,scaleY:0.7789,x:-126.75,y:-79.2},0).wait(1).to({scaleX:0.7734,scaleY:0.7734,x:-122.45,y:-75.05},0).wait(1).to({scaleX:0.7673,scaleY:0.7673,x:-117.7,y:-70.55},0).wait(1).to({scaleX:0.7606,scaleY:0.7606,x:-112.55,y:-65.55},0).wait(1).to({scaleX:0.7534,scaleY:0.7534,x:-106.9,y:-60.2},0).wait(1).to({scaleX:0.7457,scaleY:0.7457,x:-100.9,y:-54.45},0).wait(1).to({scaleX:0.7374,scaleY:0.7374,x:-94.45,y:-48.25},0).wait(1).to({scaleX:0.7286,scaleY:0.7286,x:-87.6,y:-41.7},0).wait(1).to({scaleX:0.7194,scaleY:0.7194,x:-80.4,y:-34.75},0).wait(1).to({scaleX:0.7097,scaleY:0.7097,x:-72.85,y:-27.55},0).wait(1).to({scaleX:0.6996,scaleY:0.6996,x:-65,y:-20.05},0).wait(1).to({scaleX:0.6892,scaleY:0.6892,x:-56.9,y:-12.25},0).wait(1).to({scaleX:0.6786,scaleY:0.6786,x:-48.65,y:-4.35},0).wait(1).to({scaleX:0.6679,scaleY:0.6679,x:-40.3,y:3.65},0).wait(1).to({scaleX:0.6571,scaleY:0.6571,x:-31.85,y:11.75},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:-23.45,y:19.75},0).wait(1).to({scaleX:0.6356,scaleY:0.6356,x:-15.15,y:27.75},0).wait(1).to({scaleX:0.6251,scaleY:0.6251,x:-7,y:35.55},0).wait(1).to({scaleX:0.6149,scaleY:0.6149,x:1,y:43.15},0).wait(1).to({scaleX:0.605,scaleY:0.605,x:8.65,y:50.55},0).wait(1).to({scaleX:0.5956,scaleY:0.5956,x:16,y:57.6},0).wait(1).to({scaleX:0.5865,scaleY:0.5865,x:23.05,y:64.3},0).wait(1).to({scaleX:0.578,scaleY:0.578,x:29.7,y:70.7},0).wait(1).to({scaleX:0.5699,scaleY:0.5699,x:36,y:76.75},0).wait(1).to({scaleX:0.5623,scaleY:0.5623,x:41.9,y:82.4},0).wait(1).to({scaleX:0.5552,scaleY:0.5552,x:47.45,y:87.65},0).wait(1).to({scaleX:0.5487,scaleY:0.5487,x:52.55,y:92.55},0).wait(1).to({scaleX:0.5426,scaleY:0.5426,x:57.2,y:97.05},0).wait(1).to({scaleX:0.5371,scaleY:0.5371,x:61.5,y:101.2},0).wait(1).to({scaleX:0.532,scaleY:0.532,x:65.45,y:105},0).wait(1).to({scaleX:0.5274,scaleY:0.5274,x:69.05,y:108.35},0).wait(1).to({scaleX:0.5233,scaleY:0.5233,x:72.25,y:111.45},0).wait(1).to({scaleX:0.5196,scaleY:0.5196,x:75.15,y:114.2},0).wait(1).to({scaleX:0.5164,scaleY:0.5164,x:77.65,y:116.65},0).wait(1).to({scaleX:0.5135,scaleY:0.5135,x:79.85,y:118.75},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:81.75,y:120.55},0).wait(1).to({scaleX:0.509,scaleY:0.509,x:83.4,y:122.1},0).wait(1).to({scaleX:0.5073,scaleY:0.5073,x:84.7,y:123.4},0).wait(1).to({regY:122.9,scaleX:0.506,scaleY:0.506,x:85.8,y:124.45},0).to({_off:true},1).wait(1).to({_off:false,regX:99.1,regY:123,scaleX:0.505,scaleY:0.505,x:86.55,y:125.15},0).wait(59).to({_off:true},1).wait(7));

	// ScreenMaskA copy 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_1_graphics_79 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_1_graphics_80 = new cjs.Graphics().p("Eg46AfSMAAAg+jMBx1AAAMAAAA+jg");
	var mask_1_graphics_81 = new cjs.Graphics().p("Eg4zAfOMAAAg+bMBxnAAAMAAAA+bg");
	var mask_1_graphics_82 = new cjs.Graphics().p("Eg4pAfIMAAAg+PMBxTAAAMAAAA+Pg");
	var mask_1_graphics_83 = new cjs.Graphics().p("Eg4cAfBMAAAg+BMBw5AAAMAAAA+Bg");
	var mask_1_graphics_84 = new cjs.Graphics().p("Eg4MAe3MAAAg9tMBwZAAAMAAAA9tg");
	var mask_1_graphics_85 = new cjs.Graphics().p("Eg35AerMAAAg9VMBvzAAAMAAAA9Vg");
	var mask_1_graphics_86 = new cjs.Graphics().p("Eg3iAeeMAAAg87MBvFAAAMAAAA87g");
	var mask_1_graphics_87 = new cjs.Graphics().p("Eg3IAeOMAAAg8bMBuRAAAMAAAA8bg");
	var mask_1_graphics_88 = new cjs.Graphics().p("Eg2qAd8MAAAg73MBtVAAAMAAAA73g");
	var mask_1_graphics_89 = new cjs.Graphics().p("Eg2IAdnMAAAg7NMBsRAAAMAAAA7Ng");
	var mask_1_graphics_90 = new cjs.Graphics().p("Eg1iAdRMAAAg6hMBrFAAAMAAAA6hg");
	var mask_1_graphics_91 = new cjs.Graphics().p("Eg04Ac4MAAAg5vMBpxAAAMAAAA5vg");
	var mask_1_graphics_92 = new cjs.Graphics().p("Eg0KAccMAAAg43MBoVAAAMAAAA43g");
	var mask_1_graphics_93 = new cjs.Graphics().p("EgzYAb+MAAAg37MBmxAAAMAAAA37g");
	var mask_1_graphics_94 = new cjs.Graphics().p("EgyiAbdMAAAg25MBlFAAAMAAAA25g");
	var mask_1_graphics_95 = new cjs.Graphics().p("EgxnAa6MAAAg1zMBjPAAAMAAAA1zg");
	var mask_1_graphics_96 = new cjs.Graphics().p("EgwoAaUMAAAg0nMBhRAAAMAAAA0ng");
	var mask_1_graphics_97 = new cjs.Graphics().p("EgvmAZtMAAAgzZMBfNAAAMAAAAzZg");
	var mask_1_graphics_98 = new cjs.Graphics().p("EgugAZDMAAAgyFMBdBAAAMAAAAyFg");
	var mask_1_graphics_99 = new cjs.Graphics().p("EgtXAYXMAAAgwtMBavAAAMAAAAwtg");
	var mask_1_graphics_100 = new cjs.Graphics().p("EgsLAXpMAAAgvRMBYXAAAMAAAAvRg");
	var mask_1_graphics_101 = new cjs.Graphics().p("Egq8AW6MAAAgtzMBV5AAAMAAAAtzg");
	var mask_1_graphics_102 = new cjs.Graphics().p("EgpsAWKMAAAgsTMBTZAAAMAAAAsTg");
	var mask_1_graphics_103 = new cjs.Graphics().p("EgobAVZMAAAgqxMBQ3AAAMAAAAqxg");
	var mask_1_graphics_104 = new cjs.Graphics().p("EgnJAUoMAAAgpPMBOTAAAMAAAApPg");
	var mask_1_graphics_105 = new cjs.Graphics().p("Egl3AT3MAAAgntMBLvAAAMAAAAntg");
	var mask_1_graphics_106 = new cjs.Graphics().p("EgknATHMAAAgmNMBJPAAAMAAAAmNg");
	var mask_1_graphics_107 = new cjs.Graphics().p("EgjXASXMAAAgktMBGvAAAMAAAAktg");
	var mask_1_graphics_108 = new cjs.Graphics().p("EgiKARpMAAAgjRMBEVAAAMAAAAjRg");
	var mask_1_graphics_109 = new cjs.Graphics().p("EghAAQ8MAAAgh3MBCBAAAMAAAAh3g");
	var mask_1_graphics_110 = new cjs.Graphics().p("A/4QRMAAAgghMA/xAAAMAAAAghg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A+0PoIAA/PMA9pAAAIAAfPg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A9zPBIAA+BMA7nAAAIAAeBg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A82O/IAA84MA5tAAAIAAc4g");
	var mask_1_graphics_114 = new cjs.Graphics().p("A78O+IAA7zMA35AAAIAAbzg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A7HO8IAA6zMA2PAAAIAAazg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A6VO7IAA53MA0rAAAIAAZ3g");
	var mask_1_graphics_117 = new cjs.Graphics().p("A5QO6IAA5BMAzQAAAIAAZBg");
	var mask_1_graphics_118 = new cjs.Graphics().p("A4NO5IAA4OMAx8AAAIAAYOg");
	var mask_1_graphics_119 = new cjs.Graphics().p("A3RO4IAA3hMAwwAAAIAAXhg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A2aO3IAA23MAvqAAAIAAW3g");
	var mask_1_graphics_121 = new cjs.Graphics().p("A1pO2IAA2RMAusAAAIAAWRg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A09O1IAA1wMAt0AAAIAAVwg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A0WO1IAA1TMAtDAAAIAAVTg");
	var mask_1_graphics_124 = new cjs.Graphics().p("Az0O0IAA04MAsYAAAIAAU4g");
	var mask_1_graphics_125 = new cjs.Graphics().p("AzXO0IAA0jMArzAAAIAAUjg");
	var mask_1_graphics_126 = new cjs.Graphics().p("Ay/OzIAA0PMArUAAAIAAUPg");
	var mask_1_graphics_127 = new cjs.Graphics().p("AyqOzIAA0AMAq6AAAIAAUAg");
	var mask_1_graphics_128 = new cjs.Graphics().p("AyaOyIAAzzMAqmAAAIAATzg");
	var mask_1_graphics_130 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");
	var mask_1_graphics_189 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:137.3118,y:0.5517}).wait(79).to({graphics:mask_1_graphics_79,x:137.3118,y:0.5517}).wait(1).to({graphics:mask_1_graphics_80,x:137.3794,y:0.7877}).wait(1).to({graphics:mask_1_graphics_81,x:137.49,y:1.1743}).wait(1).to({graphics:mask_1_graphics_82,x:137.6457,y:1.7185}).wait(1).to({graphics:mask_1_graphics_83,x:137.8486,y:2.4277}).wait(1).to({graphics:mask_1_graphics_84,x:138.101,y:3.3095}).wait(1).to({graphics:mask_1_graphics_85,x:138.4049,y:4.3716}).wait(1).to({graphics:mask_1_graphics_86,x:138.7626,y:5.6217}).wait(1).to({graphics:mask_1_graphics_87,x:139.1763,y:7.0676}).wait(1).to({graphics:mask_1_graphics_88,x:139.6483,y:8.7168}).wait(1).to({graphics:mask_1_graphics_89,x:140.1804,y:10.5766}).wait(1).to({graphics:mask_1_graphics_90,x:140.7747,y:12.6533}).wait(1).to({graphics:mask_1_graphics_91,x:141.4327,y:14.9526}).wait(1).to({graphics:mask_1_graphics_92,x:142.1555,y:17.4787}).wait(1).to({graphics:mask_1_graphics_93,x:142.944,y:20.2341}).wait(1).to({graphics:mask_1_graphics_94,x:143.7981,y:23.219}).wait(1).to({graphics:mask_1_graphics_95,x:144.7173,y:26.4311}).wait(1).to({graphics:mask_1_graphics_96,x:145.6997,y:29.8643}).wait(1).to({graphics:mask_1_graphics_97,x:146.7426,y:33.509}).wait(1).to({graphics:mask_1_graphics_98,x:147.8421,y:37.3512}).wait(1).to({graphics:mask_1_graphics_99,x:148.9927,y:41.3723}).wait(1).to({graphics:mask_1_graphics_100,x:150.1879,y:45.549}).wait(1).to({graphics:mask_1_graphics_101,x:151.4197,y:49.8536}).wait(1).to({graphics:mask_1_graphics_102,x:152.679,y:54.2545}).wait(1).to({graphics:mask_1_graphics_103,x:153.956,y:58.7171}).wait(1).to({graphics:mask_1_graphics_104,x:155.2402,y:63.205}).wait(1).to({graphics:mask_1_graphics_105,x:156.521,y:67.6811}).wait(1).to({graphics:mask_1_graphics_106,x:157.7882,y:72.1094}).wait(1).to({graphics:mask_1_graphics_107,x:159.0319,y:76.4557}).wait(1).to({graphics:mask_1_graphics_108,x:160.2434,y:80.6893}).wait(1).to({graphics:mask_1_graphics_109,x:161.4148,y:84.7832}).wait(1).to({graphics:mask_1_graphics_110,x:162.5399,y:88.7149}).wait(1).to({graphics:mask_1_graphics_111,x:163.6134,y:92.4663}).wait(1).to({graphics:mask_1_graphics_112,x:164.6314,y:96.0239}).wait(1).to({graphics:mask_1_graphics_113,x:165.5912,y:95.9094}).wait(1).to({graphics:mask_1_graphics_114,x:166.4911,y:95.7624}).wait(1).to({graphics:mask_1_graphics_115,x:167.3302,y:95.6254}).wait(1).to({graphics:mask_1_graphics_116,x:168.1085,y:95.4984}).wait(1).to({graphics:mask_1_graphics_117,x:166.4388,y:95.3811}).wait(1).to({graphics:mask_1_graphics_118,x:164.6707,y:95.2736}).wait(1).to({graphics:mask_1_graphics_119,x:163.0583,y:95.1755}).wait(1).to({graphics:mask_1_graphics_120,x:161.5973,y:95.0866}).wait(1).to({graphics:mask_1_graphics_121,x:160.283,y:95.0067}).wait(1).to({graphics:mask_1_graphics_122,x:159.1102,y:94.9354}).wait(1).to({graphics:mask_1_graphics_123,x:158.0739,y:94.8723}).wait(1).to({graphics:mask_1_graphics_124,x:157.1686,y:94.8173}).wait(1).to({graphics:mask_1_graphics_125,x:156.3891,y:94.7699}).wait(1).to({graphics:mask_1_graphics_126,x:155.7302,y:94.7298}).wait(1).to({graphics:mask_1_graphics_127,x:155.1869,y:94.6967}).wait(1).to({graphics:mask_1_graphics_128,x:154.7542,y:94.6453}).wait(1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_130,x:154.4592,y:94.651}).wait(59).to({graphics:mask_1_graphics_189,x:154.4592,y:94.651}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// LeafB
	this.instance_1 = new lib.leafB();
	this.instance_1.setTransform(448.1,-146.05,1,1,0,0,0,55,54.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(80).to({scaleX:0.9996,scaleY:0.9996,x:447.75,y:-145.55},0).wait(1).to({scaleX:0.9989,scaleY:0.9989,x:447.2,y:-144.75},0).wait(1).to({scaleX:0.9978,scaleY:0.9978,x:446.4,y:-143.7},0).wait(1).to({scaleX:0.9965,scaleY:0.9965,x:445.35,y:-142.3},0).wait(1).to({scaleX:0.9949,scaleY:0.9949,x:444.05,y:-140.55},0).wait(1).to({scaleX:0.9929,scaleY:0.9929,x:442.55,y:-138.45},0).wait(1).to({scaleX:0.9906,scaleY:0.9906,x:440.75,y:-135.95},0).wait(1).to({scaleX:0.9879,scaleY:0.9879,x:438.65,y:-133.05},0).wait(1).to({scaleX:0.9848,scaleY:0.9848,x:436.25,y:-129.8},0).wait(1).to({scaleX:0.9814,scaleY:0.9814,x:433.55,y:-126.1},0).wait(1).to({scaleX:0.9775,scaleY:0.9775,x:430.5,y:-122},0).wait(1).to({scaleX:0.9732,scaleY:0.9732,x:427.25,y:-117.4},0).wait(1).to({scaleX:0.9685,scaleY:0.9685,x:423.5,y:-112.35},0).wait(1).to({scaleX:0.9634,scaleY:0.9634,x:419.55,y:-106.9},0).wait(1).to({scaleX:0.9579,scaleY:0.9579,x:415.25,y:-100.95},0).wait(1).to({scaleX:0.9519,scaleY:0.9519,x:410.55,y:-94.55},0).wait(1).to({scaleX:0.9455,scaleY:0.9455,x:405.6,y:-87.75},0).wait(1).to({scaleX:0.9387,scaleY:0.9387,x:400.35,y:-80.55},0).wait(1).to({scaleX:0.9316,scaleY:0.9316,x:394.75,y:-72.9},0).wait(1).to({scaleX:0.9241,scaleY:0.9241,x:388.95,y:-64.9},0).wait(1).to({scaleX:0.9164,scaleY:0.9164,x:382.85,y:-56.6},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:376.6,y:-48.05},0).wait(1).to({scaleX:0.9002,scaleY:0.9002,x:370.25,y:-39.3},0).wait(1).to({scaleX:0.8919,scaleY:0.8919,x:363.75,y:-30.4},0).wait(1).to({scaleX:0.8835,scaleY:0.8835,x:357.3,y:-21.5},0).wait(1).to({scaleX:0.8752,scaleY:0.8752,x:350.8,y:-12.6},0).wait(1).to({scaleX:0.867,scaleY:0.867,x:344.4,y:-3.8},0).wait(1).to({scaleX:0.8589,scaleY:0.8589,x:338.1,y:4.85},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:331.9,y:13.3},0).wait(1).to({scaleX:0.8434,scaleY:0.8434,x:326,y:21.4},0).wait(1).to({scaleX:0.8361,scaleY:0.8361,x:320.3,y:29.2},0).wait(1).to({scaleX:0.8291,scaleY:0.8291,x:314.85,y:36.7},0).wait(1).to({scaleX:0.8225,scaleY:0.8225,x:309.7,y:43.75},0).wait(1).to({scaleX:0.8163,scaleY:0.8163,x:304.85,y:50.35},0).wait(1).to({scaleX:0.8104,scaleY:0.8104,x:300.25,y:56.6},0).wait(1).to({scaleX:0.805,scaleY:0.805,x:296,y:62.4},0).wait(1).to({scaleX:0.7999,scaleY:0.7999,x:292.1,y:67.85},0).wait(1).to({scaleX:0.7953,scaleY:0.7953,x:288.45,y:72.85},0).wait(1).to({scaleX:0.791,scaleY:0.791,x:285.1,y:77.4},0).wait(1).to({scaleX:0.7871,scaleY:0.7871,x:282.1,y:81.6},0).wait(1).to({scaleX:0.7836,scaleY:0.7836,x:279.35,y:85.35},0).wait(1).to({scaleX:0.7804,scaleY:0.7804,x:276.8,y:88.8},0).wait(1).to({scaleX:0.7775,scaleY:0.7775,x:274.6,y:91.8},0).wait(1).to({scaleX:0.775,scaleY:0.775,x:272.7,y:94.5},0).wait(1).to({scaleX:0.7728,scaleY:0.7728,x:270.95,y:96.8},0).wait(1).to({scaleX:0.771,scaleY:0.771,x:269.5,y:98.8},0).wait(1).to({scaleX:0.7694,scaleY:0.7694,x:268.25,y:100.55},0).wait(1).to({scaleX:0.768,scaleY:0.768,x:267.25,y:101.95},0).wait(1).to({regY:54.6,scaleX:0.767,scaleY:0.767,x:266.45,y:103.15},0).to({_off:true},1).wait(1).to({_off:false,regX:55.1,scaleX:0.7663,scaleY:0.7663,x:265.85,y:103.9},0).wait(59).to({_off:true},1).wait(7));

	// ScreenMaskA copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_2_graphics_79 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_2_graphics_80 = new cjs.Graphics().p("Eg46AfSMAAAg+jMBx1AAAMAAAA+jg");
	var mask_2_graphics_81 = new cjs.Graphics().p("Eg4zAfOMAAAg+bMBxnAAAMAAAA+bg");
	var mask_2_graphics_82 = new cjs.Graphics().p("Eg4pAfIMAAAg+PMBxTAAAMAAAA+Pg");
	var mask_2_graphics_83 = new cjs.Graphics().p("Eg4cAfBMAAAg+BMBw5AAAMAAAA+Bg");
	var mask_2_graphics_84 = new cjs.Graphics().p("Eg4MAe3MAAAg9tMBwZAAAMAAAA9tg");
	var mask_2_graphics_85 = new cjs.Graphics().p("Eg35AerMAAAg9VMBvzAAAMAAAA9Vg");
	var mask_2_graphics_86 = new cjs.Graphics().p("Eg3iAeeMAAAg87MBvFAAAMAAAA87g");
	var mask_2_graphics_87 = new cjs.Graphics().p("Eg3IAeOMAAAg8bMBuRAAAMAAAA8bg");
	var mask_2_graphics_88 = new cjs.Graphics().p("Eg2qAd8MAAAg73MBtVAAAMAAAA73g");
	var mask_2_graphics_89 = new cjs.Graphics().p("Eg2IAdnMAAAg7NMBsRAAAMAAAA7Ng");
	var mask_2_graphics_90 = new cjs.Graphics().p("Eg1iAdRMAAAg6hMBrFAAAMAAAA6hg");
	var mask_2_graphics_91 = new cjs.Graphics().p("Eg04Ac4MAAAg5vMBpxAAAMAAAA5vg");
	var mask_2_graphics_92 = new cjs.Graphics().p("Eg0KAccMAAAg43MBoVAAAMAAAA43g");
	var mask_2_graphics_93 = new cjs.Graphics().p("EgzYAb+MAAAg37MBmxAAAMAAAA37g");
	var mask_2_graphics_94 = new cjs.Graphics().p("EgyiAbdMAAAg25MBlFAAAMAAAA25g");
	var mask_2_graphics_95 = new cjs.Graphics().p("EgxnAa6MAAAg1zMBjPAAAMAAAA1zg");
	var mask_2_graphics_96 = new cjs.Graphics().p("EgwoAaUMAAAg0nMBhRAAAMAAAA0ng");
	var mask_2_graphics_97 = new cjs.Graphics().p("EgvmAZtMAAAgzZMBfNAAAMAAAAzZg");
	var mask_2_graphics_98 = new cjs.Graphics().p("EgugAZDMAAAgyFMBdBAAAMAAAAyFg");
	var mask_2_graphics_99 = new cjs.Graphics().p("EgtXAYXMAAAgwtMBavAAAMAAAAwtg");
	var mask_2_graphics_100 = new cjs.Graphics().p("EgsLAXpMAAAgvRMBYXAAAMAAAAvRg");
	var mask_2_graphics_101 = new cjs.Graphics().p("Egq8AW6MAAAgtzMBV5AAAMAAAAtzg");
	var mask_2_graphics_102 = new cjs.Graphics().p("EgpsAWKMAAAgsTMBTZAAAMAAAAsTg");
	var mask_2_graphics_103 = new cjs.Graphics().p("EgobAVZMAAAgqxMBQ3AAAMAAAAqxg");
	var mask_2_graphics_104 = new cjs.Graphics().p("EgnJAUoMAAAgpPMBOTAAAMAAAApPg");
	var mask_2_graphics_105 = new cjs.Graphics().p("Egl3AT3MAAAgntMBLvAAAMAAAAntg");
	var mask_2_graphics_106 = new cjs.Graphics().p("EgknATHMAAAgmNMBJPAAAMAAAAmNg");
	var mask_2_graphics_107 = new cjs.Graphics().p("EgjXASXMAAAgktMBGvAAAMAAAAktg");
	var mask_2_graphics_108 = new cjs.Graphics().p("EgiKARpMAAAgjRMBEVAAAMAAAAjRg");
	var mask_2_graphics_109 = new cjs.Graphics().p("EghAAQ8MAAAgh3MBCBAAAMAAAAh3g");
	var mask_2_graphics_110 = new cjs.Graphics().p("A/4QRMAAAgghMA/xAAAMAAAAghg");
	var mask_2_graphics_111 = new cjs.Graphics().p("A+0PoIAA/PMA9pAAAIAAfPg");
	var mask_2_graphics_112 = new cjs.Graphics().p("A9zPBIAA+BMA7nAAAIAAeBg");
	var mask_2_graphics_113 = new cjs.Graphics().p("A82O/IAA84MA5tAAAIAAc4g");
	var mask_2_graphics_114 = new cjs.Graphics().p("A78O+IAA7zMA35AAAIAAbzg");
	var mask_2_graphics_115 = new cjs.Graphics().p("A7HO8IAA6zMA2PAAAIAAazg");
	var mask_2_graphics_116 = new cjs.Graphics().p("A6VO7IAA53MA0rAAAIAAZ3g");
	var mask_2_graphics_117 = new cjs.Graphics().p("A5QO6IAA5BMAzQAAAIAAZBg");
	var mask_2_graphics_118 = new cjs.Graphics().p("A4NO5IAA4OMAx8AAAIAAYOg");
	var mask_2_graphics_119 = new cjs.Graphics().p("A3RO4IAA3hMAwwAAAIAAXhg");
	var mask_2_graphics_120 = new cjs.Graphics().p("A2aO3IAA23MAvqAAAIAAW3g");
	var mask_2_graphics_121 = new cjs.Graphics().p("A1pO2IAA2RMAusAAAIAAWRg");
	var mask_2_graphics_122 = new cjs.Graphics().p("A09O1IAA1wMAt0AAAIAAVwg");
	var mask_2_graphics_123 = new cjs.Graphics().p("A0WO1IAA1TMAtDAAAIAAVTg");
	var mask_2_graphics_124 = new cjs.Graphics().p("Az0O0IAA04MAsYAAAIAAU4g");
	var mask_2_graphics_125 = new cjs.Graphics().p("AzXO0IAA0jMArzAAAIAAUjg");
	var mask_2_graphics_126 = new cjs.Graphics().p("Ay/OzIAA0PMArUAAAIAAUPg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AyqOzIAA0AMAq6AAAIAAUAg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AyaOyIAAzzMAqmAAAIAATzg");
	var mask_2_graphics_130 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");
	var mask_2_graphics_189 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:137.3118,y:0.5517}).wait(79).to({graphics:mask_2_graphics_79,x:137.3118,y:0.5517}).wait(1).to({graphics:mask_2_graphics_80,x:137.3794,y:0.7877}).wait(1).to({graphics:mask_2_graphics_81,x:137.49,y:1.1743}).wait(1).to({graphics:mask_2_graphics_82,x:137.6457,y:1.7185}).wait(1).to({graphics:mask_2_graphics_83,x:137.8486,y:2.4277}).wait(1).to({graphics:mask_2_graphics_84,x:138.101,y:3.3095}).wait(1).to({graphics:mask_2_graphics_85,x:138.4049,y:4.3716}).wait(1).to({graphics:mask_2_graphics_86,x:138.7626,y:5.6217}).wait(1).to({graphics:mask_2_graphics_87,x:139.1763,y:7.0676}).wait(1).to({graphics:mask_2_graphics_88,x:139.6483,y:8.7168}).wait(1).to({graphics:mask_2_graphics_89,x:140.1804,y:10.5766}).wait(1).to({graphics:mask_2_graphics_90,x:140.7747,y:12.6533}).wait(1).to({graphics:mask_2_graphics_91,x:141.4327,y:14.9526}).wait(1).to({graphics:mask_2_graphics_92,x:142.1555,y:17.4787}).wait(1).to({graphics:mask_2_graphics_93,x:142.944,y:20.2341}).wait(1).to({graphics:mask_2_graphics_94,x:143.7981,y:23.219}).wait(1).to({graphics:mask_2_graphics_95,x:144.7173,y:26.4311}).wait(1).to({graphics:mask_2_graphics_96,x:145.6997,y:29.8643}).wait(1).to({graphics:mask_2_graphics_97,x:146.7426,y:33.509}).wait(1).to({graphics:mask_2_graphics_98,x:147.8421,y:37.3512}).wait(1).to({graphics:mask_2_graphics_99,x:148.9927,y:41.3723}).wait(1).to({graphics:mask_2_graphics_100,x:150.1879,y:45.549}).wait(1).to({graphics:mask_2_graphics_101,x:151.4197,y:49.8536}).wait(1).to({graphics:mask_2_graphics_102,x:152.679,y:54.2545}).wait(1).to({graphics:mask_2_graphics_103,x:153.956,y:58.7171}).wait(1).to({graphics:mask_2_graphics_104,x:155.2402,y:63.205}).wait(1).to({graphics:mask_2_graphics_105,x:156.521,y:67.6811}).wait(1).to({graphics:mask_2_graphics_106,x:157.7882,y:72.1094}).wait(1).to({graphics:mask_2_graphics_107,x:159.0319,y:76.4557}).wait(1).to({graphics:mask_2_graphics_108,x:160.2434,y:80.6893}).wait(1).to({graphics:mask_2_graphics_109,x:161.4148,y:84.7832}).wait(1).to({graphics:mask_2_graphics_110,x:162.5399,y:88.7149}).wait(1).to({graphics:mask_2_graphics_111,x:163.6134,y:92.4663}).wait(1).to({graphics:mask_2_graphics_112,x:164.6314,y:96.0239}).wait(1).to({graphics:mask_2_graphics_113,x:165.5912,y:95.9094}).wait(1).to({graphics:mask_2_graphics_114,x:166.4911,y:95.7624}).wait(1).to({graphics:mask_2_graphics_115,x:167.3302,y:95.6254}).wait(1).to({graphics:mask_2_graphics_116,x:168.1085,y:95.4984}).wait(1).to({graphics:mask_2_graphics_117,x:166.4388,y:95.3811}).wait(1).to({graphics:mask_2_graphics_118,x:164.6707,y:95.2736}).wait(1).to({graphics:mask_2_graphics_119,x:163.0583,y:95.1755}).wait(1).to({graphics:mask_2_graphics_120,x:161.5973,y:95.0866}).wait(1).to({graphics:mask_2_graphics_121,x:160.283,y:95.0067}).wait(1).to({graphics:mask_2_graphics_122,x:159.1102,y:94.9354}).wait(1).to({graphics:mask_2_graphics_123,x:158.0739,y:94.8723}).wait(1).to({graphics:mask_2_graphics_124,x:157.1686,y:94.8173}).wait(1).to({graphics:mask_2_graphics_125,x:156.3891,y:94.7699}).wait(1).to({graphics:mask_2_graphics_126,x:155.7302,y:94.7298}).wait(1).to({graphics:mask_2_graphics_127,x:155.1869,y:94.6967}).wait(1).to({graphics:mask_2_graphics_128,x:154.7542,y:94.6453}).wait(1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_2_graphics_130,x:154.4592,y:94.651}).wait(59).to({graphics:mask_2_graphics_189,x:154.4592,y:94.651}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// Grass
	this.instance_2 = new lib.grass_1();
	this.instance_2.setTransform(150.15,209.7,1,1,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(80).to({regX:172.6,regY:-59.1,scaleX:0.9988,scaleY:0.9988,x:136.85,y:87.65},0).wait(1).to({scaleX:0.9969,scaleY:0.9967,x:136.95,y:87.9},0).wait(1).to({scaleX:0.9942,scaleY:0.9938,x:137.1,y:88.15},0).wait(1).to({scaleX:0.9907,scaleY:0.99,x:137.35,y:88.5},0).wait(1).to({scaleX:0.9863,scaleY:0.9853,x:137.6,y:88.95},0).wait(1).to({scaleX:0.981,scaleY:0.9796,x:137.85,y:89.45},0).wait(1).to({scaleX:0.9748,scaleY:0.9729,x:138.25,y:90.1},0).wait(1).to({scaleX:0.9676,scaleY:0.9652,x:138.65,y:90.8},0).wait(1).to({scaleX:0.9594,scaleY:0.9564,x:139.15,y:91.65},0).wait(1).to({scaleX:0.9501,scaleY:0.9465,x:139.7,y:92.55},0).wait(1).to({scaleX:0.9398,scaleY:0.9354,x:140.25,y:93.6},0).wait(1).to({scaleX:0.9283,scaleY:0.9231,x:140.95,y:94.75},0).wait(1).to({scaleX:0.9158,scaleY:0.9096,x:141.65,y:96},0).wait(1).to({scaleX:0.902,scaleY:0.8949,x:142.45,y:97.4},0).wait(1).to({scaleX:0.8872,scaleY:0.8789,x:143.35,y:98.85},0).wait(1).to({scaleX:0.8712,scaleY:0.8618,x:144.25,y:100.45},0).wait(1).to({scaleX:0.8541,scaleY:0.8434,x:145.2,y:102.2},0).wait(1).to({scaleX:0.836,scaleY:0.824,x:146.25,y:104},0).wait(1).to({scaleX:0.8168,scaleY:0.8034,x:147.35,y:105.9},0).wait(1).to({scaleX:0.7968,scaleY:0.782,x:148.5,y:107.95},0).wait(1).to({scaleX:0.776,scaleY:0.7597,x:149.7,y:110},0).wait(1).to({scaleX:0.7546,scaleY:0.7367,x:150.95,y:112.15},0).wait(1).to({scaleX:0.7327,scaleY:0.7132,x:152.2,y:114.35},0).wait(1).to({scaleX:0.7105,scaleY:0.6893,x:153.55,y:116.55},0).wait(1).to({scaleX:0.6881,scaleY:0.6653,x:154.8,y:118.85},0).wait(1).to({scaleX:0.6659,scaleY:0.6414,x:156.1,y:121.05},0).wait(1).to({scaleX:0.6438,scaleY:0.6178,x:157.35,y:123.25},0).wait(1).to({scaleX:0.6222,scaleY:0.5946,x:158.65,y:125.4},0).wait(1).to({scaleX:0.6011,scaleY:0.572,x:159.85,y:127.55},0).wait(1).to({scaleX:0.5807,scaleY:0.5501,x:161.05,y:129.6},0).wait(1).to({scaleX:0.5611,scaleY:0.5291,x:162.15,y:131.55},0).wait(1).to({scaleX:0.5425,scaleY:0.509,x:163.25,y:133.4},0).wait(1).to({scaleX:0.5248,scaleY:0.49,x:164.25,y:135.2},0).wait(1).to({scaleX:0.5081,scaleY:0.4721,x:165.25,y:136.85},0).wait(1).to({scaleX:0.4924,scaleY:0.4553,x:166.15,y:138.45},0).wait(1).to({scaleX:0.4778,scaleY:0.4397,x:166.95,y:139.85},0).wait(1).to({scaleX:0.4643,scaleY:0.4251,x:167.8,y:141.25},0).wait(1).to({scaleX:0.4518,scaleY:0.4117,x:168.5,y:142.45},0).wait(1).to({scaleX:0.4403,scaleY:0.3994,x:169.15,y:143.65},0).wait(1).to({scaleX:0.4299,scaleY:0.3882,x:169.75,y:144.7},0).wait(1).to({scaleX:0.4204,scaleY:0.3781,x:170.3,y:145.65},0).wait(1).to({scaleX:0.4119,scaleY:0.3689,x:170.8,y:146.5},0).wait(1).to({scaleX:0.4043,scaleY:0.3608,x:171.25,y:147.25},0).wait(1).to({scaleX:0.3976,scaleY:0.3536,x:171.6,y:147.9},0).wait(1).to({scaleX:0.3917,scaleY:0.3473,x:171.95,y:148.55},0).wait(1).to({scaleX:0.3867,scaleY:0.3418,x:172.3,y:149},0).wait(1).to({scaleX:0.3824,scaleY:0.3373,x:172.5,y:149.45},0).wait(1).to({scaleX:0.3789,scaleY:0.3335,x:172.75,y:149.8},0).wait(1).to({regX:186,regY:63.1,scaleX:0.3761,scaleY:0.3305,x:177.95,y:190.45},0).to({_off:true},1).wait(1).to({_off:false,regX:186.7,regY:63.6,scaleX:0.3741,scaleY:0.3284,x:178.05,y:190.4},0).wait(59).to({_off:true},1).wait(7));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(165.65,77.5,0.5179,0.5179,-2.4266,0,0,50.3,75.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:50.2,regY:75.5,rotation:0,x:165.55,y:77.45,mode:"synched",loop:false},24,cjs.Ease.cubicInOut).to({regY:75.4,y:78.7,startPosition:5},5,cjs.Ease.quadInOut).to({regY:75.5,y:67.5,startPosition:21},16,cjs.Ease.quadInOut).to({regY:75.3,rotation:-3.5202,y:69.8,startPosition:30},9,cjs.Ease.cubicIn).to({regY:75.4,rotation:-6.7393,y:69.95,mode:"single",startPosition:52},25,cjs.Ease.cubicOut).wait(1).to({regX:46.5,regY:107.8,scaleX:0.5184,scaleY:0.5184,rotation:-6.739,y:86.75},0).wait(1).to({scaleX:0.5193,scaleY:0.5193,rotation:-6.7384,x:165.5},0).wait(1).to({scaleX:0.5204,scaleY:0.5204,rotation:-6.7376,x:165.45},0).wait(1).to({scaleX:0.522,scaleY:0.522,rotation:-6.7365,x:165.35},0).wait(1).to({scaleX:0.5239,scaleY:0.5239,rotation:-6.7352,x:165.2},0).wait(1).to({scaleX:0.5262,scaleY:0.5262,rotation:-6.7336,x:165.05,y:86.7},0).wait(1).to({scaleX:0.5289,scaleY:0.5289,rotation:-6.7318,x:164.9,y:86.6},0).wait(1).to({scaleX:0.5321,scaleY:0.5321,rotation:-6.7296,x:164.65},0).wait(1).to({scaleX:0.5357,scaleY:0.5357,rotation:-6.7272,x:164.5},0).wait(1).to({scaleX:0.5397,scaleY:0.5397,rotation:-6.7244,x:164.2,y:86.5},0).wait(1).to({scaleX:0.5442,scaleY:0.5442,rotation:-6.7213,x:163.95,y:86.45},0).wait(1).to({scaleX:0.5492,scaleY:0.5492,rotation:-6.7179,x:163.65,y:86.35},0).wait(1).to({scaleX:0.5547,scaleY:0.5547,rotation:-6.7141,x:163.3},0).wait(1).to({scaleX:0.5607,scaleY:0.5607,rotation:-6.71,x:162.9,y:86.25},0).wait(1).to({scaleX:0.5672,scaleY:0.5672,rotation:-6.7056,x:162.55,y:86.1},0).wait(1).to({scaleX:0.5742,scaleY:0.5742,rotation:-6.7008,x:162.05,y:86.05},0).wait(1).to({scaleX:0.5816,scaleY:0.5816,rotation:-6.6957,x:161.6,y:85.95},0).wait(1).to({scaleX:0.5896,scaleY:0.5896,rotation:-6.6902,x:161.15,y:85.8},0).wait(1).to({scaleX:0.5979,scaleY:0.5979,rotation:-6.6845,x:160.6,y:85.7},0).wait(1).to({scaleX:0.6067,scaleY:0.6067,rotation:-6.6785,x:160.05,y:85.6},0).wait(1).to({scaleX:0.6157,scaleY:0.6157,rotation:-6.6723,x:159.5,y:85.45},0).wait(1).to({scaleX:0.6251,scaleY:0.6251,rotation:-6.6659,x:158.85,y:85.4},0).wait(1).to({scaleX:0.6347,scaleY:0.6347,rotation:-6.6593,x:158.3,y:85.25},0).wait(1).to({scaleX:0.6444,scaleY:0.6444,rotation:-6.6527,x:157.7,y:85.15},0).wait(1).to({scaleX:0.6541,scaleY:0.6541,rotation:-6.646,x:157.1,y:85},0).wait(1).to({scaleX:0.6639,scaleY:0.6639,rotation:-6.6393,x:156.45,y:84.9},0).wait(1).to({scaleX:0.6735,scaleY:0.6735,rotation:-6.6327,x:155.9,y:84.75},0).wait(1).to({scaleX:0.6829,scaleY:0.6829,rotation:-6.6263,x:155.3,y:84.65},0).wait(1).to({scaleX:0.6921,scaleY:0.6921,rotation:-6.62,x:154.7,y:84.5},0).wait(1).to({scaleX:0.701,scaleY:0.701,rotation:-6.6139,x:154.2,y:84.35},0).wait(1).to({scaleX:0.7096,scaleY:0.7096,rotation:-6.608,x:153.65,y:84.25},0).wait(1).to({scaleX:0.7177,scaleY:0.7177,rotation:-6.6024,x:153.15,y:84.1},0).wait(1).to({scaleX:0.7255,scaleY:0.7255,rotation:-6.5971,x:152.65,y:84.05},0).wait(1).to({scaleX:0.7328,scaleY:0.7328,rotation:-6.5921,x:152.2,y:83.95},0).wait(1).to({scaleX:0.7396,scaleY:0.7396,rotation:-6.5874,x:151.75,y:83.85},0).wait(1).to({scaleX:0.746,scaleY:0.746,rotation:-6.5831,x:151.35,y:83.75},0).wait(1).to({scaleX:0.7519,scaleY:0.7519,rotation:-6.579,x:151.05,y:83.65},0).wait(1).to({scaleX:0.7573,scaleY:0.7573,rotation:-6.5753,x:150.7,y:83.6},0).wait(1).to({scaleX:0.7623,scaleY:0.7623,rotation:-6.5718,x:150.35,y:83.55},0).wait(1).to({scaleX:0.7669,scaleY:0.7669,rotation:-6.5687,x:150.1,y:83.5},0).wait(1).to({scaleX:0.771,scaleY:0.771,rotation:-6.5659,x:149.8,y:83.4},0).wait(1).to({scaleX:0.7748,scaleY:0.7748,rotation:-6.5633,x:149.6},0).wait(1).to({scaleX:0.7781,scaleY:0.7781,rotation:-6.5611,x:149.4,y:83.35},0).wait(1).to({scaleX:0.781,scaleY:0.781,rotation:-6.5591,x:149.2,y:83.3},0).wait(1).to({scaleX:0.7836,scaleY:0.7836,rotation:-6.5573,x:149.05,y:83.25},0).wait(1).to({scaleX:0.7858,scaleY:0.7858,rotation:-6.5558,x:148.85},0).wait(1).to({scaleX:0.7876,scaleY:0.7876,rotation:-6.5545,x:148.8,y:83.2},0).wait(1).to({scaleX:0.7892,scaleY:0.7892,rotation:-6.5535,x:148.65,y:83.15},0).wait(1).to({regX:50.3,regY:75.4,scaleX:0.7904,scaleY:0.7904,rotation:-6.5526,y:57.4},0).to({_off:true},1).wait(1).to({_off:false,regX:50.2,scaleX:0.7912,scaleY:0.7912,rotation:-6.5523,x:148.5,y:57.25,startPosition:54},0).wait(15).to({startPosition:54},0).to({regX:50.3,rotation:-9.4874,x:148.6,y:60.3,mode:"synched",startPosition:59,loop:false},9,cjs.Ease.quadInOut).to({rotation:2.8731,y:51.4,startPosition:73},14,cjs.Ease.quadInOut).to({regX:50.1,rotation:-4.575,x:148.45,y:57.3,startPosition:97},17,cjs.Ease.quadInOut).wait(4).to({startPosition:101},0).to({_off:true},1).wait(7));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(166.45,146.15,0.4778,0.4778,0,0,0,58.1,159.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({y:146.45},5,cjs.Ease.quadInOut).to({regY:159.7,scaleY:0.4931,y:145.6},12,cjs.Ease.quadInOut).to({regY:159.6,scaleY:0.4778,y:146.15},16,cjs.Ease.quadInOut).wait(23).to({regX:57,regY:90.5,scaleX:0.4783,scaleY:0.4783,x:165.85,y:113.15},0).wait(1).to({scaleX:0.479,scaleY:0.479,x:165.8},0).wait(1).to({scaleX:0.4801,scaleY:0.4801,x:165.75,y:113.2},0).wait(1).to({scaleX:0.4815,scaleY:0.4815,x:165.65,y:113.25},0).wait(1).to({scaleX:0.4833,scaleY:0.4833,x:165.55,y:113.3},0).wait(1).to({scaleX:0.4855,scaleY:0.4855,x:165.4,y:113.4},0).wait(1).to({scaleX:0.488,scaleY:0.488,x:165.2,y:113.45},0).wait(1).to({scaleX:0.4909,scaleY:0.4909,x:165.05,y:113.5},0).wait(1).to({scaleX:0.4942,scaleY:0.4942,x:164.8,y:113.6},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:164.6,y:113.75},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:164.25,y:113.9},0).wait(1).to({scaleX:0.5067,scaleY:0.5067,x:164,y:114.05},0).wait(1).to({scaleX:0.5118,scaleY:0.5118,x:163.6,y:114.2},0).wait(1).to({scaleX:0.5173,scaleY:0.5173,x:163.3,y:114.4},0).wait(1).to({scaleX:0.5233,scaleY:0.5233,x:162.9,y:114.6},0).wait(1).to({scaleX:0.5297,scaleY:0.5297,x:162.45,y:114.8},0).wait(1).to({scaleX:0.5366,scaleY:0.5366,x:162,y:115},0).wait(1).to({scaleX:0.544,scaleY:0.544,x:161.5,y:115.3},0).wait(1).to({scaleX:0.5517,scaleY:0.5517,x:161,y:115.55},0).wait(1).to({scaleX:0.5597,scaleY:0.5597,x:160.45,y:115.75},0).wait(1).to({scaleX:0.5681,scaleY:0.5681,x:159.9,y:116.05},0).wait(1).to({scaleX:0.5768,scaleY:0.5768,x:159.35,y:116.35},0).wait(1).to({scaleX:0.5856,scaleY:0.5856,x:158.75,y:116.6},0).wait(1).to({scaleX:0.5946,scaleY:0.5946,x:158.15,y:116.9},0).wait(1).to({scaleX:0.6036,scaleY:0.6036,x:157.5,y:117.15},0).wait(1).to({scaleX:0.6126,scaleY:0.6126,x:156.9,y:117.5},0).wait(1).to({scaleX:0.6215,scaleY:0.6215,x:156.3,y:117.8},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:155.75,y:118.1},0).wait(1).to({scaleX:0.6387,scaleY:0.6387,x:155.2,y:118.35},0).wait(1).to({scaleX:0.6469,scaleY:0.6469,x:154.6,y:118.6},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:154.1,y:118.85},0).wait(1).to({scaleX:0.6623,scaleY:0.6623,x:153.6,y:119.1},0).wait(1).to({scaleX:0.6695,scaleY:0.6695,x:153.15,y:119.35},0).wait(1).to({scaleX:0.6762,scaleY:0.6762,x:152.7,y:119.55},0).wait(1).to({scaleX:0.6825,scaleY:0.6825,x:152.25,y:119.75},0).wait(1).to({scaleX:0.6884,scaleY:0.6884,x:151.9,y:119.95},0).wait(1).to({scaleX:0.6939,scaleY:0.6939,x:151.5,y:120.15},0).wait(1).to({scaleX:0.6989,scaleY:0.6989,x:151.2,y:120.3},0).wait(1).to({scaleX:0.7035,scaleY:0.7035,x:150.85,y:120.4},0).wait(1).to({scaleX:0.7078,scaleY:0.7078,x:150.6,y:120.55},0).wait(1).to({scaleX:0.7116,scaleY:0.7116,x:150.3,y:120.7},0).wait(1).to({scaleX:0.715,scaleY:0.715,x:150.1,y:120.8},0).wait(1).to({scaleX:0.7181,scaleY:0.7181,x:149.9,y:120.9},0).wait(1).to({scaleX:0.7208,scaleY:0.7208,x:149.75,y:121},0).wait(1).to({scaleX:0.7232,scaleY:0.7232,x:149.55,y:121.1},0).wait(1).to({scaleX:0.7252,scaleY:0.7252,x:149.45,y:121.15},0).wait(1).to({scaleX:0.7269,scaleY:0.7269,x:149.35,y:121.2},0).wait(1).to({scaleX:0.7283,scaleY:0.7283,x:149.2,y:121.25},0).wait(1).to({regX:58.1,regY:159.7,scaleX:0.7295,scaleY:0.7295,x:149.95,y:171.75},0).to({_off:true},1).wait(1).to({_off:false,regX:58,regY:159.6,scaleX:0.7303,scaleY:0.7303,x:149.85},0).wait(15).to({regY:159.7,scaleY:0.7053,y:171.85},9,cjs.Ease.quadInOut).to({scaleY:0.7554,y:171.8},14,cjs.Ease.quadInOut).to({regY:159.6,scaleY:0.7303,y:171.75},17,cjs.Ease.quadInOut).wait(4).to({_off:true},1).wait(7));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_3_graphics_79 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_3_graphics_80 = new cjs.Graphics().p("Eg46AfSMAAAg+jMBx1AAAMAAAA+jg");
	var mask_3_graphics_81 = new cjs.Graphics().p("Eg4zAfOMAAAg+bMBxnAAAMAAAA+bg");
	var mask_3_graphics_82 = new cjs.Graphics().p("Eg4pAfIMAAAg+PMBxTAAAMAAAA+Pg");
	var mask_3_graphics_83 = new cjs.Graphics().p("Eg4cAfBMAAAg+BMBw5AAAMAAAA+Bg");
	var mask_3_graphics_84 = new cjs.Graphics().p("Eg4MAe3MAAAg9tMBwZAAAMAAAA9tg");
	var mask_3_graphics_85 = new cjs.Graphics().p("Eg35AerMAAAg9VMBvzAAAMAAAA9Vg");
	var mask_3_graphics_86 = new cjs.Graphics().p("Eg3iAeeMAAAg87MBvFAAAMAAAA87g");
	var mask_3_graphics_87 = new cjs.Graphics().p("Eg3IAeOMAAAg8bMBuRAAAMAAAA8bg");
	var mask_3_graphics_88 = new cjs.Graphics().p("Eg2qAd8MAAAg73MBtVAAAMAAAA73g");
	var mask_3_graphics_89 = new cjs.Graphics().p("Eg2IAdnMAAAg7NMBsRAAAMAAAA7Ng");
	var mask_3_graphics_90 = new cjs.Graphics().p("Eg1iAdRMAAAg6hMBrFAAAMAAAA6hg");
	var mask_3_graphics_91 = new cjs.Graphics().p("Eg04Ac4MAAAg5vMBpxAAAMAAAA5vg");
	var mask_3_graphics_92 = new cjs.Graphics().p("Eg0KAccMAAAg43MBoVAAAMAAAA43g");
	var mask_3_graphics_93 = new cjs.Graphics().p("EgzYAb+MAAAg37MBmxAAAMAAAA37g");
	var mask_3_graphics_94 = new cjs.Graphics().p("EgyiAbdMAAAg25MBlFAAAMAAAA25g");
	var mask_3_graphics_95 = new cjs.Graphics().p("EgxnAa6MAAAg1zMBjPAAAMAAAA1zg");
	var mask_3_graphics_96 = new cjs.Graphics().p("EgwoAaUMAAAg0nMBhRAAAMAAAA0ng");
	var mask_3_graphics_97 = new cjs.Graphics().p("EgvmAZtMAAAgzZMBfNAAAMAAAAzZg");
	var mask_3_graphics_98 = new cjs.Graphics().p("EgugAZDMAAAgyFMBdBAAAMAAAAyFg");
	var mask_3_graphics_99 = new cjs.Graphics().p("EgtXAYXMAAAgwtMBavAAAMAAAAwtg");
	var mask_3_graphics_100 = new cjs.Graphics().p("EgsLAXpMAAAgvRMBYXAAAMAAAAvRg");
	var mask_3_graphics_101 = new cjs.Graphics().p("Egq8AW6MAAAgtzMBV5AAAMAAAAtzg");
	var mask_3_graphics_102 = new cjs.Graphics().p("EgpsAWKMAAAgsTMBTZAAAMAAAAsTg");
	var mask_3_graphics_103 = new cjs.Graphics().p("EgobAVZMAAAgqxMBQ3AAAMAAAAqxg");
	var mask_3_graphics_104 = new cjs.Graphics().p("EgnJAUoMAAAgpPMBOTAAAMAAAApPg");
	var mask_3_graphics_105 = new cjs.Graphics().p("Egl3AT3MAAAgntMBLvAAAMAAAAntg");
	var mask_3_graphics_106 = new cjs.Graphics().p("EgknATHMAAAgmNMBJPAAAMAAAAmNg");
	var mask_3_graphics_107 = new cjs.Graphics().p("EgjXASXMAAAgktMBGvAAAMAAAAktg");
	var mask_3_graphics_108 = new cjs.Graphics().p("EgiKARpMAAAgjRMBEVAAAMAAAAjRg");
	var mask_3_graphics_109 = new cjs.Graphics().p("EghAAQ8MAAAgh3MBCBAAAMAAAAh3g");
	var mask_3_graphics_110 = new cjs.Graphics().p("A/4QRMAAAgghMA/xAAAMAAAAghg");
	var mask_3_graphics_111 = new cjs.Graphics().p("A+0PoIAA/PMA9pAAAIAAfPg");
	var mask_3_graphics_112 = new cjs.Graphics().p("A9zPBIAA+BMA7nAAAIAAeBg");
	var mask_3_graphics_113 = new cjs.Graphics().p("A82O/IAA84MA5tAAAIAAc4g");
	var mask_3_graphics_114 = new cjs.Graphics().p("A78O+IAA7zMA35AAAIAAbzg");
	var mask_3_graphics_115 = new cjs.Graphics().p("A7HO8IAA6zMA2PAAAIAAazg");
	var mask_3_graphics_116 = new cjs.Graphics().p("A6VO7IAA53MA0rAAAIAAZ3g");
	var mask_3_graphics_117 = new cjs.Graphics().p("A5QO6IAA5BMAzQAAAIAAZBg");
	var mask_3_graphics_118 = new cjs.Graphics().p("A4NO5IAA4OMAx8AAAIAAYOg");
	var mask_3_graphics_119 = new cjs.Graphics().p("A3RO4IAA3hMAwwAAAIAAXhg");
	var mask_3_graphics_120 = new cjs.Graphics().p("A2aO3IAA23MAvqAAAIAAW3g");
	var mask_3_graphics_121 = new cjs.Graphics().p("A1pO2IAA2RMAusAAAIAAWRg");
	var mask_3_graphics_122 = new cjs.Graphics().p("A09O1IAA1wMAt0AAAIAAVwg");
	var mask_3_graphics_123 = new cjs.Graphics().p("A0WO1IAA1TMAtDAAAIAAVTg");
	var mask_3_graphics_124 = new cjs.Graphics().p("Az0O0IAA04MAsYAAAIAAU4g");
	var mask_3_graphics_125 = new cjs.Graphics().p("AzXO0IAA0jMArzAAAIAAUjg");
	var mask_3_graphics_126 = new cjs.Graphics().p("Ay/OzIAA0PMArUAAAIAAUPg");
	var mask_3_graphics_127 = new cjs.Graphics().p("AyqOzIAA0AMAq6AAAIAAUAg");
	var mask_3_graphics_128 = new cjs.Graphics().p("AyaOyIAAzzMAqmAAAIAATzg");
	var mask_3_graphics_130 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");
	var mask_3_graphics_189 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:137.3118,y:0.5517}).wait(79).to({graphics:mask_3_graphics_79,x:137.3118,y:0.5517}).wait(1).to({graphics:mask_3_graphics_80,x:137.3794,y:0.7877}).wait(1).to({graphics:mask_3_graphics_81,x:137.49,y:1.1743}).wait(1).to({graphics:mask_3_graphics_82,x:137.6457,y:1.7185}).wait(1).to({graphics:mask_3_graphics_83,x:137.8486,y:2.4277}).wait(1).to({graphics:mask_3_graphics_84,x:138.101,y:3.3095}).wait(1).to({graphics:mask_3_graphics_85,x:138.4049,y:4.3716}).wait(1).to({graphics:mask_3_graphics_86,x:138.7626,y:5.6217}).wait(1).to({graphics:mask_3_graphics_87,x:139.1763,y:7.0676}).wait(1).to({graphics:mask_3_graphics_88,x:139.6483,y:8.7168}).wait(1).to({graphics:mask_3_graphics_89,x:140.1804,y:10.5766}).wait(1).to({graphics:mask_3_graphics_90,x:140.7747,y:12.6533}).wait(1).to({graphics:mask_3_graphics_91,x:141.4327,y:14.9526}).wait(1).to({graphics:mask_3_graphics_92,x:142.1555,y:17.4787}).wait(1).to({graphics:mask_3_graphics_93,x:142.944,y:20.2341}).wait(1).to({graphics:mask_3_graphics_94,x:143.7981,y:23.219}).wait(1).to({graphics:mask_3_graphics_95,x:144.7173,y:26.4311}).wait(1).to({graphics:mask_3_graphics_96,x:145.6997,y:29.8643}).wait(1).to({graphics:mask_3_graphics_97,x:146.7426,y:33.509}).wait(1).to({graphics:mask_3_graphics_98,x:147.8421,y:37.3512}).wait(1).to({graphics:mask_3_graphics_99,x:148.9927,y:41.3723}).wait(1).to({graphics:mask_3_graphics_100,x:150.1879,y:45.549}).wait(1).to({graphics:mask_3_graphics_101,x:151.4197,y:49.8536}).wait(1).to({graphics:mask_3_graphics_102,x:152.679,y:54.2545}).wait(1).to({graphics:mask_3_graphics_103,x:153.956,y:58.7171}).wait(1).to({graphics:mask_3_graphics_104,x:155.2402,y:63.205}).wait(1).to({graphics:mask_3_graphics_105,x:156.521,y:67.6811}).wait(1).to({graphics:mask_3_graphics_106,x:157.7882,y:72.1094}).wait(1).to({graphics:mask_3_graphics_107,x:159.0319,y:76.4557}).wait(1).to({graphics:mask_3_graphics_108,x:160.2434,y:80.6893}).wait(1).to({graphics:mask_3_graphics_109,x:161.4148,y:84.7832}).wait(1).to({graphics:mask_3_graphics_110,x:162.5399,y:88.7149}).wait(1).to({graphics:mask_3_graphics_111,x:163.6134,y:92.4663}).wait(1).to({graphics:mask_3_graphics_112,x:164.6314,y:96.0239}).wait(1).to({graphics:mask_3_graphics_113,x:165.5912,y:95.9094}).wait(1).to({graphics:mask_3_graphics_114,x:166.4911,y:95.7624}).wait(1).to({graphics:mask_3_graphics_115,x:167.3302,y:95.6254}).wait(1).to({graphics:mask_3_graphics_116,x:168.1085,y:95.4984}).wait(1).to({graphics:mask_3_graphics_117,x:166.4388,y:95.3811}).wait(1).to({graphics:mask_3_graphics_118,x:164.6707,y:95.2736}).wait(1).to({graphics:mask_3_graphics_119,x:163.0583,y:95.1755}).wait(1).to({graphics:mask_3_graphics_120,x:161.5973,y:95.0866}).wait(1).to({graphics:mask_3_graphics_121,x:160.283,y:95.0067}).wait(1).to({graphics:mask_3_graphics_122,x:159.1102,y:94.9354}).wait(1).to({graphics:mask_3_graphics_123,x:158.0739,y:94.8723}).wait(1).to({graphics:mask_3_graphics_124,x:157.1686,y:94.8173}).wait(1).to({graphics:mask_3_graphics_125,x:156.3891,y:94.7699}).wait(1).to({graphics:mask_3_graphics_126,x:155.7302,y:94.7298}).wait(1).to({graphics:mask_3_graphics_127,x:155.1869,y:94.6967}).wait(1).to({graphics:mask_3_graphics_128,x:154.7542,y:94.6453}).wait(1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_3_graphics_130,x:154.4592,y:94.651}).wait(59).to({graphics:mask_3_graphics_189,x:154.4592,y:94.651}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(138.15,169.8,1.1938,1.1938,0,0,0,155.4,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(80).to({regY:95.5,scaleX:1.193,scaleY:1.193,x:138.25,y:165.55},0).wait(1).to({scaleX:1.1916,scaleY:1.1916,x:138.3,y:165.45},0).wait(1).to({scaleX:1.1896,scaleY:1.1896,x:138.4,y:165.35},0).wait(1).to({scaleX:1.187,scaleY:1.187,x:138.5,y:165.2},0).wait(1).to({scaleX:1.1838,scaleY:1.1838,x:138.65,y:165.05},0).wait(1).to({scaleX:1.18,scaleY:1.18,x:138.85,y:164.85},0).wait(1).to({scaleX:1.1755,scaleY:1.1755,x:139.05,y:164.55},0).wait(1).to({scaleX:1.1702,scaleY:1.1702,x:139.35,y:164.25},0).wait(1).to({scaleX:1.1643,scaleY:1.1643,x:139.65,y:163.95},0).wait(1).to({scaleX:1.1575,scaleY:1.1575,x:139.95,y:163.6},0).wait(1).to({scaleX:1.15,scaleY:1.15,x:140.3,y:163.2},0).wait(1).to({scaleX:1.1417,scaleY:1.1417,x:140.7,y:162.7},0).wait(1).to({scaleX:1.1325,scaleY:1.1325,x:141.15,y:162.2},0).wait(1).to({scaleX:1.1226,scaleY:1.1226,x:141.65,y:161.65},0).wait(1).to({scaleX:1.1118,scaleY:1.1118,x:142.15,y:161},0).wait(1).to({scaleX:1.1001,scaleY:1.1001,x:142.7,y:160.4},0).wait(1).to({scaleX:1.0877,scaleY:1.0877,x:143.3,y:159.7},0).wait(1).to({scaleX:1.0745,scaleY:1.0745,x:143.95,y:158.95},0).wait(1).to({scaleX:1.0606,scaleY:1.0606,x:144.6,y:158.25},0).wait(1).to({scaleX:1.046,scaleY:1.046,x:145.3,y:157.4},0).wait(1).to({scaleX:1.0309,scaleY:1.0309,x:146.05,y:156.55},0).wait(1).to({scaleX:1.0153,scaleY:1.0153,x:146.8,y:155.7},0).wait(1).to({scaleX:0.9994,scaleY:0.9994,x:147.55,y:154.85},0).wait(1).to({scaleX:0.9832,scaleY:0.9832,x:148.35,y:153.95},0).wait(1).to({scaleX:0.967,scaleY:0.967,x:149.1,y:153.05},0).wait(1).to({scaleX:0.9508,scaleY:0.9508,x:149.85,y:152.15},0).wait(1).to({scaleX:0.9347,scaleY:0.9347,x:150.6,y:151.25},0).wait(1).to({scaleX:0.919,scaleY:0.919,x:151.35,y:150.35},0).wait(1).to({scaleX:0.9037,scaleY:0.9037,x:152.1,y:149.55},0).wait(1).to({scaleX:0.8888,scaleY:0.8888,x:152.8,y:148.75},0).wait(1).to({scaleX:0.8746,scaleY:0.8746,x:153.5,y:147.9},0).wait(1).to({scaleX:0.861,scaleY:0.861,x:154.15,y:147.2},0).wait(1).to({scaleX:0.8481,scaleY:0.8481,x:154.75,y:146.45},0).wait(1).to({scaleX:0.836,scaleY:0.836,x:155.35,y:145.8},0).wait(1).to({scaleX:0.8246,scaleY:0.8246,x:155.9,y:145.15},0).wait(1).to({scaleX:0.814,scaleY:0.814,x:156.4,y:144.6},0).wait(1).to({scaleX:0.8041,scaleY:0.8041,x:156.85,y:144.05},0).wait(1).to({scaleX:0.7951,scaleY:0.7951,x:157.3,y:143.55},0).wait(1).to({scaleX:0.7867,scaleY:0.7867,x:157.7,y:143.1},0).wait(1).to({scaleX:0.7791,scaleY:0.7791,x:158.05,y:142.65},0).wait(1).to({scaleX:0.7722,scaleY:0.7722,x:158.4,y:142.25},0).wait(1).to({scaleX:0.766,scaleY:0.766,x:158.7,y:141.9},0).wait(1).to({scaleX:0.7605,scaleY:0.7605,x:159,y:141.65},0).wait(1).to({scaleX:0.7556,scaleY:0.7556,x:159.2,y:141.35},0).wait(1).to({scaleX:0.7514,scaleY:0.7514,x:159.4,y:141.1},0).wait(1).to({scaleX:0.7477,scaleY:0.7477,x:159.6,y:140.9},0).wait(1).to({scaleX:0.7446,scaleY:0.7446,x:159.75,y:140.75},0).wait(1).to({scaleX:0.742,scaleY:0.742,x:159.85,y:140.6},0).wait(1).to({regY:99,scaleX:0.74,scaleY:0.74,x:160,y:143.05},0).to({_off:true},1).wait(1).to({_off:false,regX:155.5,scaleX:0.7386,scaleY:0.7386,x:160.05,y:142.95},0).wait(59).to({_off:true},1).wait(7));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_4_graphics_79 = new cjs.Graphics().p("Eg4/AfVMAAAg+pMBx/AAAMAAAA+pg");
	var mask_4_graphics_80 = new cjs.Graphics().p("Eg46AfSMAAAg+jMBx1AAAMAAAA+jg");
	var mask_4_graphics_81 = new cjs.Graphics().p("Eg4zAfOMAAAg+bMBxnAAAMAAAA+bg");
	var mask_4_graphics_82 = new cjs.Graphics().p("Eg4pAfIMAAAg+PMBxTAAAMAAAA+Pg");
	var mask_4_graphics_83 = new cjs.Graphics().p("Eg4cAfBMAAAg+BMBw5AAAMAAAA+Bg");
	var mask_4_graphics_84 = new cjs.Graphics().p("Eg4MAe3MAAAg9tMBwZAAAMAAAA9tg");
	var mask_4_graphics_85 = new cjs.Graphics().p("Eg35AerMAAAg9VMBvzAAAMAAAA9Vg");
	var mask_4_graphics_86 = new cjs.Graphics().p("Eg3iAeeMAAAg87MBvFAAAMAAAA87g");
	var mask_4_graphics_87 = new cjs.Graphics().p("Eg3IAeOMAAAg8bMBuRAAAMAAAA8bg");
	var mask_4_graphics_88 = new cjs.Graphics().p("Eg2qAd8MAAAg73MBtVAAAMAAAA73g");
	var mask_4_graphics_89 = new cjs.Graphics().p("Eg2IAdnMAAAg7NMBsRAAAMAAAA7Ng");
	var mask_4_graphics_90 = new cjs.Graphics().p("Eg1iAdRMAAAg6hMBrFAAAMAAAA6hg");
	var mask_4_graphics_91 = new cjs.Graphics().p("Eg04Ac4MAAAg5vMBpxAAAMAAAA5vg");
	var mask_4_graphics_92 = new cjs.Graphics().p("Eg0KAccMAAAg43MBoVAAAMAAAA43g");
	var mask_4_graphics_93 = new cjs.Graphics().p("EgzYAb+MAAAg37MBmxAAAMAAAA37g");
	var mask_4_graphics_94 = new cjs.Graphics().p("EgyiAbdMAAAg25MBlFAAAMAAAA25g");
	var mask_4_graphics_95 = new cjs.Graphics().p("EgxnAa6MAAAg1zMBjPAAAMAAAA1zg");
	var mask_4_graphics_96 = new cjs.Graphics().p("EgwoAaUMAAAg0nMBhRAAAMAAAA0ng");
	var mask_4_graphics_97 = new cjs.Graphics().p("EgvmAZtMAAAgzZMBfNAAAMAAAAzZg");
	var mask_4_graphics_98 = new cjs.Graphics().p("EgugAZDMAAAgyFMBdBAAAMAAAAyFg");
	var mask_4_graphics_99 = new cjs.Graphics().p("EgtXAYXMAAAgwtMBavAAAMAAAAwtg");
	var mask_4_graphics_100 = new cjs.Graphics().p("EgsLAXpMAAAgvRMBYXAAAMAAAAvRg");
	var mask_4_graphics_101 = new cjs.Graphics().p("Egq8AW6MAAAgtzMBV5AAAMAAAAtzg");
	var mask_4_graphics_102 = new cjs.Graphics().p("EgpsAWKMAAAgsTMBTZAAAMAAAAsTg");
	var mask_4_graphics_103 = new cjs.Graphics().p("EgobAVZMAAAgqxMBQ3AAAMAAAAqxg");
	var mask_4_graphics_104 = new cjs.Graphics().p("EgnJAUoMAAAgpPMBOTAAAMAAAApPg");
	var mask_4_graphics_105 = new cjs.Graphics().p("Egl3AT3MAAAgntMBLvAAAMAAAAntg");
	var mask_4_graphics_106 = new cjs.Graphics().p("EgknATHMAAAgmNMBJPAAAMAAAAmNg");
	var mask_4_graphics_107 = new cjs.Graphics().p("EgjXASXMAAAgktMBGvAAAMAAAAktg");
	var mask_4_graphics_108 = new cjs.Graphics().p("EgiKARpMAAAgjRMBEVAAAMAAAAjRg");
	var mask_4_graphics_109 = new cjs.Graphics().p("EghAAQ8MAAAgh3MBCBAAAMAAAAh3g");
	var mask_4_graphics_110 = new cjs.Graphics().p("A/4QRMAAAgghMA/xAAAMAAAAghg");
	var mask_4_graphics_111 = new cjs.Graphics().p("A+0PoIAA/PMA9pAAAIAAfPg");
	var mask_4_graphics_112 = new cjs.Graphics().p("A9zPBIAA+BMA7nAAAIAAeBg");
	var mask_4_graphics_113 = new cjs.Graphics().p("A82O/IAA84MA5tAAAIAAc4g");
	var mask_4_graphics_114 = new cjs.Graphics().p("A78O+IAA7zMA35AAAIAAbzg");
	var mask_4_graphics_115 = new cjs.Graphics().p("A7HO8IAA6zMA2PAAAIAAazg");
	var mask_4_graphics_116 = new cjs.Graphics().p("A6VO7IAA53MA0rAAAIAAZ3g");
	var mask_4_graphics_117 = new cjs.Graphics().p("A5QO6IAA5BMAzQAAAIAAZBg");
	var mask_4_graphics_118 = new cjs.Graphics().p("A4NO5IAA4OMAx8AAAIAAYOg");
	var mask_4_graphics_119 = new cjs.Graphics().p("A3RO4IAA3hMAwwAAAIAAXhg");
	var mask_4_graphics_120 = new cjs.Graphics().p("A2aO3IAA23MAvqAAAIAAW3g");
	var mask_4_graphics_121 = new cjs.Graphics().p("A1pO2IAA2RMAusAAAIAAWRg");
	var mask_4_graphics_122 = new cjs.Graphics().p("A09O1IAA1wMAt0AAAIAAVwg");
	var mask_4_graphics_123 = new cjs.Graphics().p("A0WO1IAA1TMAtDAAAIAAVTg");
	var mask_4_graphics_124 = new cjs.Graphics().p("Az0O0IAA04MAsYAAAIAAU4g");
	var mask_4_graphics_125 = new cjs.Graphics().p("AzXO0IAA0jMArzAAAIAAUjg");
	var mask_4_graphics_126 = new cjs.Graphics().p("Ay/OzIAA0PMArUAAAIAAUPg");
	var mask_4_graphics_127 = new cjs.Graphics().p("AyqOzIAA0AMAq6AAAIAAUAg");
	var mask_4_graphics_128 = new cjs.Graphics().p("AyaOyIAAzzMAqmAAAIAATzg");
	var mask_4_graphics_130 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");
	var mask_4_graphics_189 = new cjs.Graphics().p("AyPOzIAAzsMAqYAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:137.3118,y:0.5517}).wait(79).to({graphics:mask_4_graphics_79,x:137.3118,y:0.5517}).wait(1).to({graphics:mask_4_graphics_80,x:137.3794,y:0.7877}).wait(1).to({graphics:mask_4_graphics_81,x:137.49,y:1.1743}).wait(1).to({graphics:mask_4_graphics_82,x:137.6457,y:1.7185}).wait(1).to({graphics:mask_4_graphics_83,x:137.8486,y:2.4277}).wait(1).to({graphics:mask_4_graphics_84,x:138.101,y:3.3095}).wait(1).to({graphics:mask_4_graphics_85,x:138.4049,y:4.3716}).wait(1).to({graphics:mask_4_graphics_86,x:138.7626,y:5.6217}).wait(1).to({graphics:mask_4_graphics_87,x:139.1763,y:7.0676}).wait(1).to({graphics:mask_4_graphics_88,x:139.6483,y:8.7168}).wait(1).to({graphics:mask_4_graphics_89,x:140.1804,y:10.5766}).wait(1).to({graphics:mask_4_graphics_90,x:140.7747,y:12.6533}).wait(1).to({graphics:mask_4_graphics_91,x:141.4327,y:14.9526}).wait(1).to({graphics:mask_4_graphics_92,x:142.1555,y:17.4787}).wait(1).to({graphics:mask_4_graphics_93,x:142.944,y:20.2341}).wait(1).to({graphics:mask_4_graphics_94,x:143.7981,y:23.219}).wait(1).to({graphics:mask_4_graphics_95,x:144.7173,y:26.4311}).wait(1).to({graphics:mask_4_graphics_96,x:145.6997,y:29.8643}).wait(1).to({graphics:mask_4_graphics_97,x:146.7426,y:33.509}).wait(1).to({graphics:mask_4_graphics_98,x:147.8421,y:37.3512}).wait(1).to({graphics:mask_4_graphics_99,x:148.9927,y:41.3723}).wait(1).to({graphics:mask_4_graphics_100,x:150.1879,y:45.549}).wait(1).to({graphics:mask_4_graphics_101,x:151.4197,y:49.8536}).wait(1).to({graphics:mask_4_graphics_102,x:152.679,y:54.2545}).wait(1).to({graphics:mask_4_graphics_103,x:153.956,y:58.7171}).wait(1).to({graphics:mask_4_graphics_104,x:155.2402,y:63.205}).wait(1).to({graphics:mask_4_graphics_105,x:156.521,y:67.6811}).wait(1).to({graphics:mask_4_graphics_106,x:157.7882,y:72.1094}).wait(1).to({graphics:mask_4_graphics_107,x:159.0319,y:76.4557}).wait(1).to({graphics:mask_4_graphics_108,x:160.2434,y:80.6893}).wait(1).to({graphics:mask_4_graphics_109,x:161.4148,y:84.7832}).wait(1).to({graphics:mask_4_graphics_110,x:162.5399,y:88.7149}).wait(1).to({graphics:mask_4_graphics_111,x:163.6134,y:92.4663}).wait(1).to({graphics:mask_4_graphics_112,x:164.6314,y:96.0239}).wait(1).to({graphics:mask_4_graphics_113,x:165.5912,y:95.9094}).wait(1).to({graphics:mask_4_graphics_114,x:166.4911,y:95.7624}).wait(1).to({graphics:mask_4_graphics_115,x:167.3302,y:95.6254}).wait(1).to({graphics:mask_4_graphics_116,x:168.1085,y:95.4984}).wait(1).to({graphics:mask_4_graphics_117,x:166.4388,y:95.3811}).wait(1).to({graphics:mask_4_graphics_118,x:164.6707,y:95.2736}).wait(1).to({graphics:mask_4_graphics_119,x:163.0583,y:95.1755}).wait(1).to({graphics:mask_4_graphics_120,x:161.5973,y:95.0866}).wait(1).to({graphics:mask_4_graphics_121,x:160.283,y:95.0067}).wait(1).to({graphics:mask_4_graphics_122,x:159.1102,y:94.9354}).wait(1).to({graphics:mask_4_graphics_123,x:158.0739,y:94.8723}).wait(1).to({graphics:mask_4_graphics_124,x:157.1686,y:94.8173}).wait(1).to({graphics:mask_4_graphics_125,x:156.3891,y:94.7699}).wait(1).to({graphics:mask_4_graphics_126,x:155.7302,y:94.7298}).wait(1).to({graphics:mask_4_graphics_127,x:155.1869,y:94.6967}).wait(1).to({graphics:mask_4_graphics_128,x:154.7542,y:94.6453}).wait(1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_4_graphics_130,x:154.4592,y:94.651}).wait(59).to({graphics:mask_4_graphics_189,x:154.4592,y:94.651}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(159.05,57.45,1,1,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(80).to({regX:149.4,regY:58.9,scaleX:0.9996,scaleY:0.9996,x:136.3,y:48.95},0).wait(1).to({scaleX:0.999,scaleY:0.999,x:136.35,y:49.05},0).wait(1).to({scaleX:0.998,scaleY:0.998,x:136.4,y:49.2},0).wait(1).to({scaleX:0.9968,scaleY:0.9968,x:136.45,y:49.35},0).wait(1).to({scaleX:0.9953,scaleY:0.9953,x:136.55,y:49.55},0).wait(1).to({scaleX:0.9935,scaleY:0.9935,x:136.65,y:49.85},0).wait(1).to({scaleX:0.9914,scaleY:0.9914,x:136.75,y:50.2},0).wait(1).to({scaleX:0.9889,scaleY:0.9889,x:136.9,y:50.55},0).wait(1).to({scaleX:0.9861,scaleY:0.9861,x:137.05,y:51},0).wait(1).to({scaleX:0.9829,scaleY:0.9829,x:137.25,y:51.45},0).wait(1).to({scaleX:0.9793,scaleY:0.9793,x:137.4,y:52},0).wait(1).to({scaleX:0.9754,scaleY:0.9754,x:137.7,y:52.55},0).wait(1).to({scaleX:0.9711,scaleY:0.9711,x:137.9,y:53.2},0).wait(1).to({scaleX:0.9664,scaleY:0.9664,x:138.2,y:53.85},0).wait(1).to({scaleX:0.9613,scaleY:0.9613,x:138.45,y:54.65},0).wait(1).to({scaleX:0.9558,scaleY:0.9558,x:138.75,y:55.45},0).wait(1).to({scaleX:0.9499,scaleY:0.9499,x:139.05,y:56.3},0).wait(1).to({scaleX:0.9437,scaleY:0.9437,x:139.45,y:57.25},0).wait(1).to({scaleX:0.9371,scaleY:0.9371,x:139.8,y:58.2},0).wait(1).to({scaleX:0.9303,scaleY:0.9303,x:140.15,y:59.25},0).wait(1).to({scaleX:0.9231,scaleY:0.9231,x:140.5,y:60.25},0).wait(1).to({scaleX:0.9158,scaleY:0.9158,x:140.95,y:61.4},0).wait(1).to({scaleX:0.9083,scaleY:0.9083,x:141.35,y:62.5},0).wait(1).to({scaleX:0.9006,scaleY:0.9006,x:141.8,y:63.65},0).wait(1).to({scaleX:0.893,scaleY:0.893,x:142.2,y:64.8},0).wait(1).to({scaleX:0.8853,scaleY:0.8853,x:142.65,y:65.95},0).wait(1).to({scaleX:0.8777,scaleY:0.8777,x:143.1,y:67.05},0).wait(1).to({scaleX:0.8703,scaleY:0.8703,x:143.5,y:68.15},0).wait(1).to({scaleX:0.8631,scaleY:0.8631,x:143.9,y:69.25},0).wait(1).to({scaleX:0.8561,scaleY:0.8561,x:144.3,y:70.25},0).wait(1).to({scaleX:0.8494,scaleY:0.8494,x:144.65,y:71.3},0).wait(1).to({scaleX:0.843,scaleY:0.843,x:145.05,y:72.25},0).wait(1).to({scaleX:0.8369,scaleY:0.8369,x:145.4,y:73.15},0).wait(1).to({scaleX:0.8312,scaleY:0.8312,x:145.65,y:74},0).wait(1).to({scaleX:0.8258,scaleY:0.8258,x:145.95,y:74.8},0).wait(1).to({scaleX:0.8208,scaleY:0.8208,x:146.25,y:75.55},0).wait(1).to({scaleX:0.8161,scaleY:0.8161,x:146.55,y:76.25},0).wait(1).to({scaleX:0.8118,scaleY:0.8118,x:146.8,y:76.85},0).wait(1).to({scaleX:0.8079,scaleY:0.8079,x:147,y:77.5},0).wait(1).to({scaleX:0.8043,scaleY:0.8043,x:147.15,y:78},0).wait(1).to({scaleX:0.8011,scaleY:0.8011,x:147.4,y:78.5},0).wait(1).to({scaleX:0.7981,scaleY:0.7981,x:147.55,y:78.9},0).wait(1).to({scaleX:0.7955,scaleY:0.7955,x:147.65,y:79.3},0).wait(1).to({scaleX:0.7932,scaleY:0.7932,x:147.8,y:79.65},0).wait(1).to({scaleX:0.7912,scaleY:0.7912,x:147.9,y:79.95},0).wait(1).to({scaleX:0.7895,scaleY:0.7895,x:148,y:80.2},0).wait(1).to({scaleX:0.788,scaleY:0.788,x:148.1,y:80.4},0).wait(1).to({scaleX:0.7868,scaleY:0.7868,x:148.15,y:80.6},0).wait(1).to({regX:172.3,regY:67.5,scaleX:0.7858,scaleY:0.7858,x:166.2,y:87.55},0).to({_off:true},1).wait(1).to({_off:false,regX:172.2,scaleX:0.7852,scaleY:0.7852,x:166.1,y:87.6},0).wait(59).to({_off:true},1).wait(7));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(-22.65,23.2,1.1333,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(128).to({_off:true},1).wait(1).to({_off:false},0).wait(59).to({_off:true},1).wait(7));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-227.4,-199.9,729.5,423.1);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_88 = function() {
		exportRoot.tlLogo.to(exportRoot.mainMC.logo_intro.msoftLogoWhite, 0.3, { alpha: 0}, "-=0");
	}
	this.frame_120 = function() {
		exportRoot.tl1.play();
	}
	this.frame_188 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(88).call(this.frame_88).wait(32).call(this.frame_120).wait(68).call(this.frame_188).wait(1));

	// Icon
	this.instance = new lib.Icon_1();
	this.instance.setTransform(152.9,27.1,0.6891,0.6891,0,0,0,50.1,50.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(120).to({_off:false},0).to({regY:50.3,scaleX:0.5273,scaleY:0.5273,x:160.05,y:40.05,alpha:1},15,cjs.Ease.quartOut).wait(54));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(286.1,-44.2,1,1,0,0,0,58.6,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regX:58.9,regY:16,scaleX:0.5122,scaleY:0.4746,skewX:-29.297,skewY:-16.7916,x:190.95,y:21.2,startPosition:130},40,cjs.Ease.quadInOut).wait(60));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(99.3,-209.05,0.7792,0.7773,0,-29.3094,-16.7693,111.4,-160.4);
	this.shadow.alpha = 0;
	this.shadow._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(105).to({_off:false},0).to({regX:111.8,regY:-160.5,scaleX:0.7299,scaleY:0.7281,skewX:-29.3084,skewY:-16.7659,x:114.6,y:-196.5,alpha:1},24).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.9,-258.9,798.5,640.5);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(272.05,-59,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(197.1,130.8,1,1,0,0,0,197.1,130.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.35,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(674.8,60.65,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(744.3,58,1.0683,1.0683,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Ribbon
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-17.55,-5.2);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-2,-259.5,732.6,505.9), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		var ribbon = mc.ribbon;
		
		
		
		this.runBanner = function() {
			
			this.tlLogo = new TimelineLite();
			this.tl1 = new TimelineLite();
						
				exportRoot.tl1.from(screen, 0.5, { alpha: 1, ease:Power3.easeOut,onStart: function() {;screen.gotoAndPlay(1)}, onComplete: function() {exportRoot.tl1.pause()}}, "+=0.5");
				
				
				exportRoot.tl1.to(screen, 0.3, { alpha: 1, ease:Power3.easeInOut,onComplete:function(){ribbon.gotoAndPlay(0);}}, "-=0");
		
			
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.3");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(362,-214.5,368.6,460.9);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593103316357", id:"M365_FY21Q1_BTS_USA_728x90_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;