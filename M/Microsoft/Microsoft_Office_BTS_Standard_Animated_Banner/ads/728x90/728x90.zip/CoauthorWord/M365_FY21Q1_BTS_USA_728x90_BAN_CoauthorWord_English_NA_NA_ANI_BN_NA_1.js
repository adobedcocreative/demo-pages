(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1", frames: [[0,0,604,384],[606,235,268,215],[634,452,168,106],[284,386,177,130],[560,623,102,86],[804,558,156,76],[107,579,104,86],[463,386,122,39],[664,623,104,82],[804,452,151,104],[0,579,105,86],[876,345,112,90],[606,0,350,233],[463,452,169,106],[0,386,282,191],[284,518,120,111],[406,560,152,63],[560,560,152,61],[876,235,138,108]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.basicUI = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.girllefticon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.guylefticon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow1111 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.secondimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4OAWyMAAAgtjMFwdAAAMAAAAtjg");
	this.shape.setTransform(0.0046,0.0301);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1179.1,-145.7,2358.3,291.5);


(lib.titleshadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.tile_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.text03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,0,88.5,65), null);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.secondimage_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.secondimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage_1, new cjs.Rectangle(0,0,84.5,53), null);


(lib.screenBG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.basicUI();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(0,0,302,192), null);


(lib.screenshadowpicture = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.screenshadow1111();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.roundshadowshape = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.roundshadow1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45), null);


(lib.ribbon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("Ai+QCIBqghIETN4IhqAhg");
	var mask_graphics_69 = new cjs.Graphics().p("Au6QBIZhn8IEUN4I5hH7g");
	var mask_graphics_70 = new cjs.Graphics().p("A4sQAMAtFgOBIEUN4MgtFAOAg");
	var mask_graphics_71 = new cjs.Graphics().p("EgghAP/MA8vgS3IEUN2Mg8vAS4g");
	var mask_graphics_72 = new cjs.Graphics().p("EgmnAP+MBI7gWpIEUN2MhI7AWrg");
	var mask_graphics_73 = new cjs.Graphics().p("EgrMAP+MBSGgZgIETN2MhSGAZhg");
	var mask_graphics_74 = new cjs.Graphics().p("EgufAP9MBYrgbiIEUN2MhYrAbkg");
	var mask_graphics_75 = new cjs.Graphics().p("EgwrAP9MBdEgc6IETN3MhdEAc7g");
	var mask_graphics_76 = new cjs.Graphics().p("EgyBAP9MBfvgdvIEUN2MhfvAdxg");
	var mask_graphics_77 = new cjs.Graphics().p("EgytAP9MBhHgeLIEUN4MhhHAeKg");
	var mask_graphics_78 = new cjs.Graphics().p("Egy9AP9MBhngeVIEUN4MhhnAeUg");
	var mask_graphics_79 = new cjs.Graphics().p("Egy/AP+MBhrgeWIEUN3MhhrAeWg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:-14.4094,y:191.3612}).wait(1).to({graphics:mask_graphics_69,x:62.9207,y:191.2328}).wait(1).to({graphics:mask_graphics_70,x:126.232,y:191.1277}).wait(1).to({graphics:mask_graphics_71,x:176.9271,y:191.0435}).wait(1).to({graphics:mask_graphics_72,x:216.4081,y:190.9779}).wait(1).to({graphics:mask_graphics_73,x:246.077,y:190.9287}).wait(1).to({graphics:mask_graphics_74,x:267.3357,y:190.8934}).wait(1).to({graphics:mask_graphics_75,x:281.586,y:190.8697}).wait(1).to({graphics:mask_graphics_76,x:290.2296,y:190.8553}).wait(1).to({graphics:mask_graphics_77,x:294.6682,y:190.848}).wait(1).to({graphics:mask_graphics_78,x:296.3034,y:190.8453}).wait(1).to({graphics:mask_graphics_79,x:295.6679,y:190.9366}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AzWl/MAmtAAiMgmfALdg");
	this.shape.setTransform(128.275,323.1);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("Egs9AGBMBSpgYCIHSJRMhZsAayg");
	this.shape_1.setTransform(292.125,246.15);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_29 = new cjs.Graphics().p("EA7gAlmICEwJICOASIiEQKg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAysAkeICEwJILBBaIiFQJg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAp+AjXICEwJITtChIiEQJg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAhaAiRICEwJIcQDnIiEQJg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAZFAhNICEwJMAkkAErIiEQJg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EARFAgMICEwJMAsjAFrIiEQKg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AJdfNICEwJMA0KAGqIiFQJg");
	var mask_1_graphics_36 = new cjs.Graphics().p("ACReTICEwKMA7VAHlIiFQJg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AkedbICFwJMBCCAIcIiFQJg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AqvcoICEwJMBITAJPIiEQJg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Awjb4ICFwJMBOFAJ/IiEQJg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A15bNICEwKMBTbAKrIiEQJg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A60akICEwJMBYVALTIiEQJg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A/VZ/ICEwJMBc2AL3IiEQKg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgjdAZdICEwJMBg9AMZIiEQKg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgnPAY+ICEwJMBkvAM4IiFQJg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EgqsAYiICEwJMBoLANUIiEQJg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Egt3AYIICFwJMBrVANuIiEQJg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgwvAXxICEwKMBuNAOGIiEQJg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgzYAXbICEwJMBw2AObIiEQJg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Eg1xAXHICEwJMBzOAOvIiEQJg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Eg3+AW1ICEwJMB1bAPBIiEQJg");
	var mask_1_graphics_51 = new cjs.Graphics().p("Eg5+AWlICEwJMB3bAPRIiEQJg");
	var mask_1_graphics_52 = new cjs.Graphics().p("Eg7yAWWICEwJMB5PAPgIiEQJg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Eg9cAWIICEwJMB64APuIiEQJg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Eg+8AV8ICEwJMB8YAP6IiEQJg");
	var mask_1_graphics_55 = new cjs.Graphics().p("Eg/5AVxICEwJMB9vAQFIiEQJg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhAhAVnICEwJMB+/AQPIiEQJg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhBEAVeICEwKMCAFAQZIiEQJg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhBkAVVICEwJMCBFAQhIiEQJg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhCBAVOICEwJMCB/AQoIiEQJg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhCaAVHICEwJMCCxAQvIiEQJg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhCxAVDICEwKMCDfAQ1IiEQJg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_1_graphics_29,x:408.1811,y:242.45}).wait(1).to({graphics:mask_1_graphics_30,x:408.0542,y:242.4317}).wait(1).to({graphics:mask_1_graphics_31,x:407.9284,y:242.4134}).wait(1).to({graphics:mask_1_graphics_32,x:407.805,y:242.3954}).wait(1).to({graphics:mask_1_graphics_33,x:407.6852,y:242.378}).wait(1).to({graphics:mask_1_graphics_34,x:407.5698,y:242.3612}).wait(1).to({graphics:mask_1_graphics_35,x:407.46,y:242.3452}).wait(1).to({graphics:mask_1_graphics_36,x:407.3563,y:242.3301}).wait(1).to({graphics:mask_1_graphics_37,x:407.2592,y:242.316}).wait(1).to({graphics:mask_1_graphics_38,x:407.1688,y:242.3028}).wait(1).to({graphics:mask_1_graphics_39,x:407.0852,y:242.2906}).wait(1).to({graphics:mask_1_graphics_40,x:407.008,y:242.2793}).wait(1).to({graphics:mask_1_graphics_41,x:406.9371,y:242.269}).wait(1).to({graphics:mask_1_graphics_42,x:406.8721,y:242.2595}).wait(1).to({graphics:mask_1_graphics_43,x:406.8125,y:242.2509}).wait(1).to({graphics:mask_1_graphics_44,x:406.7581,y:242.2429}).wait(1).to({graphics:mask_1_graphics_45,x:406.7083,y:242.2356}).wait(1).to({graphics:mask_1_graphics_46,x:406.6628,y:242.229}).wait(1).to({graphics:mask_1_graphics_47,x:406.6212,y:242.2229}).wait(1).to({graphics:mask_1_graphics_48,x:406.5833,y:242.2174}).wait(1).to({graphics:mask_1_graphics_49,x:406.5486,y:242.2124}).wait(1).to({graphics:mask_1_graphics_50,x:406.5171,y:242.2077}).wait(1).to({graphics:mask_1_graphics_51,x:406.4883,y:242.2035}).wait(1).to({graphics:mask_1_graphics_52,x:406.462,y:242.1997}).wait(1).to({graphics:mask_1_graphics_53,x:406.4382,y:242.1962}).wait(1).to({graphics:mask_1_graphics_54,x:406.4165,y:242.1931}).wait(1).to({graphics:mask_1_graphics_55,x:403.7638,y:242.1902}).wait(1).to({graphics:mask_1_graphics_56,x:399.7876,y:242.1876}).wait(1).to({graphics:mask_1_graphics_57,x:396.1992,y:242.1853}).wait(1).to({graphics:mask_1_graphics_58,x:392.9712,y:242.1832}).wait(1).to({graphics:mask_1_graphics_59,x:390.0785,y:242.1813}).wait(1).to({graphics:mask_1_graphics_60,x:387.4986,y:242.1796}).wait(1).to({graphics:mask_1_graphics_61,x:385.9976,y:242.275}).wait(19));

	// bottom
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEF000").s().p("Eg8BgC8IAAsAMB4DAQqIAANPg");
	this.shape_2.setTransform(390,380.475);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(29).to({_off:false},0).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,774.2,476.2);


(lib.Outlook_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.image01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(0,0,75.5,52), null);


(lib.firstimage_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(0,0,84,53), null);


(lib.fill = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlrighticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girllefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(0,0,51,43), null);


(lib.face02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guylefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52,41), null);


(lib.face01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyrighticon1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,0,52.5,43), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.boxshadowpicture = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150.0023,124.9924,1,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.WordUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(0,0,302,192), null);


(lib.squareshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-31.6,-11.15,416.5,277.25,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(176.6,127.45,1,1,0,0,0,208.2,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-31.6,-11.1,416.5,277.20000000000005), null);


(lib.roundshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0,56,45), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play()
		//exportRoot.mainMC.screen.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({scaleX:2.3428,scaleY:2.3428,x:-711.2,y:264.45},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.3,337.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-879.8,191.6,2358.3,291.6);


(lib.iconcache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(14,0,1.6738,1.6738);

	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(127.4,117.7,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconcache, new cjs.Rectangle(0,0,254.6,219.9), null);


(lib.icon_teams = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.guyrighticon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,0,52.5,43), null);


(lib.guyrightcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution_1, new cjs.Rectangle(0,0,75.5,52), null);


(lib.guylefticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon_1, new cjs.Rectangle(0,0,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.girlrigthcontribution = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon_1, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon_1, new cjs.Rectangle(0,0,51,43), null);


(lib.girlleftcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution_1, new cjs.Rectangle(0,0,88.5,65), null);


(lib.BG_gray = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.WordIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.iconcache.cache(-260,-230,520,460,0.8);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.iconcache = new lib.iconcache();
	this.iconcache.name = "iconcache";
	this.iconcache.setTransform(225.3,236.4,1,1,0,0,0,127.3,109.9);

	this.timeline.addTween(cjs.Tween.get(this.iconcache).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(98,126.5,254.60000000000002,219.89999999999998), null);


(lib.logo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.screenanimation = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_81 = function() {
		exportRoot.tl1.play();
	}
	this.frame_140 = function() {
		exportRoot.tl1.pause();
	}
	this.frame_157 = function() {
		exportRoot.tl1.play();
	}
	this.frame_218 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(81).call(this.frame_81).wait(59).call(this.frame_140).wait(17).call(this.frame_157).wait(61).call(this.frame_218).wait(1));

	// guy right icon.png
	this.instance = new lib.guyrighticon();
	this.instance.setTransform(651.95,29.7,1.4303,1.4303,0,0,0,26.4,21.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({x:336.2,y:109.4,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:26.2,regY:21.5,x:335.9,y:109.25},0).wait(11).to({regX:26.4,regY:21.6,x:336.2,y:109.4},0).wait(1).to({regX:26.2,regY:21.5,scaleX:1.4226,scaleY:1.4226,x:334.55,y:109.2},0).wait(1).to({scaleX:1.4142,scaleY:1.4142,x:333.1,y:109.15},0).wait(1).to({scaleX:1.4051,scaleY:1.4051,x:331.5,y:109.05},0).wait(1).to({scaleX:1.3952,scaleY:1.3952,x:329.8},0).wait(1).to({scaleX:1.3847,scaleY:1.3847,x:328,y:108.95},0).wait(1).to({scaleX:1.3734,scaleY:1.3734,x:326.05,y:108.9},0).wait(1).to({scaleX:1.3614,scaleY:1.3614,x:323.95,y:108.8},0).wait(1).to({scaleX:1.3487,scaleY:1.3487,x:321.75,y:108.75},0).wait(1).to({scaleX:1.3353,scaleY:1.3353,x:319.45,y:108.7},0).wait(1).to({scaleX:1.3212,scaleY:1.3212,x:316.95,y:108.6},0).wait(1).to({scaleX:1.3064,scaleY:1.3064,x:314.45,y:108.55},0).wait(1).to({scaleX:1.291,scaleY:1.291,x:311.7,y:108.45},0).wait(1).to({scaleX:1.2749,scaleY:1.2749,x:308.95,y:108.35},0).wait(1).to({scaleX:1.2582,scaleY:1.2582,x:306.05,y:108.25},0).wait(1).to({scaleX:1.241,scaleY:1.241,x:303.05,y:108.15},0).wait(1).to({scaleX:1.2232,scaleY:1.2232,x:300,y:108.05},0).wait(1).to({scaleX:1.205,scaleY:1.205,x:296.8,y:107.95},0).wait(1).to({scaleX:1.1863,scaleY:1.1863,x:293.6,y:107.85},0).wait(1).to({scaleX:1.1673,scaleY:1.1673,x:290.3,y:107.75},0).wait(1).to({scaleX:1.1479,scaleY:1.1479,x:286.95,y:107.65},0).wait(1).to({scaleX:1.1283,scaleY:1.1283,x:283.55,y:107.5},0).wait(1).to({scaleX:1.1085,scaleY:1.1085,x:280.1,y:107.4},0).wait(1).to({scaleX:1.0885,scaleY:1.0885,x:276.65,y:107.3},0).wait(1).to({scaleX:1.0686,scaleY:1.0686,x:273.2,y:107.15},0).wait(1).to({scaleX:1.0486,scaleY:1.0486,x:269.7,y:107.05},0).wait(1).to({scaleX:1.0287,scaleY:1.0287,x:266.3,y:106.9},0).wait(1).to({scaleX:1.009,scaleY:1.009,x:262.9,y:106.85},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:259.45,y:106.7},0).wait(1).to({scaleX:0.9702,scaleY:0.9702,x:256.1,y:106.6},0).wait(1).to({scaleX:0.9513,scaleY:0.9513,x:252.85,y:106.5},0).wait(1).to({scaleX:0.9328,scaleY:0.9328,x:249.65,y:106.4},0).wait(1).to({scaleX:0.9148,scaleY:0.9148,x:246.5,y:106.25},0).wait(1).to({scaleX:0.8973,scaleY:0.8973,x:243.5,y:106.2},0).wait(1).to({scaleX:0.8803,scaleY:0.8803,x:240.55,y:106.1},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:237.75,y:106},0).wait(1).to({scaleX:0.8481,scaleY:0.8481,x:234.95,y:105.95},0).wait(1).to({scaleX:0.833,scaleY:0.833,x:232.35,y:105.8},0).wait(1).to({scaleX:0.8185,scaleY:0.8185,x:229.85,y:105.75},0).wait(1).to({scaleX:0.8048,scaleY:0.8048,x:227.45,y:105.65},0).wait(1).to({scaleX:0.7917,scaleY:0.7917,x:225.2,y:105.55},0).wait(1).to({scaleX:0.7793,scaleY:0.7793,x:223.05,y:105.5},0).wait(1).to({scaleX:0.7677,scaleY:0.7677,x:221,y:105.45},0).wait(1).to({scaleX:0.7568,scaleY:0.7568,x:219.15,y:105.35},0).wait(1).to({scaleX:0.7466,scaleY:0.7466,x:217.35},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:215.7,y:105.3},0).wait(1).to({scaleX:0.7284,scaleY:0.7284,x:214.25,y:105.2},0).wait(1).to({scaleX:0.7204,scaleY:0.7204,x:212.8},0).wait(1).to({scaleX:0.7131,scaleY:0.7131,x:211.6,y:105.15},0).wait(1).to({scaleX:0.7064,scaleY:0.7064,x:210.4,y:105.1},0).wait(1).to({scaleX:0.7005,scaleY:0.7005,x:209.4,y:105.05},0).wait(1).to({scaleX:0.6953,scaleY:0.6953,x:208.45},0).wait(1).to({scaleX:0.6907,scaleY:0.6907,x:207.7,y:105},0).wait(1).to({scaleX:0.6868,scaleY:0.6868,x:207},0).wait(1).to({scaleX:0.6835,scaleY:0.6835,x:206.45},0).wait(1).to({scaleX:0.6808,scaleY:0.6808,x:206,y:104.95},0).wait(1).to({scaleX:0.6788,scaleY:0.6788,x:205.65},0).wait(1).to({scaleX:0.6774,scaleY:0.6774,x:205.4,y:104.9},0).wait(1).to({scaleX:0.6765,scaleY:0.6765,x:205.2,y:104.95},0).wait(1).to({regX:26.6,regY:21.7,scaleX:0.6762,scaleY:0.6762,x:205.35,y:105},0).wait(1).to({regX:26.2,regY:21.5,x:205.05,y:104.9},0).wait(15).to({regX:26.6,regY:21.7,x:205.35,y:105},0).wait(1).to({regX:26.2,regY:21.5,scaleX:0.6761,scaleY:0.6761,x:205.05,y:104.85},0).wait(1).to({scaleX:0.6759,scaleY:0.6759},0).wait(1).to({scaleX:0.6756,scaleY:0.6756},0).wait(1).to({scaleX:0.6753,scaleY:0.6753,x:205.1,y:104.75},0).wait(1).to({scaleX:0.6748,scaleY:0.6748},0).wait(1).to({scaleX:0.6742,scaleY:0.6742,y:104.7},0).wait(1).to({scaleX:0.6735,scaleY:0.6735,x:205.15,y:104.65},0).wait(1).to({scaleX:0.6727,scaleY:0.6727,y:104.55},0).wait(1).to({scaleX:0.6717,scaleY:0.6717,x:205.2,y:104.5},0).wait(1).to({scaleX:0.6706,scaleY:0.6706,y:104.4},0).wait(1).to({scaleX:0.6693,scaleY:0.6693,x:205.25,y:104.35},0).wait(1).to({scaleX:0.6678,scaleY:0.6678,x:205.3,y:104.2},0).wait(1).to({scaleX:0.6662,scaleY:0.6662,x:205.35,y:104.05},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,x:205.4,y:103.95},0).wait(1).to({scaleX:0.6622,scaleY:0.6622,x:205.45,y:103.75},0).wait(1).to({scaleX:0.6597,scaleY:0.6597,x:205.55,y:103.6},0).wait(1).to({scaleX:0.657,scaleY:0.657,x:205.6,y:103.35},0).wait(1).to({scaleX:0.6539,scaleY:0.6539,x:205.75,y:103.1},0).wait(1).to({scaleX:0.6504,scaleY:0.6504,x:205.85,y:102.85},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:205.95,y:102.5},0).wait(1).to({scaleX:0.6416,scaleY:0.6416,x:206.05,y:102.15},0).wait(1).to({scaleX:0.6362,scaleY:0.6362,x:206.2,y:101.7},0).wait(1).to({scaleX:0.6299,scaleY:0.6299,x:206.45,y:101.2},0).wait(1).to({scaleX:0.6224,scaleY:0.6224,x:206.65,y:100.65},0).wait(1).to({scaleX:0.6134,scaleY:0.6134,x:206.9,y:99.9},0).wait(1).to({scaleX:0.6023,scaleY:0.6023,x:207.3,y:99},0).wait(1).to({scaleX:0.5886,scaleY:0.5886,x:207.65,y:97.95},0).wait(1).to({scaleX:0.5718,scaleY:0.5718,x:208.2,y:96.6},0).wait(1).to({scaleX:0.5522,scaleY:0.5522,x:208.75,y:95.05},0).wait(1).to({scaleX:0.5326,scaleY:0.5326,x:209.35,y:93.5},0).wait(1).to({scaleX:0.5154,scaleY:0.5154,x:209.85,y:92.15},0).wait(1).to({scaleX:0.5014,scaleY:0.5014,x:210.3,y:91.05},0).wait(1).to({scaleX:0.49,scaleY:0.49,x:210.65,y:90.15},0).wait(1).to({scaleX:0.4806,scaleY:0.4806,x:210.9,y:89.4},0).wait(1).to({scaleX:0.4728,scaleY:0.4728,x:211.15,y:88.75},0).wait(1).to({scaleX:0.4661,scaleY:0.4661,x:211.35,y:88.25},0).wait(1).to({scaleX:0.4604,scaleY:0.4604,x:211.5,y:87.8},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:211.7,y:87.4},0).wait(1).to({scaleX:0.4511,scaleY:0.4511,x:211.8,y:87.05},0).wait(1).to({scaleX:0.4473,scaleY:0.4473,x:211.9,y:86.75},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:212.05,y:86.5},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:212.1,y:86.3},0).wait(1).to({scaleX:0.4382,scaleY:0.4382,x:212.2,y:86},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:212.25,y:85.85},0).wait(1).to({scaleX:0.4337,scaleY:0.4337,x:212.3,y:85.65},0).wait(1).to({scaleX:0.4318,scaleY:0.4318,x:212.35,y:85.55},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:212.4,y:85.4},0).wait(1).to({scaleX:0.4286,scaleY:0.4286,x:212.5,y:85.25},0).wait(1).to({scaleX:0.4272,scaleY:0.4272,x:212.55,y:85.2},0).wait(1).to({scaleX:0.426,scaleY:0.426,y:85.05},0).wait(1).to({scaleX:0.4249,scaleY:0.4249,x:212.6,y:85},0).wait(1).to({scaleX:0.424,scaleY:0.424,y:84.9},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,x:212.65,y:84.85},0).wait(1).to({scaleX:0.4225,scaleY:0.4225,y:84.8},0).wait(1).to({scaleX:0.4219,scaleY:0.4219,x:212.7,y:84.75},0).wait(1).to({scaleX:0.4214,scaleY:0.4214,y:84.7},0).wait(1).to({scaleX:0.421,scaleY:0.421,x:212.75},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:212.7,y:84.65},0).wait(1).to({scaleX:0.4204,scaleY:0.4204},0).wait(1).to({scaleX:0.4203,scaleY:0.4203},0).wait(1).to({scaleX:0.4202,scaleY:0.4202},0).wait(1).to({regX:26.6,regY:21.6,scaleX:0.4201,scaleY:0.4201,x:212.95,y:84.7},0).wait(1));

	// guy left icon.png
	this.instance_1 = new lib.guylefticon_1();
	this.instance_1.setTransform(-202.7,21.2,1.4603,1.4603,0,0,0,25.9,20.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({scaleX:1.4604,scaleY:1.4604,x:-120.75,y:117.35,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:26,x:-120.6},0).wait(6).to({scaleX:1.4603,scaleY:1.4603},0).wait(6).to({regX:25.9,x:-120.75},0).wait(1).to({regX:26,scaleX:1.4506,scaleY:1.4506,x:-117.45,y:117.45},0).wait(1).to({scaleX:1.4399,scaleY:1.4399,x:-114.05,y:117.55},0).wait(1).to({scaleX:1.4284,scaleY:1.4284,x:-110.4,y:117.7},0).wait(1).to({scaleX:1.4159,scaleY:1.4159,x:-106.45,y:117.85},0).wait(1).to({scaleX:1.4025,scaleY:1.4025,x:-102.2,y:117.95},0).wait(1).to({scaleX:1.3882,scaleY:1.3882,x:-97.65,y:118.1},0).wait(1).to({scaleX:1.373,scaleY:1.373,x:-92.8,y:118.3},0).wait(1).to({scaleX:1.3569,scaleY:1.3569,x:-87.7,y:118.45},0).wait(1).to({scaleX:1.3399,scaleY:1.3399,x:-82.3,y:118.65},0).wait(1).to({scaleX:1.322,scaleY:1.322,x:-76.65,y:118.9},0).wait(1).to({scaleX:1.3032,scaleY:1.3032,x:-70.65,y:119.1},0).wait(1).to({scaleX:1.2837,scaleY:1.2837,x:-64.4,y:119.3},0).wait(1).to({scaleX:1.2633,scaleY:1.2633,x:-57.95,y:119.55},0).wait(1).to({scaleX:1.2422,scaleY:1.2422,x:-51.25,y:119.8},0).wait(1).to({scaleX:1.2203,scaleY:1.2203,x:-44.3,y:120.05},0).wait(1).to({scaleX:1.1978,scaleY:1.1978,x:-37.15,y:120.3},0).wait(1).to({scaleX:1.1747,scaleY:1.1747,x:-29.8,y:120.6},0).wait(1).to({scaleX:1.151,scaleY:1.151,x:-22.25,y:120.85},0).wait(1).to({scaleX:1.1268,scaleY:1.1268,x:-14.6,y:121.1},0).wait(1).to({scaleX:1.1023,scaleY:1.1023,x:-6.85,y:121.4},0).wait(1).to({scaleX:1.0774,scaleY:1.0774,x:1.05,y:121.7},0).wait(1).to({scaleX:1.0523,scaleY:1.0523,x:9.05,y:121.95},0).wait(1).to({scaleX:1.027,scaleY:1.027,x:17.1,y:122.25},0).wait(1).to({scaleX:1.0017,scaleY:1.0017,x:25.15,y:122.55},0).wait(1).to({scaleX:0.9763,scaleY:0.9763,x:33.15,y:122.8},0).wait(1).to({scaleX:0.9511,scaleY:0.9511,x:41.15,y:123.1},0).wait(1).to({scaleX:0.9261,scaleY:0.9261,x:49.1,y:123.4},0).wait(1).to({scaleX:0.9013,scaleY:0.9013,x:56.95,y:123.7},0).wait(1).to({scaleX:0.877,scaleY:0.877,x:64.7,y:123.95},0).wait(1).to({scaleX:0.853,scaleY:0.853,x:72.3,y:124.25},0).wait(1).to({scaleX:0.8296,scaleY:0.8296,x:79.75,y:124.5},0).wait(1).to({scaleX:0.8067,scaleY:0.8067,x:87,y:124.75},0).wait(1).to({scaleX:0.7845,scaleY:0.7845,x:94.05,y:125},0).wait(1).to({scaleX:0.7629,scaleY:0.7629,x:100.9,y:125.25},0).wait(1).to({scaleX:0.7422,scaleY:0.7422,x:107.5,y:125.45},0).wait(1).to({scaleX:0.7221,scaleY:0.7221,x:113.9,y:125.7},0).wait(1).to({scaleX:0.7029,scaleY:0.7029,x:120,y:125.9},0).wait(1).to({scaleX:0.6846,scaleY:0.6846,x:125.8,y:126.15},0).wait(1).to({scaleX:0.6671,scaleY:0.6671,x:131.35,y:126.35},0).wait(1).to({scaleX:0.6506,scaleY:0.6506,x:136.6,y:126.55},0).wait(1).to({scaleX:0.6349,scaleY:0.6349,x:141.6,y:126.7},0).wait(1).to({scaleX:0.6201,scaleY:0.6201,x:146.25,y:126.85},0).wait(1).to({scaleX:0.6063,scaleY:0.6063,x:150.65,y:127.05},0).wait(1).to({scaleX:0.5934,scaleY:0.5934,x:154.8,y:127.15},0).wait(1).to({scaleX:0.5814,scaleY:0.5814,x:158.55,y:127.3},0).wait(1).to({scaleX:0.5703,scaleY:0.5703,x:162.1,y:127.45},0).wait(1).to({scaleX:0.5601,scaleY:0.5601,x:165.3,y:127.55},0).wait(1).to({scaleX:0.5509,scaleY:0.5509,x:168.25,y:127.65},0).wait(1).to({scaleX:0.5425,scaleY:0.5425,x:170.95,y:127.75},0).wait(1).to({scaleX:0.535,scaleY:0.535,x:173.3,y:127.8},0).wait(1).to({scaleX:0.5283,scaleY:0.5283,x:175.45,y:127.95},0).wait(1).to({scaleX:0.5225,scaleY:0.5225,x:177.3},0).wait(1).to({scaleX:0.5175,scaleY:0.5175,x:178.85,y:128},0).wait(1).to({scaleX:0.5134,scaleY:0.5134,x:180.2,y:128.05},0).wait(1).to({scaleX:0.51,scaleY:0.51,x:181.25,y:128.1},0).wait(1).to({scaleX:0.5074,scaleY:0.5074,x:182.1,y:128.15},0).wait(1).to({scaleX:0.5056,scaleY:0.5056,x:182.65},0).wait(1).to({scaleX:0.5045,scaleY:0.5045,x:183,y:128.2},0).wait(1).to({regX:26.2,regY:20.7,scaleX:0.5042,scaleY:0.5042,x:183.05,y:128.25},0).wait(1).to({regX:26,regY:20.5,x:182.95,y:128.15},0).wait(15).to({regX:26.2,regY:20.7,x:183.05,y:128.25},0).wait(1).to({regX:26,regY:20.5,scaleX:0.5041,scaleY:0.5041,x:182.9,y:128.1},0).wait(1).to({scaleX:0.504,scaleY:0.504,x:182.85},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,x:182.8,y:128.05},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,x:182.75,y:128},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:182.65,y:127.9},0).wait(1).to({scaleX:0.5034,scaleY:0.5034,x:182.55,y:127.85},0).wait(1).to({scaleX:0.5032,scaleY:0.5032,x:182.4,y:127.75},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:182.25,y:127.65},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:182,y:127.5},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:181.75,y:127.35},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:181.5,y:127.2},0).wait(1).to({scaleX:0.5011,scaleY:0.5011,x:181.2,y:126.95},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:180.8,y:126.75},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:180.4,y:126.5},0).wait(1).to({scaleX:0.4989,scaleY:0.4989,x:179.9,y:126.2},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:179.35,y:125.8},0).wait(1).to({scaleX:0.4968,scaleY:0.4968,x:178.65,y:125.35},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:177.9,y:124.85},0).wait(1).to({scaleX:0.4938,scaleY:0.4938,x:176.95,y:124.25},0).wait(1).to({scaleX:0.4918,scaleY:0.4918,x:175.85,y:123.55},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:174.4,y:122.65},0).wait(1).to({scaleX:0.4864,scaleY:0.4864,x:172.7,y:121.5},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:170.45,y:120.05},0).wait(1).to({scaleX:0.4776,scaleY:0.4776,x:167.6,y:118.2},0).wait(1).to({scaleX:0.4718,scaleY:0.4718,x:164.3,y:116.05},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:161.15,y:114.05},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:158.55,y:112.35},0).wait(1).to({scaleX:0.4584,scaleY:0.4584,x:156.55,y:111.1},0).wait(1).to({scaleX:0.4557,scaleY:0.4557,x:154.95,y:110.05},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:153.7,y:109.2},0).wait(1).to({scaleX:0.4516,scaleY:0.4516,x:152.6,y:108.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:151.7,y:107.9},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:150.9,y:107.45},0).wait(1).to({scaleX:0.4475,scaleY:0.4475,x:150.3,y:107},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:149.7,y:106.65},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:149.2,y:106.35},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:148.75,y:106.05},0).wait(1).to({scaleX:0.4443,scaleY:0.4443,x:148.35,y:105.8},0).wait(1).to({scaleX:0.4437,scaleY:0.4437,x:148.05,y:105.6},0).wait(1).to({scaleX:0.4432,scaleY:0.4432,x:147.7,y:105.4},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:147.5,y:105.25},0).wait(1).to({scaleX:0.4423,scaleY:0.4423,x:147.25,y:105.05},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:147.1,y:104.95},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:146.9,y:104.85},0).wait(1).to({scaleX:0.4415,scaleY:0.4415,x:146.8,y:104.75},0).wait(1).to({scaleX:0.4412,scaleY:0.4412,x:146.6,y:104.7},0).wait(1).to({scaleX:0.4411,scaleY:0.4411,x:146.5,y:104.6},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:146.45,y:104.55},0).wait(1).to({scaleX:0.4408,scaleY:0.4408,x:146.4},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:146.35,y:104.5},0).wait(1).to({x:146.3},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,y:104.45},0).wait(1).to({regX:26.2,regY:20.8,x:146.4,y:104.55},0).wait(8));

	// girl right icon.png
	this.instance_2 = new lib.girlrighticon_1();
	this.instance_2.setTransform(330.85,270,1.4168,1.4168,0,0,0,25.9,21.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({x:275.55,y:190.25,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:26,x:275.7},0).wait(16).to({regX:25.9,x:275.55},0).wait(1).to({regX:26,scaleX:1.409,scaleY:1.409,x:274.85,y:190.2},0).wait(1).to({scaleX:1.4006,scaleY:1.4006,x:273.9,y:190.1},0).wait(1).to({scaleX:1.3914,scaleY:1.3914,x:272.9,y:190},0).wait(1).to({scaleX:1.3814,scaleY:1.3814,x:271.8,y:189.95},0).wait(1).to({scaleX:1.3708,scaleY:1.3708,x:270.65,y:189.85},0).wait(1).to({scaleX:1.3594,scaleY:1.3594,x:269.45,y:189.8},0).wait(1).to({scaleX:1.3473,scaleY:1.3473,x:268.15,y:189.65},0).wait(1).to({scaleX:1.3345,scaleY:1.3345,x:266.7,y:189.55},0).wait(1).to({scaleX:1.3209,scaleY:1.3209,x:265.25,y:189.45},0).wait(1).to({scaleX:1.3067,scaleY:1.3067,x:263.65,y:189.35},0).wait(1).to({scaleX:1.2918,scaleY:1.2918,x:262.1,y:189.2},0).wait(1).to({scaleX:1.2762,scaleY:1.2762,x:260.4,y:189.1},0).wait(1).to({scaleX:1.26,scaleY:1.26,x:258.6,y:188.95},0).wait(1).to({scaleX:1.2432,scaleY:1.2432,x:256.75,y:188.85},0).wait(1).to({scaleX:1.2258,scaleY:1.2258,x:254.9,y:188.65},0).wait(1).to({scaleX:1.2079,scaleY:1.2079,x:252.95,y:188.5},0).wait(1).to({scaleX:1.1895,scaleY:1.1895,x:250.95,y:188.35},0).wait(1).to({scaleX:1.1706,scaleY:1.1706,x:248.9,y:188.2},0).wait(1).to({scaleX:1.1514,scaleY:1.1514,x:246.8,y:188.05},0).wait(1).to({scaleX:1.1319,scaleY:1.1319,x:244.7,y:187.9},0).wait(1).to({scaleX:1.1121,scaleY:1.1121,x:242.5,y:187.75},0).wait(1).to({scaleX:1.0921,scaleY:1.0921,x:240.35,y:187.6},0).wait(1).to({scaleX:1.0719,scaleY:1.0719,x:238.15,y:187.4},0).wait(1).to({scaleX:1.0518,scaleY:1.0518,x:236,y:187.25},0).wait(1).to({scaleX:1.0316,scaleY:1.0316,x:233.75,y:187.1},0).wait(1).to({scaleX:1.0115,scaleY:1.0115,x:231.6,y:186.9},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:229.45,y:186.75},0).wait(1).to({scaleX:0.9719,scaleY:0.9719,x:227.3,y:186.6},0).wait(1).to({scaleX:0.9525,scaleY:0.9525,x:225.2,y:186.45},0).wait(1).to({scaleX:0.9335,scaleY:0.9335,x:223.1,y:186.25},0).wait(1).to({scaleX:0.9148,scaleY:0.9148,x:221.1,y:186.1},0).wait(1).to({scaleX:0.8966,scaleY:0.8966,x:219.1,y:186},0).wait(1).to({scaleX:0.8789,scaleY:0.8789,x:217.2,y:185.8},0).wait(1).to({scaleX:0.8618,scaleY:0.8618,x:215.3,y:185.7},0).wait(1).to({scaleX:0.8452,scaleY:0.8452,x:213.55,y:185.5},0).wait(1).to({scaleX:0.8293,scaleY:0.8293,x:211.8,y:185.45},0).wait(1).to({scaleX:0.814,scaleY:0.814,x:210.1,y:185.3},0).wait(1).to({scaleX:0.7995,scaleY:0.7995,x:208.55,y:185.2},0).wait(1).to({scaleX:0.7855,scaleY:0.7855,x:207,y:185.05},0).wait(1).to({scaleX:0.7724,scaleY:0.7724,x:205.65,y:184.95},0).wait(1).to({scaleX:0.7599,scaleY:0.7599,x:204.25,y:184.85},0).wait(1).to({scaleX:0.7481,scaleY:0.7481,x:202.95,y:184.75},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:201.75,y:184.65},0).wait(1).to({scaleX:0.7269,scaleY:0.7269,x:200.65,y:184.6},0).wait(1).to({scaleX:0.7173,scaleY:0.7173,x:199.6,y:184.45},0).wait(1).to({scaleX:0.7085,scaleY:0.7085,x:198.65},0).wait(1).to({scaleX:0.7004,scaleY:0.7004,x:197.75,y:184.35},0).wait(1).to({scaleX:0.693,scaleY:0.693,x:196.95,y:184.3},0).wait(1).to({scaleX:0.6863,scaleY:0.6863,x:196.25,y:184.25},0).wait(1).to({scaleX:0.6804,scaleY:0.6804,x:195.6,y:184.2},0).wait(1).to({scaleX:0.6751,scaleY:0.6751,x:195.05,y:184.15},0).wait(1).to({scaleX:0.6704,scaleY:0.6704,x:194.55,y:184.1},0).wait(1).to({scaleX:0.6665,scaleY:0.6665,x:194.1},0).wait(1).to({scaleX:0.6632,scaleY:0.6632,x:193.75,y:184.05},0).wait(1).to({scaleX:0.6605,scaleY:0.6605,x:193.4},0).wait(1).to({scaleX:0.6584,scaleY:0.6584,x:193.2,y:184},0).wait(1).to({scaleX:0.657,scaleY:0.657,x:193.1},0).wait(1).to({scaleX:0.6561,scaleY:0.6561,x:192.95},0).wait(1).to({regX:26.2,regY:21.8,scaleX:0.6558,scaleY:0.6558,y:184.05},0).wait(1).to({regX:26,regY:21.5,x:192.8,y:183.85},0).wait(15).to({regX:26.2,regY:21.8,x:192.95,y:184.05},0).wait(1).to({regX:26,regY:21.5,scaleX:0.6557,scaleY:0.6557,x:192.75,y:183.8},0).wait(1).to({scaleX:0.6555,scaleY:0.6555,y:183.7},0).wait(1).to({scaleX:0.6552,scaleY:0.6552,y:183.6},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:192.7,y:183.5},0).wait(1).to({scaleX:0.6543,scaleY:0.6543,x:192.6,y:183.25},0).wait(1).to({scaleX:0.6537,scaleY:0.6537,x:192.55,y:183.05},0).wait(1).to({scaleX:0.6529,scaleY:0.6529,x:192.5,y:182.8},0).wait(1).to({scaleX:0.652,scaleY:0.652,x:192.4,y:182.45},0).wait(1).to({scaleX:0.651,scaleY:0.651,x:192.3,y:182.1},0).wait(1).to({scaleX:0.6498,scaleY:0.6498,x:192.15,y:181.6},0).wait(1).to({scaleX:0.6484,scaleY:0.6484,x:192,y:181.15},0).wait(1).to({scaleX:0.6468,scaleY:0.6468,x:191.85,y:180.55},0).wait(1).to({scaleX:0.6449,scaleY:0.6449,x:191.65,y:179.85},0).wait(1).to({scaleX:0.6428,scaleY:0.6428,x:191.45,y:179.1},0).wait(1).to({scaleX:0.6404,scaleY:0.6404,x:191.2,y:178.25},0).wait(1).to({scaleX:0.6376,scaleY:0.6376,x:190.95,y:177.25},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:190.65,y:176.15},0).wait(1).to({scaleX:0.6309,scaleY:0.6309,x:190.25,y:174.8},0).wait(1).to({scaleX:0.6267,scaleY:0.6267,x:189.85,y:173.3},0).wait(1).to({scaleX:0.6218,scaleY:0.6218,x:189.35,y:171.55},0).wait(1).to({scaleX:0.6161,scaleY:0.6161,x:188.75,y:169.5},0).wait(1).to({scaleX:0.6092,scaleY:0.6092,x:188.1,y:167},0).wait(1).to({scaleX:0.601,scaleY:0.601,x:187.25,y:164},0).wait(1).to({scaleX:0.5908,scaleY:0.5908,x:186.2,y:160.35},0).wait(1).to({scaleX:0.5781,scaleY:0.5781,x:184.95,y:155.8},0).wait(1).to({scaleX:0.562,scaleY:0.562,x:183.3,y:150},0).wait(1).to({scaleX:0.5429,scaleY:0.5429,x:181.35,y:143.05},0).wait(1).to({scaleX:0.5232,scaleY:0.5232,x:179.4,y:136},0).wait(1).to({scaleX:0.506,scaleY:0.506,x:177.65,y:129.8},0).wait(1).to({scaleX:0.4922,scaleY:0.4922,x:176.25,y:124.8},0).wait(1).to({scaleX:0.481,scaleY:0.481,x:175.15,y:120.8},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:174.2,y:117.5},0).wait(1).to({scaleX:0.4645,scaleY:0.4645,x:173.5,y:114.8},0).wait(1).to({scaleX:0.4582,scaleY:0.4582,x:172.85,y:112.55},0).wait(1).to({scaleX:0.4528,scaleY:0.4528,x:172.3,y:110.6},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:171.85,y:108.95},0).wait(1).to({scaleX:0.4441,scaleY:0.4441,x:171.45,y:107.45},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,x:171.05,y:106.15},0).wait(1).to({scaleX:0.4374,scaleY:0.4374,x:170.75,y:105.05},0).wait(1).to({scaleX:0.4347,scaleY:0.4347,x:170.45,y:104.05},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:170.25,y:103.2},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:170.05,y:102.4},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:169.85,y:101.7},0).wait(1).to({scaleX:0.4265,scaleY:0.4265,x:169.65,y:101.05},0).wait(1).to({scaleX:0.425,scaleY:0.425,x:169.5,y:100.55},0).wait(1).to({scaleX:0.4236,scaleY:0.4236,x:169.35,y:100.05},0).wait(1).to({scaleX:0.4225,scaleY:0.4225,x:169.25,y:99.65},0).wait(1).to({scaleX:0.4215,scaleY:0.4215,x:169.15,y:99.25},0).wait(1).to({scaleX:0.4206,scaleY:0.4206,x:169.05,y:98.95},0).wait(1).to({scaleX:0.4198,scaleY:0.4198,x:168.95,y:98.7},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:168.9,y:98.45},0).wait(1).to({scaleX:0.4186,scaleY:0.4186,x:168.85,y:98.25},0).wait(1).to({scaleX:0.4182,scaleY:0.4182,x:168.8,y:98.1},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,x:168.75,y:98},0).wait(1).to({scaleX:0.4176,scaleY:0.4176,y:97.9},0).wait(1).to({scaleX:0.4174,scaleY:0.4174,y:97.8},0).wait(1).to({scaleX:0.4173,scaleY:0.4173,x:168.7,y:97.75},0).wait(1).to({regX:26.2,regY:21.8,x:168.8,y:97.9},0).wait(1));

	// girl left icon.png
	this.instance_3 = new lib.girllefticon_1();
	this.instance_3.setTransform(-351.4,264.15,1.4905,1.4905,0,0,0,25.3,21.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({x:-53.65,y:186.3,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:25.5,regY:21.5,x:-53.35,y:186.45},0).wait(19).to({regX:25.3,regY:21.4,x:-53.65,y:186.3},0).wait(1).to({regX:25.5,regY:21.5,scaleX:1.4804,scaleY:1.4804,x:-50.9,y:186.1},0).wait(1).to({scaleX:1.4695,scaleY:1.4695,x:-48.25,y:185.7},0).wait(1).to({scaleX:1.4575,scaleY:1.4575,x:-45.4,y:185.3},0).wait(1).to({scaleX:1.4447,scaleY:1.4447,x:-42.25,y:184.8},0).wait(1).to({scaleX:1.4309,scaleY:1.4309,x:-38.9,y:184.3},0).wait(1).to({scaleX:1.4162,scaleY:1.4162,x:-35.4,y:183.8},0).wait(1).to({scaleX:1.4005,scaleY:1.4005,x:-31.6,y:183.25},0).wait(1).to({scaleX:1.3839,scaleY:1.3839,x:-27.55,y:182.7},0).wait(1).to({scaleX:1.3664,scaleY:1.3664,x:-23.35,y:182.1},0).wait(1).to({scaleX:1.348,scaleY:1.348,x:-18.9,y:181.45},0).wait(1).to({scaleX:1.3287,scaleY:1.3287,x:-14.2,y:180.75},0).wait(1).to({scaleX:1.3085,scaleY:1.3085,x:-9.35,y:180.05},0).wait(1).to({scaleX:1.2875,scaleY:1.2875,x:-4.25,y:179.35},0).wait(1).to({scaleX:1.2657,scaleY:1.2657,x:1,y:178.55},0).wait(1).to({scaleX:1.2432,scaleY:1.2432,x:6.4,y:177.8},0).wait(1).to({scaleX:1.22,scaleY:1.22,x:12,y:176.95},0).wait(1).to({scaleX:1.1962,scaleY:1.1962,x:17.75,y:176.1},0).wait(1).to({scaleX:1.1718,scaleY:1.1718,x:23.7,y:175.25},0).wait(1).to({scaleX:1.1469,scaleY:1.1469,x:29.6,y:174.4},0).wait(1).to({scaleX:1.1216,scaleY:1.1216,x:35.75,y:173.5},0).wait(1).to({scaleX:1.096,scaleY:1.096,x:41.9,y:172.6},0).wait(1).to({scaleX:1.0701,scaleY:1.0701,x:48.2,y:171.7},0).wait(1).to({scaleX:1.0441,scaleY:1.0441,x:54.45,y:170.8},0).wait(1).to({scaleX:1.018,scaleY:1.018,x:60.75,y:169.9},0).wait(1).to({scaleX:0.9919,scaleY:0.9919,x:67.1,y:169},0).wait(1).to({scaleX:0.9659,scaleY:0.9659,x:73.35,y:168.05},0).wait(1).to({scaleX:0.9402,scaleY:0.9402,x:79.55,y:167.15},0).wait(1).to({scaleX:0.9147,scaleY:0.9147,x:85.7,y:166.25},0).wait(1).to({scaleX:0.8895,scaleY:0.8895,x:91.8,y:165.35},0).wait(1).to({scaleX:0.8649,scaleY:0.8649,x:97.75,y:164.55},0).wait(1).to({scaleX:0.8407,scaleY:0.8407,x:103.6,y:163.7},0).wait(1).to({scaleX:0.8172,scaleY:0.8172,x:109.3,y:162.85},0).wait(1).to({scaleX:0.7943,scaleY:0.7943,x:114.8,y:162.05},0).wait(1).to({scaleX:0.7721,scaleY:0.7721,x:120.2,y:161.3},0).wait(1).to({scaleX:0.7507,scaleY:0.7507,x:125.35,y:160.55},0).wait(1).to({scaleX:0.7301,scaleY:0.7301,x:130.3,y:159.8},0).wait(1).to({scaleX:0.7103,scaleY:0.7103,x:135.1,y:159.1},0).wait(1).to({scaleX:0.6914,scaleY:0.6914,x:139.7,y:158.45},0).wait(1).to({scaleX:0.6734,scaleY:0.6734,x:144,y:157.85},0).wait(1).to({scaleX:0.6563,scaleY:0.6563,x:148.15,y:157.2},0).wait(1).to({scaleX:0.6402,scaleY:0.6402,x:152,y:156.65},0).wait(1).to({scaleX:0.625,scaleY:0.625,x:155.7,y:156.15},0).wait(1).to({scaleX:0.6107,scaleY:0.6107,x:159.1,y:155.65},0).wait(1).to({scaleX:0.5974,scaleY:0.5974,x:162.4,y:155.15},0).wait(1).to({scaleX:0.5851,scaleY:0.5851,x:165.35,y:154.75},0).wait(1).to({scaleX:0.5737,scaleY:0.5737,x:168.15,y:154.35},0).wait(1).to({scaleX:0.5632,scaleY:0.5632,x:170.6,y:153.95},0).wait(1).to({scaleX:0.5536,scaleY:0.5536,x:172.9,y:153.65},0).wait(1).to({scaleX:0.545,scaleY:0.545,x:175.05,y:153.3},0).wait(1).to({scaleX:0.5373,scaleY:0.5373,x:176.9,y:153.05},0).wait(1).to({scaleX:0.5304,scaleY:0.5304,x:178.6,y:152.8},0).wait(1).to({scaleX:0.5244,scaleY:0.5244,x:179.95,y:152.65},0).wait(1).to({scaleX:0.5193,scaleY:0.5193,x:181.25,y:152.4},0).wait(1).to({scaleX:0.515,scaleY:0.515,x:182.3,y:152.25},0).wait(1).to({scaleX:0.5116,scaleY:0.5116,x:183.1,y:152.15},0).wait(1).to({scaleX:0.5089,scaleY:0.5089,x:183.8,y:152.05},0).wait(1).to({scaleX:0.507,scaleY:0.507,x:184.25,y:152},0).wait(1).to({scaleX:0.5059,scaleY:0.5059,x:184.5},0).wait(1).to({regX:25.3,regY:21.6,scaleX:0.5055,scaleY:0.5055,y:151.9},0).wait(1).to({regX:25.5,regY:21.5,x:184.6,y:151.85},0).wait(15).to({regX:25.3,regY:21.6,x:184.5,y:151.9},0).wait(1).to({regX:25.5,regY:21.5,x:184.6,y:151.8},0).wait(1).to({scaleX:0.5054,scaleY:0.5054,y:151.75},0).wait(1).to({scaleX:0.5053,scaleY:0.5053,y:151.65},0).wait(1).to({scaleX:0.5051,scaleY:0.5051,y:151.55},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:184.65,y:151.4},0).wait(1).to({scaleX:0.5047,scaleY:0.5047,x:184.6,y:151.25},0).wait(1).to({scaleX:0.5044,scaleY:0.5044,x:184.65,y:151.05},0).wait(1).to({scaleX:0.504,scaleY:0.504,y:150.8},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:184.7,y:150.55},0).wait(1).to({scaleX:0.5031,scaleY:0.5031,x:184.75,y:150.15},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,y:149.8},0).wait(1).to({scaleX:0.5019,scaleY:0.5019,x:184.8,y:149.35},0).wait(1).to({scaleX:0.5012,scaleY:0.5012,x:184.9,y:148.85},0).wait(1).to({scaleX:0.5003,scaleY:0.5003,x:184.95,y:148.2},0).wait(1).to({scaleX:0.4994,scaleY:0.4994,x:185,y:147.55},0).wait(1).to({scaleX:0.4983,scaleY:0.4983,x:185.1,y:146.75},0).wait(1).to({scaleX:0.497,scaleY:0.497,x:185.15,y:145.9},0).wait(1).to({scaleX:0.4955,scaleY:0.4955,x:185.3,y:144.8},0).wait(1).to({scaleX:0.4937,scaleY:0.4937,x:185.4,y:143.6},0).wait(1).to({scaleX:0.4917,scaleY:0.4917,x:185.55,y:142.15},0).wait(1).to({scaleX:0.4892,scaleY:0.4892,x:185.7,y:140.45},0).wait(1).to({scaleX:0.4862,scaleY:0.4862,x:185.95,y:138.35},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:186.2,y:135.75},0).wait(1).to({scaleX:0.4779,scaleY:0.4779,x:186.55,y:132.55},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:186.95,y:128.45},0).wait(1).to({scaleX:0.4649,scaleY:0.4649,x:187.45,y:123.45},0).wait(1).to({scaleX:0.4575,scaleY:0.4575,x:188,y:118.3},0).wait(1).to({scaleX:0.451,scaleY:0.451,x:188.45,y:113.75},0).wait(1).to({scaleX:0.4458,scaleY:0.4458,x:188.8,y:110.1},0).wait(1).to({scaleX:0.4416,scaleY:0.4416,x:189.1,y:107.2},0).wait(1).to({scaleX:0.4383,scaleY:0.4383,x:189.4,y:104.85},0).wait(1).to({scaleX:0.4355,scaleY:0.4355,x:189.55,y:102.95},0).wait(1).to({scaleX:0.4332,scaleY:0.4332,x:189.75,y:101.3},0).wait(1).to({scaleX:0.4312,scaleY:0.4312,x:189.85,y:99.95},0).wait(1).to({scaleX:0.4295,scaleY:0.4295,x:190,y:98.8},0).wait(1).to({scaleX:0.4281,scaleY:0.4281,x:190.1,y:97.75},0).wait(1).to({scaleX:0.4268,scaleY:0.4268,x:190.2,y:96.85},0).wait(1).to({scaleX:0.4257,scaleY:0.4257,x:190.25,y:96.05},0).wait(1).to({scaleX:0.4247,scaleY:0.4247,x:190.35,y:95.4},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:190.4,y:94.75},0).wait(1).to({scaleX:0.423,scaleY:0.423,x:190.45,y:94.25},0).wait(1).to({scaleX:0.4223,scaleY:0.4223,x:190.5,y:93.75},0).wait(1).to({scaleX:0.4217,scaleY:0.4217,x:190.55,y:93.3},0).wait(1).to({scaleX:0.4212,scaleY:0.4212,x:190.6,y:92.95},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:190.65,y:92.65},0).wait(1).to({scaleX:0.4203,scaleY:0.4203,y:92.35},0).wait(1).to({scaleX:0.42,scaleY:0.42,y:92.15},0).wait(1).to({scaleX:0.4197,scaleY:0.4197,x:190.7,y:91.9},0).wait(1).to({scaleX:0.4194,scaleY:0.4194,y:91.7},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:190.75,y:91.55},0).wait(1).to({scaleX:0.4191,scaleY:0.4191,y:91.45},0).wait(1).to({scaleX:0.4189,scaleY:0.4189,y:91.35},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,x:190.8,y:91.3},0).wait(1).to({scaleX:0.4187,scaleY:0.4187,y:91.25},0).wait(1).to({y:91.2},0).wait(1).to({regX:25.4,regY:21.6,x:190.7,y:91.25},0).wait(2));

	// guy right contribution
	this.instance_4 = new lib.guyrightcontribution_1();
	this.instance_4.setTransform(711.65,39.45,1.4303,1.4303,0,0,0,38.1,26.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).to({x:395.9,y:119.15,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:37.7,regY:26,x:395.3,y:118.9},0).wait(11).to({regX:38.1,regY:26.2,x:395.9,y:119.15},0).wait(1).to({regX:37.7,regY:26,scaleX:1.4222,scaleY:1.4216,x:393.55,y:118.75},0).wait(1).to({scaleX:1.4133,scaleY:1.4122,skewY:-0.0571,x:391.7,y:118.7},0).wait(1).to({scaleX:1.4037,scaleY:1.402,skewY:-0.0894,x:389.6,y:118.65},0).wait(1).to({scaleX:1.3934,scaleY:1.3909,skewY:-0.1243,x:387.45,y:118.55},0).wait(1).to({scaleX:1.3823,scaleY:1.379,skewY:-0.1617,x:385.05,y:118.45},0).wait(1).to({scaleX:1.3704,scaleY:1.3664,skewY:-0.2017,x:382.5,y:118.4},0).wait(1).to({scaleX:1.3578,scaleY:1.3529,skewY:-0.2443,x:379.8,y:118.3},0).wait(1).to({scaleX:1.3444,scaleY:1.3386,skewY:-0.2893,x:376.95,y:118.15},0).wait(1).to({scaleX:1.3303,scaleY:1.3235,skewY:-0.3369,x:373.95,y:118.05},0).wait(1).to({scaleX:1.3154,scaleY:1.3077,skewY:-0.3869,x:370.75,y:117.9},0).wait(1).to({scaleX:1.2998,scaleY:1.2911,skewY:-0.4394,x:367.45,y:117.75},0).wait(1).to({scaleX:1.2836,scaleY:1.2737,skewY:-0.4941,x:364,y:117.65},0).wait(1).to({scaleX:1.2666,scaleY:1.2557,skewY:-0.5511,x:360.35,y:117.55},0).wait(1).to({scaleX:1.2491,scaleY:1.237,skewY:-0.6102,x:356.6,y:117.4},0).wait(1).to({scaleX:1.2309,scaleY:1.2176,skewY:-0.6714,x:352.75,y:117.2},0).wait(1).to({scaleX:1.2122,scaleY:1.1976,skewY:-0.7343,x:348.75,y:117.1},0).wait(1).to({scaleX:1.193,scaleY:1.1771,skewY:-0.799,x:344.6,y:116.9},0).wait(1).to({scaleX:1.1733,scaleY:1.1562,skewY:-0.8652,x:340.45,y:116.75},0).wait(1).to({scaleX:1.1533,scaleY:1.1348,skewY:-0.9328,x:336.15,y:116.6},0).wait(1).to({scaleX:1.1329,scaleY:1.113,skewY:-1.0015,x:331.8,y:116.45},0).wait(1).to({scaleX:1.1122,scaleY:1.091,skewY:-1.071,x:327.35,y:116.25},0).wait(1).to({scaleX:1.0914,scaleY:1.0687,skewY:-1.1413,x:322.95,y:116.15},0).wait(1).to({scaleX:1.0704,scaleY:1.0463,skewY:-1.212,x:318.45,y:115.95},0).wait(1).to({scaleX:1.0493,scaleY:1.0239,skewY:-1.2829,x:313.95,y:115.7},0).wait(1).to({scaleX:1.0283,scaleY:1.0014,skewY:-1.3537,x:309.45,y:115.6},0).wait(1).to({scaleX:1.0073,scaleY:0.9791,skewY:-1.4243,x:305,y:115.4},0).wait(1).to({scaleX:0.9866,scaleY:0.9569,skewY:-1.4942,x:300.6,y:115.3},0).wait(1).to({scaleX:0.966,scaleY:0.935,skewY:-1.5635,x:296.15,y:115.05},0).wait(1).to({scaleX:0.9457,scaleY:0.9134,skewY:-1.6317,x:291.85,y:114.95},0).wait(1).to({scaleX:0.9258,scaleY:0.8921,skewY:-1.6986,x:287.6,y:114.75},0).wait(1).to({scaleX:0.9064,scaleY:0.8714,skewY:-1.7642,x:283.45,y:114.6},0).wait(1).to({scaleX:0.8874,scaleY:0.8511,skewY:-1.8281,x:279.4,y:114.45},0).wait(1).to({scaleX:0.8689,scaleY:0.8314,skewY:-1.8903,x:275.45,y:114.25},0).wait(1).to({scaleX:0.851,scaleY:0.8123,skewY:-1.9505,x:271.6,y:114.1},0).wait(1).to({scaleX:0.8338,scaleY:0.7939,skewY:-2.0087,x:267.95,y:114},0).wait(1).to({scaleX:0.8171,scaleY:0.7762,skewY:-2.0646,x:264.4,y:113.9},0).wait(1).to({scaleX:0.8012,scaleY:0.7592,skewY:-2.1183,x:261,y:113.75},0).wait(1).to({scaleX:0.786,scaleY:0.7429,skewY:-2.1696,x:257.75,y:113.6},0).wait(1).to({scaleX:0.7715,scaleY:0.7274,skewY:-2.2185,x:254.65,y:113.45},0).wait(1).to({scaleX:0.7577,scaleY:0.7128,skewY:-2.2648,x:251.7,y:113.35},0).wait(1).to({scaleX:0.7447,scaleY:0.6989,skewY:-2.3087,x:248.9,y:113.2},0).wait(1).to({scaleX:0.7324,scaleY:0.6858,skewY:-2.35,x:246.3,y:113.15},0).wait(1).to({scaleX:0.7209,scaleY:0.6735,skewY:-2.3886,x:243.85,y:113.05},0).wait(1).to({scaleX:0.7102,scaleY:0.6621,skewY:-2.4248,x:241.55,y:112.95},0).wait(1).to({scaleX:0.7002,scaleY:0.6515,skewY:-2.4583,x:239.4,y:112.9},0).wait(1).to({scaleX:0.691,scaleY:0.6416,skewY:-2.4893,x:237.5,y:112.8},0).wait(1).to({scaleX:0.6826,scaleY:0.6326,skewY:-2.5178,x:235.65,y:112.75},0).wait(1).to({scaleX:0.6749,scaleY:0.6244,skewY:-2.5437,x:234,y:112.7},0).wait(1).to({scaleX:0.6679,scaleY:0.617,skewY:-2.5671,x:232.55,y:112.6},0).wait(1).to({scaleX:0.6617,scaleY:0.6103,skewY:-2.5881,x:231.2,y:112.55},0).wait(1).to({scaleX:0.6561,scaleY:0.6044,skewY:-2.6067,x:230},0).wait(1).to({scaleX:0.6513,scaleY:0.5993,skewY:-2.623,x:229},0).wait(1).to({scaleX:0.6472,scaleY:0.5949,skewY:-2.6369,x:228.1,y:112.45},0).wait(1).to({scaleX:0.6437,scaleY:0.5912,skewY:-2.6485,x:227.4},0).wait(1).to({scaleX:0.6409,scaleY:0.5882,skewY:-2.658,x:226.8},0).wait(1).to({scaleX:0.6388,scaleY:0.5859,skewY:-2.6652,x:226.3},0).wait(1).to({scaleX:0.6373,scaleY:0.5843,skewY:-2.6703,x:226,y:112.4},0).wait(1).to({scaleX:0.6364,scaleY:0.5833,skewY:-2.6733,x:225.8},0).wait(1).to({regX:38.4,regY:26.4,scaleX:0.6361,scaleY:0.583,skewY:-2.6743,x:226.05,y:112.5},0).wait(79));

	// guy left contribution
	this.instance_5 = new lib.guyleftcontribution_1();
	this.instance_5.setTransform(-132.1,36.75,1.4603,1.4603,0,0,0,30.4,9.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({scaleX:1.4604,scaleY:1.4604,x:-50.15,y:132.9,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:30.5,regY:9.7,x:-50,y:132.75},0).wait(6).to({scaleX:1.4603,scaleY:1.4603},0).wait(6).to({regX:30.4,regY:9.8,x:-50.15,y:132.9},0).wait(1).to({regX:30.5,regY:9.7,scaleX:1.4504,scaleY:1.4504,skewX:-0.08,skewY:-0.0135,x:-47.45,y:132.85},0).wait(1).to({scaleX:1.4395,scaleY:1.4396,skewX:-0.1674,skewY:-0.0283,x:-44.7,y:132.95},0).wait(1).to({scaleX:1.4276,scaleY:1.4279,skewX:-0.2621,skewY:-0.0443,x:-41.7,y:133.05},0).wait(1).to({scaleX:1.4149,scaleY:1.4152,skewX:-0.3644,skewY:-0.0616,x:-38.45,y:133.2},0).wait(1).to({scaleX:1.4012,scaleY:1.4016,skewX:-0.4741,skewY:-0.0802,x:-35,y:133.3},0).wait(1).to({scaleX:1.3866,scaleY:1.3871,skewX:-0.5913,skewY:-0.1,x:-31.25,y:133.45},0).wait(1).to({scaleX:1.3711,scaleY:1.3716,skewX:-0.716,skewY:-0.1211,x:-27.35,y:133.55},0).wait(1).to({scaleX:1.3546,scaleY:1.3552,skewX:-0.8482,skewY:-0.1435,x:-23.15,y:133.75},0).wait(1).to({scaleX:1.3372,scaleY:1.3379,skewX:-0.9876,skewY:-0.1671,x:-18.75,y:133.95},0).wait(1).to({scaleX:1.3189,scaleY:1.3198,skewX:-1.1343,skewY:-0.1919,x:-14.15,y:134.05},0).wait(1).to({scaleX:1.2997,scaleY:1.3007,skewX:-1.2879,skewY:-0.2179,x:-9.25,y:134.25},0).wait(1).to({scaleX:1.2797,scaleY:1.2808,skewX:-1.4484,skewY:-0.2451,x:-4.15,y:134.45},0).wait(1).to({scaleX:1.2589,scaleY:1.2601,skewX:-1.6155,skewY:-0.2733,x:1.1,y:134.6},0).wait(1).to({scaleX:1.2373,scaleY:1.2386,skewX:-1.7888,skewY:-0.3026,x:6.55,y:134.85},0).wait(1).to({scaleX:1.2149,scaleY:1.2164,skewX:-1.9679,skewY:-0.3329,x:12.25,y:135.05},0).wait(1).to({scaleX:1.1919,scaleY:1.1935,skewX:-2.1526,skewY:-0.3642,x:18.1,y:135.25},0).wait(1).to({scaleX:1.1682,scaleY:1.17,skewX:-2.3422,skewY:-0.3963,x:24.1,y:135.5},0).wait(1).to({scaleX:1.144,scaleY:1.1459,skewX:-2.5363,skewY:-0.4291,x:30.25,y:135.7},0).wait(1).to({scaleX:1.1193,scaleY:1.1214,skewX:-2.7343,skewY:-0.4626,x:36.45,y:135.9},0).wait(1).to({scaleX:1.0942,scaleY:1.0965,skewX:-2.9356,skewY:-0.4966,x:42.8,y:136.15},0).wait(1).to({scaleX:1.0688,scaleY:1.0712,skewX:-3.1395,skewY:-0.5312,x:49.25,y:136.4},0).wait(1).to({scaleX:1.0431,scaleY:1.0456,skewX:-3.3455,skewY:-0.566,x:55.75,y:136.7},0).wait(1).to({scaleX:1.0172,scaleY:1.0199,skewX:-3.5527,skewY:-0.6011,x:62.3,y:136.85},0).wait(1).to({scaleX:0.9913,scaleY:0.9942,skewX:-3.7605,skewY:-0.6362,x:68.9,y:137.1},0).wait(1).to({scaleX:0.9654,scaleY:0.9685,skewX:-3.9682,skewY:-0.6713,x:75.45,y:137.35},0).wait(1).to({scaleX:0.9396,scaleY:0.9428,skewX:-4.1749,skewY:-0.7063,x:81.95,y:137.6},0).wait(1).to({scaleX:0.914,scaleY:0.9174,skewX:-4.3801,skewY:-0.741,x:88.55,y:137.85},0).wait(1).to({scaleX:0.8887,scaleY:0.8922,skewX:-4.583,skewY:-0.7754,x:94.9,y:138.15},0).wait(1).to({scaleX:0.8638,scaleY:0.8674,skewX:-4.7829,skewY:-0.8092,x:101.25,y:138.4},0).wait(1).to({scaleX:0.8393,scaleY:0.8431,skewX:-4.9793,skewY:-0.8424,x:107.4,y:138.55},0).wait(1).to({scaleX:0.8153,scaleY:0.8193,skewX:-5.1714,skewY:-0.8749,x:113.5,y:138.8},0).wait(1).to({scaleX:0.792,scaleY:0.796,skewX:-5.3589,skewY:-0.9066,x:119.4,y:139.05},0).wait(1).to({scaleX:0.7692,scaleY:0.7735,skewX:-5.5411,skewY:-0.9375,x:125.15,y:139.2},0).wait(1).to({scaleX:0.7472,scaleY:0.7516,skewX:-5.7176,skewY:-0.9673,x:130.8,y:139.45},0).wait(1).to({scaleX:0.7259,scaleY:0.7304,skewX:-5.8881,skewY:-0.9962,x:136.2,y:139.65},0).wait(1).to({scaleX:0.7055,scaleY:0.7101,skewX:-6.0521,skewY:-1.0239,x:141.35,y:139.85},0).wait(1).to({scaleX:0.6859,scaleY:0.6906,skewX:-6.2095,skewY:-1.0505,x:146.3,y:140},0).wait(1).to({scaleX:0.6671,scaleY:0.672,skewX:-6.3598,skewY:-1.076,x:151.05,y:140.2},0).wait(1).to({scaleX:0.6493,scaleY:0.6542,skewX:-6.5031,skewY:-1.1002,x:155.6,y:140.35},0).wait(1).to({scaleX:0.6323,scaleY:0.6374,skewX:-6.639,skewY:-1.1232,x:159.9,y:140.5},0).wait(1).to({scaleX:0.6163,scaleY:0.6214,skewX:-6.7675,skewY:-1.1449,x:164,y:140.7},0).wait(1).to({scaleX:0.6012,scaleY:0.6064,skewX:-6.8884,skewY:-1.1654,x:167.8,y:140.85},0).wait(1).to({scaleX:0.587,scaleY:0.5924,skewX:-7.0019,skewY:-1.1846,x:171.4,y:141},0).wait(1).to({scaleX:0.5738,scaleY:0.5792,skewX:-7.1078,skewY:-1.2025,x:174.75,y:141.15},0).wait(1).to({scaleX:0.5616,scaleY:0.567,skewX:-7.2061,skewY:-1.2192,x:177.85,y:141.2},0).wait(1).to({scaleX:0.5502,scaleY:0.5558,skewX:-7.2969,skewY:-1.2345,x:180.75,y:141.3},0).wait(1).to({scaleX:0.5398,scaleY:0.5455,skewX:-7.3803,skewY:-1.2486,x:183.35,y:141.4},0).wait(1).to({scaleX:0.5304,scaleY:0.536,skewX:-7.4563,skewY:-1.2615,x:185.7,y:141.5},0).wait(1).to({scaleX:0.5218,scaleY:0.5275,skewX:-7.5251,skewY:-1.2731,x:187.9,y:141.55},0).wait(1).to({scaleX:0.5141,scaleY:0.5199,skewX:-7.5867,skewY:-1.2835,x:189.9,y:141.65},0).wait(1).to({scaleX:0.5073,scaleY:0.5131,skewX:-7.6412,skewY:-1.2928,x:191.6,y:141.75},0).wait(1).to({scaleX:0.5014,scaleY:0.5072,skewX:-7.6888,skewY:-1.3008,x:193.1,y:141.8},0).wait(1).to({scaleX:0.4963,scaleY:0.5022,skewX:-7.7296,skewY:-1.3077,x:194.4,y:141.85},0).wait(1).to({scaleX:0.492,scaleY:0.4979,skewX:-7.7637,skewY:-1.3135,x:195.5},0).wait(1).to({scaleX:0.4886,scaleY:0.4945,skewX:-7.7913,skewY:-1.3182,x:196.35,y:141.9},0).wait(1).to({scaleX:0.4859,scaleY:0.4919,skewX:-7.8125,skewY:-1.3217,x:197,y:141.95},0).wait(1).to({scaleX:0.4841,scaleY:0.49,skewX:-7.8275,skewY:-1.3243,x:197.5,y:141.9},0).wait(1).to({scaleX:0.483,scaleY:0.4889,skewX:-7.8364,skewY:-1.3258,x:197.8,y:141.95},0).wait(1).to({regX:30.8,regY:10.1,scaleX:0.4826,scaleY:0.4885,skewX:-7.8393,skewY:-1.3263,x:197.85,y:142},0).wait(77));

	// girl left contribution
	this.instance_6 = new lib.girlleftcontribution_1();
	this.instance_6.setTransform(-279.45,281.8,1.4905,1.4905,0,0,0,44,32.4);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({x:18.3,y:203.95,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:44.2,regY:32.5,x:18.6,y:204.1},0).wait(18).to({regX:44,regY:32.4,x:18.3,y:203.95},0).wait(1).to({regX:44.2,regY:32.5,scaleX:1.4794,scaleY:1.4794,x:20.55,y:203.65},0).wait(1).to({scaleX:1.4672,scaleY:1.4672,x:22.65,y:203.1},0).wait(1).to({scaleX:1.4541,scaleY:1.4541,x:24.9,y:202.55},0).wait(1).to({scaleX:1.4399,scaleY:1.4399,x:27.4,y:202},0).wait(1).to({scaleX:1.4246,scaleY:1.4246,x:30,y:201.35},0).wait(1).to({scaleX:1.4083,scaleY:1.4083,x:32.85,y:200.65},0).wait(1).to({scaleX:1.391,scaleY:1.391,x:35.9,y:199.95},0).wait(1).to({scaleX:1.3726,scaleY:1.3726,x:39.05,y:199.2},0).wait(1).to({scaleX:1.3533,scaleY:1.3533,x:42.4,y:198.4},0).wait(1).to({scaleX:1.3329,scaleY:1.3329,x:45.95,y:197.55},0).wait(1).to({scaleX:1.3115,scaleY:1.3115,x:49.65,y:196.65},0).wait(1).to({scaleX:1.2892,scaleY:1.2892,x:53.55,y:195.75},0).wait(1).to({scaleX:1.266,scaleY:1.266,x:57.5,y:194.8},0).wait(1).to({scaleX:1.2419,scaleY:1.2419,x:61.7,y:193.8},0).wait(1).to({scaleX:1.217,scaleY:1.217,x:66.05,y:192.75},0).wait(1).to({scaleX:1.1914,scaleY:1.1914,x:70.45,y:191.7},0).wait(1).to({scaleX:1.165,scaleY:1.165,x:75.05,y:190.6},0).wait(1).to({scaleX:1.1381,scaleY:1.1381,x:79.75,y:189.5},0).wait(1).to({scaleX:1.1106,scaleY:1.1106,x:84.55,y:188.4},0).wait(1).to({scaleX:1.0826,scaleY:1.0826,x:89.35,y:187.25},0).wait(1).to({scaleX:1.0543,scaleY:1.0543,x:94.3,y:186.05},0).wait(1).to({scaleX:1.0256,scaleY:1.0256,x:99.3,y:184.9},0).wait(1).to({scaleX:0.9968,scaleY:0.9968,x:104.25,y:183.7},0).wait(1).to({scaleX:0.968,scaleY:0.968,x:109.3,y:182.45},0).wait(1).to({scaleX:0.9391,scaleY:0.9391,x:114.25,y:181.25},0).wait(1).to({scaleX:0.9104,scaleY:0.9104,x:119.3,y:180.1},0).wait(1).to({scaleX:0.8819,scaleY:0.8819,x:124.25,y:178.9},0).wait(1).to({scaleX:0.8537,scaleY:0.8537,x:129.15,y:177.75},0).wait(1).to({scaleX:0.8259,scaleY:0.8259,x:133.95,y:176.6},0).wait(1).to({scaleX:0.7986,scaleY:0.7986,x:138.65,y:175.5},0).wait(1).to({scaleX:0.7719,scaleY:0.7719,x:143.3,y:174.4},0).wait(1).to({scaleX:0.7459,scaleY:0.7459,x:147.8,y:173.3},0).wait(1).to({scaleX:0.7206,scaleY:0.7206,x:152.25,y:172.25},0).wait(1).to({scaleX:0.696,scaleY:0.696,x:156.45,y:171.25},0).wait(1).to({scaleX:0.6724,scaleY:0.6724,x:160.6,y:170.25},0).wait(1).to({scaleX:0.6496,scaleY:0.6496,x:164.55,y:169.3},0).wait(1).to({scaleX:0.6277,scaleY:0.6277,x:168.35,y:168.45},0).wait(1).to({scaleX:0.6068,scaleY:0.6068,x:171.95,y:167.55},0).wait(1).to({scaleX:0.5869,scaleY:0.5869,x:175.45,y:166.7},0).wait(1).to({scaleX:0.568,scaleY:0.568,x:178.7,y:165.95},0).wait(1).to({scaleX:0.5502,scaleY:0.5502,x:181.8,y:165.25},0).wait(1).to({scaleX:0.5334,scaleY:0.5334,x:184.7,y:164.55},0).wait(1).to({scaleX:0.5176,scaleY:0.5176,x:187.5,y:163.85},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:190.05,y:163.3},0).wait(1).to({scaleX:0.4892,scaleY:0.4892,x:192.35,y:162.7},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:194.55,y:162.2},0).wait(1).to({scaleX:0.465,scaleY:0.465,x:196.6,y:161.7},0).wait(1).to({scaleX:0.4545,scaleY:0.4545,x:198.45,y:161.25},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:200.1,y:160.85},0).wait(1).to({scaleX:0.4363,scaleY:0.4363,x:201.6,y:160.55},0).wait(1).to({scaleX:0.4288,scaleY:0.4288,x:202.9,y:160.25},0).wait(1).to({scaleX:0.4222,scaleY:0.4222,x:204.05,y:159.9},0).wait(1).to({scaleX:0.4165,scaleY:0.4165,x:205,y:159.7},0).wait(1).to({scaleX:0.4118,scaleY:0.4118,x:205.85,y:159.55},0).wait(1).to({scaleX:0.4079,scaleY:0.4079,x:206.55,y:159.35},0).wait(1).to({scaleX:0.405,scaleY:0.405,x:207,y:159.2},0).wait(1).to({scaleX:0.4029,scaleY:0.4029,x:207.4,y:159.15},0).wait(1).to({scaleX:0.4017,scaleY:0.4017,x:207.6,y:159.1},0).wait(1).to({regX:44.4,regY:32.8,scaleX:0.4012,scaleY:0.4012,y:159.05},0).wait(75));

	// girl rigth contribution
	this.instance_7 = new lib.girlrigthcontribution();
	this.instance_7.setTransform(422.3,271.75,1.4168,1.4168,0,0,0,39.1,19.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(14).to({_off:false},0).to({x:367,y:192,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:366.85,y:191.85},0).wait(17).to({regX:39.1,regY:19.1,x:367,y:192},0).wait(1).to({regX:39,regY:19,scaleX:1.4068,scaleY:1.4068,x:365.3,y:191.7},0).wait(1).to({scaleX:1.3958,scaleY:1.3958,x:363.65,y:191.5},0).wait(1).to({scaleX:1.3839,scaleY:1.3839,x:361.75,y:191.3},0).wait(1).to({scaleX:1.371,scaleY:1.371,x:359.8,y:191.1},0).wait(1).to({scaleX:1.3572,scaleY:1.3572,x:357.75,y:190.9},0).wait(1).to({scaleX:1.3425,scaleY:1.3425,x:355.45,y:190.65},0).wait(1).to({scaleX:1.3269,scaleY:1.3269,x:353.05,y:190.4},0).wait(1).to({scaleX:1.3103,scaleY:1.3103,x:350.5,y:190.1},0).wait(1).to({scaleX:1.2927,scaleY:1.2927,x:347.8,y:189.8},0).wait(1).to({scaleX:1.2743,scaleY:1.2743,x:345,y:189.55},0).wait(1).to({scaleX:1.255,scaleY:1.255,x:342.05,y:189.25},0).wait(1).to({scaleX:1.2348,scaleY:1.2348,x:338.95,y:188.9},0).wait(1).to({scaleX:1.2139,scaleY:1.2139,x:335.75,y:188.55},0).wait(1).to({scaleX:1.1921,scaleY:1.1921,x:332.4,y:188.2},0).wait(1).to({scaleX:1.1696,scaleY:1.1696,x:328.95,y:187.8},0).wait(1).to({scaleX:1.1464,scaleY:1.1464,x:325.4,y:187.5},0).wait(1).to({scaleX:1.1226,scaleY:1.1226,x:321.8,y:187.1},0).wait(1).to({scaleX:1.0982,scaleY:1.0982,x:318.05,y:186.65},0).wait(1).to({scaleX:1.0733,scaleY:1.0733,x:314.2,y:186.3},0).wait(1).to({scaleX:1.048,scaleY:1.048,x:310.35,y:185.85},0).wait(1).to({scaleX:1.0224,scaleY:1.0224,x:306.4,y:185.5},0).wait(1).to({scaleX:0.9965,scaleY:0.9965,x:302.45,y:185.05},0).wait(1).to({scaleX:0.9705,scaleY:0.9705,x:298.5,y:184.65},0).wait(1).to({scaleX:0.9444,scaleY:0.9444,x:294.5,y:184.2},0).wait(1).to({scaleX:0.9183,scaleY:0.9183,x:290.45,y:183.8},0).wait(1).to({scaleX:0.8923,scaleY:0.8923,x:286.5,y:183.35},0).wait(1).to({scaleX:0.8665,scaleY:0.8665,x:282.55,y:182.9},0).wait(1).to({scaleX:0.8411,scaleY:0.8411,x:278.65,y:182.55},0).wait(1).to({scaleX:0.8159,scaleY:0.8159,x:274.8,y:182.1},0).wait(1).to({scaleX:0.7913,scaleY:0.7913,x:271,y:181.75},0).wait(1).to({scaleX:0.7671,scaleY:0.7671,x:267.3,y:181.35},0).wait(1).to({scaleX:0.7436,scaleY:0.7436,x:263.75,y:180.95},0).wait(1).to({scaleX:0.7207,scaleY:0.7207,x:260.2,y:180.6},0).wait(1).to({scaleX:0.6985,scaleY:0.6985,x:256.85,y:180.2},0).wait(1).to({scaleX:0.6771,scaleY:0.6771,x:253.55,y:179.85},0).wait(1).to({scaleX:0.6565,scaleY:0.6565,x:250.4,y:179.5},0).wait(1).to({scaleX:0.6367,scaleY:0.6367,x:247.4,y:179.2},0).wait(1).to({scaleX:0.6178,scaleY:0.6178,x:244.5,y:178.9},0).wait(1).to({scaleX:0.5998,scaleY:0.5998,x:241.7,y:178.6},0).wait(1).to({scaleX:0.5828,scaleY:0.5828,x:239.1,y:178.3},0).wait(1).to({scaleX:0.5666,scaleY:0.5666,x:236.65,y:178.05},0).wait(1).to({scaleX:0.5514,scaleY:0.5514,x:234.3,y:177.85},0).wait(1).to({scaleX:0.5372,scaleY:0.5372,x:232.1,y:177.6},0).wait(1).to({scaleX:0.5239,scaleY:0.5239,x:230.1,y:177.4},0).wait(1).to({scaleX:0.5115,scaleY:0.5115,x:228.2,y:177.15},0).wait(1).to({scaleX:0.5001,scaleY:0.5001,x:226.45,y:177},0).wait(1).to({scaleX:0.4896,scaleY:0.4896,x:224.85,y:176.85},0).wait(1).to({scaleX:0.4801,scaleY:0.4801,x:223.35,y:176.65},0).wait(1).to({scaleX:0.4714,scaleY:0.4714,x:222.05,y:176.55},0).wait(1).to({scaleX:0.4637,scaleY:0.4637,x:220.9,y:176.4},0).wait(1).to({scaleX:0.4569,scaleY:0.4569,x:219.8,y:176.35},0).wait(1).to({scaleX:0.4509,scaleY:0.4509,x:218.9,y:176.2},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:218.15,y:176.1},0).wait(1).to({scaleX:0.4415,scaleY:0.4415,x:217.45,y:176.05},0).wait(1).to({scaleX:0.438,scaleY:0.438,x:216.95,y:176},0).wait(1).to({scaleX:0.4353,scaleY:0.4353,x:216.55,y:175.95},0).wait(1).to({scaleX:0.4334,scaleY:0.4334,x:216.25},0).wait(1).to({scaleX:0.4323,scaleY:0.4323,x:216.05,y:175.9},0).wait(1).to({regX:39.2,regY:19.1,scaleX:0.432,scaleY:0.432,y:175.95},0).wait(74));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("AzsjAIfBpgIIXPbI+1Jmg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:178.45,y:155.7}).wait(210));

	// r guy i shadow
	this.instance_8 = new lib.roundshadow();
	this.instance_8.setTransform(643.45,54.75,1.4303,1.4303,0,0,0,28.2,22.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(19).to({_off:false},0).to({x:327.7,y:134.45,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:327.4,y:134.05},0).wait(11).to({regX:28.2,regY:22.8,x:327.7,y:134.45},0).wait(1).to({regX:28,regY:22.5,scaleX:1.4225,scaleY:1.4225,x:326.15,y:133.75},0).wait(1).to({scaleX:1.4141,scaleY:1.4141,x:324.75,y:133.45},0).wait(1).to({scaleX:1.4049,scaleY:1.4049,x:323.25,y:133.2},0).wait(1).to({scaleX:1.395,scaleY:1.395,x:321.65,y:132.9},0).wait(1).to({scaleX:1.3844,scaleY:1.3844,x:319.9,y:132.55},0).wait(1).to({scaleX:1.373,scaleY:1.373,x:318.1,y:132.2},0).wait(1).to({scaleX:1.3609,scaleY:1.3609,x:316.1,y:131.75},0).wait(1).to({scaleX:1.3482,scaleY:1.3482,x:314.05,y:131.4},0).wait(1).to({scaleX:1.3346,scaleY:1.3346,x:311.85,y:130.95},0).wait(1).to({scaleX:1.3204,scaleY:1.3204,x:309.5,y:130.5},0).wait(1).to({scaleX:1.3056,scaleY:1.3056,x:307.1,y:130.05},0).wait(1).to({scaleX:1.29,scaleY:1.29,x:304.6,y:129.55},0).wait(1).to({scaleX:1.2738,scaleY:1.2738,x:301.95,y:129},0).wait(1).to({scaleX:1.2571,scaleY:1.2571,x:299.25,y:128.5},0).wait(1).to({scaleX:1.2397,scaleY:1.2397,x:296.45,y:127.9},0).wait(1).to({scaleX:1.2218,scaleY:1.2218,x:293.55,y:127.35},0).wait(1).to({scaleX:1.2035,scaleY:1.2035,x:290.55,y:126.75},0).wait(1).to({scaleX:1.1847,scaleY:1.1847,x:287.5,y:126.15},0).wait(1).to({scaleX:1.1655,scaleY:1.1655,x:284.4,y:125.5},0).wait(1).to({scaleX:1.146,scaleY:1.146,x:281.25,y:124.95},0).wait(1).to({scaleX:1.1263,scaleY:1.1263,x:278.05,y:124.3},0).wait(1).to({scaleX:1.1063,scaleY:1.1063,x:274.8,y:123.65},0).wait(1).to({scaleX:1.0863,scaleY:1.0863,x:271.5,y:123},0).wait(1).to({scaleX:1.0661,scaleY:1.0661,x:268.25,y:122.35},0).wait(1).to({scaleX:1.046,scaleY:1.046,x:265,y:121.75},0).wait(1).to({scaleX:1.026,scaleY:1.026,x:261.75,y:121.1},0).wait(1).to({scaleX:1.0061,scaleY:1.0061,x:258.5,y:120.45},0).wait(1).to({scaleX:0.9865,scaleY:0.9865,x:255.3,y:119.8},0).wait(1).to({scaleX:0.9671,scaleY:0.9671,x:252.2,y:119.2},0).wait(1).to({scaleX:0.9481,scaleY:0.9481,x:249.1,y:118.6},0).wait(1).to({scaleX:0.9295,scaleY:0.9295,x:246.1,y:118},0).wait(1).to({scaleX:0.9114,scaleY:0.9114,x:243.1,y:117.4},0).wait(1).to({scaleX:0.8937,scaleY:0.8937,x:240.25,y:116.85},0).wait(1).to({scaleX:0.8766,scaleY:0.8766,x:237.5,y:116.25},0).wait(1).to({scaleX:0.8601,scaleY:0.8601,x:234.85,y:115.75},0).wait(1).to({scaleX:0.8442,scaleY:0.8442,x:232.25,y:115.25},0).wait(1).to({scaleX:0.829,scaleY:0.829,x:229.75,y:114.75},0).wait(1).to({scaleX:0.8144,scaleY:0.8144,x:227.4,y:114.3},0).wait(1).to({scaleX:0.8006,scaleY:0.8006,x:225.15,y:113.85},0).wait(1).to({scaleX:0.7874,scaleY:0.7874,x:223,y:113.45},0).wait(1).to({scaleX:0.775,scaleY:0.775,x:221,y:113.05},0).wait(1).to({scaleX:0.7632,scaleY:0.7632,x:219.1,y:112.65},0).wait(1).to({scaleX:0.7523,scaleY:0.7523,x:217.3,y:112.35},0).wait(1).to({scaleX:0.742,scaleY:0.742,x:215.65,y:112},0).wait(1).to({scaleX:0.7325,scaleY:0.7325,x:214.1,y:111.7},0).wait(1).to({scaleX:0.7237,scaleY:0.7237,x:212.65,y:111.4},0).wait(1).to({scaleX:0.7156,scaleY:0.7156,x:211.4,y:111.15},0).wait(1).to({scaleX:0.7082,scaleY:0.7082,x:210.2,y:110.95},0).wait(1).to({scaleX:0.7016,scaleY:0.7016,x:209.1,y:110.7},0).wait(1).to({scaleX:0.6956,scaleY:0.6956,x:208.15,y:110.5},0).wait(1).to({scaleX:0.6903,scaleY:0.6903,x:207.3,y:110.35},0).wait(1).to({scaleX:0.6857,scaleY:0.6857,x:206.5,y:110.2},0).wait(1).to({scaleX:0.6818,scaleY:0.6818,x:205.9,y:110.1},0).wait(1).to({scaleX:0.6785,scaleY:0.6785,x:205.35,y:109.95},0).wait(1).to({scaleX:0.6758,scaleY:0.6758,x:204.9,y:109.85},0).wait(1).to({scaleX:0.6738,scaleY:0.6738,x:204.55,y:109.8},0).wait(1).to({scaleX:0.6723,scaleY:0.6723,x:204.3},0).wait(1).to({scaleX:0.6714,scaleY:0.6714,x:204.2,y:109.75},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.6712,scaleY:0.6712,x:204.3,y:109.9},0).wait(1).to({regX:28,regY:22.5,x:204.05,y:109.65},0).wait(15).to({regX:28.4,regY:22.9,x:204.3,y:109.9},0).wait(1).to({regX:28,regY:22.5,scaleX:0.671,scaleY:0.671,x:204.05,y:109.6},0).wait(1).to({scaleX:0.6708,scaleY:0.6708},0).wait(1).to({scaleX:0.6706,scaleY:0.6706},0).wait(1).to({scaleX:0.6702,scaleY:0.6702,y:109.55},0).wait(1).to({scaleX:0.6697,scaleY:0.6697,y:109.5},0).wait(1).to({scaleX:0.6691,scaleY:0.6691,x:204.1,y:109.45},0).wait(1).to({scaleX:0.6684,scaleY:0.6684,y:109.4},0).wait(1).to({scaleX:0.6676,scaleY:0.6676,x:204.15,y:109.3},0).wait(1).to({scaleX:0.6667,scaleY:0.6667,y:109.25},0).wait(1).to({scaleX:0.6656,scaleY:0.6656,x:204.2,y:109.1},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,x:204.25,y:109.05},0).wait(1).to({scaleX:0.6628,scaleY:0.6628,y:108.9},0).wait(1).to({scaleX:0.6612,scaleY:0.6612,x:204.3,y:108.8},0).wait(1).to({scaleX:0.6593,scaleY:0.6593,x:204.4,y:108.6},0).wait(1).to({scaleX:0.6572,scaleY:0.6572,x:204.45,y:108.45},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:204.55,y:108.2},0).wait(1).to({scaleX:0.6521,scaleY:0.6521,x:204.6,y:107.95},0).wait(1).to({scaleX:0.649,scaleY:0.649,x:204.7,y:107.7},0).wait(1).to({scaleX:0.6455,scaleY:0.6455,x:204.8,y:107.35},0).wait(1).to({scaleX:0.6415,scaleY:0.6415,x:204.95,y:107.05},0).wait(1).to({scaleX:0.6368,scaleY:0.6368,x:205.1,y:106.65},0).wait(1).to({scaleX:0.6315,scaleY:0.6315,x:205.3,y:106.15},0).wait(1).to({scaleX:0.6252,scaleY:0.6252,x:205.45,y:105.6},0).wait(1).to({scaleX:0.6178,scaleY:0.6178,x:205.7,y:105},0).wait(1).to({scaleX:0.6088,scaleY:0.6088,x:206,y:104.2},0).wait(1).to({scaleX:0.5978,scaleY:0.5978,x:206.35,y:103.25},0).wait(1).to({scaleX:0.5842,scaleY:0.5842,x:206.75,y:102.05},0).wait(1).to({scaleX:0.5675,scaleY:0.5675,x:207.3,y:100.6},0).wait(1).to({scaleX:0.5481,scaleY:0.5481,x:207.9,y:98.95},0).wait(1).to({scaleX:0.5286,scaleY:0.5286,x:208.55,y:97.25},0).wait(1).to({scaleX:0.5116,scaleY:0.5116,x:209.05,y:95.75},0).wait(1).to({scaleX:0.4976,scaleY:0.4976,x:209.5,y:94.55},0).wait(1).to({scaleX:0.4863,scaleY:0.4863,x:209.85,y:93.55},0).wait(1).to({scaleX:0.477,scaleY:0.477,x:210.15,y:92.75},0).wait(1).to({scaleX:0.4692,scaleY:0.4692,x:210.4,y:92.05},0).wait(1).to({scaleX:0.4627,scaleY:0.4627,x:210.6,y:91.5},0).wait(1).to({scaleX:0.457,scaleY:0.457,x:210.8,y:91},0).wait(1).to({scaleX:0.4521,scaleY:0.4521,x:210.95,y:90.55},0).wait(1).to({scaleX:0.4477,scaleY:0.4477,x:211.1,y:90.2},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:211.25,y:89.9},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,x:211.35,y:89.55},0).wait(1).to({scaleX:0.4376,scaleY:0.4376,x:211.4,y:89.3},0).wait(1).to({scaleX:0.4349,scaleY:0.4349,x:211.5,y:89.1},0).wait(1).to({scaleX:0.4326,scaleY:0.4326,x:211.55,y:88.9},0).wait(1).to({scaleX:0.4304,scaleY:0.4304,x:211.65,y:88.7},0).wait(1).to({scaleX:0.4285,scaleY:0.4285,x:211.7,y:88.55},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:211.75,y:88.4},0).wait(1).to({scaleX:0.4253,scaleY:0.4253,x:211.8,y:88.25},0).wait(1).to({scaleX:0.424,scaleY:0.424,y:88.15},0).wait(1).to({scaleX:0.4228,scaleY:0.4228,x:211.9,y:88},0).wait(1).to({scaleX:0.4218,scaleY:0.4218,y:87.95},0).wait(1).to({scaleX:0.4208,scaleY:0.4208,x:211.95,y:87.85},0).wait(1).to({scaleX:0.42,scaleY:0.42,y:87.8},0).wait(1).to({scaleX:0.4193,scaleY:0.4193,x:212,y:87.75},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,y:87.65},0).wait(1).to({scaleX:0.4183,scaleY:0.4183},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,x:212.05,y:87.6},0).wait(1).to({scaleX:0.4175,scaleY:0.4175},0).wait(1).to({scaleX:0.4173,scaleY:0.4173,y:87.55},0).wait(1).to({scaleX:0.4171,scaleY:0.4171,x:212.1},0).wait(1).to({scaleX:0.417,scaleY:0.417},0).wait(1).to({regX:28.3,regY:23,x:212.25,y:87.75},0).wait(1));

	// l guy i shadow
	this.instance_9 = new lib.roundshadow();
	this.instance_9.setTransform(-211.3,50.9,1.4603,1.4603,0,0,0,28.2,22.8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(25).to({_off:false},0).to({scaleX:1.4604,scaleY:1.4604,x:-129.35,y:147.05,alpha:0.1602},45,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:-129.65,y:146.6},0).wait(6).to({scaleX:1.4603,scaleY:1.4603},0).wait(6).to({regX:28.2,regY:22.8,x:-129.35,y:147.05},0).wait(1).to({regX:28,regY:22.5,scaleX:1.4506,scaleY:1.4506,x:-126.45,y:146.45},0).wait(1).to({scaleX:1.4399,scaleY:1.4399,x:-123,y:146.25},0).wait(1).to({scaleX:1.4284,scaleY:1.4284,x:-119.2,y:146.1},0).wait(1).to({scaleX:1.4159,scaleY:1.4159,x:-115.15,y:145.85},0).wait(1).to({scaleX:1.4025,scaleY:1.4025,x:-110.8,y:145.65},0).wait(1).to({scaleX:1.3882,scaleY:1.3882,x:-106.1,y:145.45},0).wait(1).to({scaleX:1.373,scaleY:1.373,x:-101.15,y:145.2},0).wait(1).to({scaleX:1.3569,scaleY:1.3569,x:-95.9,y:144.95},0).wait(1).to({scaleX:1.3399,scaleY:1.3399,x:-90.35,y:144.7},0).wait(1).to({scaleX:1.322,scaleY:1.322,x:-84.5,y:144.4},0).wait(1).to({scaleX:1.3032,scaleY:1.3032,x:-78.35,y:144.1},0).wait(1).to({scaleX:1.2837,scaleY:1.2837,x:-72,y:143.8},0).wait(1).to({scaleX:1.2633,scaleY:1.2633,x:-65.35,y:143.45},0).wait(1).to({scaleX:1.2422,scaleY:1.2422,x:-58.45,y:143.15},0).wait(1).to({scaleX:1.2203,scaleY:1.2203,x:-51.35,y:142.8},0).wait(1).to({scaleX:1.1978,scaleY:1.1978,x:-43.95,y:142.45},0).wait(1).to({scaleX:1.1747,scaleY:1.1747,x:-36.4,y:142.1},0).wait(1).to({scaleX:1.151,scaleY:1.151,x:-28.7,y:141.7},0).wait(1).to({scaleX:1.1268,scaleY:1.1268,x:-20.85,y:141.3},0).wait(1).to({scaleX:1.1023,scaleY:1.1023,x:-12.85,y:140.9},0).wait(1).to({scaleX:1.0774,scaleY:1.0774,x:-4.7,y:140.55},0).wait(1).to({scaleX:1.0523,scaleY:1.0523,x:3.5,y:140.15},0).wait(1).to({scaleX:1.027,scaleY:1.027,x:11.75,y:139.75},0).wait(1).to({scaleX:1.0017,scaleY:1.0017,x:20,y:139.35},0).wait(1).to({scaleX:0.9763,scaleY:0.9763,x:28.25,y:138.9},0).wait(1).to({scaleX:0.9511,scaleY:0.9511,x:36.45,y:138.55},0).wait(1).to({scaleX:0.9261,scaleY:0.9261,x:44.65,y:138.15},0).wait(1).to({scaleX:0.9013,scaleY:0.9013,x:52.7,y:137.75},0).wait(1).to({scaleX:0.877,scaleY:0.877,x:60.65,y:137.4},0).wait(1).to({scaleX:0.853,scaleY:0.853,x:68.45,y:137},0).wait(1).to({scaleX:0.8296,scaleY:0.8296,x:76.1,y:136.6},0).wait(1).to({scaleX:0.8067,scaleY:0.8067,x:83.55,y:136.25},0).wait(1).to({scaleX:0.7845,scaleY:0.7845,x:90.8,y:135.9},0).wait(1).to({scaleX:0.7629,scaleY:0.7629,x:97.8,y:135.55},0).wait(1).to({scaleX:0.7422,scaleY:0.7422,x:104.65,y:135.25},0).wait(1).to({scaleX:0.7221,scaleY:0.7221,x:111.15,y:134.9},0).wait(1).to({scaleX:0.7029,scaleY:0.7029,x:117.45,y:134.6},0).wait(1).to({scaleX:0.6846,scaleY:0.6846,x:123.35,y:134.3},0).wait(1).to({scaleX:0.6671,scaleY:0.6671,x:129.1,y:134.05},0).wait(1).to({scaleX:0.6506,scaleY:0.6506,x:134.5,y:133.8},0).wait(1).to({scaleX:0.6349,scaleY:0.6349,x:139.65,y:133.55},0).wait(1).to({scaleX:0.6201,scaleY:0.6201,x:144.4,y:133.3},0).wait(1).to({scaleX:0.6063,scaleY:0.6063,x:148.95,y:133.1},0).wait(1).to({scaleX:0.5934,scaleY:0.5934,x:153.15,y:132.9},0).wait(1).to({scaleX:0.5814,scaleY:0.5814,x:157.1,y:132.7},0).wait(1).to({scaleX:0.5703,scaleY:0.5703,x:160.65,y:132.55},0).wait(1).to({scaleX:0.5601,scaleY:0.5601,x:164,y:132.35},0).wait(1).to({scaleX:0.5509,scaleY:0.5509,x:167,y:132.2},0).wait(1).to({scaleX:0.5425,scaleY:0.5425,x:169.75,y:132.05},0).wait(1).to({scaleX:0.535,scaleY:0.535,x:172.25,y:131.95},0).wait(1).to({scaleX:0.5283,scaleY:0.5283,x:174.4,y:131.85},0).wait(1).to({scaleX:0.5225,scaleY:0.5225,x:176.3,y:131.75},0).wait(1).to({scaleX:0.5175,scaleY:0.5175,x:177.9,y:131.7},0).wait(1).to({scaleX:0.5134,scaleY:0.5134,x:179.25,y:131.6},0).wait(1).to({scaleX:0.51,scaleY:0.51,x:180.4,y:131.55},0).wait(1).to({scaleX:0.5074,scaleY:0.5074,x:181.2,y:131.5},0).wait(1).to({scaleX:0.5056,scaleY:0.5056,x:181.8},0).wait(1).to({scaleX:0.5045,scaleY:0.5045,x:182.15,y:131.45},0).wait(1).to({regX:28.2,regY:22.9,scaleX:0.5042,scaleY:0.5042,x:182.35,y:131.65},0).wait(1).to({regX:28,regY:22.5,x:182.25,y:131.45},0).wait(15).to({regX:28.2,regY:22.9,x:182.35,y:131.65},0).wait(1).to({regX:28,regY:22.5,scaleX:0.5041,scaleY:0.5041,x:182.2,y:131.4},0).wait(1).to({scaleX:0.504,scaleY:0.504,x:182.15},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,x:182.1,y:131.35},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,x:182.05,y:131.3},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:181.95,y:131.25},0).wait(1).to({scaleX:0.5034,scaleY:0.5034,x:181.85,y:131.15},0).wait(1).to({scaleX:0.5032,scaleY:0.5032,x:181.7,y:131.05},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:181.55,y:130.95},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:181.3,y:130.8},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:181.1,y:130.65},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:180.8,y:130.5},0).wait(1).to({scaleX:0.5011,scaleY:0.5011,x:180.5,y:130.3},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:180.1,y:130},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:179.7,y:129.75},0).wait(1).to({scaleX:0.4989,scaleY:0.4989,x:179.2,y:129.45},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:178.65,y:129.05},0).wait(1).to({scaleX:0.4968,scaleY:0.4968,x:178,y:128.65},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:177.2,y:128.1},0).wait(1).to({scaleX:0.4938,scaleY:0.4938,x:176.3,y:127.5},0).wait(1).to({scaleX:0.4918,scaleY:0.4918,x:175.15,y:126.75},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:173.75,y:125.85},0).wait(1).to({scaleX:0.4864,scaleY:0.4864,x:172,y:124.7},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:169.8,y:123.2},0).wait(1).to({scaleX:0.4776,scaleY:0.4776,x:166.95,y:121.35},0).wait(1).to({scaleX:0.4718,scaleY:0.4718,x:163.65,y:119.15},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:160.5,y:117.1},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:158,y:115.45},0).wait(1).to({scaleX:0.4584,scaleY:0.4584,x:156,y:114.1},0).wait(1).to({scaleX:0.4557,scaleY:0.4557,x:154.35,y:113.05},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:153.1,y:112.2},0).wait(1).to({scaleX:0.4516,scaleY:0.4516,x:152,y:111.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:151.1,y:110.9},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:150.35,y:110.4},0).wait(1).to({scaleX:0.4475,scaleY:0.4475,x:149.7,y:109.95},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:149.1,y:109.6},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:148.65,y:109.3},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:148.2,y:108.95},0).wait(1).to({scaleX:0.4443,scaleY:0.4443,x:147.8,y:108.75},0).wait(1).to({scaleX:0.4437,scaleY:0.4437,x:147.45,y:108.55},0).wait(1).to({scaleX:0.4432,scaleY:0.4432,x:147.15,y:108.3},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:146.95,y:108.15},0).wait(1).to({scaleX:0.4423,scaleY:0.4423,x:146.7,y:108},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:146.55,y:107.9},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:146.3,y:107.75},0).wait(1).to({scaleX:0.4415,scaleY:0.4415,x:146.2,y:107.7},0).wait(1).to({scaleX:0.4412,scaleY:0.4412,x:146.05,y:107.6},0).wait(1).to({scaleX:0.4411,scaleY:0.4411,x:146,y:107.5},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:145.9,y:107.45},0).wait(1).to({scaleX:0.4408,scaleY:0.4408,x:145.85,y:107.4},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:145.8},0).wait(1).to({x:145.75,y:107.35},0).wait(1).to({scaleX:0.4406,scaleY:0.4406},0).wait(1).to({regX:28.5,regY:23.1,x:145.85,y:107.6},0).wait(8));

	// r girl i shadow
	this.instance_10 = new lib.roundshadow();
	this.instance_10.setTransform(317,289.8,1.4168,1.4168,0,0,0,28.2,22.8);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(14).to({_off:false},0).to({x:261.7,y:210.05,alpha:0.1602},53,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:261.4,y:209.65},0).wait(17).to({regX:28.2,regY:22.8,x:261.7,y:210.05},0).wait(1).to({regX:28,regY:22.5,scaleX:1.4091,scaleY:1.4091,x:260.7,y:209.4},0).wait(1).to({scaleX:1.4008,scaleY:1.4008,x:259.9,y:209.1},0).wait(1).to({scaleX:1.3917,scaleY:1.3917,x:259.05,y:208.85},0).wait(1).to({scaleX:1.3819,scaleY:1.3819,x:258.2,y:208.6},0).wait(1).to({scaleX:1.3713,scaleY:1.3713,x:257.2,y:208.3},0).wait(1).to({scaleX:1.3601,scaleY:1.3601,x:256.2,y:207.95},0).wait(1).to({scaleX:1.3481,scaleY:1.3481,x:255.1,y:207.65},0).wait(1).to({scaleX:1.3354,scaleY:1.3354,x:253.9,y:207.25},0).wait(1).to({scaleX:1.3221,scaleY:1.3221,x:252.65,y:206.9},0).wait(1).to({scaleX:1.308,scaleY:1.308,x:251.35,y:206.5},0).wait(1).to({scaleX:1.2932,scaleY:1.2932,x:250,y:206.05},0).wait(1).to({scaleX:1.2778,scaleY:1.2778,x:248.65,y:205.6},0).wait(1).to({scaleX:1.2618,scaleY:1.2618,x:247.15,y:205.15},0).wait(1).to({scaleX:1.2452,scaleY:1.2452,x:245.6,y:204.65},0).wait(1).to({scaleX:1.228,scaleY:1.228,x:244.05,y:204.2},0).wait(1).to({scaleX:1.2103,scaleY:1.2103,x:242.4,y:203.65},0).wait(1).to({scaleX:1.1921,scaleY:1.1921,x:240.75,y:203.1},0).wait(1).to({scaleX:1.1735,scaleY:1.1735,x:239,y:202.6},0).wait(1).to({scaleX:1.1545,scaleY:1.1545,x:237.3,y:202.05},0).wait(1).to({scaleX:1.1352,scaleY:1.1352,x:235.5,y:201.5},0).wait(1).to({scaleX:1.1156,scaleY:1.1156,x:233.7,y:200.9},0).wait(1).to({scaleX:1.0958,scaleY:1.0958,x:231.9,y:200.35},0).wait(1).to({scaleX:1.076,scaleY:1.076,x:230.05,y:199.75},0).wait(1).to({scaleX:1.056,scaleY:1.056,x:228.2,y:199.2},0).wait(1).to({scaleX:1.0361,scaleY:1.0361,x:226.35,y:198.6},0).wait(1).to({scaleX:1.0163,scaleY:1.0163,x:224.55,y:198.05},0).wait(1).to({scaleX:0.9966,scaleY:0.9966,x:222.75,y:197.45},0).wait(1).to({scaleX:0.9771,scaleY:0.9771,x:220.95,y:196.95},0).wait(1).to({scaleX:0.9579,scaleY:0.9579,x:219.15,y:196.4},0).wait(1).to({scaleX:0.9391,scaleY:0.9391,x:217.45,y:195.85},0).wait(1).to({scaleX:0.9207,scaleY:0.9207,x:215.8,y:195.3},0).wait(1).to({scaleX:0.9027,scaleY:0.9027,x:214.1,y:194.8},0).wait(1).to({scaleX:0.8852,scaleY:0.8852,x:212.5,y:194.25},0).wait(1).to({scaleX:0.8683,scaleY:0.8683,x:210.95,y:193.8},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:209.45,y:193.3},0).wait(1).to({scaleX:0.8362,scaleY:0.8362,x:208,y:192.85},0).wait(1).to({scaleX:0.8211,scaleY:0.8211,x:206.6,y:192.4},0).wait(1).to({scaleX:0.8066,scaleY:0.8066,x:205.3,y:192},0).wait(1).to({scaleX:0.7929,scaleY:0.7929,x:204,y:191.65},0).wait(1).to({scaleX:0.7799,scaleY:0.7799,x:202.85,y:191.25},0).wait(1).to({scaleX:0.7675,scaleY:0.7675,x:201.7,y:190.85},0).wait(1).to({scaleX:0.7559,scaleY:0.7559,x:200.6,y:190.55},0).wait(1).to({scaleX:0.745,scaleY:0.745,x:199.6,y:190.25},0).wait(1).to({scaleX:0.7349,scaleY:0.7349,x:198.7,y:189.95},0).wait(1).to({scaleX:0.7255,scaleY:0.7255,x:197.8,y:189.65},0).wait(1).to({scaleX:0.7167,scaleY:0.7167,x:197,y:189.45},0).wait(1).to({scaleX:0.7087,scaleY:0.7087,x:196.3,y:189.2},0).wait(1).to({scaleX:0.7014,scaleY:0.7014,x:195.6,y:189},0).wait(1).to({scaleX:0.6949,scaleY:0.6949,x:195,y:188.8},0).wait(1).to({scaleX:0.6889,scaleY:0.6889,x:194.45,y:188.65},0).wait(1).to({scaleX:0.6837,scaleY:0.6837,x:193.95,y:188.5},0).wait(1).to({scaleX:0.6791,scaleY:0.6791,x:193.55,y:188.35},0).wait(1).to({scaleX:0.6752,scaleY:0.6752,x:193.2,y:188.25},0).wait(1).to({scaleX:0.672,scaleY:0.672,x:192.85,y:188.1},0).wait(1).to({scaleX:0.6693,scaleY:0.6693,x:192.65,y:188.05},0).wait(1).to({scaleX:0.6673,scaleY:0.6673,x:192.45,y:188},0).wait(1).to({scaleX:0.6658,scaleY:0.6658,x:192.35},0).wait(1).to({scaleX:0.665,scaleY:0.665,x:192.25,y:187.95},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.6647,scaleY:0.6647,x:192.4,y:188.1},0).wait(1).to({regX:28,regY:22.5,x:192.2,y:187.85},0).wait(15).to({regX:28.3,regY:22.9,x:192.4,y:188.1},0).wait(1).to({regX:28,regY:22.5,scaleX:0.6646,scaleY:0.6646,x:192.15,y:187.8},0).wait(1).to({scaleX:0.6644,scaleY:0.6644,y:187.7},0).wait(1).to({scaleX:0.6641,scaleY:0.6641,y:187.6},0).wait(1).to({scaleX:0.6637,scaleY:0.6637,x:192.1,y:187.45},0).wait(1).to({scaleX:0.6632,scaleY:0.6632,x:192,y:187.25},0).wait(1).to({scaleX:0.6625,scaleY:0.6625,x:191.95,y:187.05},0).wait(1).to({scaleX:0.6618,scaleY:0.6618,x:191.9,y:186.75},0).wait(1).to({scaleX:0.6608,scaleY:0.6608,x:191.8,y:186.4},0).wait(1).to({scaleX:0.6598,scaleY:0.6598,x:191.7,y:186.05},0).wait(1).to({scaleX:0.6586,scaleY:0.6586,x:191.6,y:185.6},0).wait(1).to({scaleX:0.6571,scaleY:0.6571,x:191.45,y:185.1},0).wait(1).to({scaleX:0.6555,scaleY:0.6555,x:191.25,y:184.5},0).wait(1).to({scaleX:0.6536,scaleY:0.6536,x:191.1,y:183.8},0).wait(1).to({scaleX:0.6515,scaleY:0.6515,x:190.9,y:183.05},0).wait(1).to({scaleX:0.6491,scaleY:0.6491,x:190.6,y:182.15},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:190.35,y:181.15},0).wait(1).to({scaleX:0.6431,scaleY:0.6431,x:190.05,y:180},0).wait(1).to({scaleX:0.6394,scaleY:0.6394,x:189.7,y:178.7},0).wait(1).to({scaleX:0.6352,scaleY:0.6352,x:189.3,y:177.15},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:188.8,y:175.35},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:188.2,y:173.25},0).wait(1).to({scaleX:0.6175,scaleY:0.6175,x:187.55,y:170.75},0).wait(1).to({scaleX:0.6091,scaleY:0.6091,x:186.7,y:167.7},0).wait(1).to({scaleX:0.5988,scaleY:0.5988,x:185.65,y:163.95},0).wait(1).to({scaleX:0.5859,scaleY:0.5859,x:184.4,y:159.3},0).wait(1).to({scaleX:0.5696,scaleY:0.5696,x:182.8,y:153.4},0).wait(1).to({scaleX:0.5502,scaleY:0.5502,x:180.85,y:146.45},0).wait(1).to({scaleX:0.5303,scaleY:0.5303,x:178.9,y:139.2},0).wait(1).to({scaleX:0.5129,scaleY:0.5129,x:177.15,y:132.9},0).wait(1).to({scaleX:0.4988,scaleY:0.4988,x:175.8,y:127.8},0).wait(1).to({scaleX:0.4875,scaleY:0.4875,x:174.7,y:123.7},0).wait(1).to({scaleX:0.4784,scaleY:0.4784,x:173.8,y:120.4},0).wait(1).to({scaleX:0.4708,scaleY:0.4708,x:173.05,y:117.65},0).wait(1).to({scaleX:0.4644,scaleY:0.4644,x:172.4,y:115.35},0).wait(1).to({scaleX:0.4589,scaleY:0.4589,x:171.85,y:113.4},0).wait(1).to({scaleX:0.4542,scaleY:0.4542,x:171.35,y:111.65},0).wait(1).to({scaleX:0.4501,scaleY:0.4501,x:171,y:110.2},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:170.65,y:108.9},0).wait(1).to({scaleX:0.4433,scaleY:0.4433,x:170.3,y:107.7},0).wait(1).to({scaleX:0.4405,scaleY:0.4405,x:170.05,y:106.7},0).wait(1).to({scaleX:0.4381,scaleY:0.4381,x:169.8,y:105.85},0).wait(1).to({scaleX:0.4359,scaleY:0.4359,x:169.55,y:105.05},0).wait(1).to({scaleX:0.4339,scaleY:0.4339,x:169.4,y:104.35},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:169.2,y:103.7},0).wait(1).to({scaleX:0.4307,scaleY:0.4307,x:169.05,y:103.15},0).wait(1).to({scaleX:0.4293,scaleY:0.4293,x:168.9,y:102.65},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:168.85,y:102.25},0).wait(1).to({scaleX:0.4271,scaleY:0.4271,x:168.7,y:101.85},0).wait(1).to({scaleX:0.4262,scaleY:0.4262,x:168.65,y:101.55},0).wait(1).to({scaleX:0.4255,scaleY:0.4255,x:168.55,y:101.25},0).wait(1).to({scaleX:0.4248,scaleY:0.4248,x:168.5,y:101.05},0).wait(1).to({scaleX:0.4243,scaleY:0.4243,x:168.45,y:100.85},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:168.35,y:100.7},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,y:100.6},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,y:100.45},0).wait(1).to({scaleX:0.423,scaleY:0.423,x:168.3,y:100.35},0).wait(1).to({scaleX:0.4229,scaleY:0.4229},0).wait(1).to({regX:28.2,regY:22.9,x:168.4,y:100.55},0).wait(1));

	// l girl i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(-359.2,289.45,1.4905,1.4905,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({x:-61.45,y:211.6,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:-61.75,y:211.15},0).wait(19).to({regX:28.2,regY:22.8,x:-61.45,y:211.6},0).wait(1).to({regX:28,regY:22.5,scaleX:1.4804,scaleY:1.4804,x:-59.25,y:210.55},0).wait(1).to({scaleX:1.4694,scaleY:1.4694,x:-56.5,y:209.9},0).wait(1).to({scaleX:1.4575,scaleY:1.4575,x:-53.55,y:209.25},0).wait(1).to({scaleX:1.4446,scaleY:1.4446,x:-50.35,y:208.5},0).wait(1).to({scaleX:1.4308,scaleY:1.4308,x:-46.9,y:207.7},0).wait(1).to({scaleX:1.4161,scaleY:1.4161,x:-43.2,y:206.85},0).wait(1).to({scaleX:1.4004,scaleY:1.4004,x:-39.3,y:206},0).wait(1).to({scaleX:1.3838,scaleY:1.3838,x:-35.15,y:205.05},0).wait(1).to({scaleX:1.3662,scaleY:1.3662,x:-30.8,y:204.05},0).wait(1).to({scaleX:1.3478,scaleY:1.3478,x:-26.2,y:202.95},0).wait(1).to({scaleX:1.3284,scaleY:1.3284,x:-21.4,y:201.9},0).wait(1).to({scaleX:1.3082,scaleY:1.3082,x:-16.35,y:200.75},0).wait(1).to({scaleX:1.2872,scaleY:1.2872,x:-11.1,y:199.55},0).wait(1).to({scaleX:1.2654,scaleY:1.2654,x:-5.7,y:198.3},0).wait(1).to({scaleX:1.2429,scaleY:1.2429,x:-0.1,y:197},0).wait(1).to({scaleX:1.2196,scaleY:1.2196,x:5.7,y:195.7},0).wait(1).to({scaleX:1.1958,scaleY:1.1958,x:11.65,y:194.35},0).wait(1).to({scaleX:1.1714,scaleY:1.1714,x:17.7,y:192.95},0).wait(1).to({scaleX:1.1465,scaleY:1.1465,x:23.9,y:191.55},0).wait(1).to({scaleX:1.1211,scaleY:1.1211,x:30.25,y:190.1},0).wait(1).to({scaleX:1.0955,scaleY:1.0955,x:36.55,y:188.65},0).wait(1).to({scaleX:1.0696,scaleY:1.0696,x:43.05,y:187.15},0).wait(1).to({scaleX:1.0435,scaleY:1.0435,x:49.5,y:185.7},0).wait(1).to({scaleX:1.0173,scaleY:1.0173,x:56.05,y:184.2},0).wait(1).to({scaleX:0.9912,scaleY:0.9912,x:62.55,y:182.7},0).wait(1).to({scaleX:0.9652,scaleY:0.9652,x:69.05,y:181.2},0).wait(1).to({scaleX:0.9394,scaleY:0.9394,x:75.45,y:179.75},0).wait(1).to({scaleX:0.9139,scaleY:0.9139,x:81.8,y:178.3},0).wait(1).to({scaleX:0.8887,scaleY:0.8887,x:88.1,y:176.9},0).wait(1).to({scaleX:0.864,scaleY:0.864,x:94.2,y:175.5},0).wait(1).to({scaleX:0.8398,scaleY:0.8398,x:100.2,y:174.1},0).wait(1).to({scaleX:0.8162,scaleY:0.8162,x:106.1,y:172.75},0).wait(1).to({scaleX:0.7933,scaleY:0.7933,x:111.8,y:171.45},0).wait(1).to({scaleX:0.7711,scaleY:0.7711,x:117.35,y:170.2},0).wait(1).to({scaleX:0.7497,scaleY:0.7497,x:122.7,y:168.95},0).wait(1).to({scaleX:0.729,scaleY:0.729,x:127.8,y:167.8},0).wait(1).to({scaleX:0.7092,scaleY:0.7092,x:132.75,y:166.65},0).wait(1).to({scaleX:0.6903,scaleY:0.6903,x:137.5,y:165.6},0).wait(1).to({scaleX:0.6723,scaleY:0.6723,x:141.95,y:164.6},0).wait(1).to({scaleX:0.6552,scaleY:0.6552,x:146.2,y:163.6},0).wait(1).to({scaleX:0.639,scaleY:0.639,x:150.25,y:162.7},0).wait(1).to({scaleX:0.6238,scaleY:0.6238,x:154,y:161.8},0).wait(1).to({scaleX:0.6095,scaleY:0.6095,x:157.55,y:160.95},0).wait(1).to({scaleX:0.5962,scaleY:0.5962,x:160.9,y:160.2},0).wait(1).to({scaleX:0.5838,scaleY:0.5838,x:164,y:159.55},0).wait(1).to({scaleX:0.5724,scaleY:0.5724,x:166.85,y:158.9},0).wait(1).to({scaleX:0.5619,scaleY:0.5619,x:169.45,y:158.3},0).wait(1).to({scaleX:0.5523,scaleY:0.5523,x:171.8,y:157.75},0).wait(1).to({scaleX:0.5437,scaleY:0.5437,x:173.95,y:157.25},0).wait(1).to({scaleX:0.5359,scaleY:0.5359,x:175.9,y:156.8},0).wait(1).to({scaleX:0.5291,scaleY:0.5291,x:177.6,y:156.4},0).wait(1).to({scaleX:0.5231,scaleY:0.5231,x:179.1,y:156.05},0).wait(1).to({scaleX:0.518,scaleY:0.518,x:180.4,y:155.8},0).wait(1).to({scaleX:0.5137,scaleY:0.5137,x:181.45,y:155.55},0).wait(1).to({scaleX:0.5102,scaleY:0.5102,x:182.35,y:155.35},0).wait(1).to({scaleX:0.5075,scaleY:0.5075,x:182.95,y:155.15},0).wait(1).to({scaleX:0.5056,scaleY:0.5056,x:183.45,y:155.1},0).wait(1).to({scaleX:0.5045,scaleY:0.5045,x:183.75,y:155},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.5042,scaleY:0.5042,x:183.9,y:155.15},0).wait(1).to({regX:28,regY:22.5,x:183.7,y:154.95},0).wait(15).to({regX:28.4,regY:22.9,x:183.9,y:155.15},0).wait(1).to({regX:28,regY:22.5,scaleX:0.5041,scaleY:0.5041,x:183.7,y:154.9},0).wait(1).to({scaleX:0.504,scaleY:0.504,y:154.85},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,y:154.75},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,y:154.65},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:183.75,y:154.5},0).wait(1).to({scaleX:0.5033,scaleY:0.5033,y:154.3},0).wait(1).to({scaleX:0.503,scaleY:0.503,x:183.8,y:154.1},0).wait(1).to({scaleX:0.5027,scaleY:0.5027,x:183.75,y:153.85},0).wait(1).to({scaleX:0.5022,scaleY:0.5022,x:183.8,y:153.6},0).wait(1).to({scaleX:0.5018,scaleY:0.5018,x:183.85,y:153.25},0).wait(1).to({scaleX:0.5012,scaleY:0.5012,x:183.9,y:152.85},0).wait(1).to({scaleX:0.5006,scaleY:0.5006,x:183.95,y:152.4},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:184,y:151.85},0).wait(1).to({scaleX:0.499,scaleY:0.499,x:184.05,y:151.3},0).wait(1).to({scaleX:0.498,scaleY:0.498,x:184.15,y:150.6},0).wait(1).to({scaleX:0.4969,scaleY:0.4969,x:184.2,y:149.8},0).wait(1).to({scaleX:0.4956,scaleY:0.4956,x:184.35,y:148.9},0).wait(1).to({scaleX:0.4941,scaleY:0.4941,x:184.45,y:147.8},0).wait(1).to({scaleX:0.4924,scaleY:0.4924,x:184.55,y:146.65},0).wait(1).to({scaleX:0.4903,scaleY:0.4903,x:184.7,y:145.15},0).wait(1).to({scaleX:0.4879,scaleY:0.4879,x:184.85,y:143.45},0).wait(1).to({scaleX:0.4849,scaleY:0.4849,x:185.1,y:141.3},0).wait(1).to({scaleX:0.4812,scaleY:0.4812,x:185.35,y:138.75},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:185.7,y:135.45},0).wait(1).to({scaleX:0.4707,scaleY:0.4707,x:186.15,y:131.3},0).wait(1).to({scaleX:0.4636,scaleY:0.4636,x:186.65,y:126.3},0).wait(1).to({scaleX:0.4562,scaleY:0.4562,x:187.15,y:121.05},0).wait(1).to({scaleX:0.4497,scaleY:0.4497,x:187.65,y:116.45},0).wait(1).to({scaleX:0.4445,scaleY:0.4445,x:188.05,y:112.8},0).wait(1).to({scaleX:0.4404,scaleY:0.4404,x:188.35,y:109.9},0).wait(1).to({scaleX:0.4371,scaleY:0.4371,x:188.6,y:107.55},0).wait(1).to({scaleX:0.4343,scaleY:0.4343,x:188.75,y:105.6},0).wait(1).to({scaleX:0.432,scaleY:0.432,x:188.95,y:103.95},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:189.1,y:102.6},0).wait(1).to({scaleX:0.4284,scaleY:0.4284,x:189.2,y:101.4},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:189.3,y:100.35},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,x:189.4,y:99.5},0).wait(1).to({scaleX:0.4245,scaleY:0.4245,x:189.5,y:98.65},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,x:189.55,y:98},0).wait(1).to({scaleX:0.4226,scaleY:0.4226,x:189.65,y:97.35},0).wait(1).to({scaleX:0.4219,scaleY:0.4219,y:96.8},0).wait(1).to({scaleX:0.4212,scaleY:0.4212,x:189.75,y:96.35},0).wait(1).to({scaleX:0.4206,scaleY:0.4206,x:189.8,y:95.9},0).wait(1).to({scaleX:0.4201,scaleY:0.4201,y:95.55},0).wait(1).to({scaleX:0.4196,scaleY:0.4196,x:189.85,y:95.2},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:189.9,y:94.95},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,y:94.65},0).wait(1).to({scaleX:0.4185,scaleY:0.4185,y:94.45},0).wait(1).to({scaleX:0.4183,scaleY:0.4183,x:189.95,y:94.25},0).wait(1).to({scaleX:0.4181,scaleY:0.4181,y:94.15},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,y:94},0).wait(1).to({scaleX:0.4178,scaleY:0.4178,x:190,y:93.9},0).wait(1).to({scaleX:0.4177,scaleY:0.4177,y:93.85},0).wait(1).to({scaleX:0.4176,scaleY:0.4176,y:93.8},0).wait(1).to({y:93.75},0).wait(1).to({regX:28.4,regY:23.1,scaleX:0.4175,scaleY:0.4175,x:190.2,y:93.95},0).wait(2));

	// l girl box shadow
	this.instance_12 = new lib.squareshadow();
	this.instance_12.setTransform(21.6,223.5,1.0136,1.0136,0,0,0,70.8,47.8);
	this.instance_12.alpha = 0.1602;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(9).to({_off:false},0).wait(58).to({regX:70.6,x:21.4},0).wait(19).to({regX:70.8,x:21.6},0).wait(1).to({regX:70.6,scaleX:1.006,scaleY:1.006,x:23.3,y:222.85,alpha:0.1585},0).wait(1).to({scaleX:0.9978,scaleY:0.9978,x:25.4,y:222.15,alpha:0.1567},0).wait(1).to({scaleX:0.9888,scaleY:0.9888,x:27.65,y:221.35,alpha:0.1548},0).wait(1).to({scaleX:0.9791,scaleY:0.9791,x:30.15,y:220.55,alpha:0.1527},0).wait(1).to({scaleX:0.9688,scaleY:0.9688,x:32.7,y:219.65,alpha:0.1505},0).wait(1).to({scaleX:0.9577,scaleY:0.9577,x:35.5,y:218.75,alpha:0.1481},0).wait(1).to({scaleX:0.9459,scaleY:0.9459,x:38.5,y:217.7,alpha:0.1455},0).wait(1).to({scaleX:0.9334,scaleY:0.9334,x:41.6,y:216.6,alpha:0.1428},0).wait(1).to({scaleX:0.9202,scaleY:0.9202,x:44.9,y:215.55,alpha:0.14},0).wait(1).to({scaleX:0.9064,scaleY:0.9064,x:48.45,y:214.35,alpha:0.137},0).wait(1).to({scaleX:0.8919,scaleY:0.8919,x:52.05,y:213.1,alpha:0.1338},0).wait(1).to({scaleX:0.8767,scaleY:0.8767,x:55.9,y:211.8,alpha:0.1306},0).wait(1).to({scaleX:0.8609,scaleY:0.8609,x:59.9,y:210.45,alpha:0.1272},0).wait(1).to({scaleX:0.8445,scaleY:0.8445,x:63.9,y:209.05,alpha:0.1236},0).wait(1).to({scaleX:0.8276,scaleY:0.8276,x:68.25,y:207.6,alpha:0.12},0).wait(1).to({scaleX:0.8102,scaleY:0.8102,x:72.6,y:206.15,alpha:0.1162},0).wait(1).to({scaleX:0.7923,scaleY:0.7923,x:77.15,y:204.6,alpha:0.1123},0).wait(1).to({scaleX:0.7739,scaleY:0.7739,x:81.75,y:203.05,alpha:0.1083},0).wait(1).to({scaleX:0.7552,scaleY:0.7552,x:86.45,y:201.45,alpha:0.1043},0).wait(1).to({scaleX:0.7362,scaleY:0.7362,x:91.2,y:199.85,alpha:0.1002},0).wait(1).to({scaleX:0.7169,scaleY:0.7169,x:96.1,y:198.15,alpha:0.096},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:101,y:196.55,alpha:0.0918},0).wait(1).to({scaleX:0.6779,scaleY:0.6779,x:105.9,y:194.85,alpha:0.0876},0).wait(1).to({scaleX:0.6582,scaleY:0.6582,x:110.85,y:193.15,alpha:0.0833},0).wait(1).to({scaleX:0.6386,scaleY:0.6386,x:115.8,y:191.55,alpha:0.0791},0).wait(1).to({scaleX:0.6191,scaleY:0.6191,x:120.7,y:189.85,alpha:0.0749},0).wait(1).to({scaleX:0.5997,scaleY:0.5997,x:125.6,y:188.2,alpha:0.0707},0).wait(1).to({scaleX:0.5805,scaleY:0.5805,x:130.45,y:186.55,alpha:0.0665},0).wait(1).to({scaleX:0.5616,scaleY:0.5616,x:135.2,y:184.95,alpha:0.0624},0).wait(1).to({scaleX:0.5431,scaleY:0.5431,x:139.9,y:183.35,alpha:0.0584},0).wait(1).to({scaleX:0.5249,scaleY:0.5249,x:144.45,y:181.8,alpha:0.0545},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:148.9,y:180.3,alpha:0.0507},0).wait(1).to({scaleX:0.49,scaleY:0.49,x:153.25,y:178.8,alpha:0.047},0).wait(1).to({scaleX:0.4733,scaleY:0.4733,x:157.4,y:177.4,alpha:0.0433},0).wait(1).to({scaleX:0.4572,scaleY:0.4572,x:161.5,y:176.05,alpha:0.0399},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:165.4,y:174.7,alpha:0.0365},0).wait(1).to({scaleX:0.4268,scaleY:0.4268,x:169.15,y:173.45,alpha:0.0333},0).wait(1).to({scaleX:0.4126,scaleY:0.4126,x:172.75,y:172.2,alpha:0.0302},0).wait(1).to({scaleX:0.3991,scaleY:0.3991,x:176.15,y:171.1,alpha:0.0273},0).wait(1).to({scaleX:0.3863,scaleY:0.3863,x:179.35,y:170,alpha:0.0245},0).wait(1).to({scaleX:0.3741,scaleY:0.3741,x:182.4,y:169,alpha:0.0219},0).wait(1).to({scaleX:0.3627,scaleY:0.3627,x:185.3,y:168,alpha:0.0194},0).wait(1).to({scaleX:0.352,scaleY:0.352,x:188,y:167.05,alpha:0.0171},0).wait(1).to({scaleX:0.342,scaleY:0.342,x:190.55,y:166.2,alpha:0.0149},0).wait(1).to({scaleX:0.3327,scaleY:0.3327,x:192.85,y:165.4,alpha:0.0129},0).wait(1).to({scaleX:0.3241,scaleY:0.3241,x:195.05,y:164.7,alpha:0.0111},0).wait(1).to({scaleX:0.3162,scaleY:0.3162,x:197,y:164,alpha:0.0094},0).wait(1).to({scaleX:0.309,scaleY:0.309,x:198.8,y:163.4,alpha:0.0078},0).wait(1).to({scaleX:0.3025,scaleY:0.3025,x:200.45,y:162.85,alpha:0.0064},0).wait(1).to({scaleX:0.2967,scaleY:0.2967,x:201.9,y:162.4,alpha:0.0052},0).wait(1).to({scaleX:0.2916,scaleY:0.2916,x:203.25,y:161.95,alpha:0.004},0).wait(1).to({scaleX:0.2871,scaleY:0.2871,x:204.35,y:161.5,alpha:0.0031},0).wait(1).to({scaleX:0.2832,scaleY:0.2832,x:205.3,y:161.2,alpha:0.0022},0).wait(1).to({scaleX:0.28,scaleY:0.28,x:206.1,y:160.95,alpha:0.0015},0).wait(1).to({scaleX:0.2774,scaleY:0.2774,x:206.8,y:160.7,alpha:0.001},0).wait(1).to({scaleX:0.2754,scaleY:0.2754,x:207.3,y:160.55,alpha:0.0005},0).wait(1).to({scaleX:0.274,scaleY:0.274,x:207.65,y:160.45,alpha:0.0002},0).wait(1).to({scaleX:0.2731,scaleY:0.2731,x:207.9,y:160.35,alpha:0.0001},0).wait(1).to({regX:71.5,regY:48.2,scaleX:0.2728,scaleY:0.2728,x:208,alpha:0},0).wait(74));

	// r girl box shadow
	this.instance_13 = new lib.fill();
	this.instance_13.setTransform(208.3,160.35,0.8066,0.8066,0,0,0,32.6,30.2);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(124).to({_off:false},0).to({regX:32.7,regY:30.4,scaleX:0.8549,scaleY:0.8274,x:209.95,y:159.85,alpha:1},16).wait(79));

	// r guy box shadow
	this.instance_14 = new lib.squareshadow();
	this.instance_14.setTransform(708.65,50.4,0.7804,0.7804,0,0,0,70.7,47.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(19).to({_off:false},0).to({x:392.9,y:130.1,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:391.2,y:131.6},0).wait(1).to({x:389.55,y:133.1},0).wait(1).to({x:387.95,y:134.65},0).wait(1).to({x:386.3,y:136.2},0).wait(1).to({x:384.65,y:137.8},0).wait(1).to({x:382.95,y:139.35},0).wait(1).to({x:381.3,y:140.95},0).wait(1).to({x:379.6,y:142.55},0).wait(1).to({x:377.9,y:144.2},0).wait(1).to({x:376.15,y:145.8},0).wait(1).to({x:374.45,y:147.45},0).wait(1).to({regX:70.7,x:372.8,y:149.15},0).wait(1).to({regX:70.6,scaleX:0.7761,scaleY:0.7759,x:371.2,y:148.75},0).wait(1).to({scaleX:0.7714,scaleY:0.7709,x:369.55,y:148.35},0).wait(1).to({scaleX:0.7663,scaleY:0.7655,x:367.75,y:147.95},0).wait(1).to({scaleX:0.7608,scaleY:0.7597,x:365.85,y:147.45},0).wait(1).to({scaleX:0.7549,scaleY:0.7534,x:363.8,y:146.95},0).wait(1).to({scaleX:0.7485,scaleY:0.7468,x:361.6,y:146.4},0).wait(1).to({scaleX:0.7418,scaleY:0.7396,x:359.25,y:145.8},0).wait(1).to({scaleX:0.7347,scaleY:0.7321,x:356.75,y:145.2},0).wait(1).to({scaleX:0.7272,scaleY:0.7242,x:354.2,y:144.55},0).wait(1).to({scaleX:0.7192,scaleY:0.7158,x:351.45,y:143.9},0).wait(1).to({scaleX:0.711,scaleY:0.7071,x:348.55,y:143.2},0).wait(1).to({scaleX:0.7023,scaleY:0.6979,x:345.55,y:142.45},0).wait(1).to({scaleX:0.6933,scaleY:0.6884,x:342.4,y:141.65},0).wait(1).to({scaleX:0.6839,scaleY:0.6786,x:339.2,y:140.9},0).wait(1).to({scaleX:0.6743,scaleY:0.6684,x:335.8,y:140.05},0).wait(1).to({scaleX:0.6643,scaleY:0.6578,x:332.35,y:139.2},0).wait(1).to({scaleX:0.6541,scaleY:0.647,x:328.85,y:138.35},0).wait(1).to({scaleX:0.6436,scaleY:0.636,x:325.2,y:137.45},0).wait(1).to({scaleX:0.633,scaleY:0.6247,x:321.5,y:136.5},0).wait(1).to({scaleX:0.6221,scaleY:0.6132,x:317.7,y:135.6},0).wait(1).to({scaleX:0.6111,scaleY:0.6016,x:313.9,y:134.65},0).wait(1).to({scaleX:0.6,scaleY:0.5899,x:310,y:133.7},0).wait(1).to({scaleX:0.5888,scaleY:0.5781,x:306.1,y:132.75},0).wait(1).to({scaleX:0.5776,scaleY:0.5663,x:302.25,y:131.75},0).wait(1).to({scaleX:0.5664,scaleY:0.5544,x:298.35,y:130.85},0).wait(1).to({scaleX:0.5552,scaleY:0.5427,x:294.5,y:129.9},0).wait(1).to({scaleX:0.5442,scaleY:0.531,x:290.65,y:128.95},0).wait(1).to({scaleX:0.5332,scaleY:0.5194,x:286.85,y:128},0).wait(1).to({scaleX:0.5225,scaleY:0.508,x:283.1,y:127.1},0).wait(1).to({scaleX:0.5119,scaleY:0.4969,x:279.45,y:126.15},0).wait(1).to({scaleX:0.5015,scaleY:0.4859,x:275.8,y:125.3},0).wait(1).to({scaleX:0.4914,scaleY:0.4752,x:272.3,y:124.4},0).wait(1).to({scaleX:0.4816,scaleY:0.4649,x:268.9,y:123.55},0).wait(1).to({scaleX:0.472,scaleY:0.4548,x:265.6,y:122.75},0).wait(1).to({scaleX:0.4628,scaleY:0.4451,x:262.45,y:122},0).wait(1).to({scaleX:0.454,scaleY:0.4358,x:259.35,y:121.25},0).wait(1).to({scaleX:0.4455,scaleY:0.4268,x:256.4,y:120.5},0).wait(1).to({scaleX:0.4374,scaleY:0.4182,x:253.6,y:119.8},0).wait(1).to({scaleX:0.4297,scaleY:0.4101,x:250.9,y:119.15},0).wait(1).to({scaleX:0.4223,scaleY:0.4023,x:248.35,y:118.55},0).wait(1).to({scaleX:0.4154,scaleY:0.395,x:245.95,y:117.95},0).wait(1).to({scaleX:0.4089,scaleY:0.3881,x:243.65,y:117.35},0).wait(1).to({scaleX:0.4028,scaleY:0.3817,x:241.55,y:116.85},0).wait(1).to({scaleX:0.3971,scaleY:0.3756,x:239.6,y:116.35},0).wait(1).to({scaleX:0.3918,scaleY:0.37,x:237.7,y:115.9},0).wait(1).to({scaleX:0.3869,scaleY:0.3649,x:236,y:115.5},0).wait(1).to({scaleX:0.3824,scaleY:0.3601,x:234.45,y:115.1},0).wait(1).to({scaleX:0.3783,scaleY:0.3558,x:233.05,y:114.75},0).wait(1).to({scaleX:0.3746,scaleY:0.3519,x:231.75,y:114.4},0).wait(1).to({scaleX:0.3712,scaleY:0.3484,x:230.6,y:114.15},0).wait(1).to({scaleX:0.3683,scaleY:0.3453,x:229.55,y:113.9},0).wait(1).to({scaleX:0.3657,scaleY:0.3426,x:228.65,y:113.65},0).wait(1).to({scaleX:0.3635,scaleY:0.3402,x:227.9,y:113.45},0).wait(1).to({scaleX:0.3617,scaleY:0.3383,x:227.3,y:113.3},0).wait(1).to({scaleX:0.3602,scaleY:0.3367,x:226.8,y:113.2},0).wait(1).to({scaleX:0.359,scaleY:0.3355,x:226.35,y:113.1},0).wait(1).to({scaleX:0.3582,scaleY:0.3347,x:226.1,y:113.05},0).wait(1).to({scaleX:0.3578,scaleY:0.3342,x:225.9,y:112.95},0).wait(1).to({regX:71,regY:48.4,scaleX:0.3576,scaleY:0.334,y:113},0).wait(79));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(54.35,135.65,0.2637,0.2637,0,0,0,225.1,236.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(70).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(11).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(1).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(58).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(79));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(125.4,140.2,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(17).to({regY:15.2,scaleX:0.7599,scaleY:0.7599,x:107.45,y:147.55},28,cjs.Ease.quadInOut).wait(25).to({regX:38,x:107.55},0).wait(11).to({regX:37.9,x:107.45},0).wait(1).to({regX:38,x:107.55},0).wait(58).to({regX:37.9,x:107.45},0).wait(79));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(120.3,143.35,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(17).to({regX:37.7,regY:15.7,scaleX:0.7718,scaleY:0.7718,x:107.45,y:147.55},28,cjs.Ease.quadInOut).to({alpha:0},24,cjs.Ease.quadOut).to({_off:true},1).wait(149));

	// first image
	this.instance_15 = new lib.firstimage_1();
	this.instance_15.setTransform(234.9,125.55,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(23).to({regX:42,regY:26.6,scaleX:0.576,scaleY:0.576,x:238.05,y:134.35},30,cjs.Ease.quadInOut).wait(17).to({regY:26.5,y:134.3},0).wait(11).to({regY:26.6,y:134.35},0).wait(1).to({regY:26.5,y:134.3},0).wait(58).to({regY:26.6,y:134.35},0).wait(79));

	// square shadow
	this.instance_16 = new lib.squareshadow();
	this.instance_16.setTransform(233.35,129.15,0.4651,0.4621,0,0,0,71,48);
	this.instance_16.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(23).to({regX:71.2,regY:48.2,scaleX:0.325,scaleY:0.3131,x:237.85,y:134.45},30,cjs.Ease.quadInOut).to({_off:true},1).wait(165));

	// second image
	this.instance_17 = new lib.secondimage_1();
	this.instance_17.setTransform(249.4,152.25,0.7473,0.7473,0,0,0,41.9,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(27).to({regX:42,regY:26.4,scaleX:0.5752,scaleY:0.5752,y:155.4},30,cjs.Ease.quadInOut).wait(13).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(11).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(1).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(58).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(79));

	// square shadow
	this.instance_18 = new lib.squareshadow();
	this.instance_18.setTransform(248.05,156.75,0.4651,0.4621,0,0,0,70.9,48.1);
	this.instance_18.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(27).to({regX:71.2,regY:48.4,scaleX:0.3475,scaleY:0.2831,x:249.5,y:156},30,cjs.Ease.quadInOut).to({_off:true},1).wait(161));

	// screen
	this.instance_19 = new lib.WordUI();
	this.instance_19.setTransform(178.55,155.6,0.8368,0.8368,0,0,0,151,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(70).to({regY:96,y:155.7},0).wait(11).to({regY:95.9,y:155.6},0).wait(1).to({regY:96,y:155.7},0).wait(58).to({regY:95.9,y:155.6},0).wait(79));

	// screen shadow
	this.instance_20 = new lib.shadow_1();
	this.instance_20.setTransform(179.9,132.35,0.888,0.888,0,0,0,180.6,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(70).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(11).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(1).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(58).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(79));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-389.1,-8.7,1154.3000000000002,339.09999999999997);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-32.25,2.6,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Am6CCIAAkEIN1AAIAAEEg");
	this.shape.setTransform(-59.375,2.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-10.8,88.7,26.1), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(272.05,-59,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(411,27.25,0.6221,0.6221,0,0,0,197.1,130.7);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.35,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(674.8,60.65,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(744.2,57.9,1.0683,1.0683,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Ribbon
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(125.2,-89.65,0.4597,0.4597);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(365.65,111,2.4361,0.37,0,0,0,150.1,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-188.6,730.9,924.8000000000001), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		var ribbon = mc.ribbon;
		
		
		
		this.runBanner = function() {
			
			this.tl1 = new TimelineLite();
						
				exportRoot.tl1.from(screen, 1, { alpha: 0, x: "+=129",y: "+=250", ease:Power3.easeOut,
					onStart: function() {screen.gotoAndPlay(1);},
					onComplete: function() {exportRoot.tl1.pause();}
				}, "+=0.5");
				
				
				exportRoot.tl1.to(screen, 1.475, {x: "-=35.5",y: "+=9.4",scaleX: 0.748,scaleY: 0.748, ease:Quad.easeInOut}, "+=0");
				exportRoot.tl1.to(screen, 1.5, {x: "-=108",y: "+=12",scaleX: 0.748,scaleY: 0.748, ease:Power3.easeInOut,onStart:function(){ribbon.gotoAndPlay(0);}}, "+=0.1");
		
			
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,-44.7,366.9,153.8);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1.png?1593011070532", id:"M365_FY21Q1_BTS_USA_728x90_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;