(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[0,0,217,600],[219,0,296,327],[0,602,31,70],[517,0,227,191],[467,329,246,258],[219,329,246,314]]}
];


// symbols:



(lib.BG = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.cloud_top = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Rock4 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Rock_1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.rock_2 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Rock_3 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.top_sky2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.cloud_top();
	this.instance.setTransform(156.6,-1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_sky2, new cjs.Rectangle(156.6,-1.6,296,327), null);


(lib.top_sky1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0.698)","rgba(249,248,248,0.698)","rgba(235,235,235,0)"],[0,0.498,1],0,-43.9,0,39.1).s().p("A3fG3IAAttMAu/AAAIAANtg");
	this.shape.setTransform(303.8796,76.4011);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.cloud_top();
	this.instance.setTransform(156.6,-1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_sky1, new cjs.Rectangle(153.5,-1.6,300.8,327), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Mountain_rock_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock4();
	this.instance.setTransform(-142.05,175.45,0.97,0.97);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_4, new cjs.Rectangle(-142,175.5,30,67.9), null);


(lib.Mountain_rock_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock_3();
	this.instance.setTransform(-22.3,162.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_3, new cjs.Rectangle(-22.3,162.1,246,314), null);


(lib.Mountain_rock_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.rock_2();
	this.instance.setTransform(-155.65,96.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_2, new cjs.Rectangle(-155.6,96.5,246,258), null);


(lib.Mountain_rock_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock_1();
	this.instance.setTransform(-98.55,211.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_1, new cjs.Rectangle(-98.5,211.6,227,191.00000000000003), null);


(lib.Mountain_BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.BG();
	this.instance.setTransform(51.2,-0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_BG, new cjs.Rectangle(51.2,-0.5,217,600), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.line_blip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgqAqQgRgSAAgYQAAgYARgSQASgRAYAAQAYAAASARQASASAAAYQAAAYgSASQgSASgYAAQgYAAgSgSg");
	this.shape.setTransform(6,6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_blip, new cjs.Rectangle(0,0,12,12), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.Mountain_rock_3_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		/*exportRoot.tl2.play();*/
	}
	this.frame_117 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(116).call(this.frame_117).wait(1));

	// Layer_6
	this.blip_1 = new lib.line_blip();
	this.blip_1.name = "blip_1";
	this.blip_1.setTransform(172.8,226.3,0.2,0.2,0,0,0,6.3,6);
	this.blip_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1).wait(87).to({_off:false},0).to({regX:6,scaleX:1.1,scaleY:1.1,x:172.75,y:226.25},11,cjs.Ease.cubicOut).to({regX:6.1,regY:6.1,scaleX:0.9,scaleY:0.9,x:172.8,y:226.3},5,cjs.Ease.cubicInOut).wait(15));

	// Layer_5
	this.blip_1_1 = new lib.line_blip();
	this.blip_1_1.name = "blip_1_1";
	this.blip_1_1.setTransform(132.45,247.4,0.2,0.2,0,0,0,6,6);
	this.blip_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1_1).wait(66).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:132.4,y:247.35},11,cjs.Ease.cubicOut).to({scaleX:0.9,scaleY:0.9},5,cjs.Ease.cubicInOut).wait(36));

	// Layer_4
	this.blip_1_2 = new lib.line_blip();
	this.blip_1_2.name = "blip_1_2";
	this.blip_1_2.setTransform(79.6,262.65,0.2,0.2,0,0,0,6.3,6.3);
	this.blip_1_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1_2).wait(41).to({_off:false},0).to({regX:6,regY:6,scaleX:1.1,scaleY:1.1},11,cjs.Ease.cubicOut).to({scaleX:0.9,scaleY:0.9,y:262.6},5,cjs.Ease.cubicInOut).wait(61));

	// Layer_13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhPU9IAlgRIB6ENIglARg");
	var mask_graphics_1 = new cjs.Graphics().p("AhQU9IAmgRIB7ENIgmARg");
	var mask_graphics_2 = new cjs.Graphics().p("AhRU9IApgSIB6ENIgpASg");
	var mask_graphics_3 = new cjs.Graphics().p("AhUU9IAugVIB7ENIguAVg");
	var mask_graphics_4 = new cjs.Graphics().p("AhXU9IA0gYIB7ENIg0AYg");
	var mask_graphics_5 = new cjs.Graphics().p("AhbU9IA9gcIB6ENIg9Acg");
	var mask_graphics_6 = new cjs.Graphics().p("AhhU9IBIggIB7ENIhIAgg");
	var mask_graphics_7 = new cjs.Graphics().p("AhnU9IBUgmIB7ENIhUAmg");
	var mask_graphics_8 = new cjs.Graphics().p("AhuU+IBiguIB7ENIhiAtg");
	var mask_graphics_9 = new cjs.Graphics().p("Ah2U+IBzg1IB6ENIhzA1g");
	var mask_graphics_10 = new cjs.Graphics().p("Ah/U+ICEg9IB7ENIiEA9g");
	var mask_graphics_11 = new cjs.Graphics().p("AiJU+ICYhHIB7ENIiYBHg");
	var mask_graphics_12 = new cjs.Graphics().p("AiUU+ICuhRIB7ENIiuBRg");
	var mask_graphics_13 = new cjs.Graphics().p("AigU+IDGhbIB7EMIjGBcg");
	var mask_graphics_14 = new cjs.Graphics().p("AitU+IDghnIB7ENIjgBng");
	var mask_graphics_15 = new cjs.Graphics().p("Ai7U+ID8h0IB7ENIj8B0g");
	var mask_graphics_16 = new cjs.Graphics().p("AjKU+IEaiBIB7EMIkaCCg");
	var mask_graphics_17 = new cjs.Graphics().p("AjaU+IE6iQIB7ENIk5CQg");
	var mask_graphics_18 = new cjs.Graphics().p("AjrU/IFbigIB8ENIlbCgg");
	var mask_graphics_19 = new cjs.Graphics().p("Aj9U/IF/iwIB8ENIl/Cwg");
	var mask_graphics_20 = new cjs.Graphics().p("AkPU/IGkjBIB7ENImkDBg");
	var mask_graphics_21 = new cjs.Graphics().p("AkjU/IHMjTIB7ENInMDTg");
	var mask_graphics_22 = new cjs.Graphics().p("Ak3U/IHzjlIB8ENInzDlg");
	var mask_graphics_23 = new cjs.Graphics().p("AlKU/IIZj2IB8ENIoZD2g");
	var mask_graphics_24 = new cjs.Graphics().p("AlbVAII8kHIB7ENIo8EHg");
	var mask_graphics_25 = new cjs.Graphics().p("AlsVAIJekXIB7ENIpeEXg");
	var mask_graphics_26 = new cjs.Graphics().p("Al8VAIJ9klIB8ENIp9Elg");
	var mask_graphics_27 = new cjs.Graphics().p("AmLVAIKbkzIB8ENIqbEzg");
	var mask_graphics_28 = new cjs.Graphics().p("AmZVAIK3k/IB8ENIq3E/g");
	var mask_graphics_29 = new cjs.Graphics().p("AmmVAILRlLIB8ENIrRFLg");
	var mask_graphics_30 = new cjs.Graphics().p("AmyVAILplWIB8ENIrpFWg");
	var mask_graphics_31 = new cjs.Graphics().p("Am9VAIL/lgIB8ENIr/Fgg");
	var mask_graphics_32 = new cjs.Graphics().p("AnHVBIMTlqIB8ENIsTFpg");
	var mask_graphics_33 = new cjs.Graphics().p("AnQVBIMmlzIB7ENIsmFzg");
	var mask_graphics_34 = new cjs.Graphics().p("AnYVBIM2l6IB7ENIs2F6g");
	var mask_graphics_35 = new cjs.Graphics().p("AnfVBINEmAIB7EMItEGBg");
	var mask_graphics_36 = new cjs.Graphics().p("AnmVBINRmGIB8ENItRGGg");
	var mask_graphics_37 = new cjs.Graphics().p("AnrVBINbmLIB8ENItbGLg");
	var mask_graphics_38 = new cjs.Graphics().p("AnvVBINkmPIB7ENItkGPg");
	var mask_graphics_39 = new cjs.Graphics().p("AnzVBINrmSIB8ENItrGSg");
	var mask_graphics_40 = new cjs.Graphics().p("An1VBINwmUIB7ENItvGUg");
	var mask_graphics_41 = new cjs.Graphics().p("An3VBINzmVIB8EMItzGWg");
	var mask_graphics_42 = new cjs.Graphics().p("An3VBINzmWIB8ENItzGWg");
	var mask_graphics_43 = new cjs.Graphics().p("An4VBIN1mXIB8ENIt1GXg");
	var mask_graphics_44 = new cjs.Graphics().p("An6VBIN6mZIB7ENIt6GZg");
	var mask_graphics_45 = new cjs.Graphics().p("An+VBIOCmdIB7ENIuCGdg");
	var mask_graphics_46 = new cjs.Graphics().p("AoEVBIONmiIB8ENIuNGig");
	var mask_graphics_47 = new cjs.Graphics().p("AoLVBIOcmoIB7ENIucGog");
	var mask_graphics_48 = new cjs.Graphics().p("AoUVBIOtmwIB8EMIutGxg");
	var mask_graphics_49 = new cjs.Graphics().p("AofVBIPDm6IB8ENIvDG6g");
	var mask_graphics_50 = new cjs.Graphics().p("AorVBIPbnFIB8ENIvbHFg");
	var mask_graphics_51 = new cjs.Graphics().p("Ao4VBIP2nRIB7EMIv2HSg");
	var mask_graphics_52 = new cjs.Graphics().p("ApIVBIQVnfIB8ENIwVHfg");
	var mask_graphics_53 = new cjs.Graphics().p("ApZVCIQ3nwIB8ENIw3Hwg");
	var mask_graphics_54 = new cjs.Graphics().p("AprVCIRcoBIB7ENIxcIBg");
	var mask_graphics_55 = new cjs.Graphics().p("Ap/VCISDoTIB8ENIyDITg");
	var mask_graphics_56 = new cjs.Graphics().p("AqSVCISpokIB8ENIypIkg");
	var mask_graphics_57 = new cjs.Graphics().p("AqjVCITLozIB8ENIzLIzg");
	var mask_graphics_58 = new cjs.Graphics().p("AqyVCITppBIB8ENIzpJBg");
	var mask_graphics_59 = new cjs.Graphics().p("ArAVDIUFpOIB8ENI0FJNg");
	var mask_graphics_60 = new cjs.Graphics().p("ArMVDIUdpZIB8ENI0dJZg");
	var mask_graphics_61 = new cjs.Graphics().p("ArWVDIUypjIB7ENI0yJjg");
	var mask_graphics_62 = new cjs.Graphics().p("ArfVDIVDprIB8ENI1DJrg");
	var mask_graphics_63 = new cjs.Graphics().p("ArmVDIVSpyIB7ENI1SJyg");
	var mask_graphics_64 = new cjs.Graphics().p("ArsVDIVdp3IB8ENI1dJ3g");
	var mask_graphics_65 = new cjs.Graphics().p("ArwVDIVlp6IB8ENI1lJ6g");
	var mask_graphics_66 = new cjs.Graphics().p("AryVDIVqp9IB7ENI1qJ9g");
	var mask_graphics_67 = new cjs.Graphics().p("ArzVDIVsp+IB7ENI1sJ+g");
	var mask_graphics_68 = new cjs.Graphics().p("Ar0VDIVup+IB7ENI1uJ+g");
	var mask_graphics_69 = new cjs.Graphics().p("Ar3VDIVzqBIB8ENI1zKBg");
	var mask_graphics_70 = new cjs.Graphics().p("Ar8VDIV9qFIB8ENI19KFg");
	var mask_graphics_71 = new cjs.Graphics().p("AsDVDIWLqMIB8ENI2LKMg");
	var mask_graphics_72 = new cjs.Graphics().p("AsLVDIWcqTIB7ENI2cKTg");
	var mask_graphics_73 = new cjs.Graphics().p("AsWVDIWxqdIB8ENI2xKdg");
	var mask_graphics_74 = new cjs.Graphics().p("AsiVDIXKqoIB7ENI3KKog");
	var mask_graphics_75 = new cjs.Graphics().p("AsxVDIXnq2IB8ENI3nK2g");
	var mask_graphics_76 = new cjs.Graphics().p("AtBVDIYHrEIB8ENI4HLEg");
	var mask_graphics_77 = new cjs.Graphics().p("AtTVDIYsrVIB7ENI4sLVg");
	var mask_graphics_78 = new cjs.Graphics().p("AtnVEIZTroIB8ENI5TLog");
	var mask_graphics_79 = new cjs.Graphics().p("At5VEIZ4r5IB7ENI54L5g");
	var mask_graphics_80 = new cjs.Graphics().p("AuKVEIaZsHIB8EMI6ZMIg");
	var mask_graphics_81 = new cjs.Graphics().p("AuYVEIa1sVIB8ENI61MVg");
	var mask_graphics_82 = new cjs.Graphics().p("AulVEIbPsgIB8ENI7PMgg");
	var mask_graphics_83 = new cjs.Graphics().p("AuvVEIbksqIB7ENI7kMqg");
	var mask_graphics_84 = new cjs.Graphics().p("Au4VEIb1sxIB8EMI71Myg");
	var mask_graphics_85 = new cjs.Graphics().p("Au+VEIcCs4IB8ENI8DM4g");
	var mask_graphics_86 = new cjs.Graphics().p("AvDVEIcMs8IB7ENI8MM8g");
	var mask_graphics_87 = new cjs.Graphics().p("AvGVEIcSs/IB7ENI8SM/g");
	var mask_graphics_88 = new cjs.Graphics().p("AvHVEIcUs/IB7EMI8UNAg");
	var mask_graphics_89 = new cjs.Graphics().p("AvHVEIcUs/IB7EMI8UNAg");
	var mask_graphics_90 = new cjs.Graphics().p("AvHVEIcTs/IB8ENI8TM/g");
	var mask_graphics_91 = new cjs.Graphics().p("AvHVEIcTs/IB8ENI8TM/g");
	var mask_graphics_92 = new cjs.Graphics().p("AvHVEIcTs/IB8ENI8TM/g");
	var mask_graphics_93 = new cjs.Graphics().p("AvGVEIcSs/IB7ENI8SM/g");
	var mask_graphics_94 = new cjs.Graphics().p("AvGVEIcSs/IB7ENI8SM/g");
	var mask_graphics_95 = new cjs.Graphics().p("AvGVEIcRs+IB8ENI8RM+g");
	var mask_graphics_96 = new cjs.Graphics().p("AvFVEIcQs+IB7ENI8QM+g");
	var mask_graphics_97 = new cjs.Graphics().p("AvFVEIcPs+IB8ENI8PM+g");
	var mask_graphics_98 = new cjs.Graphics().p("AvEVEIcOs9IB7ENI8OM9g");
	var mask_graphics_99 = new cjs.Graphics().p("AvEVEIcNs9IB8ENI8NM9g");
	var mask_graphics_100 = new cjs.Graphics().p("AvDVEIcMs8IB7ENI8MM8g");
	var mask_graphics_101 = new cjs.Graphics().p("AvDVEIcLs8IB8ENI8LM8g");
	var mask_graphics_102 = new cjs.Graphics().p("AvCVEIcJs7IB8ENI8JM7g");
	var mask_graphics_103 = new cjs.Graphics().p("AvBVEIcIs7IB7ENI8IM7g");
	var mask_graphics_104 = new cjs.Graphics().p("AvAVEIcGs6IB7ENI8GM6g");
	var mask_graphics_105 = new cjs.Graphics().p("AvAVEIcFs5IB8EMI8FM6g");
	var mask_graphics_106 = new cjs.Graphics().p("Au/VEIcEs5IB7ENI8EM4g");
	var mask_graphics_107 = new cjs.Graphics().p("Au/VDIcDs3IB8EMI8DM4g");
	var mask_graphics_108 = new cjs.Graphics().p("Au+VDIcCs3IB7ENI8CM3g");
	var mask_graphics_109 = new cjs.Graphics().p("Au+VDIcBs3IB8ENI8BM3g");
	var mask_graphics_110 = new cjs.Graphics().p("Au9VDIcAs2IB7ENI8AM2g");
	var mask_graphics_111 = new cjs.Graphics().p("Au9VDIb/s2IB8ENI7/M2g");
	var mask_graphics_112 = new cjs.Graphics().p("Au9VDIb/s2IB8ENI7/M2g");
	var mask_graphics_113 = new cjs.Graphics().p("Au8VDIb+s2IB7ENI7+M2g");
	var mask_graphics_114 = new cjs.Graphics().p("Au8VDIb+s1IB7EMI7+M2g");
	var mask_graphics_115 = new cjs.Graphics().p("Au8VDIb+s1IB7ENI7+M1g");
	var mask_graphics_116 = new cjs.Graphics().p("Au8VDIb9s1IB8ENI79M1g");
	var mask_graphics_117 = new cjs.Graphics().p("Au8U6Ib9s1IB8EMI79M2g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-4.6239,y:161.0223}).wait(1).to({graphics:mask_graphics_1,x:-4.5775,y:161.0227}).wait(1).to({graphics:mask_graphics_2,x:-4.4384,y:161.024}).wait(1).to({graphics:mask_graphics_3,x:-4.2065,y:161.026}).wait(1).to({graphics:mask_graphics_4,x:-3.8818,y:161.0289}).wait(1).to({graphics:mask_graphics_5,x:-3.4643,y:161.0327}).wait(1).to({graphics:mask_graphics_6,x:-2.9541,y:161.0372}).wait(1).to({graphics:mask_graphics_7,x:-2.3511,y:161.0426}).wait(1).to({graphics:mask_graphics_8,x:-1.6553,y:161.0488}).wait(1).to({graphics:mask_graphics_9,x:-0.8668,y:161.0558}).wait(1).to({graphics:mask_graphics_10,x:0.0145,y:161.0637}).wait(1).to({graphics:mask_graphics_11,x:0.9885,y:161.0724}).wait(1).to({graphics:mask_graphics_12,x:2.0554,y:161.0819}).wait(1).to({graphics:mask_graphics_13,x:3.215,y:161.0922}).wait(1).to({graphics:mask_graphics_14,x:4.4673,y:161.1034}).wait(1).to({graphics:mask_graphics_15,x:5.8125,y:161.1154}).wait(1).to({graphics:mask_graphics_16,x:7.2503,y:161.1282}).wait(1).to({graphics:mask_graphics_17,x:8.781,y:161.1418}).wait(1).to({graphics:mask_graphics_18,x:10.4044,y:161.1563}).wait(1).to({graphics:mask_graphics_19,x:12.1206,y:161.1716}).wait(1).to({graphics:mask_graphics_20,x:13.9296,y:161.1877}).wait(1).to({graphics:mask_graphics_21,x:15.8313,y:161.2047}).wait(1).to({graphics:mask_graphics_22,x:17.7331,y:161.2217}).wait(1).to({graphics:mask_graphics_23,x:19.542,y:161.2378}).wait(1).to({graphics:mask_graphics_24,x:21.2582,y:161.2531}).wait(1).to({graphics:mask_graphics_25,x:22.8817,y:161.2676}).wait(1).to({graphics:mask_graphics_26,x:24.4123,y:161.2812}).wait(1).to({graphics:mask_graphics_27,x:25.8502,y:161.294}).wait(1).to({graphics:mask_graphics_28,x:27.1953,y:161.306}).wait(1).to({graphics:mask_graphics_29,x:28.4477,y:161.3172}).wait(1).to({graphics:mask_graphics_30,x:29.6073,y:161.3275}).wait(1).to({graphics:mask_graphics_31,x:30.6741,y:161.337}).wait(1).to({graphics:mask_graphics_32,x:31.6481,y:161.3457}).wait(1).to({graphics:mask_graphics_33,x:32.5294,y:161.3536}).wait(1).to({graphics:mask_graphics_34,x:33.3179,y:161.3606}).wait(1).to({graphics:mask_graphics_35,x:34.0137,y:161.3668}).wait(1).to({graphics:mask_graphics_36,x:34.6167,y:161.3722}).wait(1).to({graphics:mask_graphics_37,x:35.1269,y:161.3767}).wait(1).to({graphics:mask_graphics_38,x:35.5444,y:161.3805}).wait(1).to({graphics:mask_graphics_39,x:35.869,y:161.3834}).wait(1).to({graphics:mask_graphics_40,x:36.101,y:161.3854}).wait(1).to({graphics:mask_graphics_41,x:36.2401,y:161.3867}).wait(1).to({graphics:mask_graphics_42,x:36.3531,y:161.3716}).wait(1).to({graphics:mask_graphics_43,x:36.432,y:161.3723}).wait(1).to({graphics:mask_graphics_44,x:36.6667,y:161.3745}).wait(1).to({graphics:mask_graphics_45,x:37.0578,y:161.378}).wait(1).to({graphics:mask_graphics_46,x:37.6053,y:161.383}).wait(1).to({graphics:mask_graphics_47,x:38.3092,y:161.3894}).wait(1).to({graphics:mask_graphics_48,x:39.1696,y:161.3973}).wait(1).to({graphics:mask_graphics_49,x:40.1864,y:161.4066}).wait(1).to({graphics:mask_graphics_50,x:41.3597,y:161.4172}).wait(1).to({graphics:mask_graphics_51,x:42.6894,y:161.4294}).wait(1).to({graphics:mask_graphics_52,x:44.1755,y:161.4429}).wait(1).to({graphics:mask_graphics_53,x:45.8181,y:161.4579}).wait(1).to({graphics:mask_graphics_54,x:47.6171,y:161.4743}).wait(1).to({graphics:mask_graphics_55,x:49.5334,y:161.4917}).wait(1).to({graphics:mask_graphics_56,x:51.3324,y:161.5081}).wait(1).to({graphics:mask_graphics_57,x:52.975,y:161.5231}).wait(1).to({graphics:mask_graphics_58,x:54.4611,y:161.5366}).wait(1).to({graphics:mask_graphics_59,x:55.7908,y:161.5487}).wait(1).to({graphics:mask_graphics_60,x:56.9641,y:161.5594}).wait(1).to({graphics:mask_graphics_61,x:57.9809,y:161.5687}).wait(1).to({graphics:mask_graphics_62,x:58.8413,y:161.5765}).wait(1).to({graphics:mask_graphics_63,x:59.5453,y:161.5829}).wait(1).to({graphics:mask_graphics_64,x:60.0928,y:161.5879}).wait(1).to({graphics:mask_graphics_65,x:60.4839,y:161.5915}).wait(1).to({graphics:mask_graphics_66,x:60.7186,y:161.5936}).wait(1).to({graphics:mask_graphics_67,x:60.7756,y:161.5716}).wait(1).to({graphics:mask_graphics_68,x:60.8688,y:161.5723}).wait(1).to({graphics:mask_graphics_69,x:61.1476,y:161.5743}).wait(1).to({graphics:mask_graphics_70,x:61.6122,y:161.5777}).wait(1).to({graphics:mask_graphics_71,x:62.2626,y:161.5825}).wait(1).to({graphics:mask_graphics_72,x:63.0989,y:161.5886}).wait(1).to({graphics:mask_graphics_73,x:64.121,y:161.5961}).wait(1).to({graphics:mask_graphics_74,x:65.329,y:161.6049}).wait(1).to({graphics:mask_graphics_75,x:66.7228,y:161.6151}).wait(1).to({graphics:mask_graphics_76,x:68.3024,y:161.6267}).wait(1).to({graphics:mask_graphics_77,x:70.0679,y:161.6396}).wait(1).to({graphics:mask_graphics_78,x:71.9727,y:161.6535}).wait(1).to({graphics:mask_graphics_79,x:73.7382,y:161.6664}).wait(1).to({graphics:mask_graphics_80,x:75.3178,y:161.678}).wait(1).to({graphics:mask_graphics_81,x:76.7116,y:161.6882}).wait(1).to({graphics:mask_graphics_82,x:77.9196,y:161.697}).wait(1).to({graphics:mask_graphics_83,x:78.9417,y:161.7045}).wait(1).to({graphics:mask_graphics_84,x:79.7779,y:161.7106}).wait(1).to({graphics:mask_graphics_85,x:80.4284,y:161.7154}).wait(1).to({graphics:mask_graphics_86,x:80.893,y:161.7188}).wait(1).to({graphics:mask_graphics_87,x:81.1717,y:161.7208}).wait(1).to({graphics:mask_graphics_88,x:81.2635,y:161.7214}).wait(1).to({graphics:mask_graphics_89,x:81.2629,y:161.7212}).wait(1).to({graphics:mask_graphics_90,x:81.2575,y:161.7205}).wait(1).to({graphics:mask_graphics_91,x:81.2486,y:161.7192}).wait(1).to({graphics:mask_graphics_92,x:81.2362,y:161.7175}).wait(1).to({graphics:mask_graphics_93,x:81.2202,y:161.7152}).wait(1).to({graphics:mask_graphics_94,x:81.2006,y:161.7125}).wait(1).to({graphics:mask_graphics_95,x:81.1775,y:161.7092}).wait(1).to({graphics:mask_graphics_96,x:81.1508,y:161.7054}).wait(1).to({graphics:mask_graphics_97,x:81.1205,y:161.7012}).wait(1).to({graphics:mask_graphics_98,x:81.0867,y:161.6964}).wait(1).to({graphics:mask_graphics_99,x:81.0494,y:161.6912}).wait(1).to({graphics:mask_graphics_100,x:81.0085,y:161.6854}).wait(1).to({graphics:mask_graphics_101,x:80.964,y:161.6791}).wait(1).to({graphics:mask_graphics_102,x:80.9159,y:161.6724}).wait(1).to({graphics:mask_graphics_103,x:80.8652,y:161.6652}).wait(1).to({graphics:mask_graphics_104,x:80.8172,y:161.6585}).wait(1).to({graphics:mask_graphics_105,x:80.7727,y:161.6522}).wait(1).to({graphics:mask_graphics_106,x:80.7318,y:161.6465}).wait(1).to({graphics:mask_graphics_107,x:80.6945,y:161.6412}).wait(1).to({graphics:mask_graphics_108,x:80.6606,y:161.6364}).wait(1).to({graphics:mask_graphics_109,x:80.6304,y:161.6322}).wait(1).to({graphics:mask_graphics_110,x:80.6037,y:161.6284}).wait(1).to({graphics:mask_graphics_111,x:80.5806,y:161.6252}).wait(1).to({graphics:mask_graphics_112,x:80.561,y:161.6224}).wait(1).to({graphics:mask_graphics_113,x:80.545,y:161.6202}).wait(1).to({graphics:mask_graphics_114,x:80.5326,y:161.6184}).wait(1).to({graphics:mask_graphics_115,x:80.5237,y:161.6171}).wait(1).to({graphics:mask_graphics_116,x:80.5183,y:161.6164}).wait(1).to({graphics:mask_graphics_117,x:84.4009,y:160.6973}).wait(1));

	// Layer_11
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF001").ss(5.5,1,1).p("AxFJAQIrlTCaiBIKHi4IFXjCIHokx");
	this.shape.setTransform(114.575,253.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(118));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.5,192.8,224.2,120.69999999999999);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// rock_3_txt
	this.rock_3_txt = new lib.Mountain_rock_3_txt();
	this.rock_3_txt.name = "rock_3_txt";
	this.rock_3_txt.setTransform(74.4,-54.85,1.63,1.63,0,0,0,175.5,88);

	this.timeline.addTween(cjs.Tween.get(this.rock_3_txt).wait(1));

	// rock_1
	this.rock_1 = new lib.Mountain_rock_1();
	this.rock_1.name = "rock_1";
	this.rock_1.setTransform(89.15,75.8,1.63,1.63,0,0,0,100.5,46.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_1).wait(1));

	// rock_2
	this.rock_2 = new lib.Mountain_rock_2();
	this.rock_2.name = "rock_2";
	this.rock_2.setTransform(271.85,105.8,1.63,1.63,0,0,0,164,66.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_2).wait(1));

	// rock_3_img
	this.rock_3 = new lib.Mountain_rock_3();
	this.rock_3.name = "rock_3";
	this.rock_3.setTransform(74.4,-58.5,1.63,1.63,0,0,0,175.5,88);

	this.timeline.addTween(cjs.Tween.get(this.rock_3).wait(1));

	// rock_4
	this.rock_4 = new lib.Mountain_rock_4();
	this.rock_4.name = "rock_4";
	this.rock_4.setTransform(168.75,-120.5,1.63,1.63,0,0,0,12,27.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_4).wait(1));

	// top_sky
	this.cloud_1 = new lib.top_sky1();
	this.cloud_1.name = "cloud_1";
	this.cloud_1.setTransform(-154.85,-192.9,1.2888,1.2888,0,0,0,228.9,133.4);

	this.timeline.addTween(cjs.Tween.get(this.cloud_1).wait(1));

	// top_sky copy
	this.cloud_2 = new lib.top_sky2();
	this.cloud_2.name = "cloud_2";
	this.cloud_2.setTransform(-217.8,109.1,1.5743,1.5743,0,0,0,228.9,133.2);

	this.timeline.addTween(cjs.Tween.get(this.cloud_2).wait(1));

	// bg
	this.bg = new lib.Mountain_BG();
	this.bg.name = "bg";
	this.bg.setTransform(51.45,-216.7,1.63,1.63,0,0,0,204,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(-331.6,-421.3,489.5,1077.6), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		exportRoot.tl1.play();
		exportRoot.tlbg.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(24).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(66.5,886.1,0.1849,0.1849,0,0,0,-39.5,1.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.0594,scaleY:3.0594,x:66.4},13,cjs.Ease.quadOut).to({x:-103.6},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgUrBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_15 = new cjs.Graphics().p("EgU3BHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_16 = new cjs.Graphics().p("EgVaBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_17 = new cjs.Graphics().p("EgWVBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_18 = new cjs.Graphics().p("EgXoBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_19 = new cjs.Graphics().p("EgZSBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_20 = new cjs.Graphics().p("EgbUBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_21 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_22 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_23 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_24 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_25 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_26 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:231.7572,y:459.506}).wait(1).to({graphics:mask_graphics_15,x:230.575,y:459.506}).wait(1).to({graphics:mask_graphics_16,x:227.0284,y:459.506}).wait(1).to({graphics:mask_graphics_17,x:221.1174,y:459.506}).wait(1).to({graphics:mask_graphics_18,x:212.842,y:459.506}).wait(1).to({graphics:mask_graphics_19,x:202.2023,y:459.506}).wait(1).to({graphics:mask_graphics_20,x:189.1981,y:459.506}).wait(1).to({graphics:mask_graphics_21,x:170.3212,y:459.506}).wait(1).to({graphics:mask_graphics_22,x:149.0417,y:459.506}).wait(1).to({graphics:mask_graphics_23,x:132.491,y:459.506}).wait(1).to({graphics:mask_graphics_24,x:120.669,y:459.506}).wait(1).to({graphics:mask_graphics_25,x:113.5758,y:459.506}).wait(1).to({graphics:mask_graphics_26,x:111.3476,y:459.506}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-200.65,882.4,3.0594,3.0594,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:19.15},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgqKCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgtbCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Egw4CaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Eg0hCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Eg4UCaqMAAAk1TMBSHAAAMAAAE1Tg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:68.2273,y:916.1858}).wait(51).to({graphics:mask_1_graphics_51,x:68.2273,y:916.1858}).wait(1).to({graphics:mask_1_graphics_52,x:67.0331,y:916.1858}).wait(1).to({graphics:mask_1_graphics_53,x:63.4503,y:916.1858}).wait(1).to({graphics:mask_1_graphics_54,x:57.479,y:916.1858}).wait(1).to({graphics:mask_1_graphics_55,x:49.1193,y:916.1858}).wait(1).to({graphics:mask_1_graphics_56,x:38.371,y:916.1858}).wait(1).to({graphics:mask_1_graphics_57,x:25.2342,y:916.1858}).wait(1).to({graphics:mask_1_graphics_58,x:9.7088,y:916.1858}).wait(1).to({graphics:mask_1_graphics_59,x:-8.205,y:916.1858}).wait(1).to({graphics:mask_1_graphics_60,x:-28.5073,y:916.1858}).wait(1).to({graphics:mask_1_graphics_61,x:-51.1982,y:916.1858}).wait(1).to({graphics:mask_1_graphics_62,x:-76.2775,y:916.1858}).wait(1).to({graphics:mask_1_graphics_63,x:-103.7454,y:916.1858}).wait(1).to({graphics:mask_1_graphics_64,x:-133.6018,y:916.1858}).wait(1).to({graphics:mask_1_graphics_65,x:-165.8467,y:916.1858}).wait(1).to({graphics:mask_1_graphics_66,x:-200.4801,y:916.1858}).wait(1).to({graphics:mask_1_graphics_67,x:-237.502,y:916.1858}).wait(1).to({graphics:mask_1_graphics_68,x:-269.8699,y:916.1858}).wait(1).to({graphics:mask_1_graphics_69,x:-290.7693,y:916.1858}).wait(1).to({graphics:mask_1_graphics_70,x:-312.8631,y:916.1858}).wait(1).to({graphics:mask_1_graphics_71,x:-336.151,y:916.1858}).wait(1).to({graphics:mask_1_graphics_72,x:-360.525,y:916.1858}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(19.15,882.4,3.0594,3.0594,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(68.2,2281.7,0.5414,5.7885,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({scaleY:5.7403,y:2262.05},0).to({regX:484.9,x:-458.55},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(68.2,2281.7,0.5414,5.7885,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({scaleY:5.741,y:2262.35},0).wait(2).to({regX:484.9,scaleY:5.7885,x:-458.55,y:2281.7},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-721,-73.6,1052.1,1979.6);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(3,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Ap1CeIAAk7ITrAAIAAE7g");
	this.shape.setTransform(-38.375,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-101.4,-16.5,126.10000000000001,31.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(145.7,1.4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(93.85,570,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(138.6,570.25,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(16.15,16.35,1,1,0,0,0,-52.6,-23.7);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// people
	this.mountain = new lib.mountain_anim();
	this.mountain.name = "mountain";
	this.mountain.setTransform(253.35,213.55,0.614,0.614,0,0,0,284.2,24.8);

	this.timeline.addTween(cjs.Tween.get(this.mountain).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-124.7,-60.3,300.5,669.6999999999999), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "moun") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillMountain(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillMountain = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.mountain.rock_3_txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		//mc.txtCta.alpha=0
		//mc.cta.alpha=0
		//mc.replay_btn.alpha=0
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
		
			this.tl1 = new TimelineLite();
				
				exportRoot.tl1.from(mc.logo_1, 0.7, { x: "+=200",	ease:Power4.easeOut}, "+=0");
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { x: "+=200",	ease:Power4.easeOut}, "-=0");
				exportRoot.tl1.from(mc.cta, 0.7, { x: "+=200", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.2");	
		
				exportRoot.tl1.stop();
				
				this.tlbg = new TimelineLite();
					
				exportRoot.tlbg.from(mc.mountain.bg, 5, { x: "+=20",	ease:Power4.easeOut}, "+=0.5");
				exportRoot.tlbg.from(mc.mountain.rock_1, 5, { x: "+=120",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_2, 5, { x: "+=80",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_3_txt, 5, { x: "+=40",	ease:Power4.easeOut, onStart:function(){mc.mountain.rock_3_txt.play();}}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_3, 5, { x: "+=40",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_4, 5, { x: "+=30",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.cloud_1, 14, { x: "+=80",	ease:Power2.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.cloud_2, 14, { x: "+=100",	ease:Power2.easeOut}, "-=14");
			//	exportRoot.tlbg.from(mc.mountain.cloud_3, 14, { x: "+=10",	ease:Power2.easeOut}, "-=14");
				
				exportRoot.tlbg.stop();
				
				this.tl2 = new TimelineLite();
				
					for (var i = 0; i < exportRoot.mountainText1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText1[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=3.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText1[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
						for (var i = 0; i < exportRoot.mountainText2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText2[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=3");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText2[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
								for (var i = 0; i < exportRoot.mountainText3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText3[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=2.45");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText3[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl2.stop();
				
				
			mc.logo_intro.gotoAndPlay(1)
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.7,239.7,220.5,369.7);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1583776248194", id:"O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;