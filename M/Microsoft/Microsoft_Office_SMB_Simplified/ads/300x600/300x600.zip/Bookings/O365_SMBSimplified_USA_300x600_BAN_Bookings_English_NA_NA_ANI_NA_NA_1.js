(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[0,0,350,197],[312,1134,140,250],[612,988,324,39],[612,1029,323,37],[612,1068,323,36],[454,1230,323,33],[612,1106,322,26],[454,1285,322,17],[454,1265,322,18],[454,1192,322,36],[454,1134,321,56],[312,1386,320,77],[600,887,318,99],[600,765,316,120],[296,993,314,139],[0,1240,310,155],[592,595,308,168],[292,813,306,178],[590,407,304,186],[644,0,301,192],[590,208,299,197],[292,611,298,200],[292,407,296,202],[0,1034,294,204],[0,199,292,206],[352,0,290,206],[0,407,290,207],[0,616,290,207],[0,825,290,207],[294,208,193,179]]}
];


// symbols:



(lib.booking_mobile_laptop = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.booking_mobile_small = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Base = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00000 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00001 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00002 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00003 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00004 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00005 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00006 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00007 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00008 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00009 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00010 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00011 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00012 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00013 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00014 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00015 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00016 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00017 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00018 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00019 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00020 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00022 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00024 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00026 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00028 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00030 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x1500 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wide_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#D8D8D8","#E7E7E7","#F9F9F9","#FFFFFF"],[0.369,0.631,0.831,1],0,0,0,0,0,196).s().p("A1eVfQo6o5AAsmQAAslI6o5QI5o6MlAAQMmAAI5I6QI6I5AAMlQAAMmo6I5Qo5I6smAAQslAAo5o6g");
	this.shape.setTransform(194.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wide_shadow_sub, new cjs.Rectangle(0,0,389,389), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A4/MAAAhx9MCXtAAAMAAABx9g");
	this.shape.setTransform(485.475,149.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,-214.9,971,729.5), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tile_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,1],-0.5,12.2,-0.5,24.3).s().p("A5bD6IAAnzMAy3AAAIAAHzg");
	this.shape.setTransform(162.8,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow_sub, new cjs.Rectangle(0,0,325.6,50), null);


(lib.phone_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["#A3A4A5","#5C5D5E","#BEBFC2"],[0.039,0.769,1],0,66.9,0,-66.8).ss(0.5,1,1).p("AkmqZIJNAAQA8AAAAA8IAAEJIAAB/IAAMzQAAA8g8AAIpNAAQg8AAAAg8IAAs6IAAjpIAAiYQAAg8A8AAg");
	this.shape.setTransform(36.25,66.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#131415").s().p("AkmKaQg8AAAAg8IAAs6IAAjpIAAiYQAAg8A8AAIJNAAQA8AAAAA8IAAEJIAAB/IAAMzQAAA8g8AAg");
	this.shape_1.setTransform(36.25,66.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#797A7C").s().p("AFjB4IAAh/IAIAAIAAB/gAlqBwIAAjnIAIAAIAADng");
	this.shape_2.setTransform(36.25,33.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_sub, new cjs.Rectangle(-0.2,-1,73,135.3), null);


(lib.phone_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.063)","rgba(0,0,0,0.278)","rgba(0,0,0,0.498)"],[0,0.125,0.38,1],-5.2,-6.5,-5.2,5.5).s().p("Ak5BCImLiDIWJAAImLCDg");
	this.shape.setTransform(70.875,6.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_shadow, new cjs.Rectangle(0,0,141.8,13.2), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.booking_mobile_laptop();
	this.instance.parent = this;
	this.instance.setTransform(0.65,-0.65,0.8576,0.8576);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.MainScreen, new cjs.Rectangle(0.7,-0.6,300.1,168.9), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.laptop_shadow_2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0.698)","rgba(0,0,0,0.098)","rgba(0,0,0,0)"],[0.369,0.596,0.831,1],0,0,0,0,0,196).s().p("A1eVfQo6o5AAsmQAAslI6o5QI5o6MlAAQMmAAI5I6QI6I5AAMlQAAMmo6I5Qo5I6smAAQslAAo5o6g");
	this.shape.setTransform(194.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_shadow_2_sub, new cjs.Rectangle(0,0,389,389), null);


(lib.laptop_shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.698)","rgba(0,0,0,0)"],[0.412,0.976],2.3,-2.8,0,2.3,-2.8,5.8).s().p("AgPAMQgQgPAAgYIAAgBIA1AAIAAAAIAAA4IALAAIgKABQgXAAgPgRg");
	this.shape.setTransform(156.05,215.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.698)","rgba(0,0,0,0)"],[0.412,0.976],-2.3,-2.8,0,-2.3,-2.8,5.8).s().p("AgfAcIAKAAIAAg4IA1AAIAAABQAAAYgQAPQgQARgWAAIgJgBg");
	this.shape_1.setTransform(474.75,215.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.698)","rgba(0,0,0,0)"],[0,1],-130.9,-0.3,-130.9,2.8).s().p("AYZAdMgwxAAAIgKAAIAAg4IgBAAIAAgBMAxFAAAIACAAIAAABIAAA4g");
	this.shape_2.setTransform(315.375,215.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_shadow_1, new cjs.Rectangle(152.8,212.6,325.2,5.900000000000006), null);


(lib.logoc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AhlB3QgngpAAhNQAAhGArguQAqgtA/AAQA/gBAjApQAjApAABIIAAAaIjSAAQACArAZAXQAZAYArAAQAxgBApgdIAAA4QgpAahGABQhDgBgngqgAgrhXQgVAXgFAiICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape.setTransform(209.9026,-127.8368,0.2091,0.2091);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AhNB3QgrgrAAhEQAAhMAuguQAugvBKABQArgBAgAQIAABBQgggZglAAQgsAAgcAeQgcAfAAAvQAAAwAbAcQAZAbAtAAQAmAAAhgaIAAA8QglAWgyAAQhFgBgpgqg");
	this.shape_1.setTransform(203.95,-127.8,0.2091,0.2091,0,0,0,-0.2,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgjDiIAAkzIBFAAIAAEzgAgdidQgMgMAAgRQAAgQAMgMQANgLAQAAQARAAANALQAMAMAAAQQAAAQgMAMQgNAMgRAAQgRAAgMgLg");
	this.shape_2.setTransform(199.9499,-129.3423,0.2091,0.2091);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgyAAAAA6IAAApIBHAAIAAA3IhHAAIAAD9g");
	this.shape_3.setTransform(196.4999,-129.4573,0.2091,0.2091);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgzAAAAA6IAAApIBIAAIAAA3IhHAAIAAD9g");
	this.shape_4.setTransform(192.454,-129.4573,0.2091,0.2091);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AiWCjQg4g9gBhhQABhnA5g+QA5g+BiAAQBaAAA4A8QA4A8gBBiQAABog4A+Qg5A9heAAQheAAg4g8gAhehzQglAtAABHQAABIAkAsQAkAsA7AAQA9AAAkgqQAkgqAAhLQgBhMgigrQgjgqg9AAQg7AAglAsg");
	this.shape_5.setTransform(185.7,-129.1,0.2091,0.2091,0,0,0,0,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_6.setTransform(118.6,-125.15,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_7.setTransform(110.7,-125.15,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(118.6,-133.05,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(110.7,-133.05,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_10.setTransform(152.15,-129.4,0.2091,0.2091,0,0,0,-0.2,-0.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_11.setTransform(232.2597,-129.0338,0.2091,0.2091);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_12.setTransform(225.872,-129.1123,0.2091,0.2091);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_13.setTransform(219.3327,-129.1123,0.2091,0.2091);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoc, new cjs.Rectangle(107.2,-136.6,127.8,15), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.wide_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow_sub.cache(0,0,390,390,.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow_sub = new lib.wide_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(194.5,194.5,1,1,0,0,0,194.5,194.5);
	this.shadow_sub.alpha = 0.8008;

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.wide_shadow, new cjs.Rectangle(0,0,389,389), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow_sub.cache(0,0,325,50,.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow_sub = new lib.shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(162.8,43.7,1,1,0,0,0,162.8,43.7);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,325.6,50), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Phone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEJEIAAyHIKJAAIAASHg");
	mask.setTransform(36.5,66);

	// Layer_13
	this.instance = new lib.booking_mobile_small();
	this.instance.parent = this;
	this.instance.setTransform(3.95,8.5,0.4607,0.4607);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_11
	this.phone = new lib.phone_sub();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(36.3,66.6,1,1,0,0,0,36.3,66.6);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

	// Layer_12
	this.phone_shadow = new lib.phone_shadow();
	this.phone_shadow.name = "phone_shadow";
	this.phone_shadow.parent = this;
	this.phone_shadow.setTransform(36.25,129,1,0.7,0,0,0,70.9,6.7);
	this.phone_shadow.alpha = 0.3984;

	this.timeline.addTween(cjs.Tween.get(this.phone_shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.Phone, new cjs.Rectangle(-34.6,-0.2,141.7,133.79999999999998), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_54 = function() {
		exportRoot.tl1.play()
	}
	this.frame_75 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(21).call(this.frame_75).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298,321.6,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:320.9},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(49));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AmofKIAAyrMBGZAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("Am4fKIAAyrMBGZAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("AnmfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("AozfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("AqefKIAAyrMBGZAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("AspfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("AvSfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("Ax7fKIAAyrMBGZAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("A0GfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("A1xfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("A2+fKIAAyrMBGZAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("A3sfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("A38fKIAAyrMBGZAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:199.4334}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:199.4334}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:199.4334}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:199.4334}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:199.4334}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:199.4334}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:199.4334}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:199.4334}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:199.4334}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:199.4334}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:199.4334}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:199.4334}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:199.4334}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.9,314.25,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:300.35},12,cjs.Ease.quadInOut).to({_off:true},24).wait(26));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhM1CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTjCIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhanCIBMAAAkQBMCXtAAAMAAAEQBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:289.9213}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:289.9213}).wait(1).to({graphics:mask_1_graphics_52,x:295.8271,y:289.9213}).wait(1).to({graphics:mask_1_graphics_53,x:289.2111,y:289.9213}).wait(1).to({graphics:mask_1_graphics_54,x:278.1844,y:289.9213}).wait(1).to({graphics:mask_1_graphics_55,x:262.7471,y:289.9213}).wait(1).to({graphics:mask_1_graphics_56,x:242.8992,y:289.9213}).wait(1).to({graphics:mask_1_graphics_57,x:218.6406,y:289.9213}).wait(1).to({graphics:mask_1_graphics_58,x:189.9713,y:289.9213}).wait(1).to({graphics:mask_1_graphics_59,x:156.8914,y:289.9213}).wait(1).to({graphics:mask_1_graphics_60,x:119.4008,y:289.9213}).wait(1).to({graphics:mask_1_graphics_61,x:77.4995,y:289.9213}).wait(1).to({graphics:mask_1_graphics_62,x:31.1876,y:289.9213}).wait(1).to({graphics:mask_1_graphics_63,x:-19.5349,y:289.9213}).wait(1).to({graphics:mask_1_graphics_64,x:-74.6682,y:289.9213}).wait(1).to({graphics:mask_1_graphics_65,x:-134.212,y:289.9213}).wait(1).to({graphics:mask_1_graphics_66,x:-198.1666,y:289.9213}).wait(1).to({graphics:mask_1_graphics_67,x:-266.5318,y:289.9213}).wait(1).to({graphics:mask_1_graphics_68,x:-339.3076,y:289.9213}).wait(1).to({graphics:mask_1_graphics_69,x:-416.4941,y:289.9213}).wait(1).to({graphics:mask_1_graphics_70,x:-491.7868,y:289.9213}).wait(1).to({graphics:mask_1_graphics_71,x:-534.7908,y:289.9213}).wait(1).to({graphics:mask_1_graphics_72,x:-580,y:289.9213}).wait(4));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.35,314.25,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({_off:true},25).wait(1));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({x:-674.6},21,cjs.Ease.quadIn).to({_off:true},3).wait(1));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-674.6},21,cjs.Ease.quadIn).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160,-580.6,1943.5,1741.1999999999998);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logoc();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(32.85,1.1,1,1,0,0,0,170.6,-129.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-30.6,-6.4,127.80000000000001,15), null);


(lib.laptop_shadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow_sub.cache(0,0,390,390,.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow_sub = new lib.laptop_shadow_2_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(194.5,194.5,1,1,0,0,0,194.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_shadow_2, new cjs.Rectangle(0,0,389,389), null);


(lib.laptop_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// Layer_11
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C1C1C").s().p("A1XMBIgl4BMAr5AAAIglYBg");
	this.shape.setTransform(278.9543,-81.5948,1,0.9751);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CDCDCD").s().p("A1XMmIgU5LMArXAAAIgUZLg");
	this.shape_1.setTransform(278.9543,-85.2271,1,0.9751);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DBDBDB").s().p("A1XNDIgP6FMArNAAAIgPaFg");
	this.shape_2.setTransform(278.9543,-88.0792,1,0.9751);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E5E5E5").s().p("A1XNaIgK6zMArDAAAIgKazg");
	this.shape_3.setTransform(278.9543,-90.322,1,0.9751);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EEEEEE").s().p("A1XNsIgI7XMAq/AAAIgIbXg");
	this.shape_4.setTransform(278.9543,-92.0284,1,0.9751);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F4F4F4").s().p("A1XN5IgF7xMAq5AAAIgFbxg");
	this.shape_5.setTransform(278.9543,-93.296,1,0.9751);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F8F8F8").s().p("A1XOCIgD8DMAq1AAAIgDcDg");
	this.shape_6.setTransform(278.9543,-94.198,1,0.9751);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FBFBFB").s().p("A1XOIIgC8QMAqzAAAIgCcQg");
	this.shape_7.setTransform(278.9543,-94.8318,1,0.9751);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FDFDFD").s().p("A1XOMIgB8YMAqxAAAIgBcYg");
	this.shape_8.setTransform(278.9543,-95.2218,1,0.9751);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(254,254,254,0.898)").s().p("A1XOPIgB8dMAqxAAAIgBcdg");
	this.shape_9.setTransform(278.9543,-95.49,1,0.9751);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.8)").s().p("A1XOQIAA8fMAqvAAAIAAcfg");
	this.shape_10.setTransform(278.9543,-95.6119,1,0.9751);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.6)").s().p("A1XORIAA8hMAqvAAAIAAchg");
	this.shape_11.setTransform(278.9543,-95.685,1,0.9751);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.298)").s().p("A1XN7IAA71MAqvAAAIAAb1g");
	this.shape_12.setTransform(278.95,-95.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},20).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[]},1).wait(47));

	// Layer_10 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_28 = new cjs.Graphics().p("AqRNeIAA71MAqwAAAIAAb1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(28).to({graphics:mask_graphics_28,x:207.9032,y:-91.9962}).wait(52));

	// Layer_9
	this.instance = new lib.MainScreen();
	this.instance.parent = this;
	this.instance.setTransform(142.4,-187.6,0.9144,1.0325,0,0,0,0.7,-0.8);
	this.instance.alpha = 0;

	this.Screen = new lib.MainScreen();
	this.Screen.name = "Screen";
	this.Screen.parent = this;
	this.Screen.setTransform(142.4,-183.7,0.9144,1.0325,0,0,0,0.7,-0.8);

	var maskedShapeInstanceList = [this.instance,this.Screen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.Screen}]},28).wait(52));

	// Layer_2
	this.instance_1 = new lib.Laptop_Main_00000();
	this.instance_1.parent = this;
	this.instance_1.setTransform(117,2);

	this.instance_2 = new lib.Laptop_Main_00001();
	this.instance_2.parent = this;
	this.instance_2.setTransform(117,0.75);

	this.instance_3 = new lib.Laptop_Main_00002();
	this.instance_3.parent = this;
	this.instance_3.setTransform(117,0.75);

	this.instance_4 = new lib.Laptop_Main_00003();
	this.instance_4.parent = this;
	this.instance_4.setTransform(117.5,0);

	this.instance_5 = new lib.Laptop_Main_00004();
	this.instance_5.parent = this;
	this.instance_5.setTransform(117,0);

	this.instance_6 = new lib.Laptop_Main_00005();
	this.instance_6.parent = this;
	this.instance_6.setTransform(117,-8.25);

	this.instance_7 = new lib.Laptop_Main_00006();
	this.instance_7.parent = this;
	this.instance_7.setTransform(117,-26);

	this.instance_8 = new lib.Laptop_Main_00007();
	this.instance_8.parent = this;
	this.instance_8.setTransform(118,-46.25);

	this.instance_9 = new lib.Laptop_Main_00008();
	this.instance_9.parent = this;
	this.instance_9.setTransform(118.55,-67.3);

	this.instance_10 = new lib.Laptop_Main_00009();
	this.instance_10.parent = this;
	this.instance_10.setTransform(119.5,-89.3);

	this.instance_11 = new lib.Laptop_Main_00010();
	this.instance_11.parent = this;
	this.instance_11.setTransform(120.3,-110.3);

	this.instance_12 = new lib.Laptop_Main_00011();
	this.instance_12.parent = this;
	this.instance_12.setTransform(121.75,-129.3);

	this.instance_13 = new lib.Laptop_Main_00012();
	this.instance_13.parent = this;
	this.instance_13.setTransform(123.8,-145.3);

	this.instance_14 = new lib.Laptop_Main_00013();
	this.instance_14.parent = this;
	this.instance_14.setTransform(124.8,-158.3);

	this.instance_15 = new lib.Laptop_Main_00014();
	this.instance_15.parent = this;
	this.instance_15.setTransform(125.8,-168.3);

	this.instance_16 = new lib.Laptop_Main_00015();
	this.instance_16.parent = this;
	this.instance_16.setTransform(126.8,-176.3);

	this.instance_17 = new lib.Laptop_Main_00016();
	this.instance_17.parent = this;
	this.instance_17.setTransform(128.05,-182.3);

	this.instance_18 = new lib.Laptop_Main_00017();
	this.instance_18.parent = this;
	this.instance_18.setTransform(129.1,-187.35);

	this.instance_19 = new lib.Laptop_Main_00018();
	this.instance_19.parent = this;
	this.instance_19.setTransform(130.05,-190.3);

	this.instance_20 = new lib.Laptop_Main_00019();
	this.instance_20.parent = this;
	this.instance_20.setTransform(131.1,-192.3);

	this.instance_21 = new lib.Laptop_Main_00020();
	this.instance_21.parent = this;
	this.instance_21.setTransform(132.3,-194.3);

	this.instance_22 = new lib.Laptop_Main_00022();
	this.instance_22.parent = this;
	this.instance_22.setTransform(133.3,-196.35);

	this.instance_23 = new lib.Laptop_Main_00024();
	this.instance_23.parent = this;
	this.instance_23.setTransform(134.3,-196.3);

	this.instance_24 = new lib.Laptop_Main_00026();
	this.instance_24.parent = this;
	this.instance_24.setTransform(134.3,-197.3);

	this.instance_25 = new lib.Laptop_Main_00028();
	this.instance_25.parent = this;
	this.instance_25.setTransform(134.3,-197.3);

	this.instance_26 = new lib.Laptop_Main_00030();
	this.instance_26.parent = this;
	this.instance_26.setTransform(134.3,-197.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},6).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},2).to({state:[{t:this.instance_25}]},2).to({state:[{t:this.instance_26}]},2).wait(45));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A5HCbICqk1MAsxAAAIC0E1g");
	mask_1.setTransform(278.8,23.025);

	// Layer_5
	this.instance_27 = new lib.shadow();
	this.instance_27.parent = this;
	this.instance_27.setTransform(278.8,68.7,1,0.76,0,0,0,162.8,77.3);
	this.instance_27.alpha = 0.3984;
	this.instance_27._off = true;

	var maskedShapeInstanceList = [this.instance_27];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(6).to({_off:false},0).to({scaleY:1,y:34.25,alpha:0.1484},24,cjs.Ease.cubicInOut).wait(50));

	// Layer_1
	this.instance_28 = new lib.Laptop_Base();
	this.instance_28.parent = this;
	this.instance_28.setTransform(117,8.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(80));

	// Layer_6
	this.tile_sub = new lib.laptop_shadow_1();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.parent = this;
	this.tile_sub.setTransform(42,-89.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(80));

	// Layer_8
	this.instance_29 = new lib.laptop_shadow_2();
	this.instance_29.parent = this;
	this.instance_29.setTransform(187.4,9.3,0.3625,0.0329,0,0,0,194.7,194.6);
	this.instance_29.alpha = 0.3984;
	this.instance_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(6).to({_off:false},0).wait(1).to({regX:194.5,regY:194.5,scaleX:0.3632,scaleY:0.0333,x:187.2,y:9.2,alpha:0.3976},0).wait(1).to({scaleX:0.3654,scaleY:0.0346,x:186.75,y:8.95,alpha:0.3949},0).wait(1).to({scaleX:0.3693,scaleY:0.0368,x:186,y:8.5,alpha:0.3903},0).wait(1).to({scaleX:0.3749,scaleY:0.04,x:184.85,y:7.9,alpha:0.3837},0).wait(1).to({scaleX:0.3824,scaleY:0.0443,x:183.45,y:7.1,alpha:0.3749},0).wait(1).to({scaleX:0.3915,scaleY:0.0495,x:181.7,y:6.1,alpha:0.3641},0).wait(1).to({scaleX:0.4022,scaleY:0.0557,x:179.6,y:4.9,alpha:0.3514},0).wait(1).to({scaleX:0.4142,scaleY:0.0625,x:177.25,y:3.55,alpha:0.3372},0).wait(1).to({scaleX:0.427,scaleY:0.0699,x:174.75,y:2.15,alpha:0.3221},0).wait(1).to({scaleX:0.4401,scaleY:0.0774,x:172.2,y:0.65,alpha:0.3065},0).wait(1).to({scaleX:0.4531,scaleY:0.0848,x:169.7,y:-0.8,alpha:0.2912},0).wait(1).to({scaleX:0.4654,scaleY:0.0918,x:167.3,y:-2.2,alpha:0.2766},0).wait(1).to({scaleX:0.4768,scaleY:0.0984,x:165.1,y:-3.45,alpha:0.2631},0).wait(1).to({scaleX:0.4872,scaleY:0.1043,x:163.05,y:-4.6,alpha:0.2509},0).wait(1).to({scaleX:0.4963,scaleY:0.1095,x:161.3,y:-5.65,alpha:0.24},0).wait(1).to({scaleX:0.5043,scaleY:0.1141,x:159.75,y:-6.5,alpha:0.2306},0).wait(1).to({scaleX:0.5111,scaleY:0.118,x:158.45,y:-7.25,alpha:0.2226},0).wait(1).to({scaleX:0.5167,scaleY:0.1212,x:157.35,y:-7.95,alpha:0.2159},0).wait(1).to({scaleX:0.5213,scaleY:0.1238,x:156.45,y:-8.4,alpha:0.2105},0).wait(1).to({scaleX:0.5249,scaleY:0.1259,x:155.75,y:-8.8,alpha:0.2062},0).wait(1).to({scaleX:0.5276,scaleY:0.1274,x:155.2,y:-9.1,alpha:0.2031},0).wait(1).to({scaleX:0.5294,scaleY:0.1285,x:154.85,y:-9.3,alpha:0.2009},0).wait(1).to({scaleX:0.5305,scaleY:0.1291,x:154.7,y:-9.45,alpha:0.1996},0).wait(1).to({regX:194.7,regY:193.4,scaleX:0.5308,scaleY:0.1293,y:-9.5,alpha:0.1992},0).wait(50));

	// Layer_7
	this.instance_30 = new lib.wide_shadow();
	this.instance_30.parent = this;
	this.instance_30.setTransform(267.2,45.5,2.2,0.3,0,0,0,194.6,194.2);
	this.instance_30.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).to({alpha:1},15).wait(65));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160.9,-197.3,855.9,301.3);


(lib.icon_teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x1500();
	this.instance.parent = this;
	this.instance.setTransform(29.75,34.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.parent = this;
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.parent = this;
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-11.95,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#108675").s().p("Ap2CjIAAlFITtAAIAAFFg");
	this.shape.setTransform(-38.025,-1.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-101.1,-17.5,126.19999999999999,32.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(43.85,194,0.3479,0.3479);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(66.2,34.15,1.1275,1.1275,0,0,0,0.4,0.8);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(224.3,555.45,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(277.4,556,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.parent = this;
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// phone
	this.phone = new lib.Phone();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(83.55,418.65,1,1,0,0,0,36.3,66.8);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

	// laptop
	this.laptop = new lib.laptop_anim();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(229.05,452.15,1,0.88,0,0,0,284,24.7);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";
	this.txt.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-215.8,-8,855.8,605.7), null);


// stage content:
(lib.O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var laptop = mc.laptop
		var phone = mc.phone
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
			
		var stage3D = new depthjs.Stage3D();
		stage.addChild(stage3D);
		
		var cont3D = new depthjs.Container3D();
		var logo_mc = new lib.logo_mc();
		cont3D.x = 210;
		cont3D.y = 238;
		cont3D.addChild(logo_mc);
		
		stage3D.addChild(cont3D);
		
		var s = new createjs.Shape().set({y:0,x:0});
		s.graphics.f("blue").dr(0,0,250,50);
		s.x = 40; s.y=285
		s.alpha=0
			stage.addChild(s);
		
			exportRoot.mainMC.txt.getChildAt(11).mask = s
			exportRoot.mainMC.txt.getChildAt(12).mask = s
		
			this.tl1 = new TimelineLite();
					
		
		
				//Launch				headline1
				exportRoot.tl1.from(exportRoot.headline1, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "+=0.5");
				exportRoot.tl1.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.2");
		
				//your 					headline2
				exportRoot.tl1.from(exportRoot.headline2, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.2");
		
				//own 					headline3
				exportRoot.tl1.from(exportRoot.headline3, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.4");
				
			
				
				
				//easy					headline4
				exportRoot.tl1.from(exportRoot.headline4, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.1");
				
				//easy-to				headline5
				exportRoot.tl1.from(exportRoot.headline5, 0.1, { x:"+=7", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.1");
		
				//easy-to-use,			headline6
				exportRoot.tl1.from(exportRoot.headline6, 0.1, { x:"+=7", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
		
				
				
				
				//easy					headline7
				exportRoot.tl1.from(exportRoot.headline7, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.1");
				
				//easy-to				headline8
				exportRoot.tl1.from(exportRoot.headline8, 0.1, { x:"+=7", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline8, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.1");
		
				//easy-to-manage 		headline9
				exportRoot.tl1.from(exportRoot.headline9, 0.1, { x:"+=7", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
				
			
				
				//customer				headline10
				exportRoot.tl1.from(exportRoot.headline10, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline10, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.1");
				
				//customer-facing 		headline11
				exportRoot.tl1.from(exportRoot.headline11, 0.1, { x:"+=7", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline11, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
				
				
				
				//Bookings				headline12
				exportRoot.tl1.from(exportRoot.headline12, 0.1, { x:"+=5", y:"-=2.5",scaleX:.85, scaleY:.85, alpha: 0, ease:Back.easeOut}, "-=0.02");
		
				
				//site​			headline13
				exportRoot.tl1.from(exportRoot.headline13, 0.1, { x:"+=7", y:"-=2.5",scaleX:.75, scaleY:.75, alpha: 0, ease:Back.easeOut}, "-=0.02");
				//exportRoot.tl1.to(exportRoot.headline13, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.1");
				
				
		
				
		
				//exportRoot.tl1.from(cont3D, 2, {x:"+=150", ease:Power4.easeOut});
				exportRoot.tl1.from(cont3D, 1.6, {rotY: "+=60",x:"+=150", ease:Power4.easeInOut}, "+=0.4");
				exportRoot.tl1.to(s, 1.6, {x: "-=100", ease:Power4.easeInOut}, "-=1.6");
				exportRoot.tl1.to(exportRoot.headline12, 1.6, {x: "+=150", ease:Power4.easeInOut}, "-=1.6");
				exportRoot.tl1.to(exportRoot.headline13, 1.6, {x: "+=150", ease:Power4.easeInOut}, "-=1.6");
		
				exportRoot.tl1.to(cont3D, 1, {x:130, y:"+=30", z:-600, ease:Power4.easeInOut}, "+=0.5");
		
		
		
				exportRoot.tl1.from(phone, 1.2, {x: "+=300", ease:Power3.easeOut}, "-=1");
				exportRoot.tl1.from(laptop, 1.2, {x: "+=300", ease:Power4.easeOut, onStart:function(){laptop.play();}}, "-=1.2");
		
				
				for (var i = 0; i < exportRoot.headline14.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline14[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=1");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline14[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline15.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline15[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline15[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
		
		
				
		
			
			
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=150",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=150", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
				
				
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.8,292,705.8,305.70000000000005);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574945572181", id:"O365_SMBSimplified_USA_300x600_BAN_Bookings_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;