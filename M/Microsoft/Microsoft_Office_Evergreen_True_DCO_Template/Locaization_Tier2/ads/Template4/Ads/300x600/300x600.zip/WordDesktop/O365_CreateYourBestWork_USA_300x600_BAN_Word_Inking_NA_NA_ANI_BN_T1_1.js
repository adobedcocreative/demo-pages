(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_", frames: [[701,123,93,13],[402,291,377,42],[402,335,377,16],[679,61,100,29],[679,92,100,29],[679,0,153,59],[679,123,20,126],[402,0,275,289],[0,0,400,358]]}
];


// symbols:



(lib.highlighted = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.menu = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.menu_btm = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.menu_pens_red = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.menu_pens_yellow = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.penmoveshadow = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.PenPurple = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.screen2 = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.SurfacePro11 = function() {
	this.spriteSheet = ss["O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.scroll_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.screen2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.scroll_screen, new cjs.Rectangle(0,0,275,289), null);


(lib.ring = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1.5,1,1).p("AgQAMQAAABALgKQAKgHAMgH");
	this.shape.setTransform(14.4,5.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(1.8,1,1).p("AighOQAKgGACgBQAygVBegIQBqgKBdAUQBgAVAVAmQAcAxgyAkQg5AoiXAWQiEAThfgDQhrgEgrgfQghgYAJggQAHgZAfgZQAdgXAygTQAWgIAUgFg");
	this.shape_1.setTransform(32.2,11.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ring, new cjs.Rectangle(-1,-1,66.4,25.7), null);


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.3,0.1,0.877,0.877,135,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.pen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.PenPurple();
	this.instance.parent = this;
	this.instance.setTransform(47.1,25.1,1.669,1.669,-13.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pen, new cjs.Rectangle(0,0,150.9,261.6), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.8,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3,2.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.5,2.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1,2.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.1,2.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.3,-5.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.3,2.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.5,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.2,0,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.3,8.4), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.cta, null, null);


(lib.moveshadeopac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.penmoveshadow();
	this.instance.parent = this;
	this.instance.setTransform(0,53.5,1,0.751,-20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.moveshadeopac, new cjs.Rectangle(0,0,158.9,95), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.7,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6,-5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.7,-5.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.6), null);


(lib.highlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.highlighted();
	this.instance.parent = this;
	this.instance.setTransform(0,1.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.highlight, new cjs.Rectangle(0,1.3,93,13), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.4,15.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.4,15.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.circle_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.circle_bg, null, null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6,4.2,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.6,16.6,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,2.8,32.2,27.7);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.1,0.1,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.2},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.4},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1},0).wait(1).to({x:-0.9},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.1},0).wait(1).to({x:0.3},0).wait(1).to({x:0.5},0).wait(1).to({x:0.6},0).wait(2).to({x:0.4},0).wait(1).to({x:0.3},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(3).to({x:0.1},0).wait(2).to({x:0.2},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.2,0.1,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.1},8,cjs.Ease.get(1)).wait(2).to({x:19.9},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.4,-4.1,11.3,8.4);


(lib.moveshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.moveshadeopac();
	this.instance.parent = this;
	this.instance.setTransform(67.3,13.8,1,1,0,0,0,79.4,47.5);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.moveshadow, new cjs.Rectangle(-12.1,-33.7,158.9,95), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34,-5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3,-5.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.6), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.5,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(13.7,1.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.4,7.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.7,7.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.4,-4.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.7,-4.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_Logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.3,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play()
	}
	this.frame_63 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(4).call(this.frame_63).wait(40));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(297.9,898.1,0.357,0.357,0,0,0,-39.8,1.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.9,scaleY:5.9,x:298,y:897.7},13,cjs.Ease.quadOut).to({x:63.6},12,cjs.Ease.quadInOut).to({_off:true},1).wait(76));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgImBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_15 = new cjs.Graphics().p("EgKIBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_16 = new cjs.Graphics().p("EgLrBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_17 = new cjs.Graphics().p("EgNNBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_18 = new cjs.Graphics().p("EgOvBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_19 = new cjs.Graphics().p("EgQRBLKIAAz6MBK/AAAIAAT6g");
	var mask_graphics_20 = new cjs.Graphics().p("EgR0BLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_21 = new cjs.Graphics().p("EgTWBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_22 = new cjs.Graphics().p("EgU4BLKIAAz6MBK/AAAIAAT6g");
	var mask_graphics_23 = new cjs.Graphics().p("EgWbBLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_24 = new cjs.Graphics().p("EgX9BLKIAAz6MBLAAAAIAAT6g");
	var mask_graphics_25 = new cjs.Graphics().p("EgZfBLKIAAz6MBK/AAAIAAT6g");
	var mask_graphics_26 = new cjs.Graphics().p("EgbCBLKIAAz6MBLAAAAIAAT6g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:425,y:481}).wait(1).to({graphics:mask_graphics_15,x:415.2,y:481}).wait(1).to({graphics:mask_graphics_16,x:405.3,y:481}).wait(1).to({graphics:mask_graphics_17,x:395.5,y:481}).wait(1).to({graphics:mask_graphics_18,x:385.7,y:481}).wait(1).to({graphics:mask_graphics_19,x:375.8,y:481}).wait(1).to({graphics:mask_graphics_20,x:366,y:481}).wait(1).to({graphics:mask_graphics_21,x:356.2,y:481}).wait(1).to({graphics:mask_graphics_22,x:346.3,y:481}).wait(1).to({graphics:mask_graphics_23,x:336.5,y:481}).wait(1).to({graphics:mask_graphics_24,x:326.7,y:481}).wait(1).to({graphics:mask_graphics_25,x:316.8,y:481}).wait(1).to({graphics:mask_graphics_26,x:307,y:481}).wait(1).to({graphics:null,x:0,y:0}).wait(76));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(64.5,890.7,5.904,5.904,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.4,890.7,5.904,5.904,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_1}]},22).to({state:[]},1).wait(39));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:300.4},12,cjs.Ease.quadInOut).wait(13).to({_off:false},0).wait(2).to({regY:0.1,scaleX:2.51,scaleY:2.51,x:44.6,y:62},22,cjs.Ease.quadInOut).to({_off:true},1).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.device_animation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_85 = function() {
		TweenLite.to(exportRoot.mainMC.anim.devices, 1.2, {x: "+=64", y: "-=6", scaleX: 0.92, scaleY: 0.92,	ease: Power4.easeInOut}, "-=0");
	}
	this.frame_290 = function() {
		TweenLite.to(exportRoot.mainMC.anim.devices, 1.2, {x: "-=28", y: "+=35", scaleX: 0.79, scaleY: 0.79,	ease: Power3.easeInOut}, "-=0");
	}
	this.frame_313 = function() {
		exportRoot.tl2.play()
		exportRoot.finalHeadline.play()
	}
	this.frame_322 = function() {
		exportRoot.subHeadline.play()
	}
	this.frame_324 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(85).call(this.frame_85).wait(205).call(this.frame_290).wait(23).call(this.frame_313).wait(9).call(this.frame_322).wait(2).call(this.frame_324).wait(1));

	// Pen
	this.pen = new lib.pen();
	this.pen.name = "pen";
	this.pen.parent = this;
	this.pen.setTransform(606.1,425.3,1,1,79,0,0,107.8,198.3);
	this.pen._off = true;

	this.timeline.addTween(cjs.Tween.get(this.pen).wait(11).to({_off:false},0).wait(1).to({regX:88,regY:123.4,rotation:78.7,x:673.5,y:390.2},0).wait(1).to({rotation:78.3,x:670.4,y:388.4},0).wait(1).to({rotation:77.9,x:666.3,y:386.1},0).wait(1).to({rotation:77.3,x:661.5,y:383.2},0).wait(1).to({rotation:76.6,x:655.6,y:379.9},0).wait(1).to({rotation:75.8,x:648.8,y:375.9},0).wait(1).to({rotation:74.8,x:640.9,y:371.5},0).wait(1).to({rotation:73.8,x:632,y:366.4},0).wait(1).to({rotation:72.6,x:622,y:360.7},0).wait(1).to({rotation:71.3,x:610.9,y:354.5},0).wait(1).to({rotation:69.8,x:598.7,y:347.7},0).wait(1).to({rotation:68.3,x:585.5,y:340.4},0).wait(1).to({rotation:66.6,x:571.3,y:332.6},0).wait(1).to({rotation:64.9,x:556.2,y:324.4},0).wait(1).to({rotation:63,x:540.4,y:315.9},0).wait(1).to({rotation:61.1,x:524.1,y:307.1},0).wait(1).to({rotation:59.2,x:507.2,y:298.3},0).wait(1).to({rotation:57.3,x:490.3,y:289.4},0).wait(1).to({rotation:55.3,x:473.3,y:280.7},0).wait(1).to({rotation:53.4,x:456.7,y:272.1},0).wait(1).to({rotation:51.6,x:440.5,y:264},0).wait(1).to({rotation:49.8,x:425,y:256.3},0).wait(1).to({rotation:48.2,x:410.3,y:248.9},0).wait(1).to({rotation:46.6,x:396.4,y:242.2},0).wait(1).to({rotation:45.2,x:383.5,y:235.9},0).wait(1).to({rotation:43.8,x:371.6,y:230.2},0).wait(1).to({rotation:42.6,x:360.8,y:225},0).wait(1).to({rotation:41.5,x:351,y:220.4},0).wait(1).to({rotation:40.5,x:342.3,y:216.3},0).wait(1).to({rotation:39.7,x:334.6,y:212.7},0).wait(1).to({rotation:38.9,x:327.9,y:209.5},0).wait(1).to({rotation:38.3,x:322.1,y:206.8},0).wait(1).to({rotation:37.7,x:317.2,y:204.5},0).wait(1).to({rotation:37.3,x:313.1,y:202.7},0).wait(1).to({regX:107.7,regY:198.4,rotation:36.9,x:280.8,y:273},0).wait(15).to({regX:107.9,rotation:24.2,x:366.5,y:273.1},20,cjs.Ease.quadInOut).wait(11).to({y:272.8},0).wait(1).to({regX:88,regY:123.4,rotation:24.5,x:377,y:194.2},0).wait(1).to({rotation:25,x:374,y:191.3},0).wait(1).to({rotation:25.7,x:370.1,y:187.5},0).wait(1).to({rotation:26.6,x:365.1,y:182.8},0).wait(1).to({rotation:27.6,x:358.9,y:176.9},0).wait(1).to({rotation:28.9,x:351.6,y:170},0).wait(1).to({rotation:30.4,x:343,y:161.9},0).wait(1).to({rotation:32.1,x:333.2,y:152.8},0).wait(1).to({rotation:33.9,x:322.3,y:142.8},0).wait(1).to({rotation:35.9,x:310.6,y:132.1},0).wait(1).to({rotation:38.1,x:298.2,y:120.9},0).wait(1).to({rotation:40.2,x:285.8,y:109.7},0).wait(1).to({rotation:42.3,x:273.5,y:99},0).wait(1).to({rotation:44.2,x:262,y:88.9},0).wait(1).to({rotation:46,x:251.4,y:79.8},0).wait(1).to({rotation:47.5,x:242,y:71.9},0).wait(1).to({rotation:48.9,x:234,y:65.2},0).wait(1).to({rotation:50,x:227.5,y:59.6},0).wait(1).to({rotation:50.9,x:222.2,y:55.2},0).wait(1).to({rotation:51.5,x:218.1,y:51.9},0).wait(1).to({regX:107.9,regY:198.4,rotation:52,x:168.5,y:111.3},0).wait(14).to({regX:107.8,regY:198.3,x:168.4,y:111.2},0).to({regX:107.9,scaleX:1,scaleY:1,rotation:51,x:168.5,y:114.3},3).to({scaleX:1,scaleY:1,rotation:55,x:169.8,y:110.3},2).to({rotation:52,x:169.4,y:111.3},5).wait(36).to({regX:107.8,y:111.2},0).wait(1).to({regX:88,regY:123.4,rotation:51.7,x:216,y:50.7},0).wait(1).to({rotation:51.4,x:215.7,y:52.2},0).wait(1).to({rotation:50.9,x:215.3,y:54.1},0).wait(1).to({rotation:50.3,x:214.9,y:56.6},0).wait(1).to({rotation:49.6,x:214.3,y:59.6},0).wait(1).to({rotation:48.8,x:213.6,y:63.1},0).wait(1).to({rotation:47.8,x:212.8,y:67.2},0).wait(1).to({rotation:46.7,x:211.9,y:72},0).wait(1).to({rotation:45.4,x:210.9,y:77.3},0).wait(1).to({rotation:44.1,x:209.7,y:83.2},0).wait(1).to({rotation:42.6,x:208.4,y:89.6},0).wait(1).to({rotation:41,x:207,y:96.5},0).wait(1).to({rotation:39.4,x:205.5,y:103.6},0).wait(1).to({rotation:37.8,x:204,y:110.9},0).wait(1).to({rotation:36.1,x:202.5,y:118.2},0).wait(1).to({rotation:34.6,x:201,y:125.2},0).wait(1).to({rotation:33.1,x:199.6,y:131.9},0).wait(1).to({rotation:31.8,x:198.3,y:138},0).wait(1).to({rotation:30.6,x:197.1,y:143.4},0).wait(1).to({rotation:29.5,x:196,y:148.3},0).wait(1).to({rotation:28.6,x:195.1,y:152.4},0).wait(1).to({rotation:27.9,x:194.3,y:156},0).wait(1).to({rotation:27.3,x:193.7,y:158.8},0).wait(1).to({rotation:26.8,x:193.3,y:161.1},0).wait(1).to({regX:107.9,regY:198.3,rotation:26.4,x:177.3,y:238.6},0).wait(11).to({x:177.7,y:239.2},0).wait(1).to({regX:88,regY:123.4,x:194.8,y:162.8},0).wait(1).to({x:196.4,y:162.3},0).wait(1).to({scaleX:1,scaleY:1,x:198.3,y:161.8},0).wait(1).to({x:200.3,y:161.3},0).wait(1).to({x:202.6,y:160.7},0).wait(1).to({x:205,y:160},0).wait(1).to({regX:108,regY:198.3,rotation:26.3,x:192.3,y:235.2},0).wait(1).to({regX:88,regY:123.4,scaleX:1,scaleY:1,rotation:27.5,x:212.4,y:159.9},0).wait(1).to({rotation:28.7,x:217.5,y:160.6},0).wait(1).to({rotation:30.1,x:223.1,y:161.4},0).wait(1).to({rotation:31.5,x:228.9,y:162.2},0).wait(1).to({rotation:33,x:235.1,y:163.3},0).wait(1).to({rotation:34.6,x:241.6,y:164.3},0).wait(1).to({rotation:36.2,x:248.5,y:165.6},0).wait(1).to({regX:108.1,regY:198.3,scaleX:1,scaleY:1,rotation:38,x:225.4,y:238},0).wait(1).to({regX:88,regY:123.4,scaleX:1,scaleY:1,rotation:44,x:268.6,y:175.6},0).wait(1).to({regX:108.2,regY:198.3,scaleX:1,scaleY:1,rotation:50.4,x:237.3,y:248.6},0).to({scaleX:1,scaleY:1,rotation:57,x:235.2,y:255.4},1).wait(1).to({regX:88,regY:123.4,scaleX:1,scaleY:1,rotation:59.9,x:276.4,y:204.1},0).wait(1).to({regX:108.3,regY:198.3,rotation:63,x:208.2,y:262.5},0).wait(1).to({regX:88,regY:123.4,scaleX:0.99,scaleY:0.99,rotation:59.9,x:256.4,y:207.3},0).wait(1).to({rotation:56.8,x:247,y:203.8},0).wait(1).to({rotation:53.4,x:237.1,y:200.4},0).wait(1).to({regX:108.4,regY:198.3,scaleX:0.99,scaleY:0.99,rotation:50,x:182.5,y:260.4},0).wait(1).to({regX:88,regY:123.4,rotation:48.1,x:220.7,y:193.6},0).wait(1).to({rotation:46.1,x:214.6,y:190.2},0).wait(1).to({regX:108.5,regY:198.2,rotation:44,x:171.2,y:254.2},0).wait(1).to({regX:88,regY:123.4,rotation:40.3,x:204.7,y:180.3},0).wait(1).to({regX:108.5,regY:198.3,scaleX:0.99,scaleY:0.99,rotation:36.1,x:173.3,y:245.6},0).wait(1).to({regX:88,regY:123.4,scaleX:1,scaleY:1,rotation:34.3,x:200.3,y:171.1},0).wait(1).to({scaleX:1,scaleY:1,rotation:32.4,x:200,y:168.8},0).wait(1).to({scaleX:1,scaleY:1,rotation:30.5,x:199.5,y:166.5},0).wait(1).to({scaleX:1,scaleY:1,rotation:28.5,x:199,y:164.3},0).wait(1).to({regX:107.9,regY:198.3,scaleX:1,scaleY:1,rotation:26.4,x:183.6,y:238.2},0).wait(1).to({x:185.6},0).wait(10).to({x:184.8},0).to({regX:108,rotation:88,x:572.1,y:157.5},26,cjs.Ease.quadIn).to({_off:true},1).wait(44));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A1bbbMAAAgnOMA6yAAAMAAAAnOg");
	var mask_graphics_140 = new cjs.Graphics().p("A9ZTiMAAAgnCMA6yAAAMAAAAnCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:239.1,y:175.5}).wait(140).to({graphics:mask_graphics_140,x:290.1,y:226.1}).wait(185));

	// MoveShadow
	this.instance = new lib.moveshadow();
	this.instance.parent = this;
	this.instance.setTransform(609.8,454.7,0.826,0.624,0,0,0,15.3,48.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).wait(1).to({regX:67.3,regY:13.8,x:646,y:427.7,alpha:0.013},0).wait(1).to({x:639.1,y:422.1,alpha:0.026},0).wait(1).to({x:632.1,y:416.4,alpha:0.04},0).wait(1).to({x:624.8,y:410.5,alpha:0.054},0).wait(1).to({x:617.4,y:404.4,alpha:0.069},0).wait(1).to({x:609.8,y:398.3,alpha:0.083},0).wait(1).to({x:602,y:391.9,alpha:0.098},0).wait(1).to({x:594.1,y:385.5,alpha:0.114},0).wait(1).to({x:586,y:378.9,alpha:0.13},0).wait(1).to({x:577.8,y:372.2,alpha:0.146},0).wait(1).to({x:569.4,y:365.4,alpha:0.162},0).wait(1).to({x:560.8,y:358.5,alpha:0.178},0).wait(1).to({x:552.2,y:351.5,alpha:0.195},0).wait(1).to({x:543.4,y:344.3,alpha:0.212},0).wait(1).to({x:534.5,y:337.1,alpha:0.23},0).wait(1).to({x:525.4,y:329.7,alpha:0.247},0).wait(1).to({x:516.3,y:322.3,alpha:0.265},0).wait(1).to({x:507.1,y:314.8,alpha:0.283},0).wait(1).to({regX:15.5,regY:48.3,x:454.9,y:328.8,alpha:0.301},0).wait(1).to({regX:67.3,regY:13.8,x:480.9,y:303.7},0).wait(1).to({x:463.8,y:300},0).wait(1).to({x:446.9,y:296.4},0).wait(1).to({x:430.4,y:292.9},0).wait(1).to({x:414.6,y:289.5},0).wait(1).to({x:399.7,y:286.4},0).wait(1).to({x:385.9,y:283.4},0).wait(1).to({x:373.4,y:280.7},0).wait(1).to({x:362,y:278.3},0).wait(1).to({x:352,y:276.2},0).wait(1).to({x:343.2,y:274.3},0).wait(1).to({x:335.7,y:272.7},0).wait(1).to({x:329.3,y:271.4},0).wait(1).to({x:324,y:270.2},0).wait(1).to({x:319.8,y:269.3},0).wait(1).to({regX:15.3,regY:48.1,x:273.8,y:290.2},0).wait(16).to({regX:67.3,regY:13.8,x:318.4,y:268.8},0).wait(1).to({x:320.6},0).wait(1).to({x:323.4,y:268.9},0).wait(1).to({x:326.8},0).wait(1).to({x:330.8,y:269},0).wait(1).to({x:335.5,y:269.1},0).wait(1).to({x:340.8,y:269.2},0).wait(1).to({x:346.7,y:269.3},0).wait(1).to({x:353.1,y:269.4},0).wait(1).to({x:359.7,y:269.5},0).wait(1).to({x:366.4,y:269.6},0).wait(1).to({x:373.1,y:269.7},0).wait(1).to({x:379.3,y:269.8},0).wait(1).to({x:385.1,y:269.9},0).wait(1).to({x:390.3,y:270},0).wait(1).to({x:394.8,y:270.1},0).wait(1).to({x:398.6,y:270.2},0).wait(1).to({x:401.7},0).wait(1).to({x:404.2,y:270.3},0).wait(1).to({regX:15.3,regY:48.1,x:363.1,y:291.7},0).wait(12).to({regX:67.3,regY:13.8,x:402.5,y:269.4},0).wait(1).to({x:397.3,y:268.2},0).wait(1).to({x:390.4,y:266.5},0).wait(1).to({x:381.7,y:264.4},0).wait(1).to({x:371,y:261.9},0).wait(1).to({x:358.2,y:258.8},0).wait(1).to({x:343.2,y:255.2},0).wait(1).to({x:326.3,y:251.1},0).wait(1).to({x:307.4,y:246.6},0).wait(1).to({regX:15.3,regY:48.3,x:244.1,y:263.2},0).wait(1).to({regX:67.3,regY:13.8,x:275.7,y:223.8},0).wait(1).to({x:264.2,y:205.9},0).wait(1).to({x:253,y:188.4},0).wait(1).to({x:242.4,y:171.9},0).wait(1).to({x:232.8,y:157},0).wait(1).to({x:224.4,y:143.8},0).wait(1).to({x:217.1,y:132.5},0).wait(1).to({x:211.2,y:123.2},0).wait(1).to({x:206.4,y:115.8},0).wait(1).to({x:202.8,y:110.2},0).wait(1).to({regX:15.3,regY:48.1,x:157.4,y:127.7},0).wait(60).to({x:164,y:128.2},0).wait(1).to({regX:67.3,regY:13.8,x:207.1,y:108.1},0).wait(1).to({x:207.3,y:109.9},0).wait(1).to({x:207.5,y:112.2},0).wait(1).to({x:207.8,y:115.1},0).wait(1).to({x:208.1,y:118.6},0).wait(1).to({x:208.5,y:122.8},0).wait(1).to({x:209,y:127.6},0).wait(1).to({x:209.6,y:133},0).wait(1).to({x:210.2,y:139.2},0).wait(1).to({x:210.9,y:145.9},0).wait(1).to({x:211.6,y:153.2},0).wait(1).to({x:212.4,y:161},0).wait(1).to({x:213.2,y:169},0).wait(1).to({x:214,y:177.1},0).wait(1).to({x:214.8,y:185.1},0).wait(1).to({x:215.5,y:192.8},0).wait(1).to({x:216.3,y:200},0).wait(1).to({x:216.9,y:206.6},0).wait(1).to({x:217.5,y:212.5},0).wait(1).to({x:218,y:217.7},0).wait(1).to({x:218.5,y:222.1},0).wait(1).to({x:218.8,y:225.8},0).wait(1).to({x:219.1,y:228.9},0).wait(1).to({x:219.4,y:231.2},0).wait(1).to({regX:15.3,regY:48.1,x:176.6,y:254.4},0).wait(11).to({x:172.2,y:258},0).wait(1).to({regX:67.3,regY:13.8,x:216.6,y:236.1},0).wait(1).to({x:218.3,y:235.5},0).wait(1).to({x:220.3,y:234.8},0).wait(1).to({x:222.6,y:234},0).wait(1).to({x:225.2,y:233},0).wait(1).to({x:228.2,y:232},0).wait(1).to({regX:15.3,regY:48.3,x:188.5,y:252.4},0).wait(1).to({regX:67.3,regY:13.8,x:234.2,y:231},0).wait(1).to({x:237.3,y:231.1},0).wait(1).to({x:240.6,y:231.3},0).wait(1).to({x:244.2,y:231.6},0).wait(1).to({x:248.1,y:231.8},0).wait(1).to({x:252.4,y:232},0).wait(1).to({x:256.9,y:232.3},0).wait(1).to({regX:15.5,regY:48.3,x:218.9,y:254.1},0).wait(1).to({regX:67.3,regY:13.8,x:266,y:236.6},0).wait(1).to({regX:15.5,regY:48.4,x:227.5,y:262.3},0).to({x:223.6,y:267.6},1).wait(1).to({regX:67.3,regY:13.8,x:252.9,y:249.5},0).wait(1).to({regX:15.6,regY:48.5,x:196.4,y:274.7},0).wait(1).to({regX:67.3,regY:13.8,x:233,y:252.9},0).wait(1).to({x:226.8,y:252.7},0).wait(1).to({x:220.4,y:252.6},0).wait(1).to({regX:15.6,regY:48.5,x:171.4,y:274.1},0).wait(1).to({regX:67.3,regY:13.8,x:211.2,y:250.5},0).wait(1).to({x:208.2,y:248.6},0).wait(1).to({regX:15.6,regY:48.5,x:162.6,y:268.3},0).wait(1).to({regX:67.3,regY:13.8,x:207.8,y:242.6},0).wait(1).to({regX:15.6,regY:48.5,x:167.9,y:260.1},0).wait(1).to({regX:67.3,regY:13.8,x:213.3,y:237.4},0).wait(1).to({x:216,y:236.3},0).wait(1).to({x:218.8,y:235.1},0).wait(1).to({x:221.6,y:234},0).wait(1).to({regX:15.3,regY:48.1,x:181.8,y:254.5},0).wait(1).to({x:182.6},0).wait(10).to({x:181.8},0).to({x:561.4,y:199.9},26,cjs.Ease.quadIn).to({_off:true},1).wait(44));

	// Ringmask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_209 = new cjs.Graphics().p("AgfgMIAPgEIAwAdIgPAFg");
	var mask_1_graphics_210 = new cjs.Graphics().p("AgogIIAkgNIAtAhIgiAKg");
	var mask_1_graphics_211 = new cjs.Graphics().p("AgygEIA6gVIArAkIg0APg");
	var mask_1_graphics_212 = new cjs.Graphics().p("Ag7AAIBQgdIAnAnIhIAUg");
	var mask_1_graphics_213 = new cjs.Graphics().p("AhFAEIBmglIAlAqIhbAZg");
	var mask_1_graphics_214 = new cjs.Graphics().p("AhOAIIB7gtIAiAtIhuAeg");
	var mask_1_graphics_215 = new cjs.Graphics().p("AhXAMICRg1IAeAwIiBAjg");
	var mask_1_graphics_216 = new cjs.Graphics().p("AhhAQICng9IAcAzIiVAog");
	var mask_1_graphics_217 = new cjs.Graphics().p("AhLAnIgigWIBTgdIBpggIARATIAMAXIACAIIAAACIinAlg");
	var mask_1_graphics_218 = new cjs.Graphics().p("AhUAqIglgYIBbggIB2gcIAEACIARANIANAaIAAAJIgBABIiXAYIgeAJIgDABg");
	var mask_1_graphics_219 = new cjs.Graphics().p("AiHASIBjgkICDgYIAEABIAXAKIAOAdIgDAKIgBABIinATIggAKIgEACIgXADg");
	var mask_1_graphics_220 = new cjs.Graphics().p("AiVARIBsgoICPgUIAGAAIAaAJIAQAfIgGALIgBAAIi2APIgjAMIgEACIgaAHg");
	var mask_1_graphics_221 = new cjs.Graphics().p("AiiAQIB0gqICigSIAfAHIAQAiIgHALIjIAKIglANIghAOg");
	var mask_1_graphics_222 = new cjs.Graphics().p("AiaAmIgkgVICAgwIAJgBIDAgKIAlAFIADACIAMAlIgDANIgBABIjsAAIgCAAIhRAbg");
	var mask_1_graphics_223 = new cjs.Graphics().p("AjaARICUg3IDogEIArADIAEACIAKAsIAAAQIkRgLIgDAAIheAcIgaADg");
	var mask_1_graphics_224 = new cjs.Graphics().p("Aj4AQICog9IE9AFIAMBGIk6gWIiJAmg");
	var mask_1_graphics_225 = new cjs.Graphics().p("AhkgBIiKAlIgugeIDVhMIFkBBIh2BMg");
	var mask_1_graphics_226 = new cjs.Graphics().p("AiNgUIiKAmIgugdIEChcIGJB7Ij3BUg");
	var mask_1_graphics_227 = new cjs.Graphics().p("Ai2gmIiKAmIgvgdIEvhrIGvC3Il3Bag");
	var mask_1_graphics_228 = new cjs.Graphics().p("AjAgvIiKAnIgugeIFChyIGvDOIlGBjg");
	var mask_1_graphics_229 = new cjs.Graphics().p("AhlCjIgageIhFi9IiGAlIgugeIFChyIGvDOImXB5g");
	var mask_1_graphics_230 = new cjs.Graphics().p("AiyCOIgSjGIiGAlIgugeIFChyIGvDOImTBxIiDAIg");
	var mask_1_graphics_231 = new cjs.Graphics().p("AjxCRIAsjMIiFAlIgugeIFChyIGvDOImYB0Ii+ALg");
	var mask_1_graphics_232 = new cjs.Graphics().p("AlCCRIB9jNIiFAmIgugeIFChyIGvDOImdB2IkJAJg");
	var mask_1_graphics_233 = new cjs.Graphics().p("AkxB8IB3i9IiAAnIgugeIFChxIGvDOImdB2Il0APg");
	var mask_1_graphics_234 = new cjs.Graphics().p("AmwCZICngpIB2iuIh/AmIgugeIFBhxIGwDOImnCBg");
	var mask_1_graphics_235 = new cjs.Graphics().p("AnDBmICmgqICaiZIh7AlIgvgeIFBhxIGwDOIo0DBg");
	var mask_1_graphics_236 = new cjs.Graphics().p("AnQBTICngqICuiGIh3AlIgugeIFBhxIGwDOIo0DBg");
	var mask_1_graphics_237 = new cjs.Graphics().p("AnjAJIC1gJIClhbIhWAWIgugeIFAhxIGxDPIqADag");
	var mask_1_graphics_238 = new cjs.Graphics().p("AnzgxID9AXIB9hBIhWAWIgugeIFBhxIGwDPIp/Dag");
	var mask_1_graphics_239 = new cjs.Graphics().p("AnriPIEJBnIBhgxIhWAWIgugeIFBhxIGwDPIrbDWg");
	var mask_1_graphics_240 = new cjs.Graphics().p("AnrAZIBRggIAiglIBCgeIg5gWIGqh0IGwDPIp/Dag");
	var mask_1_graphics_294 = new cjs.Graphics().p("AlAHMIiqqsIBQghIAigmIBDgeIg6gWILlhyIB1Obg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(209).to({graphics:mask_1_graphics_209,x:171,y:256.2}).wait(1).to({graphics:mask_1_graphics_210,x:171.9,y:255.7}).wait(1).to({graphics:mask_1_graphics_211,x:172.9,y:255.3}).wait(1).to({graphics:mask_1_graphics_212,x:173.8,y:254.9}).wait(1).to({graphics:mask_1_graphics_213,x:174.8,y:254.5}).wait(1).to({graphics:mask_1_graphics_214,x:175.7,y:254.1}).wait(1).to({graphics:mask_1_graphics_215,x:176.6,y:253.7}).wait(1).to({graphics:mask_1_graphics_216,x:177.6,y:253.2}).wait(1).to({graphics:mask_1_graphics_217,x:178.8,y:253.1}).wait(1).to({graphics:mask_1_graphics_218,x:180,y:253}).wait(1).to({graphics:mask_1_graphics_219,x:181.4,y:253.1}).wait(1).to({graphics:mask_1_graphics_220,x:182.8,y:253.2}).wait(1).to({graphics:mask_1_graphics_221,x:184.1,y:253.3}).wait(1).to({graphics:mask_1_graphics_222,x:186.9,y:253.2}).wait(1).to({graphics:mask_1_graphics_223,x:189.7,y:253.2}).wait(1).to({graphics:mask_1_graphics_224,x:192.7,y:253.2}).wait(1).to({graphics:mask_1_graphics_225,x:196.3,y:254.2}).wait(1).to({graphics:mask_1_graphics_226,x:200.4,y:256.1}).wait(1).to({graphics:mask_1_graphics_227,x:204.6,y:257.9}).wait(1).to({graphics:mask_1_graphics_228,x:205.5,y:258.8}).wait(1).to({graphics:mask_1_graphics_229,x:205.5,y:259.9}).wait(1).to({graphics:mask_1_graphics_230,x:205.5,y:259.9}).wait(1).to({graphics:mask_1_graphics_231,x:205.5,y:260.2}).wait(1).to({graphics:mask_1_graphics_232,x:205.5,y:260.2}).wait(1).to({graphics:mask_1_graphics_233,x:203.9,y:260.6}).wait(1).to({graphics:mask_1_graphics_234,x:199.9,y:260.4}).wait(1).to({graphics:mask_1_graphics_235,x:198,y:263.5}).wait(1).to({graphics:mask_1_graphics_236,x:196.7,y:263.5}).wait(1).to({graphics:mask_1_graphics_237,x:194.8,y:264.9}).wait(1).to({graphics:mask_1_graphics_238,x:193.2,y:264.9}).wait(1).to({graphics:mask_1_graphics_239,x:194,y:264.6}).wait(1).to({graphics:mask_1_graphics_240,x:194.1,y:264.9}).wait(54).to({graphics:mask_1_graphics_294,x:194,y:289.9}).wait(20).to({graphics:null,x:0,y:0}).wait(11));

	// Ring
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1.5,1,1).p("AgQAMQAAABAMgKQAKgHALgH");
	this.shape.setTransform(174.7,257);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(1.8,1,1).p("AighOQAKgGACgBQAygVBegIQBqgKBdAUQBgAVAVAmQAcAxgyAkQg5AoiXAWQiEAThfgDQhrgEgrgfQghgYAJggQAHgZAfgZQAdgXAygTQAWgIAUgFg");
	this.shape_1.setTransform(192.5,263.7);

	this.instance_1 = new lib.ring();
	this.instance_1.parent = this;
	this.instance_1.setTransform(192.5,263.7,1,1,0,0,0,32.2,11.8);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},209).to({state:[{t:this.instance_1}]},85).to({state:[{t:this.instance_1}]},20).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(294).to({_off:false},0).to({y:339.1,alpha:0},20,cjs.Ease.quadInOut).wait(11));

	// menu tabs
	this.instance_2 = new lib.menu_pens_yellow();
	this.instance_2.parent = this;
	this.instance_2.setTransform(138.3,117.4,0.64,0.64);

	this.instance_3 = new lib.menu_pens_red();
	this.instance_3.parent = this;
	this.instance_3.setTransform(138.3,117.4,0.64,0.64);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},130).wait(195));

	// menu
	this.instance_4 = new lib.menu_btm();
	this.instance_4.parent = this;
	this.instance_4.setTransform(101.2,336.3);

	this.instance_5 = new lib.menu();
	this.instance_5.parent = this;
	this.instance_5.setTransform(101.2,101);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4}]}).wait(325));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_61 = new cjs.Graphics().p("AGRXQIAAh9IO8AAIAAB9g");
	var mask_2_graphics_62 = new cjs.Graphics().p("AGrXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_63 = new cjs.Graphics().p("AHFXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_64 = new cjs.Graphics().p("AHfXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_65 = new cjs.Graphics().p("AH4XPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_66 = new cjs.Graphics().p("AIRXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_67 = new cjs.Graphics().p("AIqXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_68 = new cjs.Graphics().p("AJDXPIAAh8IO7AAIAAB8g");
	var mask_2_graphics_69 = new cjs.Graphics().p("AJbXPIAAh8IO7AAIAAB8g");
	var mask_2_graphics_70 = new cjs.Graphics().p("AJzXPIAAh8IO7AAIAAB8g");
	var mask_2_graphics_71 = new cjs.Graphics().p("AKKXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_72 = new cjs.Graphics().p("AKhXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_73 = new cjs.Graphics().p("AK4XPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_74 = new cjs.Graphics().p("ALPXPIAAh8IO7AAIAAB8g");
	var mask_2_graphics_75 = new cjs.Graphics().p("ALlXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_76 = new cjs.Graphics().p("AL7XPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_77 = new cjs.Graphics().p("AMRXPIAAh8IO7AAIAAB8g");
	var mask_2_graphics_78 = new cjs.Graphics().p("AMmXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_79 = new cjs.Graphics().p("AM7XPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_80 = new cjs.Graphics().p("ANQXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_81 = new cjs.Graphics().p("ANkXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_140 = new cjs.Graphics().p("ANkXPIAAh8IO8AAIAAB8g");
	var mask_2_graphics_141 = new cjs.Graphics().p("ANkXCIAAh9IO8AAIAAB9g");
	var mask_2_graphics_142 = new cjs.Graphics().p("ANkW0IAAh8IO8AAIAAB8g");
	var mask_2_graphics_143 = new cjs.Graphics().p("ANkWmIAAh8IO8AAIAAB8g");
	var mask_2_graphics_144 = new cjs.Graphics().p("ANkWZIAAh9IO8AAIAAB9g");
	var mask_2_graphics_145 = new cjs.Graphics().p("ANkWLIAAh8IO8AAIAAB8g");
	var mask_2_graphics_146 = new cjs.Graphics().p("ANkV+IAAh9IO8AAIAAB9g");
	var mask_2_graphics_147 = new cjs.Graphics().p("ANkVwIAAh8IO8AAIAAB8g");
	var mask_2_graphics_148 = new cjs.Graphics().p("ANkVjIAAh9IO8AAIAAB9g");
	var mask_2_graphics_149 = new cjs.Graphics().p("ANkVVIAAh9IO8AAIAAB9g");
	var mask_2_graphics_150 = new cjs.Graphics().p("ANkVHIAAh8IO8AAIAAB8g");
	var mask_2_graphics_151 = new cjs.Graphics().p("ANkU6IAAh9IO8AAIAAB9g");
	var mask_2_graphics_152 = new cjs.Graphics().p("ANkUsIAAh8IO8AAIAAB8g");
	var mask_2_graphics_153 = new cjs.Graphics().p("ANkUfIAAh9IO8AAIAAB9g");
	var mask_2_graphics_154 = new cjs.Graphics().p("ANkURIAAh8IO8AAIAAB8g");
	var mask_2_graphics_155 = new cjs.Graphics().p("ANkUDIAAh8IO8AAIAAB8g");
	var mask_2_graphics_156 = new cjs.Graphics().p("ANkT2IAAh9IO8AAIAAB9g");
	var mask_2_graphics_157 = new cjs.Graphics().p("ANkToIAAh8IO8AAIAAB8g");
	var mask_2_graphics_158 = new cjs.Graphics().p("ANkTbIAAh9IO8AAIAAB9g");
	var mask_2_graphics_159 = new cjs.Graphics().p("ANkTNIAAh8IO8AAIAAB8g");
	var mask_2_graphics_160 = new cjs.Graphics().p("ANkTAIAAh9IO8AAIAAB9g");
	var mask_2_graphics_161 = new cjs.Graphics().p("ANkSyIAAh9IO8AAIAAB9g");
	var mask_2_graphics_162 = new cjs.Graphics().p("ANkSkIAAh8IO8AAIAAB8g");
	var mask_2_graphics_163 = new cjs.Graphics().p("ANkSXIAAh9IO8AAIAAB9g");
	var mask_2_graphics_164 = new cjs.Graphics().p("ANkSJIAAh8IO8AAIAAB8g");
	var mask_2_graphics_165 = new cjs.Graphics().p("ANkR8IAAh9IO8AAIAAB9g");
	var mask_2_graphics_166 = new cjs.Graphics().p("ANkRuIAAh8IO8AAIAAB8g");
	var mask_2_graphics_167 = new cjs.Graphics().p("ANkRgIAAh8IO8AAIAAB8g");
	var mask_2_graphics_168 = new cjs.Graphics().p("ANkRTIAAh9IO8AAIAAB9g");
	var mask_2_graphics_169 = new cjs.Graphics().p("ANkRFIAAh8IO8AAIAAB8g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(61).to({graphics:mask_2_graphics_61,x:135.7,y:148.8}).wait(1).to({graphics:mask_2_graphics_62,x:138.3,y:148.7}).wait(1).to({graphics:mask_2_graphics_63,x:140.9,y:148.7}).wait(1).to({graphics:mask_2_graphics_64,x:143.5,y:148.7}).wait(1).to({graphics:mask_2_graphics_65,x:146,y:148.7}).wait(1).to({graphics:mask_2_graphics_66,x:148.5,y:148.7}).wait(1).to({graphics:mask_2_graphics_67,x:151,y:148.7}).wait(1).to({graphics:mask_2_graphics_68,x:153.4,y:148.7}).wait(1).to({graphics:mask_2_graphics_69,x:155.8,y:148.7}).wait(1).to({graphics:mask_2_graphics_70,x:158.2,y:148.7}).wait(1).to({graphics:mask_2_graphics_71,x:160.6,y:148.7}).wait(1).to({graphics:mask_2_graphics_72,x:162.9,y:148.7}).wait(1).to({graphics:mask_2_graphics_73,x:165.2,y:148.7}).wait(1).to({graphics:mask_2_graphics_74,x:167.4,y:148.7}).wait(1).to({graphics:mask_2_graphics_75,x:169.7,y:148.7}).wait(1).to({graphics:mask_2_graphics_76,x:171.9,y:148.7}).wait(1).to({graphics:mask_2_graphics_77,x:174,y:148.7}).wait(1).to({graphics:mask_2_graphics_78,x:176.2,y:148.7}).wait(1).to({graphics:mask_2_graphics_79,x:178.3,y:148.7}).wait(1).to({graphics:mask_2_graphics_80,x:180.4,y:148.7}).wait(1).to({graphics:mask_2_graphics_81,x:182.4,y:148.7}).wait(59).to({graphics:mask_2_graphics_140,x:182.4,y:148.7}).wait(1).to({graphics:mask_2_graphics_141,x:182.4,y:147.4}).wait(1).to({graphics:mask_2_graphics_142,x:182.4,y:146}).wait(1).to({graphics:mask_2_graphics_143,x:182.4,y:144.6}).wait(1).to({graphics:mask_2_graphics_144,x:182.4,y:143.3}).wait(1).to({graphics:mask_2_graphics_145,x:182.4,y:141.9}).wait(1).to({graphics:mask_2_graphics_146,x:182.4,y:140.6}).wait(1).to({graphics:mask_2_graphics_147,x:182.4,y:139.2}).wait(1).to({graphics:mask_2_graphics_148,x:182.4,y:137.9}).wait(1).to({graphics:mask_2_graphics_149,x:182.4,y:136.5}).wait(1).to({graphics:mask_2_graphics_150,x:182.4,y:135.1}).wait(1).to({graphics:mask_2_graphics_151,x:182.4,y:133.8}).wait(1).to({graphics:mask_2_graphics_152,x:182.4,y:132.4}).wait(1).to({graphics:mask_2_graphics_153,x:182.4,y:131.1}).wait(1).to({graphics:mask_2_graphics_154,x:182.4,y:129.7}).wait(1).to({graphics:mask_2_graphics_155,x:182.4,y:128.3}).wait(1).to({graphics:mask_2_graphics_156,x:182.4,y:127}).wait(1).to({graphics:mask_2_graphics_157,x:182.4,y:125.6}).wait(1).to({graphics:mask_2_graphics_158,x:182.4,y:124.3}).wait(1).to({graphics:mask_2_graphics_159,x:182.4,y:122.9}).wait(1).to({graphics:mask_2_graphics_160,x:182.4,y:121.6}).wait(1).to({graphics:mask_2_graphics_161,x:182.4,y:120.2}).wait(1).to({graphics:mask_2_graphics_162,x:182.4,y:118.8}).wait(1).to({graphics:mask_2_graphics_163,x:182.4,y:117.5}).wait(1).to({graphics:mask_2_graphics_164,x:182.4,y:116.1}).wait(1).to({graphics:mask_2_graphics_165,x:182.4,y:114.8}).wait(1).to({graphics:mask_2_graphics_166,x:182.4,y:113.4}).wait(1).to({graphics:mask_2_graphics_167,x:182.4,y:112}).wait(1).to({graphics:mask_2_graphics_168,x:182.4,y:110.7}).wait(1).to({graphics:mask_2_graphics_169,x:182.4,y:109.3}).wait(156));

	// highlighted
	this.instance_6 = new lib.highlight();
	this.instance_6.parent = this;
	this.instance_6.setTransform(317.9,291,1,1,0,0,0,46.5,6.5);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(61).to({_off:false},0).wait(79).to({y:212.2},29,cjs.Ease.quadInOut).to({_off:true},125).wait(31));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("A1bbbMAAAgnOMA6yAAAMAAAAnOg");
	var mask_3_graphics_140 = new cjs.Graphics().p("A9ZTiMAAAgnCMA6yAAAMAAAAnCg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:239.1,y:175.5}).wait(140).to({graphics:mask_3_graphics_140,x:290.1,y:226.1}).wait(185));

	// scroll screen
	this.instance_7 = new lib.scroll_screen();
	this.instance_7.parent = this;
	this.instance_7.setTransform(285.8,292.4,1,1,0,0,0,137.5,144.5);

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(140).to({y:213.6},29,cjs.Ease.quadInOut).wait(125).to({y:292.4},20,cjs.Ease.quadInOut).wait(11));

	// grey screen
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E6E6E6").s().p("A9YTnMAAAgnNMA6yAAAMAAAAnNg");
	this.shape_2.setTransform(289.5,226.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(325));

	// surface
	this.instance_8 = new lib.SurfacePro11();
	this.instance_8.parent = this;
	this.instance_8.setTransform(89.7,88.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(325));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(89.7,88.1,400,358);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.8,10.8);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.8,10.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.3,6.6,11.3,8.4);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(22,2.4,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.1,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("ArZCbIAAk1IWzAAIAAE1g");
	this.shape.setTransform(10,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-62.9,-14.4,146,30.9), null);


(lib.Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.stop()
	}
	this.frame_306 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(306).call(this.frame_306).wait(1));

	// Animation
	this.devices = new lib.device_animation();
	this.devices.name = "devices";
	this.devices.parent = this;
	this.devices.setTransform(173.4,155.3,0.602,0.602,0,0,0,288.1,257.9);

	this.timeline.addTween(cjs.Tween.get(this.devices).wait(307));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(54,53,278.2,246.2);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(284.8,4.1,0.348,0.348,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(222.7,555.7,0.496,0.496);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// circle Bonus
	this.bg_circle = new lib.circle_bg();
	this.bg_circle.name = "bg_circle";
	this.bg_circle.parent = this;
	this.bg_circle.setTransform(184,524.9);

	this.timeline.addTween(cjs.Tween.get(this.bg_circle).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(241.7,553.8,0.943,0.943,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// anim
	this.anim = new lib.Intro();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(-24.7,165.9);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// MSFT Logo
	this.logo = new lib.logos();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.9,19.2,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgNKAwSMAAAhgjIaVAAMAAABgjg");
	this.shape.setTransform(152,302.3,1.855,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-4.2,-6.6,324.2,617.9), null);


// stage content:
(lib.O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC

		this.initBanner = function (data) {

			Object.keys = function(obj) {
				var keys = [];

				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)

				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "cost" && data[keys[i]].length > 1) {
							exportRoot.fillPriceMc(data[keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}


		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillPriceMc = function (txtDetails) {

			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)

				this.mainMC.bg_circle.addChild(mc);
			}
		}


		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}


		this.tlanim = new TimelineLite();


		this.tl1 = new TimelineLite();
		this.tl2 = new TimelineLite();
		this.tl = new TimelineLite();
		var mc = exportRoot.mainMC


		this.runBanner = function() {


			exportRoot.finalHeadline = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				exportRoot.finalHeadline.from(exportRoot.headline1[i], 0.6, {x: "+=50",	alpha: 0, ease: Power3.easeOut}, "-=0.4");
			}
			exportRoot.finalHeadline.stop()

			exportRoot.subHeadline = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				exportRoot.subHeadline.from(exportRoot.headline2[i], 0.6, {x: "+=50",	alpha: 0, ease: Power3.easeOut}, "-=0.4");
			}
			exportRoot.subHeadline.stop()




		    exportRoot.tl1.to(mc.anim, 0.9, {alpha: 1,	x: "-=350",ease: Power4.easeOut, onStart:function(){mc.anim.devices.play()}})
			exportRoot.tl1.to(mc.cta, 0.7, {alpha: 1,	x: "-=300",	ease: Power4.easeOut}, "-=0.9");
			exportRoot.tl1.to(mc.txtCta, 0.7, {alpha: 1,	x: "-=300", ease: Power4.easeOut}, "-=0.9");


			exportRoot.tl1.stop()

			exportRoot.tl2.to(mc.replay_btn, 0.7, {alpha: 1,	x: "-=300",ease: Power4.easeOut}, "-=0.5")

			exportRoot.tl2.stop()


			mc.logo.gotoAndPlay(1)
		}
		    mc.anim.x += 350
			mc.txtCta.x += 300;
			mc.cta.x += 300;
			mc.replay_btn.x+=300
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(145.8,293.4,324.2,617.9);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_.png?1537307772151", id:"O365_CreateYourBestWork_USA_300x600_BAN_Word_Inking_NA_NA_ANI_BN_T1_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
