(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[970,1253,30,30],[912,275,33,33],[912,310,33,33],[645,1212,324,39],[645,1253,323,37],[0,1270,323,36],[0,1308,323,33],[649,1292,322,26],[325,1330,322,17],[649,1320,322,18],[325,1292,322,36],[322,1212,321,56],[0,1145,320,77],[628,1111,318,99],[628,989,316,120],[312,989,314,139],[0,988,310,155],[0,818,308,168],[604,809,306,178],[604,621,304,186],[301,621,301,192],[0,619,299,197],[0,417,298,200],[588,209,296,202],[292,209,294,204],[0,0,292,206],[588,413,290,206],[0,208,290,207],[294,0,290,207],[586,0,290,207],[41,1224,29,29],[886,0,125,273],[300,415,193,179],[948,275,57,56],[0,1224,39,38]]}
];


// symbols:



(lib.Chris = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.groupchat_thumbnail = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Kayo = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Base = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00000 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00001 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00002 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00003 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00004 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00005 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00006 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00007 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00008 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00009 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00010 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00011 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00012 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00013 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00014 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00015 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00016 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00017 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00018 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00019 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00020 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00022 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00024 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00026 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00028 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Laptop_Main_00030 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.MJ = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.mobile_small = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x1500 = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.topbar_lady = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.will = function() {
	this.initialize(ss["O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wide_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#D8D8D8","#E7E7E7","#F9F9F9","#FFFFFF"],[0.369,0.631,0.831,1],0,0,0,0,0,196).s().p("A1eVfQo6o5AAsmQAAslI6o5QI5o6MlAAQMmAAI5I6QI6I5AAMlQAAMmo6I5Qo5I6smAAQslAAo5o6g");
	this.shape.setTransform(194.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wide_shadow_sub, new cjs.Rectangle(0,0,389,389), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(149.9997,124.9923,0.309,0.3071);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,300,250), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.Kayo();
	this.instance.parent = this;
	this.instance.setTransform(-11,2,0.2257,0.2257);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-5.229,8.363,0.1788,0.1788);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_1.setTransform(-4.5867,8.38,0.1793,0.1793);

	this.txt3 = new cjs.Text("Works for me . Thanks!", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 6;
	this.txt3.lineWidth = 42;
	this.txt3.parent = this;
	this.txt3.setTransform(-1.3,10.75);

	this.txt2 = new cjs.Text("1/28  1:13 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 24;
	this.txt2.parent = this;
	this.txt2.setTransform(17.35,6.45);

	this.txt1 = new cjs.Text("Kayo Minwa", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 21;
	this.txt1.parent = this;
	this.txt1.setTransform(-1.3,6.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_11, new cjs.Rectangle(-11,2,54.3,16.8), null);


(lib.txt_08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.MJ();
	this.instance.parent = this;
	this.instance.setTransform(-11,2,0.25,0.25);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-5.7602,8.2646,0.1789,0.1789);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_1.setTransform(-5.1867,8.28,0.1793,0.1793);

	this.txt3 = new cjs.Text("Yeah this is a great idea, I also have some finance stuff to go through, is it ok if i pick your brain  on the call Kayo?", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 4;
	this.txt3.lineWidth = 135;
	this.txt3.parent = this;
	this.txt3.setTransform(-1.3,9.2);

	this.txt2 = new cjs.Text("1/28  1:13 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 18;
	this.txt2.parent = this;
	this.txt2.setTransform(20.75,5.4);

	this.txt1 = new cjs.Text("Martha Daydon", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 24;
	this.txt1.parent = this;
	this.txt1.setTransform(-1.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_08, new cjs.Rectangle(-11,2,146.5,19.3), null);


(lib.txt_07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.MJ();
	this.instance.parent = this;
	this.instance.setTransform(-11,2,0.25,0.25);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-5.7602,8.2646,0.1789,0.1789);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_1.setTransform(-5.1867,8.28,0.1793,0.1793);

	this.txt3 = new cjs.Text("This is fantastic progress. If you both can set something up with me to review when you feel are in\na good place for feedback. I have a free slot tomorrow morning at 9:00.", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 4;
	this.txt3.lineWidth = 132;
	this.txt3.parent = this;
	this.txt3.setTransform(-1.3,9.2);

	this.txt2 = new cjs.Text("1/28  1:18 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 18;
	this.txt2.parent = this;
	this.txt2.setTransform(20.75,5.4);

	this.txt1 = new cjs.Text("Martha Daydon", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 24;
	this.txt1.parent = this;
	this.txt1.setTransform(-1.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_07, new cjs.Rectangle(-11,2,144,19.3), null);


(lib.txt_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.Chris();
	this.instance.parent = this;
	this.instance.setTransform(-76.15,3.65,0.23,0.23);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape.setTransform(-70.7367,9.98,0.1793,0.1793);

	this.txt = new cjs.Text("Simon Tagg", "3px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 17;
	this.txt.parent = this;
	this.txt.setTransform(-66.75,6.25);

	this.txt3 = new cjs.Text("Reply", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 6;
	this.txt3.lineWidth = 15;
	this.txt3.parent = this;
	this.txt3.setTransform(-76.25,16.35);

	this.txt1 = new cjs.Text("1:15 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 21;
	this.txt1.parent = this;
	this.txt1.setTransform(-49.45,6.55);

	this.txt2 = new cjs.Text("That would be a huge help. I will call you at  12 to discuss.", "3px 'Segoe Pro'", "#293549");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 6;
	this.txt2.lineWidth = 84;
	this.txt2.parent = this;
	this.txt2.setTransform(-67.1,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt2},{t:this.txt1},{t:this.txt3},{t:this.txt},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_05, new cjs.Rectangle(-78.2,3.7,96.6,20.7), null);


(lib.txt_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.will();
	this.instance.parent = this;
	this.instance.setTransform(1.05,14.75,0.2164,0.2164);

	this.txt5 = new cjs.Text("1:14 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 5;
	this.txt5.lineWidth = 22;
	this.txt5.parent = this;
	this.txt5.setTransform(31.55,16.55);

	this.txt4 = new cjs.Text("Will Sheradon", "3px 'Segoe Pro'");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 5;
	this.txt4.lineWidth = 17;
	this.txt4.parent = this;
	this.txt4.setTransform(11.85,16.55);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(129.5898,13.8146,0.1789,0.1789);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_1.setTransform(-4.7867,8.33,0.1793,0.1793);

	this.txt6 = new cjs.Text("I can help you with the rollout plan for EMEA as I've been working closely this week with the local marketing team to get the timings", "3px 'Segoe Pro'", "#293549");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 4;
	this.txt6.lineWidth = 106;
	this.txt6.parent = this;
	this.txt6.setTransform(12.05,20.6);

	this.txt3 = new cjs.Text("Daniela, I can help you with the deck today. I've completed the initial costing for spring.", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 4;
	this.txt3.lineWidth = 137;
	this.txt3.parent = this;
	this.txt3.setTransform(2.15,8.9);

	this.txt2 = new cjs.Text("1/28  1:13 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 22;
	this.txt2.parent = this;
	this.txt2.setTransform(21.85,4.75);

	this.txt1 = new cjs.Text("Will Sheradon", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 17;
	this.txt1.parent = this;
	this.txt1.setTransform(2.15,4.75);

	this.instance_1 = new lib.will();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-11,2,0.2164,0.2164);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt6},{t:this.shape_1},{t:this.shape},{t:this.txt4},{t:this.txt5},{t:this.instance}]}).wait(1));

	// Layer_7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FAFAF7").s().p("ArvCjQgIAAABgHIAAk3QgBgHAIAAIXgAAQAHAAAAAHIAAE3QAAAHgHAAg");
	this.shape_2.setTransform(74.85,27.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ArwAwQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBQAAgBgBAAQAAgBAAAAQAAgBAAAAIAAhSQAAgBAAgBQAAAAAAgBQABAAAAgBQABAAAAgBQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABgBIXhAAQAGAAAAAHIAABSQAAAFgGABg");
	this.shape_3.setTransform(74.85,6.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_04, new cjs.Rectangle(-11,1.8,161.8,42.5), null);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tile_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,1],-0.5,12.2,-0.5,24.3).s().p("A5bD6IAAnzMAy3AAAIAAHzg");
	this.shape.setTransform(162.8,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow_sub, new cjs.Rectangle(0,0,325.6,50), null);


(lib.press_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAoQgKAAAAgKIAAg7QAAgKAKAAIAdAAQAKAAAAAKIAAA7QAAAKgKAAg");
	this.shape.setTransform(2.525,3.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.press_sub, new cjs.Rectangle(0,0,5.1,8), null);


(lib.phone_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["#A3A4A5","#5C5D5E","#BEBFC2"],[0.039,0.769,1],0,66.9,0,-66.8).ss(0.5,1,1).p("AkmqZIJNAAQA8AAAAA8IAAEJIAAB/IAAMzQAAA8g8AAIpNAAQg8AAAAg8IAAs6IAAjpIAAiYQAAg8A8AAg");
	this.shape.setTransform(36.25,66.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#131415").s().p("AkmKaQg8AAAAg8IAAs6IAAjpIAAiYQAAg8A8AAIJNAAQA8AAAAA8IAAEJIAAB/IAAMzQAAA8g8AAg");
	this.shape_1.setTransform(36.25,66.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#797A7C").s().p("AFjB4IAAh/IAIAAIAAB/gAlqBwIAAjnIAIAAIAADng");
	this.shape_2.setTransform(36.25,33.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_sub, new cjs.Rectangle(-0.2,-1,73,135.3), null);


(lib.phone_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.063)","rgba(0,0,0,0.278)","rgba(0,0,0,0.498)"],[0,0.125,0.38,1],-5.2,-6.5,-5.2,5.5).s().p("Ak5BCImLiDIWJAAImLCDg");
	this.shape.setTransform(70.875,6.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_shadow, new cjs.Rectangle(0,0,141.8,13.2), null);


(lib.Notification_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("1", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(1.1,2.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#3B4657").ss(0.1,1,1).p("AARAAQAAAHgFAFQgFAFgHAAQgGAAgFgFQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGg");
	this.shape.setTransform(1.65,1.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C62030").s().p("AgLALQgEgEgBgHQABgGAEgFQAFgEAGgBQAHABAEAEQAFAFABAGQgBAHgFAEQgEAFgHABQgGgBgFgFg");
	this.shape_1.setTransform(1.65,1.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.txt}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Notification_1, new cjs.Rectangle(-1,-1,10.1,11.4), null);


(lib.Notification = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("2", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(1.1,2.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#3B4657").ss(0.1,1,1).p("AARAAQAAAHgFAFQgFAFgHAAQgGAAgFgFQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGg");
	this.shape.setTransform(1.65,1.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C62030").s().p("AgLALQgEgEgBgHQABgGAEgFQAFgEAGgBQAHABAEAEQAFAFABAGQgBAHgFAEQgEAFgHABQgGgBgFgFg");
	this.shape_1.setTransform(1.65,1.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.txt}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Notification, new cjs.Rectangle(-1,-1,10.1,11.4), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mobileScr = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mobile_small();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.1224,1.1224);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mobileScr, new cjs.Rectangle(0,0,140.3,306.4), null);


(lib.mobile_Screen_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhVCNIAAgNQAAgWAHgQQAEgPAPgQQAPgQAjgZQAbgSAMgUQAMgSAAgZQAAgXgNgOQgOgNgWAAQgRAAgSAJQgRAJgPAQIAAgiQANgNARgHQARgHAXAAQAjAAAWAUQAWAVAAAiQAAAegNAWQgPAWgiAYQgiAZgKAKQgMALgEAKQgEAKAAAOICIAAIAAAcg");
	this.shape.setTransform(47.3021,233.4815,0.1289,0.1289);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CB4B32").s().p("AiqCsQhIhHAAhlQAAhkBIhHQBHhHBjAAQBlAABHBHQBHBHAABkQAABlhHBHQhHBHhlAAQhjAAhHhHg");
	this.shape_1.setTransform(47.4981,234.452,0.1294,0.1294);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E9E8E6").ss(3).p("EhUXAAAMCovAAA");
	this.shape_2.setTransform(69.8978,223.3493,0.1294,0.1294);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#5E5C5A").s().p("AgyBNIAAgdQAUAQAXAAQAeAAABgXQgBgJgGgHQgHgGgTgJQgWgKgJgJQgJgLAAgRQAAgVAQgOQARgNAYAAQASAAARAHIAAAbQgPgMgWAAQgMAAgIAHQgIAGAAAKQAAALAGAGQAFAFATAJQAYAJAJALQAKAKAAARQAAAWgRANQgQAOgbAAQgXgBgSgJg");
	this.shape_3.setTransform(129.0738,245.2184,0.1289,0.1289);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#5E5C5A").s().p("AgMB6IAAjzIAZAAIAADzg");
	this.shape_4.setTransform(127.7106,244.7092,0.1289,0.1289);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#5E5C5A").s().p("AgMB6IAAjzIAZAAIAADzg");
	this.shape_5.setTransform(126.6794,244.7092,0.1289,0.1289);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5E5C5A").s().p("AgyBJQgOgMAAgXQAAgsA3gIIAvgHQABgqgjAAQgbAAgZAUIAAgbQAHgFASgFQASgGAMABQA6AAAAA9IAABqIgbAAIAAgaIAAAAQgRAfghAAQgXgBgPgNgAAAAFQgVACgIAIQgIAGAAAPQAAANAJAHQAJAIANAAQATAAANgOQANgNgBgVIAAgQg");
	this.shape_6.setTransform(125.0326,245.2184,0.1289,0.1289);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#5E5C5A").s().p("AghBpQgZgOgNgbQgOgaAAgiQAAgiAPgcQAPgdAbgQQAbgPAgAAQAiAAAVAJIAAAdQgZgOgeAAQgaAAgTAMQgUAMgMAWQgKAWgBAdQABAcAJAUQAKAVAVALQARAMAZAAQAjAAAZgQIAAAbQgZANgnAAQgeAAgZgOg");
	this.shape_7.setTransform(122.6994,244.7962,0.1289,0.1289);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#5E5C5A").s().p("AgqBUIAAikIAaAAIAAAiIABAAQAGgRAKgKQALgKAPAAQALAAAFACIAAAcQgHgGgNAAQgRAAgKARQgMAQAAAaIAABUg");
	this.shape_8.setTransform(105.4195,245.2023,0.1289,0.1289);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5E5C5A").s().p("AgyBJQgOgMAAgXQAAgsA2gIIAwgHQAAgqghAAQgdAAgYAUIAAgbQAIgFAQgFQAUgGALABQA6AAAAA9IAABqIgbAAIAAgaIAAAAQgRAfggAAQgZgBgOgNgAgBAFQgUACgIAIQgIAGAAAPQAAANAJAHQAJAIANAAQAUAAAMgOQAMgNAAgVIAAgQg");
	this.shape_9.setTransform(103.3893,245.2184,0.1289,0.1289);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#5E5C5A").s().p("Ag4BmQgTgXAAgmQAAgoAVgYQAUgZAiAAQAiAAAPAbIABAAIAAhmIAaAAIAADzIgaAAIAAgcIgBAAQgSAggmAAQgfAAgSgWgAgigIQgOASAAAeQAAAdANAQQANARAWAAQAWgBANgQQAPgPAAgZIAAgYQAAgUgOgNQgOgOgTABQgXAAgOARg");
	this.shape_10.setTransform(101.0561,244.735,0.1289,0.1289);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5E5C5A").s().p("AAqBUIAAhcQAAg1gmAAQgTAAgNAPQgNAPAAAXIAABcIgaAAIAAikIAaAAIAAAcIABAAQASggAjABQAbAAAOARQAOASAAAgIAABkg");
	this.shape_11.setTransform(98.7196,245.1926,0.1289,0.1289);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5E5C5A").s().p("AgzA/QgUgVAAgqQAAgWAKgVQAKgVASgKQARgMAUABQAggBASAWQASAVAAAlIAAANIhzAAQABAbANAPQAPAPAXAAQAdAAAWgSIAAAYQgVAQgkABQgiAAgUgYgAgbgxQgNANgDAVIBYAAQAAgWgLgNQgLgNgTAAQgRAAgOAOg");
	this.shape_12.setTransform(96.4122,245.2184,0.1289,0.1289);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5E5C5A").s().p("AgMB6IAAjzIAZAAIAADzg");
	this.shape_13.setTransform(94.7944,244.7092,0.1289,0.1289);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#5E5C5A").s().p("AgyBJQgOgNAAgWQAAgsA3gIIAwgHQAAgqgiAAQgcAAgZAUIAAgbQAHgFASgFQASgGAMABQA6AAAAA9IAABqIgaAAIAAgaIgBAAQgRAfghAAQgXgBgPgNgAAAAFQgUACgIAIQgJAGAAAPQAAANAJAHQAJAIANAAQAUAAAMgOQANgOAAgUIAAgQg");
	this.shape_14.setTransform(93.1412,245.2184,0.1289,0.1289);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#5E5C5A").s().p("AghBpQgZgOgNgbQgOgaAAgiQAAgiAPgcQAPgdAbgQQAbgPAgAAQAiAAAVAJIAAAdQgagOgdAAQgaAAgTAMQgUAMgLAWQgMAWAAAdQAAAbALAVQAKAVAUALQARAMAZAAQAkAAAYgQIAAAbQgZANgnAAQgeAAgZgOg");
	this.shape_15.setTransform(90.808,244.7962,0.1289,0.1289);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#6363A6").s().p("AgyBNIAAgdQAUAQAXAAQAeAAABgXQgBgJgFgHQgHgGgUgJQgWgKgJgJQgJgLAAgRQAAgVAQgOQARgNAYAAQASAAARAHIAAAbQgPgMgWAAQgMAAgIAHQgIAGAAAKQAAALAGAGQAFAFAUAJQAXAJAJALQAKAKAAARQgBAWgQANQgQAOgaAAQgYgBgSgJg");
	this.shape_16.setTransform(74.7656,245.2184,0.1289,0.1289);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#6363A6").s().p("ABbBUIAAhdQAAgcgJgMQgJgMgTAAQgRAAgMAQQgMAPAAAWIAABcIgZAAIAAhhQAAgwgmAAQgRAAgLAPQgMAOAAAYIAABcIgaAAIAAikIAaAAIAAAbIABAAQARgeAiAAQAQAAANAJQAMAIAFARQATgjAkABQA2AAAABDIAABkg");
	this.shape_17.setTransform(72.1134,245.1926,0.1289,0.1289);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#6363A6").s().p("AgyBJQgOgNAAgWQAAgsA3gIIAvgHQAAgqghAAQgcAAgZAUIAAgbQAHgFASgFQASgGAMABQA6AAAAA9IAABqIgbAAIAAgaIAAAAQgRAfghAAQgXgBgPgNgAAAAFQgUACgJAIQgIAGAAAPQAAANAJAHQAJAIANAAQAUAAAMgOQAMgNAAgVIAAgQg");
	this.shape_18.setTransform(69.126,245.2184,0.1289,0.1289);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#6363A6").s().p("AgzA/QgUgWAAgpQAAgYAKgTQALgVAQgKQASgMAUABQAggBASAWQASAUAAAmIAAANIh0AAQABAcAOAOQAOAPAYAAQAcAAAXgSIAAAYQgWAQgjABQgiAAgUgYgAgbgxQgNAMgDAWIBYAAQgBgWgKgNQgMgNgTAAQgRAAgNAOg");
	this.shape_19.setTransform(67.0409,245.2184,0.1289,0.1289);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#6363A6").s().p("AgNBzIAAjNIhCAAIAAgYICfAAIAAAYIhCAAIAADNg");
	this.shape_20.setTransform(65.2588,244.7962,0.1289,0.1289);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#5E5C5A").s().p("AgTA8IAAhhIgcAAIAAgWIAcAAIAAgoIAZgJIAAAxIAqAAIAAAWIgqAAIAABcQAAARAGAHQAGAHANAAQAKAAAHgFIAAAXQgJAEgQAAQgqAAAAgwg");
	this.shape_21.setTransform(45.375,244.9283,0.1289,0.1289);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#5E5C5A").s().p("AgyBJQgOgMAAgXQAAgsA2gIIAwgHQABgqgjAAQgbAAgZAUIAAgbQAGgFATgFQASgGAMABQA6AAAAA9IAABqIgbAAIAAgaIAAAAQgRAfghAAQgXgBgPgNgAAAAFQgUACgJAIQgIAGAAAPQAAANAIAHQAKAIANAAQATAAANgOQAMgNAAgVIAAgQg");
	this.shape_22.setTransform(43.5316,245.2184,0.1289,0.1289);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#5E5C5A").s().p("AAqB6IAAhfQAAgygmAAQgTAAgNAPQgNAOAAAWIAABeIgaAAIAAjzIAaAAIAABrIABAAQATggAiAAQA3AAAABDIAABlg");
	this.shape_23.setTransform(41.3435,244.7092,0.1289,0.1289);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#5E5C5A").s().p("AghBpQgZgOgOgbQgNgaAAgiQAAgiAPgcQAPgdAbgQQAagPAiAAQAhAAAVAJIAAAdQgZgOgeAAQgaAAgTAMQgUAMgMAWQgLAXAAAcQAAAbAKAVQALAVATALQATAMAYAAQAjAAAZgQIAAAbQgZANgmAAQggAAgYgOg");
	this.shape_24.setTransform(38.7943,244.7962,0.1289,0.1289);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#5E5C5A").s().p("AhHB3IAAgYQAIADAHAAQAUAAAKgXIANggIhAijIAdAAIAwCKIAAAAIADgMIAvh+IAcAAIhMC+QgTAzglAAQgIAAgJgCg");
	this.shape_25.setTransform(19.713,245.7179,0.1289,0.1289);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#5E5C5A").s().p("AgTA8IAAhhIgcAAIAAgWIAcAAIAAgoIAZgJIAAAxIAqAAIAAAWIgqAAIAABcQAAARAGAHQAGAHANAAQAKAAAHgFIAAAXQgKAEgPAAQgqAAAAgwg");
	this.shape_26.setTransform(17.9502,244.9283,0.1289,0.1289);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#5E5C5A").s().p("AgNB4IAAikIAaAAIAACkgAgMhaQgEgFAAgIQAAgGAEgGQAHgFAFAAQAHAAAFAFQAFAGABAGQAAAIgGAFQgFAFgHAAQgGAAgGgFg");
	this.shape_27.setTransform(16.732,244.7285,0.1289,0.1289);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#5E5C5A").s().p("AgNBSIg/ikIAdAAIAqB3QADAHACARIABAAQABgOADgJIAsh4IAcAAIhBCkg");
	this.shape_28.setTransform(15.198,245.2184,0.1289,0.1289);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#5E5C5A").s().p("AgMB4IAAikIAZAAIAACkgAgLhaQgFgFAAgIQAAgGAFgGQAGgFAFAAQAHAAAFAFQAFAFAAAHQAAAIgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_29.setTransform(13.6673,244.7285,0.1289,0.1289);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#5E5C5A").s().p("AgSA8IAAhhIgdAAIAAgWIAdAAIAAgoIAZgJIAAAxIApAAIAAAWIgpAAIAABcQAAARAFAHQAGAHANAAQAKAAAHgFIAAAXQgJAEgPAAQgrAAABgwg");
	this.shape_30.setTransform(12.4201,244.9283,0.1289,0.1289);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#5E5C5A").s().p("AgXBMQgTgLgJgTQgKgRAAgZQAAgoAXgZQAZgYAlAAQAVgBARAJIAAAbQgTgNgUAAQgZAAgQASQgQASAAAcQAAAdAPARQAPARAZAAQAVAAAUgOIAAAZQgUAMgaAAQgVAAgSgLg");
	this.shape_31.setTransform(10.7476,245.2184,0.1289,0.1289);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#5E5C5A").s().p("ABIBzIgXhAIhhAAIgYBAIgeAAIBZjlIAbAAIBZDlgAgEhHIgjBhIBPAAIglhhIgDgPIAAAAQgBAIgDAHg");
	this.shape_32.setTransform(8.3982,244.7962,0.1289,0.1289);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#6363A6").s().p("AgMBjQgeAAgVgUQgWgWABgeIAAh+ICqAAIAADFQgIACgIgBg");
	this.shape_33.setTransform(66.8314,238.0834,0.1289,0.1289);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#6363A6").s().p("AgyAzQgWgVAAgeQAAgdAWgVQAVgWAdAAQAeAAAVAWQAWAVAAAdQAAAegWAVQgVAWgeAAQgdAAgVgWg");
	this.shape_34.setTransform(66.8733,235.3474,0.1289,0.1289);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#6363A6").s().p("AhEBjIgQgBIAAjFICqAAIAAB+QAAAegWAWQgUAUgeAAg");
	this.shape_35.setTransform(72.948,238.0834,0.1289,0.1289);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#6363A6").s().p("AgyAzQgWgVAAgeQAAgdAWgVQAVgWAdAAQAeAAAVAWQAWAVAAAdQAAAegWAVQgVAWgeAAQgdAAgVgWg");
	this.shape_36.setTransform(72.9126,235.3474,0.1289,0.1289);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#6363A6").s().p("AgpCcQgeAAgVgVQgVgVAAgeIAAjvIDjAAIAADvQAAAegVAVQgWAVgeAAg");
	this.shape_37.setTransform(69.98,238.4411,0.1289,0.1289);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#6363A6").s().p("AgyA0QgWgWAAgeQAAgdAWgWQAVgVAdAAQAeAAAVAVQAWAWAAAdQAAAegWAWQgVAVgeAAQgdAAgVgVg");
	this.shape_38.setTransform(69.98,234.9381,0.1289,0.1289);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#5E5C5A").s().p("AjWDhQgMgBgLgFQgKgGgFgLQgLgUAOgTIA5g2IAAiUQAAgpASgnQAXgwAugcQAugdA2ABIAFAAQA3AAAtAcQAuAdAXAvQASAlAAArIAACUIA+A0QAPATgKAVQgFALgKAGQgLAHgNAAgAjlC0QgDAFADAFQAEAIALAAIGtAAQAMAAAEgJQACgFgDgFIhGg5IAAihQAAgjgPgiQgTgogogYQgngZgvAAIgFAAQgvAAgnAZQgoAYgTAoQgQAiAAAjIAACnIgIAAg");
	this.shape_39.setTransform(13.7843,235.8017,0.1289,0.1289);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#5E5C5A").s().p("Ag6AkQgbgTgKgeQgGgPAKgNQAKgNAPAAICEAAQAQAAAKANQAJANgFAPQgKAegbATQgbATggAAQggAAgagTgAhGgZQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAHAWAUAOQATAOAYAAQAYAAAUgOQATgOAIgWQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIiEAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_40.setTransform(13.7879,240.0396,0.1289,0.1289);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#5E5C5A").s().p("ADPEXIhdhdQgwAEg7AAQhwAAhogNQgegEgTgWQgVgXAAgeIAAk1QAAghAYgXQAXgXAhAAIGQAAQAgAAAYAXQAXAXAAAhIAAHMQgBANgGALQgIAKgMAFQgHADgJAAQgSAAgMgMgADsD7QAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAnMQAAgQgLgMQgMgLgPAAImQAAQgRAAgLALQgLAMAAAQIAAE1QgBAPALALQAKALAOACQBqANBpAAQA3AAA7gEIAJgBgAiRAUIAAhKIDIAAIAABKgAiRhSIAAhLIEjAAIAABLg");
	this.shape_41.setTransform(41.8236,237.2358,0.1289,0.1289);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#5D5C5A").s().p("AgsAtIAAhZIBZAAIAABZg");
	this.shape_42.setTransform(99.1772,236.3109,0.1289,0.1289);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#5D5C5A").s().p("AgsAtIAAhZIBZAAIAABZg");
	this.shape_43.setTransform(97.6723,237.9126,0.1289,0.1289);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#5D5C5A").s().p("AgsAtIAAhZIBZAAIAABZg");
	this.shape_44.setTransform(96.1641,237.9126,0.1289,0.1289);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#5D5C5A").s().p("AgsAtIAAhZIBZAAIAABZg");
	this.shape_45.setTransform(97.6723,236.3109,0.1289,0.1289);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#5D5C5A").s().p("AgsAtIAAhZIBZAAIAABZg");
	this.shape_46.setTransform(96.1641,236.3109,0.1289,0.1289);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#5D5C5A").s().p("AjSD8QgagMgQgOQgIgHgEgGIgCgDIAAl1QAAgRAMgNQANgMARAAIBsAAIAAg+QAAgJAGgFQAGgGAJAAQAIAAAGAGQAGAGAAAIIAAA+ICaAAIAAg+QAAgIAGgGQAGgGAIAAQAJAAAFAGQAGAGAAAIIAAA+IBqAAQASAAAMAMQAMANAAARIgBF3QgKAWglATQhGAjiDAAQiSAAhSgkgAjriuQgEAEAAAHIAAFtQARATAsAPQBLAaB5AAQBtAAA/gaQAlgPANgSIAAluQAAgHgEgEQgEgEgHAAIhqAAIAAAyQAAAIgGAGQgFAGgJAAQgIAAgGgGQgGgGAAgIIAAgyIiaAAIAAAyQAAAIgGAGQgGAGgIAAQgJAAgGgGQgGgGAAgIIAAgyIhsAAQgHAAgEAEg");
	this.shape_47.setTransform(97.6626,236.7009,0.1289,0.1289);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#CB4B32").s().p("AhVBWQgkgkAAgyQAAgxAkgkQAkgkAxAAQAyAAAlAkQAjAkAAAxQAAAzgjAjQglAkgyAAQgxAAgkgkg");
	this.shape_48.setTransform(129.971,232.6851,0.1294,0.1294);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#5C5B59").s().p("AALDdQhFgwg+hRQhMhkgVhhQgThaAmgdIAKgHQAVgRANgHQAWgLAUADQAeAGAYAoQAeAzgIAfQgFAWgiAZIgGAEIACATQAKAfArA4QAiAuAXAUQAWATAIgEIAFgEQAhgaAXABQAgAAAoAsQAhAjgDAfQgDAVgSATQgMALgYAQIgFAEQgOAJgXAAQgwAAhCgrgAiSjhIgYARIgKAIQgZATASBKQAUBXBHBeQBHBdBOArQBDAlAZgRIAGgEQATgNAJgIQANgMACgMQACgRgYgaQgfghgTgBQgMgBgaAUIgFAEQgaATgqgkQgagYgjguQgug8gMgkQgMgkAVgQIAGgEQAagTADgNQAEgSgYgnQgRgdgRgDIgEAAQgKAAgOAIg");
	this.shape_49.setTransform(125.9557,237.008,0.1289,0.1289);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#959491").s().p("AnHA8QgZAAgSgRQgRgSAAgZQAAgXARgTQASgRAZAAIOPAAQAZAAASARQARATAAAXQAAAZgRASQgSARgZAAg");
	this.shape_50.setTransform(69.9606,225.5408,0.1289,0.1289);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#F9F9F9").s().p("EhUXAPwIAA/gMCovAAAIAAfgg");
	this.shape_51.setTransform(69.8978,236.3192,0.1294,0.1294);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mobile_Screen_c, new cjs.Rectangle(-1.5,221.9,142.8,27.5), null);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.mainchat_top = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		//this.txt4.textBaseline = "alphabetic"
		//this.txt5.textBaseline = "alphabetic"
		//this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.txt3 = new cjs.Text("Private", "3px 'Segoe Pro Semibold'", "#8C8C8C");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 6;
	this.txt3.lineWidth = 42;
	this.txt3.parent = this;
	this.txt3.setTransform(203.95,-12.25);

	this.timeline.addTween(cjs.Tween.get(this.txt3).wait(1));

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6F75B6").s().p("AAIAOIgHgDIgBAAIgHADIgBAAQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIACgIIgBgBIgGgFIAAgCIABAAIAIgCIABAAIAEgIIAAgBIABABIAEAIIABAAIAIACIABAAIAAACIgGAFIAAABIABAIQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBAAIAAABIgBgBg");
	this.shape.setTransform(74.575,-11.2875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Top_symbols
	this.instance = new lib.groupchat_thumbnail();
	this.instance.parent = this;
	this.instance.setTransform(20.85,-16,0.2409,0.2409);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#586071").s().p("AgEBSIAAhNIhNAAIAAgJIBNAAIAAhNIAJAAIAABNIBNAAIAAAJIhNAAIAABNg");
	this.shape_1.setTransform(53.9455,-2.659,0.1818,0.1818);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_2.setTransform(31.7104,-13.2406,0.1787,0.1787);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_3.setTransform(57.9063,-13.2396,0.1788,0.1788);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E8E8E5").s().p("Ag+AdIAAg5IB9AAIAAA5g");
	this.shape_4.setTransform(208.95,-11.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance}]}).wait(1));

	// Top_txt
	this.txt2 = new cjs.Text("...", "5px 'Segoe Pro Semibold'", "#0C1F3B");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 9;
	this.txt2.lineWidth = 14;
	this.txt2.parent = this;
	this.txt2.setTransform(79.4,-11.9);

	this.txt1 = new cjs.Text("Sales", "5px 'Segoe Pro Semibold'", "#0C1F3B");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 9;
	this.txt1.lineWidth = 14;
	this.txt1.parent = this;
	this.txt1.setTransform(60.1,-10.7);

	this.txt8 = new cjs.Text("Files", "3px 'Segoe Pro'", "#303C51");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 6;
	this.txt8.lineWidth = 18;
	this.txt8.parent = this;
	this.txt8.setTransform(42.55,-1.6);

	this.txt7 = new cjs.Text("Conversation", "3px 'Segoe Pro'", "#7073BC");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 6;
	this.txt7.lineWidth = 18;
	this.txt7.parent = this;
	this.txt7.setTransform(21.5,-1.6);

	this.txt = new cjs.Text("Store Portal > ", "4px 'Segoe Pro Semibold'", "#0C1F3B");
	this.txt.name = "txt";
	this.txt.lineHeight = 7;
	this.txt.lineWidth = 42;
	this.txt.parent = this;
	this.txt.setTransform(33.9,-10.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7073BC").s().p("AhTAEIAAgGICoAAIAAAGg");
	this.shape_5.setTransform(30.05,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.txt},{t:this.txt7},{t:this.txt8},{t:this.txt1},{t:this.txt2}]}).wait(1));

	// bg_2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F3F3F0").s().p("AxTB/IAAj9MAinAAAIAAD9g");
	this.shape_6.setTransform(110.8,-11.125);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainchat_top, new cjs.Rectangle(0,-23.8,248.3,30.200000000000003), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.laptop_shadow_2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0.698)","rgba(0,0,0,0.098)","rgba(0,0,0,0)"],[0.369,0.596,0.831,1],0,0,0,0,0,196).s().p("A1eVfQo6o5AAsmQAAslI6o5QI5o6MlAAQMmAAI5I6QI6I5AAMlQAAMmo6I5Qo5I6smAAQslAAo5o6g");
	this.shape.setTransform(194.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_shadow_2_sub, new cjs.Rectangle(0,0,389,389), null);


(lib.laptop_shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.698)","rgba(0,0,0,0)"],[0.412,0.976],2.3,-2.8,0,2.3,-2.8,5.8).s().p("AgPAMQgQgPAAgYIAAgBIA1AAIAAAAIAAA4IALAAIgKABQgXAAgPgRg");
	this.shape.setTransform(156.05,215.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.698)","rgba(0,0,0,0)"],[0.412,0.976],-2.3,-2.8,0,-2.3,-2.8,5.8).s().p("AgfAcIAKAAIAAg4IA1AAIAAABQAAAYgQAPQgQARgWAAIgJgBg");
	this.shape_1.setTransform(474.75,215.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.698)","rgba(0,0,0,0)"],[0,1],-130.9,-0.3,-130.9,2.8).s().p("AYZAdMgwxAAAIgKAAIAAg4IgBAAIAAgBMAxFAAAIACAAIAAABIAAA4g");
	this.shape_2.setTransform(315.375,215.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_shadow_1, new cjs.Rectangle(152.8,212.6,325.2,5.900000000000006), null);


(lib.keyboard_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("EN(UK)", "2px 'Segoe Pro'", "#2E4747");
	this.text.textAlign = "center";
	this.text.lineHeight = 5;
	this.text.lineWidth = 8;
	this.text.parent = this;
	this.text.setTransform(33.65,41.35);

	this.text_1 = new cjs.Text("0", "4px 'Segoe Pro'", "#2E4747");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 7;
	this.text_1.lineWidth = 6;
	this.text_1.parent = this;
	this.text_1.setTransform(61.8,5.5);

	this.text_2 = new cjs.Text("9", "4px 'Segoe Pro'", "#2E4747");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 7;
	this.text_2.lineWidth = 6;
	this.text_2.parent = this;
	this.text_2.setTransform(55.6,5.5);

	this.text_3 = new cjs.Text("8", "4px 'Segoe Pro'", "#2E4747");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 7;
	this.text_3.lineWidth = 6;
	this.text_3.parent = this;
	this.text_3.setTransform(49.3,5.5);

	this.text_4 = new cjs.Text("7", "4px 'Segoe Pro'", "#2E4747");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 7;
	this.text_4.lineWidth = 6;
	this.text_4.parent = this;
	this.text_4.setTransform(43.05,5.5);

	this.text_5 = new cjs.Text("6", "4px 'Segoe Pro'", "#2E4747");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 7;
	this.text_5.lineWidth = 6;
	this.text_5.parent = this;
	this.text_5.setTransform(36.7,5.5);

	this.text_6 = new cjs.Text("5", "4px 'Segoe Pro'", "#2E4747");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 7;
	this.text_6.lineWidth = 6;
	this.text_6.parent = this;
	this.text_6.setTransform(30.3,5.5);

	this.text_7 = new cjs.Text("4", "4px 'Segoe Pro'", "#2E4747");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 7;
	this.text_7.lineWidth = 6;
	this.text_7.parent = this;
	this.text_7.setTransform(24.05,5.5);

	this.text_8 = new cjs.Text("3", "4px 'Segoe Pro'", "#2E4747");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 7;
	this.text_8.lineWidth = 6;
	this.text_8.parent = this;
	this.text_8.setTransform(17.65,5.5);

	this.text_9 = new cjs.Text("2", "4px 'Segoe Pro'", "#2E4747");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 7;
	this.text_9.lineWidth = 6;
	this.text_9.parent = this;
	this.text_9.setTransform(11.35,5.5);

	this.text_10 = new cjs.Text("1", "4px 'Segoe Pro'", "#2E4747");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 7;
	this.text_10.lineWidth = 6;
	this.text_10.parent = this;
	this.text_10.setTransform(5,5.5);

	this.text_11 = new cjs.Text("p", "4px 'Segoe Pro'", "#2E4747");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 7;
	this.text_11.lineWidth = 6;
	this.text_11.parent = this;
	this.text_11.setTransform(61.8,13.2);

	this.text_12 = new cjs.Text("o", "4px 'Segoe Pro'", "#2E4747");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 7;
	this.text_12.lineWidth = 6;
	this.text_12.parent = this;
	this.text_12.setTransform(55.6,13.2);

	this.text_13 = new cjs.Text("i", "4px 'Segoe Pro'", "#2E4747");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 7;
	this.text_13.lineWidth = 6;
	this.text_13.parent = this;
	this.text_13.setTransform(49.3,13.2);

	this.text_14 = new cjs.Text("u", "4px 'Segoe Pro'", "#2E4747");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 7;
	this.text_14.lineWidth = 6;
	this.text_14.parent = this;
	this.text_14.setTransform(43.05,13.2);

	this.text_15 = new cjs.Text("y", "4px 'Segoe Pro'", "#2E4747");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 7;
	this.text_15.lineWidth = 6;
	this.text_15.parent = this;
	this.text_15.setTransform(36.7,13.2);

	this.text_16 = new cjs.Text("t", "4px 'Segoe Pro'", "#2E4747");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 7;
	this.text_16.lineWidth = 6;
	this.text_16.parent = this;
	this.text_16.setTransform(30.3,13.2);

	this.text_17 = new cjs.Text("r", "4px 'Segoe Pro'", "#2E4747");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 7;
	this.text_17.lineWidth = 6;
	this.text_17.parent = this;
	this.text_17.setTransform(24.05,13.2);

	this.text_18 = new cjs.Text("e", "4px 'Segoe Pro'", "#2E4747");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 7;
	this.text_18.lineWidth = 6;
	this.text_18.parent = this;
	this.text_18.setTransform(17.65,13.2);

	this.text_19 = new cjs.Text("w", "4px 'Segoe Pro'", "#2E4747");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 7;
	this.text_19.lineWidth = 6;
	this.text_19.parent = this;
	this.text_19.setTransform(11.35,13.2);

	this.text_20 = new cjs.Text("q", "4px 'Segoe Pro'", "#2E4747");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 7;
	this.text_20.lineWidth = 6;
	this.text_20.parent = this;
	this.text_20.setTransform(5,13.2);

	this.text_21 = new cjs.Text("Go", "3px 'Segoe Pro'", "#4CB7AC");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 6;
	this.text_21.lineWidth = 6;
	this.text_21.parent = this;
	this.text_21.setTransform(61.15,40.75);

	this.text_22 = new cjs.Text("/", "4px 'Segoe Pro'", "#2E4747");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 7;
	this.text_22.lineWidth = 6;
	this.text_22.parent = this;
	this.text_22.setTransform(20.8,39.95);

	this.text_23 = new cjs.Text("www.", "2px 'Segoe Pro'", "#2E4747");
	this.text_23.textAlign = "center";
	this.text_23.lineHeight = 5;
	this.text_23.lineWidth = 6;
	this.text_23.parent = this;
	this.text_23.setTransform(53.6,41.15);

	this.text_24 = new cjs.Text(".", "4px 'Segoe Pro'", "#2E4747");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 7;
	this.text_24.lineWidth = 6;
	this.text_24.parent = this;
	this.text_24.setTransform(46.6,40.35);

	this.text_25 = new cjs.Text(",", "4px 'Segoe Pro'", "#2E4747");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 7;
	this.text_25.lineWidth = 6;
	this.text_25.parent = this;
	this.text_25.setTransform(14.7,39.95);

	this.text_26 = new cjs.Text("!#1", "4px 'Segoe Pro'", "#2E4747");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 7;
	this.text_26.lineWidth = 9;
	this.text_26.parent = this;
	this.text_26.setTransform(6.7,40.4);

	this.text_27 = new cjs.Text("m", "4px 'Segoe Pro'", "#2E4747");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 7;
	this.text_27.lineWidth = 6;
	this.text_27.parent = this;
	this.text_27.setTransform(52.35,31.05);

	this.text_28 = new cjs.Text("n", "4px 'Segoe Pro'", "#2E4747");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 7;
	this.text_28.lineWidth = 6;
	this.text_28.parent = this;
	this.text_28.setTransform(46.2,31.05);

	this.text_29 = new cjs.Text("b", "4px 'Segoe Pro'", "#2E4747");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 7;
	this.text_29.lineWidth = 6;
	this.text_29.parent = this;
	this.text_29.setTransform(39.8,31.05);

	this.text_30 = new cjs.Text("v", "4px 'Segoe Pro'", "#2E4747");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 7;
	this.text_30.lineWidth = 6;
	this.text_30.parent = this;
	this.text_30.setTransform(33.5,31.05);

	this.text_31 = new cjs.Text("c", "4px 'Segoe Pro'", "#2E4747");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 7;
	this.text_31.lineWidth = 6;
	this.text_31.parent = this;
	this.text_31.setTransform(27.15,31.05);

	this.text_32 = new cjs.Text("x", "4px 'Segoe Pro'", "#2E4747");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 7;
	this.text_32.lineWidth = 6;
	this.text_32.parent = this;
	this.text_32.setTransform(20.9,31.05);

	this.text_33 = new cjs.Text("z", "4px 'Segoe Pro'", "#2E4747");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 7;
	this.text_33.lineWidth = 6;
	this.text_33.parent = this;
	this.text_33.setTransform(14.6,31.05);

	this.text_34 = new cjs.Text("l", "4px 'Segoe Pro'", "#2E4747");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 7;
	this.text_34.lineWidth = 6;
	this.text_34.parent = this;
	this.text_34.setTransform(58.75,22.2);

	this.text_35 = new cjs.Text("k", "4px 'Segoe Pro'", "#2E4747");
	this.text_35.textAlign = "center";
	this.text_35.lineHeight = 7;
	this.text_35.lineWidth = 6;
	this.text_35.parent = this;
	this.text_35.setTransform(52.5,22.2);

	this.text_36 = new cjs.Text("j", "4px 'Segoe Pro'", "#2E4747");
	this.text_36.textAlign = "center";
	this.text_36.lineHeight = 7;
	this.text_36.lineWidth = 6;
	this.text_36.parent = this;
	this.text_36.setTransform(46.1,22.2);

	this.text_37 = new cjs.Text("h", "4px 'Segoe Pro'", "#2E4747");
	this.text_37.textAlign = "center";
	this.text_37.lineHeight = 7;
	this.text_37.lineWidth = 6;
	this.text_37.parent = this;
	this.text_37.setTransform(39.9,22.2);

	this.text_38 = new cjs.Text("g", "4px 'Segoe Pro'", "#2E4747");
	this.text_38.textAlign = "center";
	this.text_38.lineHeight = 7;
	this.text_38.lineWidth = 6;
	this.text_38.parent = this;
	this.text_38.setTransform(33.55,22.2);

	this.text_39 = new cjs.Text("f", "4px 'Segoe Pro'", "#2E4747");
	this.text_39.textAlign = "center";
	this.text_39.lineHeight = 7;
	this.text_39.lineWidth = 6;
	this.text_39.parent = this;
	this.text_39.setTransform(27.1,22.2);

	this.text_40 = new cjs.Text("d", "4px 'Segoe Pro'", "#2E4747");
	this.text_40.textAlign = "center";
	this.text_40.lineHeight = 7;
	this.text_40.lineWidth = 6;
	this.text_40.parent = this;
	this.text_40.setTransform(20.8,22.2);

	this.text_41 = new cjs.Text("s", "4px 'Segoe Pro'", "#2E4747");
	this.text_41.textAlign = "center";
	this.text_41.lineHeight = 7;
	this.text_41.lineWidth = 6;
	this.text_41.parent = this;
	this.text_41.setTransform(14.55,22.2);

	this.text_42 = new cjs.Text("a", "4px 'Segoe Pro'", "#2E4747");
	this.text_42.textAlign = "center";
	this.text_42.lineHeight = 7;
	this.text_42.lineWidth = 6;
	this.text_42.parent = this;
	this.text_42.setTransform(8.45,22.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_42},{t:this.text_41},{t:this.text_40},{t:this.text_39},{t:this.text_38},{t:this.text_37},{t:this.text_36},{t:this.text_35},{t:this.text_34},{t:this.text_33},{t:this.text_32},{t:this.text_31},{t:this.text_30},{t:this.text_29},{t:this.text_28},{t:this.text_27},{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

	// Layer_45
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2E4747").ss(0.3,1,1).p("AEKgKIAWAAQADAAAAADIAAAPQAAADgDAAIgWAAQgDAAgCgDIgHgIIAHgHQACgDADAAgAEXgEIgFAEIAFAFAENgEIAFAEIgFAFAkiAAIAOgPIAQAPIgJAAIAAAQIgMAAIAAgQg");
	this.shape.setTransform(33.7,30.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAFAFA").s().p("AD/DRQgKAAAAgKIAAg7QAAgKAKAAIAsAAQAKAAgBAKIAAA7QABAKgKAAgACzDRQgLAAAAgKIAAg7QAAgKALAAIAqAAQAKAAAAAKIAAA7QAAAKgKAAgAB1DRQgKAAAAgKIAAg7QAAgKAKAAIAeAAQALAAgBAKIAAA7QABAKgLAAgAhODRQgLAAABgKIAAg7QgBgKALAAIChAAQALAAgBAKIAAA7QABAKgLAAgAiMDRQgLAAABgKIAAg7QgBgKALAAIAeAAQALAAAAAKIAAA7QAAAKgLAAgAjLDRQgLAAABgKIAAg7QgBgKALAAIAeAAQALAAAAAKIAAA7QAAAKgLAAgAkrDRQgJAAgBgKIAAg7QABgKAJAAIA9AAQAKAAAAAKIAAA7QAAAKgKAAgAD0B4QgKAAAAgKIAAg7QAAgKAKAAIA3AAQAKAAgBAKIAAA7QABAKgKAAgAEABPIAHAJQADADACAAIAWAAQAAAAABAAQAAAAABgBQAAAAAAgBQAAAAAAgBIAAgQQAAgBAAgBQAAAAAAgBQgBAAAAAAQgBAAAAAAIgWAAIAWAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAABIAAAQQAAABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAIgWAAQgCAAgDgDIgHgJIAHgHQACgDADAAQgDAAgCADIgHAHgAEUBQIAFAFIgFgFIAFgFIgFAFgAEQBVIAEgFIgEgFIAEAFgACuB4QgKAAABgKIAAg7QgBgKAKAAIAgAAQAJAAABAKIAAA7QgBAKgJAAgABvB4QgKAAAAgKIAAg7QAAgKAKAAIAgAAQAJAAABAKIAAA7QgBAKgJAAgAAwB4QgKAAAAgKIAAg7QAAgKAKAAIAgAAQAJAAABAKIAAA7QgBAKgJAAgAgOB4QgLAAABgKIAAg7QgBgKALAAIAdAAQALAAAAAKIAAA7QAAAKgLAAgAhOB4QgKAAABgKIAAg7QgBgKAKAAIAfAAQALAAAAAKIAAA7QAAAKgLAAgAiMB4QgLAAABgKIAAg7QgBgKALAAIAeAAQALAAAAAKIAAA7QAAAKgLAAgAjLB4QgLAAABgKIAAg7QgBgKALAAIAeAAQALAAAAAKIAAA7QAAAKgLAAgAkrB4QgJAAgBgKIAAg7QABgKAJAAIA4AAQAJAAABAKIAAA7QgBAKgJAAgAkXBgIAMAAIAAgQIAKAAIgRgQIgNAQIAIAAIAAAQgAkXBgIAAgQIgIAAIANgQIARAQIgKAAIAAAQgAkfBQgADsAdQgKAAABgKIAAg5QgBgKAKAAIAfAAQALAAAAAKIAAA5QAAAKgLAAgACtAdQgKAAABgKIAAg5QgBgKAKAAIAfAAQALAAAAAKIAAA5QAAAKgLAAgABuAdQgKAAABgKIAAg5QgBgKAKAAIAfAAQALAAAAAKIAAA5QAAAKgLAAgAAwAdQgLAAABgKIAAg5QgBgKALAAIAeAAQALAAAAAKIAAA5QAAAKgLAAgAgOAdQgLAAABgKIAAg5QgBgKALAAIAdAAQALAAAAAKIAAA5QAAAKgLAAgAhOAdQgLAAABgKIAAg5QgBgKALAAIAeAAQAKAAAAAKIAAA5QAAAKgKAAgAiNAdQgLAAABgKIAAg5QgBgKALAAIAeAAQAKAAAAAKIAAA5QAAAKgKAAgAjMAdQgLAAABgKIAAg5QgBgKALAAIAeAAQAKAAAAAKIAAA5QAAAKgKAAgAkLAdQgLAAABgKIAAg5QgBgKALAAIAeAAQAKAAAAAKIAAA5QAAAKgKAAgAENg6QgLAAAAgKIAAg7QAAgKALAAIAfAAQAKAAgBAKIAAA7QABAKgKAAgADOg6QgLAAAAgKIAAg7QAAgKALAAIAeAAQALAAgBAKIAAA7QABAKgLAAgACPg6QgLAAAAgKIAAg7QAAgKALAAIAeAAQALAAgBAKIAAA7QABAKgLAAgABQg6QgLAAAAgKIAAg7QAAgKALAAIAeAAQALAAgBAKIAAA7QABAKgLAAgAARg6QgLAAAAgKIAAg7QAAgKALAAIAfAAQAKAAgBAKIAAA7QABAKgKAAgAgtg6QgLAAAAgKIAAg7QAAgKALAAIAfAAQAKAAgBAKIAAA7QABAKgKAAgAhug6QgJAAgBgKIAAg7QABgKAJAAIAgAAQAKAAgBAKIAAA7QABAKgKAAgAitg6QgJAAgBgKIAAg7QABgKAJAAIAgAAQAKAAgBAKIAAA7QABAKgKAAgAjsg6QgJAAgBgKIAAg7QABgKAJAAIAgAAQAKAAgBAKIAAA7QABAKgKAAgAkrg6QgJAAgBgKIAAg7QABgKAJAAIAgAAQAKAAAAAKIAAA7QAAAKgKAAgAENiTQgLAAAAgKIAAgpQAAgKALAAIAfAAQAKAAgBAKIAAApQABAKgKAAgADOiTQgLAAAAgKIAAgpQAAgKALAAIAeAAQALAAgBAKIAAApQABAKgLAAgACPiTQgLAAAAgKIAAgpQAAgKALAAIAeAAQALAAgBAKIAAApQABAKgLAAgABQiTQgLAAAAgKIAAgpQAAgKALAAIAeAAQALAAgBAKIAAApQABAKgLAAgAARiTQgLAAAAgKIAAgpQAAgKALAAIAfAAQAKAAgBAKIAAApQABAKgKAAgAgtiTQgLAAAAgKIAAgpQAAgKALAAIAfAAQAKAAgBAKIAAApQABAKgKAAgAhuiTQgJAAgBgKIAAgpQABgKAJAAIAgAAQAKAAgBAKIAAApQABAKgKAAgAitiTQgJAAgBgKIAAgpQABgKAJAAIAgAAQAKAAgBAKIAAApQABAKgKAAgAjsiTQgJAAgBgKIAAgpQABgKAJAAIAgAAQAKAAgBAKIAAApQABAKgKAAgAkriTQgJAAgBgKIAAgpQABgKAJAAIAgAAQAKAAAAAKIAAApQAAAKgKAAg");
	this.shape_1.setTransform(33.5,22.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DCDFE1").s().p("AlMDnIAAnNIKZAAIAAHNgAD1CDIAAA6QAAAKAKAAIArAAQAKAAAAgKIAAg6QAAgKgKAAIgrAAQgKAAAAAKgACoCDIAAA6QAAAKAKAAIArAAQAKAAAAgKIAAg6QAAgKgKAAIgrAAQgKAAAAAKgABqCDIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAhZCDIAAA6QAAAKAKAAICiAAQAKAAAAgKIAAg6QAAgKgKAAIiiAAQgKAAAAAKgAiXCDIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAjWCDIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAk1CDIAAA6QAAAKAKAAIA9AAQAKAAAAgKIAAg6QAAgKgKAAIg9AAQgKAAAAAKgADpAqIAAA6QAAAKAKAAIA3AAQAKAAAAgKIAAg6QAAgKgKAAIg3AAQgKAAAAAKgACkAqIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgABlAqIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAAmAqIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAgZAqIAAA6QAAAKAKAAIAeAAQAKAAAAgKIAAg6QAAgKgKAAIgeAAQgKAAAAAKgAhYAqIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAiXAqIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAjWAqIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgKgKAAIgfAAQgKAAAAAKgAk1AqIAAA6QAAAKAKAAIA3AAQAKAAAAgKIAAg6QAAgKgKAAIg3AAQgKAAAAAKgADigwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgACjgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgABkgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgAAlgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgAgZgwIAAA5QAAAKAKAAIAeAAQAKAAAAgKIAAg5QAAgKgKAAIgeAAQgKAAAAAKgAhZgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgAiYgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgAjXgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgAkWgwIAAA5QAAAKAKAAIAfAAQAKAAAAgKIAAg5QAAgKgKAAIgfAAQgKAAAAAKgAECiIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgADDiIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgACEiIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgABFiIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAAGiIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAg4iIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAh4iIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAi3iIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAj2iIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAk1iIIAAA6QAAAKAKAAIAfAAQAKAAAAgKIAAg6QAAgLgKABIgfAAQgKgBAAALgAECjPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgADDjPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgACEjPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgABFjPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgAAGjPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgAg4jPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgAh4jPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgAi3jPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgAj2jPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALgAk1jPIAAAoQAAAKAKAAIAfAAQAKAAAAgKIAAgoQAAgLgKABIgfAAQgKgBAAALg");
	this.shape_2.setTransform(33.55,23.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.keyboard_sub, new cjs.Rectangle(0,0.5,66.9,48.9), null);


(lib.iconportal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgwAoIAAhOIBhAAIAABOg");
	mask.setTransform(7.125,6.45);

	// Layer_1
	this.instance = new lib.will();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.3739,0.3739);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.iconportal, new cjs.Rectangle(2.2,2.5,9.899999999999999,7.9), null);


(lib.icon_WD = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgHAJIAAgRIAGAAQAEAAACACQACADABADIgBAEIgEAEIgEABgAgDAGIACAAQABAAAAAAQAAAAABAAQAAAAABgBQAAAAAAAAQADgCAAgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQgCgBgCAAIgCAAg");
	this.shape.setTransform(4.65,2.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAEAJIgEgLIAAgCIAAABIAAABIgCALIgEAAIgFgRIADAAIAEAMIAAACIABgCIADgMIACAAIADAMIABACIAAgCIADgMIADAAIgFARg");
	this.shape_1.setTransform(2.5,2.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#148489").s().p("AghAdIAAg5IBCAAIAAA5g");
	this.shape_2.setTransform(3.35,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon_WD, new cjs.Rectangle(-0.7,-1.2,10,7.4), null);


(lib.icon_FS = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAJIgBgBIAAgDIACABIACABIABgBIABgCIgBgBIgCgCIgCgBIgBgDIAAgDIACgBIACgBIADAAIABABIAAADIgBgBIgCgBIgCABIAAACIAAABIABABIABABIADABIABADQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAIgDAAg");
	this.shape.setTransform(3.575,2.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEAJIAAgRIAJAAIAAADIgGAAIAAAFIAFAAIAAABIgFAAIAAAIg");
	this.shape_1.setTransform(2.325,2.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DA3E04").s().p("AghAdIAAg5IBCAAIAAA5g");
	this.shape_2.setTransform(3.35,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon_FS, new cjs.Rectangle(-0.3,-1.2,10,7.4), null);


(lib.icon_folder = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcAUIAAgnIAYAAIADAJIAeAAIAAAeg");
	this.shape.setTransform(3.375,2.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#57AF4A").s().p("AghAdIAAg5IBCAAIAAA5gAgcAVIA5AAIAAgeIgeAAIgDgJIgYAAg");
	this.shape_1.setTransform(3.35,2.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon_folder, new cjs.Rectangle(0,0,6.7,5.8), null);


(lib.topbar_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Search or type a command", "3px 'Segoe Pro'", "#404D60");
	this.txt.name = "txt";
	this.txt.lineHeight = 6;
	this.txt.lineWidth = 36;
	this.txt.parent = this;
	this.txt.setTransform(132.5,5.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(268.7086,6.2662,0.1789,0.1789);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_1.setTransform(268.7086,6.2684,0.1789,0.1789);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4A5483").s().p("AgxAyQgVgVAAgdQAAgcAVgVQAVgVAcAAQAdAAAVAVQAVAUAAAdQAAAdgVAVQgVAVgdAAQgdAAgUgVg");
	this.shape_2.setTransform(268.7086,6.2684,0.1789,0.1789);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.1).p("AqsAfIVZAAQADAAACgDQABgBAAgCIAAgxQAAgCgBgCQgCgCgDAAI1ZAAQgCAAgCACQgCACAAACIAAAxQAAACACABQACADACAAg");
	this.shape_3.setTransform(150.0749,4.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EAEEF0").s().p("AqsAeQAAAAgBAAQgBAAAAAAQgBAAAAgBQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAIAAgxQAAAAAAgBQAAAAAAgBQABAAAAgBQAAgBABAAQAAAAABgBQAAAAABAAQAAAAABAAQABAAAAAAIVZAAQABAAAAAAQABAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABABAAAAQAAABAAAAQAAABAAAAIAAAxQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAg");
	this.shape_4.setTransform(150.0749,4.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FDFEFE").s().p("AAkBdIhVhWQgDgDAAgEQAAgDADgDIBVhWQADgDAEAAQAEAAADADQADADAAAEQAAAEgDADIhOBOIBOBPQADADAAAEQAAAEgDADQgDADgEAAQgEAAgDgDg");
	this.shape_5.setTransform(3.1539,4.1427,0.1793,0.1793);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FDFEFE").s().p("AgxBdQgDgDAAgEQAAgEADgDIBOhPIhOhOQgDgDAAgEQAAgEADgDQADgDAEAAQAEAAADADIBVBWQADADAAADQAAAEgDADIhVBWQgDADgEAAQgEAAgDgDg");
	this.shape_6.setTransform(10.8448,4.1427,0.1793,0.1793);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2BHQgHAAgFgGQgGgFAAgIIAAhnQAAgIAGgFQAFgFAHAAIA5AAIAAAKIg5AAQgHAAgBAIIAABnQABAIAHAAIBsAAQAJAAgBgIIAAg0IALAAIAAA0QAAAIgFAFQgGAGgIAAg");
	this.shape_7.setTransform(74.7923,4.3309,0.1793,0.1793);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag6A5QgCgDABgDIAJgeIBLhLQAFgFAGAAQAGAAAEAFIAKAKQAFAEAAAHQAAAGgFAEIhMBMIggAGIgBABQgDAAgCgDgAAggvIhJBJIgHAWIAYgEIBJhKQAEgDgEgDIgKgLQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAAAAAIgEACg");
	this.shape_8.setTransform(75.2247,3.7322,0.1789,0.1789);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAAANIg8A8IgMgMIA8g9Ig8g8IAMgMIA8A9IA9g9IAMAMIg9A8IA9A9IgMAMg");
	this.shape_9.setTransform(295.5146,4.1106,0.1793,0.1793);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhMBOIAAh9IAZAAIAAgeICAAAIAAB/IgbAAIAAAcgAhEBHIBuAAIAAhvIhuAAgAgsgvIBeAAIAABaIATAAIAAhxIhxAAg");
	this.shape_10.setTransform(286.3529,4.1516,0.1793,0.1793);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhIAKIAAgTICQAAIAAATg");
	this.shape_11.setTransform(276.6184,4.0274,0.1789,0.1789);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4A5483").s().p("A3bAoIAAhQMAu3AAAIAABQgASAgUQgJAJAAAMQAAANAJAIQAJAKAMgBQANABAJgKQAJgIAAgNQAAgMgJgJQgJgIgNgBQgMABgJAIg");
	this.shape_12.setTransform(149.9749,4.05);

	this.instance = new lib.topbar_lady();
	this.instance.parent = this;
	this.instance.setTransform(263.85,0.3,0.1281,0.1281);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.txt}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.topbar_c, new cjs.Rectangle(0,0,300,17.2), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.wide_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow_sub.cache(0,0,390,390,.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow_sub = new lib.wide_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(194.5,194.5,1,1,0,0,0,194.5,194.5);
	this.shadow_sub.alpha = 0.8008;

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.wide_shadow, new cjs.Rectangle(0,0,389,389), null);


(lib.txt_09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.Kayo();
	this.instance.parent = this;
	this.instance.setTransform(-11,1,0.2257,0.2257);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(-5.2979,7.2615,0.1788,0.1788);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_1.setTransform(-4.5867,7.28,0.1793,0.1793);

	this.txt2 = new cjs.Text("1/28  1:23 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 24;
	this.txt2.parent = this;
	this.txt2.setTransform(21,4.9);

	this.txt1 = new cjs.Text("Kayo Minwa", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 21;
	this.txt1.parent = this;
	this.txt1.setTransform(2.2,4.9);

	this.txt3 = new cjs.Text("It would be great to sync with you both by EOD to have a quick run through, thanks!", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 6;
	this.txt3.lineWidth = 126;
	this.txt3.parent = this;
	this.txt3.setTransform(2.2,8.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt3},{t:this.txt1},{t:this.txt2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_2.setTransform(7.5633,57.63,0.1793,0.1793);

	this.instance_1 = new lib.Chris();
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.3,48.5,0.23,0.23);

	this.txt4 = new cjs.Text("Simon Tagg", "3px 'Segoe Pro'");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 5;
	this.txt4.lineWidth = 17;
	this.txt4.parent = this;
	this.txt4.setTransform(11.75,51.95);

	this.txt5 = new cjs.Text("1:17 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 5;
	this.txt5.lineWidth = 21;
	this.txt5.parent = this;
	this.txt5.setTransform(29.05,52.25);

	this.txt6 = new cjs.Text("This is ok with me! Speak later.", "3px 'Segoe Pro'", "#293549");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 4;
	this.txt6.lineWidth = 131;
	this.txt6.parent = this;
	this.txt6.setTransform(11.4,56.6);

	this.txt_07 = new lib.txt_08();
	this.txt_07.name = "txt_07";
	this.txt_07.parent = this;
	this.txt_07.setTransform(35.05,23.4,1,1,0,0,0,21.8,8.8);

	this.txt_11 = new lib.txt_11();
	this.txt_11.name = "txt_11";
	this.txt_11.parent = this;
	this.txt_11.setTransform(34.85,40.4,1,1,0,0,0,21.8,8.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FAFAF7").s().p("AryEBQgGABAAgFIAAn5QAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABgBIAEgBIXmAAQAFABAAAEIAAH5QAAAFgFgBg");
	this.shape_3.setTransform(74.925,38.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AryA7QgGAAAAgIIAAhmQAAgDABgDQABAAAAAAQABAAAAgBQABAAABAAQAAAAABAAIXlAAQAGAAAAAHIAABmQAAAIgGAAg");
	this.shape_4.setTransform(75.05,5.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.txt_11},{t:this.txt_07},{t:this.txt6},{t:this.txt5},{t:this.txt4},{t:this.instance_1},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_09, new cjs.Rectangle(-11,0.1,162.2,68.60000000000001), null);


(lib.txt_06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape.setTransform(6.5133,29.08,0.1793,0.1793);

	this.instance = new lib.Chris();
	this.instance.parent = this;
	this.instance.setTransform(1.25,22.15,0.23,0.23);

	this.txt4 = new cjs.Text("Simon Tagg", "3px 'Segoe Pro'");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 5;
	this.txt4.lineWidth = 17;
	this.txt4.parent = this;
	this.txt4.setTransform(10.7,25);

	this.txt5 = new cjs.Text("1:17 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 5;
	this.txt5.lineWidth = 21;
	this.txt5.parent = this;
	this.txt5.setTransform(28.85,25.3);

	this.txt6 = new cjs.Text("The goal is still for each local marketing team to be able to target audience segments.", "3px 'Segoe Pro'", "#293549");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 4;
	this.txt6.lineWidth = 131;
	this.txt6.parent = this;
	this.txt6.setTransform(10.35,29.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAVIgOgPQgEgDAEgDQADgDAEADIAMALIAfgfQAEgEADAEQAEADgEAEIgiAiQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape_1.setTransform(-5.429,8.313,0.1788,0.1788);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#82BE4D").s().p("AgoApQgRgRAAgYQAAgXARgRQARgRAXAAQAYAAARARQARARAAAXQAAAYgRARQgRARgYAAQgXAAgRgRg");
	this.shape_2.setTransform(-4.7867,8.33,0.1793,0.1793);

	this.instance_1 = new lib.will();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-11,2,0.2164,0.2164);

	this.txt3 = new cjs.Text("That's great! I will collate all the materials from the media agency for buying locations, footfall verses media costs. I will presume the plan is still to look for live locations to bring the campaign to life.", "3px 'Segoe Pro'", "#293549");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 4;
	this.txt3.lineWidth = 135;
	this.txt3.parent = this;
	this.txt3.setTransform(2.15,8.8);

	this.txt2 = new cjs.Text("1/28  1:16 PM", "3px 'Segoe Pro'", "#969CA6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 23;
	this.txt2.parent = this;
	this.txt2.setTransform(21.7,5.15);

	this.txt1 = new cjs.Text("Will Sheradon", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 21;
	this.txt1.parent = this;
	this.txt1.setTransform(2.15,5.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.instance_1},{t:this.shape_2},{t:this.shape_1},{t:this.txt6},{t:this.txt5},{t:this.txt4},{t:this.instance},{t:this.shape}]}).wait(1));

	// Layer_4
	this.txt_07 = new lib.txt_07();
	this.txt_07.name = "txt_07";
	this.txt_07.parent = this;
	this.txt_07.setTransform(34.05,43,1,1,0,0,0,21.8,8.8);

	this.timeline.addTween(cjs.Tween.get(this.txt_07).wait(1));

	// Layer_3
	this.txt7 = new cjs.Text("Reply", "3px 'Segoe Pro'", "#293549");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 6;
	this.txt7.lineWidth = 15;
	this.txt7.parent = this;
	this.txt7.setTransform(1.8,52.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FAFAF7").s().p("AryCzQgGgBAAgEIAAlbQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAABgBIAEgBIXmAAQAFABAAAEIAAFbQAAAEgFABg");
	this.shape_3.setTransform(74.925,37.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ArxBcQgDAAgBgDQgDgEAAgFIAAifQAAgGADgDQABgDADAAIXjAAQAHAAAAAMIAACfQAAAMgHAAg");
	this.shape_4.setTransform(74.925,9.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.txt7}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt_06, new cjs.Rectangle(-11,0.7,162.1,59.699999999999996), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.press_sub.cache(-3,-5,10,15,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.press_sub = new lib.press_sub();
	this.press_sub.name = "press_sub";
	this.press_sub.parent = this;
	this.press_sub.setTransform(0,0.05,1,1,0,0,0,2.5,4);

	this.timeline.addTween(cjs.Tween.get(this.press_sub).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-3.9,5.1,7.9);


(lib.TopBar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.topbar.cache(-300,-20,600,40,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// topbar
	this.topbar = new lib.topbar_c();
	this.topbar.name = "topbar";
	this.topbar.parent = this;
	this.topbar.setTransform(-4.85,4.3,1,1,0,0,0,150,8.6);

	this.timeline.addTween(cjs.Tween.get(this.topbar).wait(1));

}).prototype = getMCSymbolPrototype(lib.TopBar, new cjs.Rectangle(-154.8,-4.3,299.9,17.2), null);


(lib.sidebar_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt4 = new cjs.Text("Files", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt4.name = "txt4";
	this.txt4.textAlign = "center";
	this.txt4.lineHeight = 5;
	this.txt4.lineWidth = 9;
	this.txt4.parent = this;
	this.txt4.setTransform(6.7,63.55);

	this.txt3 = new cjs.Text("Meetings", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.textAlign = "center";
	this.txt3.lineHeight = 5;
	this.txt3.lineWidth = 9;
	this.txt3.parent = this;
	this.txt3.setTransform(6.85,52.15);

	this.txt2 = new cjs.Text("Teams", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.textAlign = "center";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 7;
	this.txt2.parent = this;
	this.txt2.setTransform(6.7,40.8);

	this.txt1 = new cjs.Text("Chat", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt1.name = "txt1";
	this.txt1.textAlign = "center";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 7;
	this.txt1.parent = this;
	this.txt1.setTransform(6.7,29.35);

	this.txt = new cjs.Text("Activity", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 7;
	this.txt.parent = this;
	this.txt.setTransform(6.7,18);

	this.instance = new lib.Notification();
	this.instance.parent = this;
	this.instance.setTransform(9.75,11.9,1,1,0,0,0,1.7,1.7);

	this.instance_1 = new lib.Notification_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(9.75,23.35,1,1,0,0,0,1.7,1.7);

	this.instance_2 = new lib.Notification_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(9.75,34.75,1,1,0,0,0,1.7,1.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgTATQgIgIAAgLQAAgLAIgHQAJgJAKAAQAMAAAIAJQAIAHAAALQAAALgIAIQgIAJgMgBQgKABgJgJg");
	this.shape.setTransform(8.6319,72.15,0.1818,0.1818);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTATQgIgIAAgLQAAgLAIgHQAIgJALAAQALAAAJAJQAIAHAAALQAAALgIAIQgJAJgLgBQgKABgJgJg");
	this.shape_1.setTransform(7.1228,72.15,0.1818,0.1818);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgTATQgIgIAAgLQAAgLAIgHQAIgJALAAQALAAAJAJQAIAHAAALQAAALgIAIQgJAJgLgBQgKABgJgJg");
	this.shape_2.setTransform(5.6046,72.15,0.1818,0.1818);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhQBVQgLAAgEgJQgEgHAFgHIAWgVIAAg3QAAgRAHgNQAIgSASgLQARgLAVAAIABAAQAUAAASALQARALAJASQAGANAAARIAAA3IAYAUQAGAGgEAJQgEAJgLAAgAhWBEIAAAEQABADAFAAIChAAQAFAAABgDQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAgBgBIgagVIAAg8QAAgOgGgMQgHgPgPgJQgPgKgRAAIgBAAQgSAAgPAKQgPAJgHAPQgGANAAANIAAA+IgDAAg");
	this.shape_3.setTransform(7.2504,13.6538,0.1783,0.1783);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgWANQgJgHgEgLQgCgEADgGQADgFAHABIAxAAQAGgBAEAFQADAGgCAEQgDALgLAHQgKAIgMgBQgMABgKgIgAgagJIAAACQADAHAIAFQAHAGAIAAQAJAAAHgGQAIgFADgHIAAgCIgCAAIgxAAg");
	this.shape_4.setTransform(7.2499,15.8698,0.1783,0.1783);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABeBwIgqgqQgVACgcAAQgpAAgxgFQgJgCgGgHQgHgHAAgJIAAiDQAAgKAIgHQAHgIAKAAICpAAQAKAAAIAIQAHAHAAAKIAADDQAAAGgGACIgEABQgDAAgDgDgAg0AAIBDAAIAAgOIhDAAgAg0gqIBpAAIAAgPIhpAAg");
	this.shape_5.setTransform(6.929,25.364,0.179,0.179);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQARIAAghIAhAAIAAAhg");
	this.shape_6.setTransform(8.0188,47.7132,0.1783,0.1783);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgQARIAAghIAhAAIAAAhg");
	this.shape_7.setTransform(7.2386,48.5425,0.1783,0.1783);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQARIAAghIAhAAIAAAhg");
	this.shape_8.setTransform(6.4583,48.5425,0.1783,0.1783);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQARIAAghIAhAAIAAAhg");
	this.shape_9.setTransform(7.2386,47.7132,0.1783,0.1783);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgQARIAAghIAhAAIAAAhg");
	this.shape_10.setTransform(6.4583,47.7132,0.1783,0.1783);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhOBfQgSgJgCgHIgBgBIAAiKQAAgHAFgFQAEgEAHAAIAoAAIAAgYQAAgDADgBQACgDADAAQAHAAAAAHIAAAYIA6AAIAAgYQAAgDACgBQACgDADAAQADAAADADQACABAAADIAAAYIAnAAQAHAAAEAEQAFAFAAAHIAACLQgFAIgNAIQgaANgxAAQg2AAgfgNgAhZg8IAACIQAXAWBJAAQApAAAXgKQAOgGAFgGIAAiIQAAgHgGAAIgnAAIAAATQAAADgCADQgDACgDAAQgDAAgCgCQgCgDAAgDIAAgTIg6AAIAAATQAAAIgHAAQgDAAgCgCQgDgDAAgDIAAgTIgoAAQgGAAAAAHg");
	this.shape_11.setTransform(7.2341,47.9183,0.1783,0.1783);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag9ByQgKAAgGgHQgIgHABgKIAAiKIBBhBIBRAAQAJAAAHAHQAIAHAAAKIAACzQAAAKgIAHQgHAHgJAAgAhKBaQgBAFAEAFQAFAEAFAAIB7AAQAFAAAEgEQAFgFAAgFIAAizQAAgFgFgFQgEgEgFAAIhEAAIAAA8QAAAEgEADQgDAEgFAAIg4AAgAhKgrIAAABIA4AAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAg7g");
	this.shape_12.setTransform(7.0408,59.5722,0.179,0.179);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AggAnIAAgNIAHABIAXAAQAJAAAGgHQAHgGAAgLIAAgdIg0AAIAAgNIBBAAIAAAqQAAAQgLAKQgKAKgOAAg");
	this.shape_13.setTransform(8.7679,37.1998,0.1783,0.1783);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAWQgJgJAAgNQAAgMAJgIQAJgKAMABQANgBAJAKQAJAIAAAMQAAANgJAJQgJAIgNABQgMgBgJgIgAgMgLQgFAEAAAHQAAAHAFAGQAGAFAGAAQAIAAAFgFQAFgGAAgHQAAgHgFgEQgFgGgIAAQgGAAgGAGg");
	this.shape_14.setTransform(8.7322,35.7463,0.1783,0.1783);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgVAdQgLgKAAgQIAAgqIBBAAIAAANIg0AAIAAAdQAAALAHAGQAHAHAIAAIAXAAIAHgBIAAANIgeAAQgNAAgLgKg");
	this.shape_15.setTransform(5.5042,37.1998,0.1783,0.1783);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgVAWQgJgJAAgNQAAgMAJgIQAJgKAMABQANgBAJAKQAJAIAAAMQAAANgJAJQgJAIgNABQgMgBgJgIgAgMgLQgFAEAAAHQAAAHAFAGQAGAFAGAAQAIAAAFgFQAFgGAAgHQAAgHgFgEQgFgGgIAAQgGAAgGAGg");
	this.shape_16.setTransform(5.5042,35.7463,0.1783,0.1783);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgUAWQgJgJAAgNQAAgLAJgJQAIgKAMABQANgBAIAKQAJAJAAALQAAANgJAJQgIAIgNABQgMgBgIgIgAgLgLQgGAEAAAHQAAAHAGAGQAEAFAHAAQAIAAAFgFQAFgGAAgHQAAgHgFgEQgFgGgIAAQgHAAgEAGg");
	this.shape_17.setTransform(7.1226,35.5234,0.1783,0.1783);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgIA9QgOAAgLgLQgLgKAAgPIAAhVIBYAAIAABVQABAPgLAKQgKALgQAAgAgfAZQAAAKAHAGQAHAIAJgBIAQAAQALABAGgIQAHgGAAgKIAAhJIg/AAg");
	this.shape_18.setTransform(7.1226,37.3603,0.1783,0.1783);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#585EA8").s().p("AlzFAIAAp/ILnAAIAAJ/g");
	this.shape_19.setTransform(7.4682,27.5838,0.1783,0.1783);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#A4A5D2").s().p("AgWFAIAAp/IAtAAIAAJ/g");
	this.shape_20.setTransform(0.4147,27.5838,0.1783,0.1783);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3B4657").s().p("AhGNtIAA7ZICNAAIAAbZg");
	this.shape_21.setTransform(7.075,87.6748);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.sidebar_c, new cjs.Rectangle(0,0,17.2,175.4), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow_sub.cache(0,0,325,50,.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow_sub = new lib.shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(162.8,43.7,1,1,0,0,0,162.8,43.7);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,325.6,50), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.press_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_11 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(11).call(this.frame_11).wait(1));

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(2.5,3.95);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.5},2,cjs.Ease.cubicIn).to({alpha:0},9,cjs.Ease.cubicOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.1,8);


(lib.Notification_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.notifications.cache(-18,-175,36,350,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.notifications = new lib.sidebar_c();
	this.notifications.name = "notifications";
	this.notifications.parent = this;
	this.notifications.setTransform(8.6,87.7,1,1,0,0,0,8.6,87.7);

	this.timeline.addTween(cjs.Tween.get(this.notifications).wait(1));

}).prototype = getMCSymbolPrototype(lib.Notification_bar, new cjs.Rectangle(0,0,17.2,175.4), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mobile_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mbl_screen.cache(-140,-250,280,500,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mbl_screen = new lib.mobile_Screen_c();
	this.mbl_screen.name = "mbl_screen";
	this.mbl_screen.parent = this;
	this.mbl_screen.setTransform(-0.5,0,1,1,0,0,0,69.9,124.7);

	this.timeline.addTween(cjs.Tween.get(this.mbl_screen).wait(1));

}).prototype = getMCSymbolPrototype(lib.mobile_screen, new cjs.Rectangle(-71.9,97.2,142.8,27.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_54 = function() {
		exportRoot.tl1.play()
	}
	this.frame_75 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(21).call(this.frame_75).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(151.95,125,0.1053,0.1053,0,0,0,-38.5,2.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:1.7421,scaleY:1.7421,x:151.85,y:124.85},13,cjs.Ease.quadOut).to({x:82.7},12,cjs.Ease.quadInOut).to({_off:true},1).wait(49));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("ACdLPIAAl4IWJAAIAAF4g");
	var mask_graphics_15 = new cjs.Graphics().p("ACYLPIAAl4IWJAAIAAF4g");
	var mask_graphics_16 = new cjs.Graphics().p("ACKLPIAAl4IWIAAIAAF4g");
	var mask_graphics_17 = new cjs.Graphics().p("AByLPIAAl4IWIAAIAAF4g");
	var mask_graphics_18 = new cjs.Graphics().p("ABQLPIAAl4IWIAAIAAF4g");
	var mask_graphics_19 = new cjs.Graphics().p("AAkLPIAAl4IWJAAIAAF4g");
	var mask_graphics_20 = new cjs.Graphics().p("AgQLPIAAl4IWIAAIAAF4g");
	var mask_graphics_21 = new cjs.Graphics().p("AhFLPIAAl4IWIAAIAAF4g");
	var mask_graphics_22 = new cjs.Graphics().p("AhwLPIAAl4IWHAAIAAF4g");
	var mask_graphics_23 = new cjs.Graphics().p("AiSLPIAAl4IWHAAIAAF4g");
	var mask_graphics_24 = new cjs.Graphics().p("AiqLPIAAl4IWHAAIAAF4g");
	var mask_graphics_25 = new cjs.Graphics().p("Ai5LPIAAl4IWIAAIAAF4g");
	var mask_graphics_26 = new cjs.Graphics().p("Ai+LPIAAl4IWHAAIAAF4g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:157.366,y:71.9016}).wait(1).to({graphics:mask_graphics_15,x:156.883,y:71.9016}).wait(1).to({graphics:mask_graphics_16,x:155.4339,y:71.9016}).wait(1).to({graphics:mask_graphics_17,x:153.0189,y:71.9016}).wait(1).to({graphics:mask_graphics_18,x:149.6378,y:71.9016}).wait(1).to({graphics:mask_graphics_19,x:145.2908,y:71.9016}).wait(1).to({graphics:mask_graphics_20,x:139.9777,y:71.9016}).wait(1).to({graphics:mask_graphics_21,x:134.6646,y:71.9016}).wait(1).to({graphics:mask_graphics_22,x:130.3175,y:71.9016}).wait(1).to({graphics:mask_graphics_23,x:126.9365,y:71.9016}).wait(1).to({graphics:mask_graphics_24,x:124.5215,y:71.9016}).wait(1).to({graphics:mask_graphics_25,x:123.0724,y:71.9016}).wait(1).to({graphics:mask_graphics_26,x:122.541,y:71.9016}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.parent = this;
	this.instance_1.setTransform(83.25,122.9,1.7421,1.7421,0,0,0,0.3,0.3);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({regX:0.2,x:152.75},12,cjs.Ease.quadInOut).to({_off:true},25).wait(25));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(152.75,122.9,1.7421,1.7421,0,0,0,0.2,0.3);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({_off:false},0).to({regX:0.8,regY:0.9,scaleX:0.683,scaleY:0.683,x:50.4,y:22.55},21,cjs.Ease.cubicInOut).to({_off:true},1).wait(3));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(131.4,113.9,1,1,0,0,0,131.4,113.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},72).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(13.6,1,1.0009,1.0001);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3597,7.077,1.0009,1.0001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6702,7.077,1.0009,1.0001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3597,-4.2244,1.0009,1.0001);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6702,-4.2244,1.0009,1.0001);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.laptop_shadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow_sub.cache(0,0,390,390,.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow_sub = new lib.laptop_shadow_2_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(194.5,194.5,1,1,0,0,0,194.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_shadow_2, new cjs.Rectangle(0,0,389,389), null);


(lib.keyboard = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		for (var i= 0; i < this.keyboard_sub.getNumChildren(); i++) {
		    var child = this.keyboard_sub.getChildAt(i);
			if (child.text) {
				child.textBaseline = "alphabetic"
			}
		}
		
		this.keyboard_sub.cache(-1,-3,70,50,1);
		this.stop;
	}
	this.frame_115 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(115).call(this.frame_115).wait(1));

	// Layer_4
	this.instance = new lib.press_anim("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(23.7,12.3,1,1,0,0,0,2.5,4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(34).to({_off:false},0).wait(8).to({x:7.95,y:21.15},0).wait(8).to({x:14.3,y:39.1},0).to({_off:true},8).wait(7).to({_off:false,x:61.6,y:12.3},0).wait(8).to({x:7.9,y:21.15},0).to({_off:true},8).wait(9).to({_off:false,x:39.55,y:21.1},0).wait(8).to({x:45.9,y:30.15},0).to({_off:true},8).wait(10));

	// Layer_1
	this.instance_1 = new lib.press_anim("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(33.2,21.15,1,1,0,0,0,2.5,4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(31).to({_off:false},0).wait(8).to({x:17.4,y:12.3},0).wait(8).to({x:30.1},0).to({_off:true},8).wait(5).to({_off:false,x:14.2,y:21.15},0).wait(8).to({x:17.4,y:12.35},0).wait(8).to({x:52.15,y:21.15},0).to({_off:true},8).wait(2).to({_off:false,x:30.15,y:12.3},0).wait(8).to({x:17.4},0).to({_off:true},8).wait(5).to({_off:false,scaleX:1.2574,x:60.95,y:39.15},0).to({_off:true},8).wait(1));

	// Layer_2
	this.keyboard_sub = new lib.keyboard_sub();
	this.keyboard_sub.name = "keyboard_sub";
	this.keyboard_sub.parent = this;
	this.keyboard_sub.setTransform(33.15,22.85,1,1,0,0,0,33.4,23.3);

	this.timeline.addTween(cjs.Tween.get(this.keyboard_sub).wait(116));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,66.8,48.9);


(lib.icon_teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x1500();
	this.instance.parent = this;
	this.instance.setTransform(29.75,34.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.parent = this;
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.parent = this;
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.Contacts_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// contacts
	this.instance = new lib.icon_FS();
	this.instance.parent = this;
	this.instance.setTransform(8.4,135.15,1,1,0,0,0,3.4,2.9);

	this.instance_1 = new lib.icon_WD();
	this.instance_1.parent = this;
	this.instance_1.setTransform(8.2,120.15,1,1,0,0,0,3.4,2.9);

	this.instance_2 = new lib.icon_folder();
	this.instance_2.parent = this;
	this.instance_2.setTransform(8.55,69.3,1,1,0,0,0,3.4,2.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// txt
	this.instance_3 = new lib.iconportal();
	this.instance_3.parent = this;
	this.instance_3.setTransform(8,13.6,0.8,0.8,0,0,0,7.3,7.2);

	this.txt6 = new cjs.Text("...", "10px 'Segoe Pro'");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 15;
	this.txt6.lineWidth = 61;
	this.txt6.parent = this;
	this.txt6.setTransform(55.55,135.0001);

	this.txt5 = new cjs.Text("...", "10px 'Segoe Pro'");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 15;
	this.txt5.lineWidth = 61;
	this.txt5.parent = this;
	this.txt5.setTransform(55.55,120.8001);

	this.txt4 = new cjs.Text("...", "10px 'Segoe Pro'");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 15;
	this.txt4.lineWidth = 61;
	this.txt4.parent = this;
	this.txt4.setTransform(55.55,106.8001);

	this.txt3 = new cjs.Text("...", "10px 'Segoe Pro'");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 15;
	this.txt3.lineWidth = 61;
	this.txt3.parent = this;
	this.txt3.setTransform(55.55,56.8001);

	this.txt1 = new cjs.Text("Favorites", "3px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 6;
	this.txt1.lineWidth = 61;
	this.txt1.parent = this;
	this.txt1.setTransform(4.85,7.1501);

	this.txt2 = new cjs.Text("Store Portal\nGeneral \nInventory\nOnline\nPromotions\nSales\nStore Layout\n\nRenewal\nGeneral\nCustomers\nInvoicing\nProposals\nSafetly Training\n\nWarehouse #02\n\nField Service", "4px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.lineWidth = 61;
	this.txt2.parent = this;
	this.txt2.setTransform(13.8,15.1001);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt2},{t:this.txt1},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.instance_3}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlONYIAA6vIKdAAIAAavg");
	this.shape.setTransform(33.5,85.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Contacts_box, new cjs.Rectangle(0,0,118.6,188.5), null);


(lib.Contacts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.Contacts.cache(-90,-175,180,350,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Contacts
	this.Contacts = new lib.Contacts_box();
	this.Contacts.name = "Contacts";
	this.Contacts.parent = this;
	this.Contacts.setTransform(3.2,6.4,1,1,0,0,0,33.5,85.6);

	this.timeline.addTween(cjs.Tween.get(this.Contacts).wait(1));

}).prototype = getMCSymbolPrototype(lib.Contacts, new cjs.Rectangle(-30.3,-79.2,118.6,188.5), null);


(lib.Chat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.txt_05 = new lib.txt_05();
	this.txt_05.name = "txt_05";
	this.txt_05.parent = this;
	this.txt_05.setTransform(138.45,31.1,1,1,0,0,0,49.6,6.8);

	this.timeline.addTween(cjs.Tween.get(this.txt_05).wait(1));

	// Layer_1
	this.txt_04 = new lib.txt_04();
	this.txt_04.name = "txt_04";
	this.txt_04.parent = this;
	this.txt_04.setTransform(32.8,7,1,1,0,0,0,21.8,8.8);

	this.txt_06 = new lib.txt_06();
	this.txt_06.name = "txt_06";
	this.txt_06.parent = this;
	this.txt_06.setTransform(32.8,54.6,1,1,0,0,0,21.8,8.8);

	this.txt_09 = new lib.txt_09();
	this.txt_09.name = "txt_09";
	this.txt_09.parent = this;
	this.txt_09.setTransform(32.8,113.8,1,1,0,0,0,21.8,8.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_09},{t:this.txt_06},{t:this.txt_04}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Chat, new cjs.Rectangle(0,0,162.2,173.7), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.parent = this;
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.Side_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Contacts
	this.instance = new lib.Contacts();
	this.instance.parent = this;
	this.instance.setTransform(37.8,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// sidebar
	this.instance_1 = new lib.Notification_bar();
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.15,-11.25,1,1,0,0,0,8.6,87.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Side_bar, new cjs.Rectangle(-6.4,-98.9,132.5,193.2), null);


(lib.Phone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.phone.cache(0,0,73,134,1.5)
		this.phone_shadow.cache(0,0,150,15,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_10 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEASIAAgjIKJAAIAAAjg");
	mask.setTransform(36.5,9.85);

	// Layer_9
	this.instance = new lib.mobileScr();
	this.instance.parent = this;
	this.instance.setTransform(36.4,79.45,0.4659,0.4659,0,0,0,70.3,153.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AlEJEIAAyHIKJAAIAASHg");
	mask_1.setTransform(36.5,66);

	// Layer_13
	this.keyboard = new lib.keyboard();
	this.keyboard.name = "keyboard";
	this.keyboard.parent = this;
	this.keyboard.setTransform(36.5,102.1,1,1,0,0,0,33.3,23.1);

	var maskedShapeInstanceList = [this.keyboard];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.keyboard).wait(1));

	// Layer_6
	this.instance_1 = new lib.mobile_screen();
	this.instance_1.parent = this;
	this.instance_1.setTransform(36.9,65.35,0.47,0.47,0,0,0,0.2,0.1);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_7
	this.mobilePage = new lib.mobileScr();
	this.mobilePage.name = "mobilePage";
	this.mobilePage.parent = this;
	this.mobilePage.setTransform(36.4,79.45,0.4659,0.4659,0,0,0,70.3,153.3);

	var maskedShapeInstanceList = [this.mobilePage];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.mobilePage).wait(1));

	// Layer_14
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlEJEIAAyHIKJAAIAASHg");
	this.shape.setTransform(36.5,66);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.phone = new lib.phone_sub();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(36.3,66.6,1,1,0,0,0,36.3,66.6);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

	// Layer_2
	this.phone_shadow = new lib.phone_shadow();
	this.phone_shadow.name = "phone_shadow";
	this.phone_shadow.parent = this;
	this.phone_shadow.setTransform(36.25,129,1,0.7,0,0,0,70.9,6.7);
	this.phone_shadow.alpha = 0.3984;

	this.timeline.addTween(cjs.Tween.get(this.phone_shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.Phone, new cjs.Rectangle(-34.6,-0.2,141.7,133.79999999999998), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-11.95,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#53569E").s().p("Ap2CjIAAlFITtAAIAAFFg");
	this.shape.setTransform(-49.5507,-1.225,0.8705,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-104.5,-17.5,109.9,32.6), null);


(lib.mainchat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MainChat
	this.Chat = new lib.Chat();
	this.Chat.name = "Chat";
	this.Chat.parent = this;
	this.Chat.setTransform(109.25,82.2,1,1,0,0,0,88.5,83.2);

	this.timeline.addTween(cjs.Tween.get(this.Chat).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F3F0").s().p("AxTNjIAA7FMAinAAAIAAbFg");
	this.shape.setTransform(110.8,86.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainchat, new cjs.Rectangle(0,-1,221.6,174.4), null);


(lib.main_chat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.MainChat_top.cache(-101,-70,444,120,1)
		this.MainChat.cache(-222,-200,444,400,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// MainChat
	this.MainChat_top = new lib.mainchat_top();
	this.MainChat_top.name = "MainChat_top";
	this.MainChat_top.parent = this;
	this.MainChat_top.setTransform(9.25,7.6,1,1,0,0,0,110.8,75.6);

	this.timeline.addTween(cjs.Tween.get(this.MainChat_top).wait(1));

	// MainChat
	this.MainChat = new lib.mainchat();
	this.MainChat.name = "MainChat";
	this.MainChat.parent = this;
	this.MainChat.setTransform(9.25,7.6,1,1,0,0,0,110.8,75.6);

	this.timeline.addTween(cjs.Tween.get(this.MainChat).wait(1));

}).prototype = getMCSymbolPrototype(lib.main_chat, new cjs.Rectangle(-101.5,-91.8,248.2,197.2), null);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// TopBar
	this.instance = new lib.TopBar();
	this.instance.parent = this;
	this.instance.setTransform(154.9,4.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Side_bar
	this.instance_1 = new lib.Side_bar();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.45,99.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// MainChat
	this.Chat = new lib.main_chat();
	this.Chat.name = "Chat";
	this.Chat.parent = this;
	this.Chat.setTransform(182.4,94.4);

	this.timeline.addTween(cjs.Tween.get(this.Chat).wait(1));

}).prototype = getMCSymbolPrototype(lib.MainScreen, new cjs.Rectangle(0,0,682.8,201.7), null);


(lib.laptop_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// Layer_11
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C1C1C").s().p("A1XMBIgl4BMAr5AAAIglYBg");
	this.shape.setTransform(278.95,-81.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CDCDCD").s().p("A1XMmIgU5LMArXAAAIgUZLg");
	this.shape_1.setTransform(278.95,-85.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DBDBDB").s().p("A1XNDIgP6FMArNAAAIgPaFg");
	this.shape_2.setTransform(278.95,-88.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E5E5E5").s().p("A1XNaIgK6zMArDAAAIgKazg");
	this.shape_3.setTransform(278.95,-90.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EEEEEE").s().p("A1XNsIgI7XMAq/AAAIgIbXg");
	this.shape_4.setTransform(278.95,-92.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F4F4F4").s().p("A1XN5IgF7xMAq5AAAIgFbxg");
	this.shape_5.setTransform(278.95,-93.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F8F8F8").s().p("A1XOCIgD8DMAq1AAAIgDcDg");
	this.shape_6.setTransform(278.95,-94.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FBFBFB").s().p("A1XOIIgC8QMAqzAAAIgCcQg");
	this.shape_7.setTransform(278.95,-95.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FDFDFD").s().p("A1XOMIgB8YMAqxAAAIgBcYg");
	this.shape_8.setTransform(278.95,-95.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(254,254,254,0.898)").s().p("A1XOPIgB8dMAqxAAAIgBcdg");
	this.shape_9.setTransform(278.95,-95.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.8)").s().p("A1XOQIAA8fMAqvAAAIAAcfg");
	this.shape_10.setTransform(278.95,-95.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.6)").s().p("A1XORIAA8hMAqvAAAIAAchg");
	this.shape_11.setTransform(278.95,-95.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.298)").s().p("A1XORIAA8iMAqvAAAIAAcig");
	this.shape_12.setTransform(278.95,-96);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},20).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[]},1).wait(47));

	// Layer_10 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_28 = new cjs.Graphics().p("A1XOMIAA8XMAqvAAAIAAcXg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(28).to({graphics:mask_graphics_28,x:278.95,y:-96.575}).wait(52));

	// Layer_9
	this.instance = new lib.MainScreen();
	this.instance.parent = this;
	this.instance.setTransform(142.4,-187.6,0.9144,1.0325,0,0,0,0.7,-0.8);
	this.instance.alpha = 0;

	this.Screen = new lib.MainScreen();
	this.Screen.name = "Screen";
	this.Screen.parent = this;
	this.Screen.setTransform(142.4,-187.6,0.9144,1.0325,0,0,0,0.7,-0.8);

	var maskedShapeInstanceList = [this.instance,this.Screen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.Screen}]},28).wait(52));

	// Layer_2
	this.instance_1 = new lib.Laptop_Main_00000();
	this.instance_1.parent = this;
	this.instance_1.setTransform(117,2);

	this.instance_2 = new lib.Laptop_Main_00001();
	this.instance_2.parent = this;
	this.instance_2.setTransform(117,0.75);

	this.instance_3 = new lib.Laptop_Main_00002();
	this.instance_3.parent = this;
	this.instance_3.setTransform(117,0.75);

	this.instance_4 = new lib.Laptop_Main_00003();
	this.instance_4.parent = this;
	this.instance_4.setTransform(117.5,0);

	this.instance_5 = new lib.Laptop_Main_00004();
	this.instance_5.parent = this;
	this.instance_5.setTransform(117,0);

	this.instance_6 = new lib.Laptop_Main_00005();
	this.instance_6.parent = this;
	this.instance_6.setTransform(117,-8.25);

	this.instance_7 = new lib.Laptop_Main_00006();
	this.instance_7.parent = this;
	this.instance_7.setTransform(117,-26);

	this.instance_8 = new lib.Laptop_Main_00007();
	this.instance_8.parent = this;
	this.instance_8.setTransform(118,-46.25);

	this.instance_9 = new lib.Laptop_Main_00008();
	this.instance_9.parent = this;
	this.instance_9.setTransform(118.55,-67.3);

	this.instance_10 = new lib.Laptop_Main_00009();
	this.instance_10.parent = this;
	this.instance_10.setTransform(119.5,-89.3);

	this.instance_11 = new lib.Laptop_Main_00010();
	this.instance_11.parent = this;
	this.instance_11.setTransform(120.3,-110.3);

	this.instance_12 = new lib.Laptop_Main_00011();
	this.instance_12.parent = this;
	this.instance_12.setTransform(121.75,-129.3);

	this.instance_13 = new lib.Laptop_Main_00012();
	this.instance_13.parent = this;
	this.instance_13.setTransform(123.8,-145.3);

	this.instance_14 = new lib.Laptop_Main_00013();
	this.instance_14.parent = this;
	this.instance_14.setTransform(124.8,-158.3);

	this.instance_15 = new lib.Laptop_Main_00014();
	this.instance_15.parent = this;
	this.instance_15.setTransform(125.8,-168.3);

	this.instance_16 = new lib.Laptop_Main_00015();
	this.instance_16.parent = this;
	this.instance_16.setTransform(126.8,-176.3);

	this.instance_17 = new lib.Laptop_Main_00016();
	this.instance_17.parent = this;
	this.instance_17.setTransform(128.05,-182.3);

	this.instance_18 = new lib.Laptop_Main_00017();
	this.instance_18.parent = this;
	this.instance_18.setTransform(129.1,-187.35);

	this.instance_19 = new lib.Laptop_Main_00018();
	this.instance_19.parent = this;
	this.instance_19.setTransform(130.05,-190.3);

	this.instance_20 = new lib.Laptop_Main_00019();
	this.instance_20.parent = this;
	this.instance_20.setTransform(131.1,-192.3);

	this.instance_21 = new lib.Laptop_Main_00020();
	this.instance_21.parent = this;
	this.instance_21.setTransform(132.3,-194.3);

	this.instance_22 = new lib.Laptop_Main_00022();
	this.instance_22.parent = this;
	this.instance_22.setTransform(133.3,-196.35);

	this.instance_23 = new lib.Laptop_Main_00024();
	this.instance_23.parent = this;
	this.instance_23.setTransform(134.3,-196.3);

	this.instance_24 = new lib.Laptop_Main_00026();
	this.instance_24.parent = this;
	this.instance_24.setTransform(134.3,-197.3);

	this.instance_25 = new lib.Laptop_Main_00028();
	this.instance_25.parent = this;
	this.instance_25.setTransform(134.3,-197.3);

	this.instance_26 = new lib.Laptop_Main_00030();
	this.instance_26.parent = this;
	this.instance_26.setTransform(134.3,-197.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},6).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},2).to({state:[{t:this.instance_25}]},2).to({state:[{t:this.instance_26}]},2).wait(45));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A5HCbICqk1MAsxAAAIC0E1g");
	mask_1.setTransform(278.8,23.025);

	// Layer_5
	this.instance_27 = new lib.shadow();
	this.instance_27.parent = this;
	this.instance_27.setTransform(278.8,68.7,1,0.76,0,0,0,162.8,77.3);
	this.instance_27.alpha = 0.3984;
	this.instance_27._off = true;

	var maskedShapeInstanceList = [this.instance_27];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(6).to({_off:false},0).to({scaleY:1,y:34.25,alpha:0.1484},24,cjs.Ease.cubicInOut).wait(50));

	// Layer_1
	this.instance_28 = new lib.Laptop_Base();
	this.instance_28.parent = this;
	this.instance_28.setTransform(117,8.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(80));

	// Layer_6
	this.tile_sub = new lib.laptop_shadow_1();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.parent = this;
	this.tile_sub.setTransform(42,-89.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(80));

	// Layer_8
	this.instance_29 = new lib.laptop_shadow_2();
	this.instance_29.parent = this;
	this.instance_29.setTransform(187.4,9.3,0.3625,0.0329,0,0,0,194.7,194.6);
	this.instance_29.alpha = 0.3984;
	this.instance_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(6).to({_off:false},0).wait(1).to({regX:194.5,regY:194.5,scaleX:0.3632,scaleY:0.0333,x:187.2,y:9.2,alpha:0.3976},0).wait(1).to({scaleX:0.3654,scaleY:0.0346,x:186.75,y:8.95,alpha:0.3949},0).wait(1).to({scaleX:0.3693,scaleY:0.0368,x:186,y:8.5,alpha:0.3903},0).wait(1).to({scaleX:0.3749,scaleY:0.04,x:184.85,y:7.9,alpha:0.3837},0).wait(1).to({scaleX:0.3824,scaleY:0.0443,x:183.45,y:7.1,alpha:0.3749},0).wait(1).to({scaleX:0.3915,scaleY:0.0495,x:181.7,y:6.1,alpha:0.3641},0).wait(1).to({scaleX:0.4022,scaleY:0.0557,x:179.6,y:4.9,alpha:0.3514},0).wait(1).to({scaleX:0.4142,scaleY:0.0625,x:177.25,y:3.55,alpha:0.3372},0).wait(1).to({scaleX:0.427,scaleY:0.0699,x:174.75,y:2.15,alpha:0.3221},0).wait(1).to({scaleX:0.4401,scaleY:0.0774,x:172.2,y:0.65,alpha:0.3065},0).wait(1).to({scaleX:0.4531,scaleY:0.0848,x:169.7,y:-0.8,alpha:0.2912},0).wait(1).to({scaleX:0.4654,scaleY:0.0918,x:167.3,y:-2.2,alpha:0.2766},0).wait(1).to({scaleX:0.4768,scaleY:0.0984,x:165.1,y:-3.45,alpha:0.2631},0).wait(1).to({scaleX:0.4872,scaleY:0.1043,x:163.05,y:-4.6,alpha:0.2509},0).wait(1).to({scaleX:0.4963,scaleY:0.1095,x:161.3,y:-5.65,alpha:0.24},0).wait(1).to({scaleX:0.5043,scaleY:0.1141,x:159.75,y:-6.5,alpha:0.2306},0).wait(1).to({scaleX:0.5111,scaleY:0.118,x:158.45,y:-7.25,alpha:0.2226},0).wait(1).to({scaleX:0.5167,scaleY:0.1212,x:157.35,y:-7.95,alpha:0.2159},0).wait(1).to({scaleX:0.5213,scaleY:0.1238,x:156.45,y:-8.4,alpha:0.2105},0).wait(1).to({scaleX:0.5249,scaleY:0.1259,x:155.75,y:-8.8,alpha:0.2062},0).wait(1).to({scaleX:0.5276,scaleY:0.1274,x:155.2,y:-9.1,alpha:0.2031},0).wait(1).to({scaleX:0.5294,scaleY:0.1285,x:154.85,y:-9.3,alpha:0.2009},0).wait(1).to({scaleX:0.5305,scaleY:0.1291,x:154.7,y:-9.45,alpha:0.1996},0).wait(1).to({regX:194.7,regY:193.4,scaleX:0.5308,scaleY:0.1293,y:-9.5,alpha:0.1992},0).wait(50));

	// Layer_7
	this.instance_30 = new lib.wide_shadow();
	this.instance_30.parent = this;
	this.instance_30.setTransform(267.2,45.5,2.2,0.3,0,0,0,194.6,194.2);
	this.instance_30.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).to({alpha:1},15).wait(65));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160.9,-197.3,855.9,301.3);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(0.1,0.2,1,1,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(42.95,219.55,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(96.05,220.1,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.parent = this;
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// phone
	this.phone = new lib.Phone();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(164.65,193.55,0.6423,0.6421,0,0,0,36.3,66.8);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

	// laptop
	this.laptop = new lib.laptop_anim();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(253.2,213.5,0.614,0.5403,0,0,0,283.9,24.7);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";
	this.txt.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(50.1,22.1,0.6827,0.6848,0,0,0,0.5,0.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-19.8,0,525.4,256.3), null);


// stage content:
(lib.O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var laptop = mc.laptop
		var phone = mc.phone
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
			
		var stage3D = new depthjs.Stage3D();
		stage.addChild(stage3D);
			
		var cont3D = new depthjs.Container3D();
		var logo_mc = new lib.logo_mc();
		cont3D.x = 210;
		cont3D.y = 70;
		cont3D.addChild(logo_mc);
		
		stage3D.addChild(cont3D);
		
		var s = new createjs.Shape().set({y:0,x:0});
		s.graphics.f("blue").dr(0,0,250,50);
		s.x = 50; s.y=116
		s.alpha=0
			stage.addChild(s);
			exportRoot.mainMC.txt.getChildAt(7).mask = s
			exportRoot.mainMC.txt.getChildAt(8).mask = s
		
			this.tl1 = new TimelineLite();
					
				//Keep track
		
				// Chat
				exportRoot.tl1.from(exportRoot.headline1, 0.1, { x:"+=5", y:"-=2.5",scaleX:.75, scaleY:.75, alpha: 0, ease:Back.easeOut}, "+=0.5");
				exportRoot.tl1.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
				
				// Video
				exportRoot.tl1.from(exportRoot.headline2, 0.1, { x:"+=7", y:"-=2.5",scaleX:.75, scaleY:.75, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
		
				// Phone
				exportRoot.tl1.from(exportRoot.headline3, 0.1, { x:"+=7", y:"-=2.5",scaleX:.75, scaleY:.75, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
		
				//Cloud storage
				exportRoot.tl1.from(exportRoot.headline4, 0.1, { x:"+=3.5", y:"-=1.75",scaleX:.875, scaleY:.875, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.from(exportRoot.headline5, 0.1, { x:"+=0", y:"-=1.75",scaleX:.875, scaleY:.875, alpha: 0, ease:Back.easeOut}, "-=0.02");
				
				exportRoot.tl1.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
				exportRoot.tl1.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				
				//Project Management
				exportRoot.tl1.from(exportRoot.headline6, 0.1, { x:"+=6.5", y:"-=1.75",scaleX:.875, scaleY:.875, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.from(exportRoot.headline7, 0.1, { x:"+=2", y:"-=1.75",scaleX:.875, scaleY:.875, alpha: 0, ease:Back.easeOut}, "-=0.02");
				
				exportRoot.tl1.to(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
				exportRoot.tl1.to(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
		
				//Team collaboration
				exportRoot.tl1.from(exportRoot.headline8, 0.1, { x:"+=7.5", y:"-=1.75",scaleX:.875, scaleY:.875, alpha: 0, ease:Back.easeOut}, "-=0.02");
				exportRoot.tl1.from(exportRoot.headline9, 0.1, { x:"+=3", y:"-=1.75",scaleX:.875, scaleY:.875, alpha: 0, ease:Back.easeOut}, "-=0.02");
				
		
				exportRoot.tl1.from(cont3D, 1.6, {rotY: "+=60",x:"+=200", ease:Power4.easeInOut});
				exportRoot.tl1.to(s, 1.6, {x: "-=140", ease:Power4.easeInOut}, "-=1.6");
				exportRoot.tl1.to(exportRoot.headline8, 1.6, {x: "+=150", ease:Power4.easeInOut}, "-=1.6");
				exportRoot.tl1.to(exportRoot.headline9, 1.6, {x: "+=150", ease:Power4.easeInOut}, "-=1.6");
		
				exportRoot.tl1.to(cont3D, 1, {x:222, y:"+=27", z:-1000, ease:Power4.easeInOut}, "+=0.5");
		
				exportRoot.tl1.from(phone, 1.2, {x: "-=350", ease:Power3.easeOut}, "-=1");
				exportRoot.tl1.from(laptop, 1.2, {x: "-=350", ease:Power4.easeOut, onStart:function(){laptop.play();}}, "-=1.2");
		
				
				for (var i = 0; i < exportRoot.headline10.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline10[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=1");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline10[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline11.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
		
				exportRoot.tl1.from(phone.keyboard, .6, {y: "+=55", ease:Power3.easeOut, onStart:function(){phone.keyboard.play();}}, "-=1");
		
				exportRoot.tl1.to(phone.keyboard, .4, {y: "+=55", ease:Power3.easeIn}, "+=2");
				exportRoot.tl1.to(phone.mobilePage, .4, {y: "-=27", ease:Power3.easeInOut}, "-=.4");
				exportRoot.tl1.to(laptop.Screen.Chat.MainChat, .4, {y: "-=20", ease:Power3.easeInOut}, "-=.2");
				
		
			
				
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "-=100",	ease:Power4.easeOut}, "-=3");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=3");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)	
				
				
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(130.2,125,375.40000000000003,131.3);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574948131079", id:"O365_SMBSimplified_USA_300x250_BAN_Teams_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;