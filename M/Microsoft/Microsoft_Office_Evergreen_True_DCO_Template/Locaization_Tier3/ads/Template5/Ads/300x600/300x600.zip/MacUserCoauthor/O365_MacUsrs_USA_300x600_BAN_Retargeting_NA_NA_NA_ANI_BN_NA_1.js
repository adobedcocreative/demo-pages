(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_", frames: [[855,578,169,85],[193,252,171,85],[366,252,171,85],[0,335,171,85],[346,339,171,85],[519,404,171,85],[173,339,171,85],[692,404,171,85],[513,665,169,85],[684,665,169,85],[171,600,169,85],[0,596,169,85],[684,578,169,85],[342,600,169,85],[684,491,169,85],[342,513,169,85],[513,578,169,85],[0,422,169,85],[171,426,169,85],[342,426,169,85],[855,491,169,85],[171,513,169,85],[0,509,169,85],[513,491,169,85],[0,0,300,250],[302,0,300,250],[604,0,300,202],[604,204,300,198],[0,252,191,81]]}
];


// symbols:



(lib.Bitmap10 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.mac = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Macbook = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.macbookscreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.MacScreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.transform = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.4824,406.9504,1,2.3867);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,-564.3,971,1942.5), null);


(lib.txt_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.parent = this;

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.parent = this;

	this.instance_2 = new lib.Bitmap4();
	this.instance_2.parent = this;

	this.instance_3 = new lib.Bitmap5();
	this.instance_3.parent = this;

	this.instance_4 = new lib.Bitmap6();
	this.instance_4.parent = this;

	this.instance_5 = new lib.Bitmap7();
	this.instance_5.parent = this;

	this.instance_6 = new lib.Bitmap8();
	this.instance_6.parent = this;

	this.instance_7 = new lib.Bitmap9();
	this.instance_7.parent = this;

	this.instance_8 = new lib.Bitmap10();
	this.instance_8.parent = this;

	this.instance_9 = new lib.Bitmap11();
	this.instance_9.parent = this;

	this.instance_10 = new lib.Bitmap12();
	this.instance_10.parent = this;

	this.instance_11 = new lib.Bitmap13();
	this.instance_11.parent = this;

	this.instance_12 = new lib.Bitmap14();
	this.instance_12.parent = this;

	this.instance_13 = new lib.Bitmap15();
	this.instance_13.parent = this;

	this.instance_14 = new lib.Bitmap16();
	this.instance_14.parent = this;

	this.instance_15 = new lib.Bitmap17();
	this.instance_15.parent = this;

	this.instance_16 = new lib.Bitmap18();
	this.instance_16.parent = this;

	this.instance_17 = new lib.Bitmap19();
	this.instance_17.parent = this;

	this.instance_18 = new lib.Bitmap20();
	this.instance_18.parent = this;

	this.instance_19 = new lib.Bitmap21();
	this.instance_19.parent = this;

	this.instance_20 = new lib.Bitmap22();
	this.instance_20.parent = this;

	this.instance_21 = new lib.Bitmap23();
	this.instance_21.parent = this;

	this.instance_22 = new lib.Bitmap24();
	this.instance_22.parent = this;

	this.instance_23 = new lib.Bitmap25();
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,171,85);


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.person = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiDB+IAAgFQAAgXANgQQANgRAbgKQAJgEAbgCQACgHABgLQgPgMgJgTQgIgTAAgXQAAgqALgRQAPgYAtAAQAtAAAQAYQALASAAApQAAAXgJATQgJAUgPAMQABAMADAGQAYACALADQA2APAAAzIAAAFg");
	this.shape.setTransform(0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.person, new cjs.Rectangle(-13.1,-12.6,26.299999999999997,25.2), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Macbook_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Macbook();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Macbook_1, new cjs.Rectangle(0,0,300,250), null);


(lib.Mac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mac();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.96,0.96);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mac, new cjs.Rectangle(0,0,288,240), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Image = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Transform
	this.instance = new lib.transform();
	this.instance.parent = this;
	this.instance.setTransform(56.4,55.15,0.9714,1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("As5FDIAAqFIZzAAIAAKFg");
	var mask_graphics_1 = new cjs.Graphics().p("As5FDIAAqFIZzAAIAAKFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:150.15,y:96}).wait(1).to({graphics:mask_graphics_1,x:150.15,y:96}).wait(1));

	// Layer_1
	this.instance_1 = new lib.macbookscreen();
	this.instance_1.parent = this;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(56.4,55.2,185.6,80.99999999999999);


(lib.flag_2_name = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.txt = new cjs.Text("", "32px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 43;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-11.5,-22.55);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("AoWDBIAAmBIQtAAIAAGBg");
	this.shape.setTransform(35.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],-1.4,-2,-1.4,2).s().p("AoWAUIAAgnIQtAAIAAAng");
	this.shape_1.setTransform(35.5,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_2_name, new cjs.Rectangle(-18,-24.5,108.5,47.8), null);


(lib.flag_1_name = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.txt = new cjs.Text("", "32px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 43;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-11.5,-22.55);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("AoWDBIAAmBIQtAAIAAGBg");
	this.shape.setTransform(35.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],-1.4,-2,-1.4,2).s().p("AoWAUIAAgnIQtAAIAAAng");
	this.shape_1.setTransform(35.5,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_1_name, new cjs.Rectangle(-18,-24.5,108.5,47.8), null);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("AglELIAAoVIBLAAIAAIVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.7,7.5,53.5);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("AglELIAAoVIBLAAIAAIVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.7,7.5,53.5);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.flag_2_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.person();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("Ai9DBIAAmBIF7AAIAAGBg");
	this.shape.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],35.1,-2,35.1,2).s().p("Ai9AUIAAgnIF7AAIAAAng");
	this.shape_1.setTransform(-1,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_2_square, new cjs.Rectangle(-20,-19.2,38,42.5), null);


(lib.flag_1_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.person();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("Ai9DBIAAmBIF7AAIAAGBg");
	this.shape.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],35.4,-2,35.4,2).s().p("AjAAUIAAgnIGBAAIAAAng");
	this.shape_1.setTransform(-1.25,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_1_square, new cjs.Rectangle(-20.5,-19.2,38.5,42.5), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.msft.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.msft = new lib.ms();
	this.msft.name = "msft";
	this.msft.parent = this;
	this.msft.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.msft}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_63 = function() {
		exportRoot.mainMC.anim.gotoAndPlay(1)
	}
	this.frame_77 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(63).call(this.frame_63).wait(14).call(this.frame_77).wait(1));

	// Layer_2
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.parent = this;
	this.instance_1.setTransform(302.7,339.4,0.3276,0.3276,0,0,0,-39.9,1.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.4173,scaleY:5.4173,x:302.75,y:339.2},13,cjs.Ease.quadOut).to({x:87.75},12,cjs.Ease.quadInOut).to({_off:true},1).wait(51));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AlmfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_15 = new cjs.Graphics().p("Al1fHIAAyRMBE0AAAIAASRg");
	var mask_graphics_16 = new cjs.Graphics().p("AmifHIAAyRMBE0AAAIAASRg");
	var mask_graphics_17 = new cjs.Graphics().p("AntfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_18 = new cjs.Graphics().p("ApWfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_19 = new cjs.Graphics().p("ArefHIAAyRMBE0AAAIAASRg");
	var mask_graphics_20 = new cjs.Graphics().p("AuDfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_21 = new cjs.Graphics().p("AwofHIAAyRMBE0AAAIAASRg");
	var mask_graphics_22 = new cjs.Graphics().p("AywfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_23 = new cjs.Graphics().p("A0ZfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_24 = new cjs.Graphics().p("A1kfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_25 = new cjs.Graphics().p("A2RfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_26 = new cjs.Graphics().p("A2gfHIAAyRMBE0AAAIAASRg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:404.6146,y:199.0879}).wait(1).to({graphics:mask_graphics_15,x:403.1112,y:199.0879}).wait(1).to({graphics:mask_graphics_16,x:398.6008,y:199.0879}).wait(1).to({graphics:mask_graphics_17,x:391.0834,y:199.0879}).wait(1).to({graphics:mask_graphics_18,x:380.5591,y:199.0879}).wait(1).to({graphics:mask_graphics_19,x:367.0278,y:199.0879}).wait(1).to({graphics:mask_graphics_20,x:350.4896,y:199.0879}).wait(1).to({graphics:mask_graphics_21,x:333.9514,y:199.0879}).wait(1).to({graphics:mask_graphics_22,x:320.4202,y:199.0879}).wait(1).to({graphics:mask_graphics_23,x:309.8959,y:199.0879}).wait(1).to({graphics:mask_graphics_24,x:302.3785,y:199.0879}).wait(1).to({graphics:mask_graphics_25,x:297.8681,y:199.0879}).wait(1).to({graphics:mask_graphics_26,x:296.3646,y:199.0879}).wait(1).to({graphics:null,x:0,y:0}).wait(51));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logocopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(88.55,332.7,5.4173,5.4173,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(305,332.7,5.4173,5.4173,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({_off:true,x:305},12,cjs.Ease.quadInOut).wait(52));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},12,cjs.Ease.quadInOut).wait(25).to({scaleX:2.3001,scaleY:2.3001,x:34.8,y:-503.85},22,cjs.Ease.quadInOut).wait(5));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,339.3,1,1,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55).to({x:-674.7},21,cjs.Ease.quadIn).wait(2));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(297.95,339.3,1,1,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(56).to({x:-674.7},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160.1,-631.9,1943.6,1942.5);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.aFlagMC_B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"in":1,"out":40});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_39 = function() {
		this.stop()
	}
	this.frame_64 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(25).call(this.frame_64).wait(1));

	// mask_idn
	this.instance = new lib.Tween2();
	this.instance.parent = this;
	this.instance.setTransform(0,0.5,1,0.0187,0,0,0,0,26.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({regY:0,scaleY:0.1468,y:-0.0326},0).wait(1).to({scaleY:0.2742,y:-0.0651},0).wait(1).to({scaleY:0.3953,y:-0.0959},0).wait(1).to({scaleY:0.5069,y:-0.1244},0).wait(1).to({scaleY:0.6072,y:-0.1499},0).wait(1).to({scaleY:0.6955,y:-0.1724},0).wait(1).to({scaleY:0.7716,y:-0.1918},0).wait(1).to({scaleY:0.8357,y:-0.2081},0).wait(1).to({scaleY:0.8884,y:-0.2216},0).wait(1).to({scaleY:0.9301,y:-0.2322},0).wait(1).to({scaleY:0.9615,y:-0.2402},0).wait(1).to({scaleY:0.9833,y:-0.2457},0).wait(1).to({scaleY:0.9959,y:-0.249},0).wait(1).to({regY:26.5,scaleY:1,y:26.5},0).to({_off:true},49).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AobDVIAAmoIQ3AAIAAGog");
	mask.setTransform(98.775,-5.5);

	// Layer 1
	this.flag = new lib.flag_2_name();
	this.flag.name = "flag";
	this.flag.parent = this;
	this.flag.setTransform(-46.15,-7.5);

	var maskedShapeInstanceList = [this.flag];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flag).wait(27).to({regX:35.5,regY:0.3,x:6.65,y:-7.2},0).wait(1).to({x:21.95},0).wait(1).to({x:35.55},0).wait(1).to({x:47.7},0).wait(1).to({x:58.4},0).wait(1).to({x:67.8},0).wait(1).to({x:75.9},0).wait(1).to({x:82.75},0).wait(1).to({x:88.3},0).wait(1).to({x:92.65},0).wait(1).to({x:95.75},0).wait(1).to({x:97.6},0).wait(1).to({regX:0,regY:0,x:62.75,y:-7.5},0).wait(1).to({regX:35.5,regY:0.3,x:97.45,y:-7.2},0).wait(1).to({x:95.25},0).wait(1).to({x:91.75},0).wait(1).to({x:87.05},0).wait(1).to({x:81.2},0).wait(1).to({x:74.3},0).wait(1).to({x:66.35},0).wait(1).to({x:57.3},0).wait(1).to({x:47.1},0).wait(1).to({x:35.65},0).wait(1).to({x:22.8},0).wait(1).to({x:7.9},0).wait(1).to({regX:0,regY:0,x:-46.15,y:-7.5},0).wait(13));

	// Layer 1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("Ai9DVIAAmoIF7AAIAAGog");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:21.775,y:-5.5}).wait(49).to({graphics:null,x:0,y:0}).wait(1));

	// Layer 1
	this.instance_1 = new lib.flag_2_square();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.25,-7.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(1).to({regX:-1,regY:2,x:-14.9,y:-5.5},0).wait(1).to({x:-13.95},0).wait(1).to({x:-12.45},0).wait(1).to({x:-10.45},0).wait(1).to({x:-7.95},0).wait(1).to({x:-4.95},0).wait(1).to({x:-1.4},0).wait(1).to({x:2.7},0).wait(1).to({x:7.55},0).wait(1).to({x:13.3},0).wait(1).to({regX:0,regY:0,x:21.75,y:-7.5},0).wait(26).to({x:-11},10).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.8,156.5,53.6);


(lib.aFlagMC_A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"in":1,"out":40});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_39 = function() {
		this.stop()
	}
	this.frame_64 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(25).call(this.frame_64).wait(1));

	// mask_idn
	this.instance = new lib.Tween1();
	this.instance.parent = this;
	this.instance.setTransform(0,0.5,1,0.0187,0,0,0,0,26.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({regY:0,scaleY:0.1468,y:-0.0326},0).wait(1).to({scaleY:0.2742,y:-0.0651},0).wait(1).to({scaleY:0.3953,y:-0.0959},0).wait(1).to({scaleY:0.5069,y:-0.1244},0).wait(1).to({scaleY:0.6072,y:-0.1499},0).wait(1).to({scaleY:0.6955,y:-0.1724},0).wait(1).to({scaleY:0.7716,y:-0.1918},0).wait(1).to({scaleY:0.8357,y:-0.2081},0).wait(1).to({scaleY:0.8884,y:-0.2216},0).wait(1).to({scaleY:0.9301,y:-0.2322},0).wait(1).to({scaleY:0.9615,y:-0.2402},0).wait(1).to({scaleY:0.9833,y:-0.2457},0).wait(1).to({scaleY:0.9959,y:-0.249},0).wait(1).to({regY:26.5,scaleY:1,y:26.5},0).to({_off:true},49).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AobDVIAAmoIQ3AAIAAGog");
	mask.setTransform(98.775,-5.5);

	// Layer 1
	this.flag = new lib.flag_1_name();
	this.flag.name = "flag";
	this.flag.parent = this;
	this.flag.setTransform(-46.15,-7.5);

	var maskedShapeInstanceList = [this.flag];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flag).wait(27).to({regX:35.5,regY:0.3,x:6.65,y:-7.2},0).wait(1).to({x:21.95},0).wait(1).to({x:35.55},0).wait(1).to({x:47.7},0).wait(1).to({x:58.4},0).wait(1).to({x:67.8},0).wait(1).to({x:75.9},0).wait(1).to({x:82.75},0).wait(1).to({x:88.3},0).wait(1).to({x:92.65},0).wait(1).to({x:95.75},0).wait(1).to({x:97.6},0).wait(1).to({regX:0,regY:0,x:62.75,y:-7.5},0).wait(1).to({regX:35.5,regY:0.3,x:97.45,y:-7.2},0).wait(1).to({x:95.25},0).wait(1).to({x:91.75},0).wait(1).to({x:87.05},0).wait(1).to({x:81.2},0).wait(1).to({x:74.3},0).wait(1).to({x:66.35},0).wait(1).to({x:57.3},0).wait(1).to({x:47.1},0).wait(1).to({x:35.65},0).wait(1).to({x:22.8},0).wait(1).to({x:7.9},0).wait(1).to({regX:0,regY:0,x:-46.15,y:-7.5},0).wait(13));

	// Layer 1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("Ai9DVIAAmoIF7AAIAAGog");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:21.775,y:-5.5}).wait(49).to({graphics:null,x:0,y:0}).wait(1));

	// Layer 1
	this.instance_1 = new lib.flag_1_square();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.25,-7.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(1).to({regX:-1.3,regY:2,x:-15.2,y:-5.5},0).wait(1).to({x:-14.25},0).wait(1).to({x:-12.75},0).wait(1).to({x:-10.75},0).wait(1).to({x:-8.25},0).wait(1).to({x:-5.25},0).wait(1).to({x:-1.7},0).wait(1).to({x:2.4},0).wait(1).to({x:7.25},0).wait(1).to({x:13},0).wait(1).to({regX:0,regY:0,x:21.75,y:-7.5},0).wait(26).to({x:-11},10).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.8,156.5,53.6);


(lib.Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_34 = function() {
		this.flag2.gotoAndPlay('in')
	}
	this.frame_193 = function() {
		this.flag1.gotoAndPlay('in')
	}
	this.frame_399 = function() {
		//this.flag1.gotoAndPlay('out')
	}
	this.frame_402 = function() {
		//this.flag2.gotoAndPlay('out')
	}
	this.frame_451 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(159).call(this.frame_193).wait(206).call(this.frame_399).wait(3).call(this.frame_402).wait(49).call(this.frame_451).wait(122));

	// flag1
	this.flag1 = new lib.aFlagMC_A();
	this.flag1.name = "flag1";
	this.flag1.parent = this;
	this.flag1.setTransform(262.75,153.3,0.5502,0.5502,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.flag1).wait(220).to({x:44.85,y:165.3},25,cjs.Ease.quadInOut).wait(15).to({x:51.7},0).wait(5).to({x:58},0).wait(5).to({x:63.75},0).wait(5).to({x:71.1},0).wait(49).to({x:15.7,y:176.7},14,cjs.Ease.quadInOut).wait(9).to({x:21.45},0).wait(4).to({x:29.85},0).wait(5).to({x:36.15},0).wait(4).to({x:42.45},0).wait(4).to({x:50.85},0).wait(4).to({x:57.7},0).wait(205));

	// flag2
	this.flag2 = new lib.aFlagMC_B();
	this.flag2.name = "flag2";
	this.flag2.parent = this;
	this.flag2.setTransform(147.45,77.4,0.5502,0.5502,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.flag2).wait(78).to({x:274.2,y:127},28,cjs.Ease.cubicInOut).wait(31).to({x:128.55,y:140.8},19,cjs.Ease.quadInOut).wait(15).to({x:138},0).wait(5).to({x:146.95},0).wait(5).to({x:155.35},0).wait(5).to({x:163.35,y:140.5},0).wait(100).to({x:143.1,y:166.15},14,cjs.Ease.quadInOut).wait(9).to({x:147.3},0).wait(4).to({x:153.6},0).wait(4).to({x:160.45},0).wait(4).to({x:165.7},0).wait(4).to({x:173.05},0).wait(5).to({x:178.45,y:165.4},0).wait(243));

	// Image
	this.instance = new lib.Image("single",0);
	this.instance.parent = this;
	this.instance.setTransform(83.8,69.9,0.7686,0.7686,0,0,0,150,101.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(68).to({startPosition:1},0).wait(10).to({startPosition:1},0).to({regY:101,scaleX:1.5363,scaleY:1.5363,x:147.05,y:98.45},28,cjs.Ease.cubicInOut).wait(7).to({startPosition:0},0).wait(460));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AVzRUIAAh0MgwVAAAIAAgpIgLAAIAA8eIgLAAIAAjsMA0xAAAIAADsIghAAIAAbLIBhAAIAAB8IhhAAIAAB0gA4mNkMAuZAAAIAA7LMguZAAAgA1rqGIAAjKIL2AAIAADKg");
	mask.setTransform(152.275,104.675);

	// ScreenBG
	this.instance_1 = new lib.MacScreen();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-75,-54.45,1.5,1.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(573));

	// Layer_3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A44O+IAA1VMAxxAAAIAAVVg");
	mask_1.setTransform(144.4114,95.7809);

	// ScreenText
	this.instance_2 = new lib.Text("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(144.75,160.1,1.5,1.5,0,0,0,84.5,42.8);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(78).to({startPosition:1},0).to({y:208.4},28,cjs.Ease.cubicInOut).wait(61).to({startPosition:1},0).wait(4).to({startPosition:2},0).wait(5).to({startPosition:3},0).wait(5).to({startPosition:4},0).wait(5).to({startPosition:5},0).wait(70).to({startPosition:6},0).wait(4).to({startPosition:7},0).wait(5).to({startPosition:8},0).wait(5).to({startPosition:9},0).wait(5).to({startPosition:10},0).wait(31).to({startPosition:11},0).wait(3).to({startPosition:12},0).wait(4).to({startPosition:13},0).wait(4).to({startPosition:14},0).wait(4).to({startPosition:15},0).wait(4).to({startPosition:16},0).wait(5).to({startPosition:17},0).wait(14).to({startPosition:18},0).wait(3).to({startPosition:19},0).wait(4).to({startPosition:20},0).wait(5).to({startPosition:21},0).wait(4).to({startPosition:22},0).wait(4).to({startPosition:23},0).wait(4).to({startPosition:24},0).wait(205));

	// ScreenFill
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A4GOGIAA8LMAwNAAAIAAcLg");
	this.shape.setTransform(145.325,104.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(573));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.8,-6.1,378,221.6);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(24.2,1.55,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.05,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AsDCQIAAkfIYHAAIAAEfg");
	this.shape.setTransform(13,0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-64.2,-13.6,154.4,28.799999999999997), null);


(lib.Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_7 = function() {
		exportRoot.tlH1.play()
	}
	this.frame_9 = function() {
		exportRoot.tl2.play()
	}
	this.frame_14 = function() {
		this.screen.play(1)
	}
	this.frame_409 = function() {
		exportRoot.tl1.play()
	}
	this.frame_440 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7).call(this.frame_7).wait(2).call(this.frame_9).wait(5).call(this.frame_14).wait(395).call(this.frame_409).wait(31).call(this.frame_440).wait(236));

	// Whitebar
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcU8MAAAgp3IA5AAMAAAAp3g");
	this.shape.setTransform(325.85,347.225);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgdU8MAAAgp3IA7AAMAAAAp3g");
	this.shape_1.setTransform(138.15,343.025);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcU8MAAAgp3IA6AAMAAAAp3g");
	this.shape_2.setTransform(157.75,342.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdU8MAAAgp3IA6AAMAAAAp3g");
	this.shape_3.setTransform(150.5,342.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},170).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},70).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},39).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(286));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(170).to({_off:false},0).wait(1).to({x:302.05,y:346.675},0).wait(1).to({x:280.05,y:346.175},0).wait(1).to({x:259.675,y:345.725},0).wait(1).to({x:240.925,y:345.325},0).wait(1).to({x:223.625,y:344.925},0).wait(1).to({x:207.775,y:344.575},0).wait(1).to({x:193.275,y:344.225},0).wait(1).to({x:180.025,y:343.925},0).wait(1).to({x:167.975,y:343.675},0).wait(1).to({x:157,y:343.425},0).wait(1).to({x:147.1,y:343.225},0).to({_off:true},1).wait(1).to({_off:false,x:130.125,y:342.825},0).to({_off:true},1).wait(2).to({_off:false,x:110.85,y:342.375},0).to({_off:true},1).wait(2).to({_off:false,x:97.6,y:342.075},0).to({_off:true},1).wait(1).to({_off:false,x:91.425,y:341.975},0).to({_off:true},1).wait(1).to({_off:false,x:86.9,y:341.875},0).wait(1).to({x:85.175,y:341.825},0).wait(1).to({x:83.75,y:341.775},0).to({_off:true},1).wait(1).to({_off:false,x:81.6,y:341.725},0).wait(1).to({x:80.85},0).wait(1).to({x:80.25},0).wait(1).to({x:79.8,y:341.675},0).wait(1).to({x:79.5},0).wait(1).to({x:79.25},0).to({_off:true},1).wait(2).to({_off:false,x:78.9},0).wait(1).to({_off:true},1).wait(75).to({_off:false,x:79.25,y:342.225},0).to({_off:true},1).wait(3).to({_off:false,x:82.85},0).wait(1).to({x:84.45},0).wait(1).to({x:86.35},0).wait(1).to({x:88.6,y:342.275},0).to({_off:true},1).wait(5).to({_off:false,x:111,y:342.325},0).wait(1).to({x:116.375},0).wait(1).to({x:122.225,y:342.375},0).wait(1).to({x:128.525},0).wait(1).to({x:135.175},0).wait(1).to({x:142.075,y:342.425},0).wait(1).to({x:149.175},0).wait(1).to({x:156.225,y:342.475},0).wait(1).to({x:163.175},0).wait(1).to({x:169.925,y:342.525},0).wait(1).to({x:176.325},0).wait(1).to({x:182.3},0).wait(1).to({x:187.85,y:342.575},0).wait(1).to({x:192.95},0).wait(1).to({x:197.575},0).wait(1).to({x:201.75,y:342.625},0).wait(1).to({x:205.475},0).wait(1).to({x:208.8},0).wait(1).to({x:211.725},0).wait(1).to({x:214.3},0).wait(1).to({x:216.525},0).wait(1).to({x:218.45,y:342.675},0).wait(1).to({x:220.05},0).wait(1).to({x:221.4},0).wait(1).to({x:222.55},0).wait(1).to({x:223.4},0).wait(1).to({x:224.05},0).wait(1).to({x:224.5},0).wait(1).to({x:224.75},0).wait(1).to({x:224.85},0).wait(40).to({x:224.75},0).wait(1).to({x:224.45},0).wait(1).to({x:223.9},0).wait(1).to({x:223.05},0).wait(1).to({x:221.9},0).wait(1).to({x:220.4},0).wait(1).to({x:218.475},0).wait(1).to({x:216.05},0).wait(1).to({x:213.025},0).wait(1).to({x:209.35},0).wait(1).to({x:204.9},0).wait(1).to({x:199.65},0).wait(1).to({x:193.675},0).to({_off:true},1).wait(1).to({_off:false,x:180.675},0).wait(1).to({x:174.525},0).wait(1).to({x:169.125},0).wait(1).to({x:164.55},0).wait(1).to({x:160.8},0).to({_off:true},1).wait(1).to({_off:false,x:155.375},0).wait(1).to({x:153.525},0).wait(1).to({x:152.15},0).wait(1).to({x:151.15},0).to({_off:true},1).wait(2).to({_off:false,x:150},0).wait(286));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(182).to({_off:false},0).to({_off:true},1).wait(1).to({_off:false,x:122.95,y:342.675},0).wait(1).to({x:116.55,y:342.525},0).to({_off:true},1).wait(1).to({_off:false,x:105.85,y:342.275},0).wait(1).to({x:101.45,y:342.175},0).to({_off:true},1).wait(1).to({_off:false,x:94.3,y:342.025},0).to({_off:true},1).wait(1).to({_off:false,x:89,y:341.925},0).to({_off:true},1).wait(3).to({_off:false,x:82.55,y:341.775},0).to({_off:true},1).wait(6).to({_off:false,x:79.1,y:341.675},0).wait(1).to({x:79},0).to({_off:true},1).wait(2).to({_off:false,x:78.85},0).wait(73).to({y:342.225},0).wait(1).to({x:78.95},0).to({_off:true},1).wait(1).to({_off:false,x:79.75},0).wait(1).to({x:80.55},0).wait(1).to({x:81.55},0).to({_off:true},1).wait(4).to({_off:false,x:91.25,y:342.275},0).wait(1).to({x:94.3},0).wait(1).to({x:97.75},0).wait(1).to({x:101.7},0).wait(1).to({x:106.1,y:342.325},0).to({_off:true},1).wait(82).to({_off:false,x:187.2,y:342.675},0).to({_off:true},1).wait(11).to({_off:false,x:150.1},0).to({_off:true},1).wait(286));

	// Screen
	this.screen = new lib.Screen();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(152.4,560.5,0.7277,0.7277,0,0,0,150.6,99.4);
	this.screen.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(3).to({regX:168.9,regY:104.7,x:165.65,y:548.7,alpha:0.0655},0).wait(1).to({y:532.2,alpha:0.1348},0).wait(1).to({y:515.05,alpha:0.2068},0).wait(1).to({x:165.6,y:497.6,alpha:0.28},0).wait(1).to({y:480.3,alpha:0.3528},0).wait(1).to({y:463.5,alpha:0.4233},0).wait(1).to({y:447.55,alpha:0.49},0).wait(1).to({x:165.55,y:432.8,alpha:0.5521},0).wait(1).to({y:419.3,alpha:0.6088},0).wait(1).to({y:407.05,alpha:0.6601},0).wait(1).to({y:396.1,alpha:0.7062},0).wait(1).to({y:386.3,alpha:0.7472},0).wait(1).to({y:377.6,alpha:0.7837},0).wait(1).to({y:369.9,alpha:0.8161},0).wait(1).to({x:165.5,y:363.1,alpha:0.8447},0).wait(1).to({y:357.1,alpha:0.8698},0).wait(1).to({y:351.8,alpha:0.892},0).wait(1).to({y:347.2,alpha:0.9113},0).wait(1).to({y:343.2,alpha:0.9282},0).wait(1).to({y:339.7,alpha:0.9428},0).wait(1).to({y:336.7,alpha:0.9553},0).wait(1).to({y:334.15,alpha:0.966},0).wait(1).to({y:332.05,alpha:0.975},0).wait(1).to({y:330.25,alpha:0.9824},0).wait(1).to({y:328.85,alpha:0.9884},0).wait(1).to({y:327.75,alpha:0.9931},0).wait(1).to({y:326.9,alpha:0.9965},0).wait(1).to({y:326.35,alpha:0.9988},0).wait(1).to({regX:150.3,regY:99.2,x:152.2,y:322.25,alpha:1},0).wait(645));

	// MacMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_170 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_graphics_171 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_172 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_173 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_graphics_174 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_175 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_graphics_176 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_177 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_178 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_179 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_180 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_181 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_182 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_183 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_184 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_graphics_185 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_186 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_187 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_188 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_189 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_190 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_191 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_192 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_193 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_194 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_195 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_196 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_197 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_198 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_199 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_200 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_201 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_202 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_203 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_204 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_205 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_206 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_207 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_208 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_209 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_210 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_280 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_281 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_282 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_283 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_284 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_285 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_286 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_287 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_288 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_289 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_290 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_291 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_292 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_293 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_294 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_295 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_296 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_297 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_298 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_299 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_300 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_301 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_302 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_graphics_303 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_304 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_305 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_graphics_306 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_graphics_307 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_308 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_309 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_310 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_graphics_311 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_graphics_312 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_graphics_313 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_graphics_314 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_graphics_315 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_graphics_316 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_317 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_318 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_319 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_320 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_321 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_322 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_323 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_324 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_363 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_364 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_365 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_366 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_367 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_368 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_369 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_370 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_371 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_372 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_373 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_374 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_375 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_376 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_377 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_378 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_379 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_380 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_381 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_382 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_383 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_384 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_385 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_386 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_387 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_388 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_389 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_graphics_390 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(170).to({graphics:mask_graphics_170,x:108.9,y:347.95}).wait(1).to({graphics:mask_graphics_171,x:85.45,y:347.4}).wait(1).to({graphics:mask_graphics_172,x:63.725,y:346.9}).wait(1).to({graphics:mask_graphics_173,x:43.675,y:346.45}).wait(1).to({graphics:mask_graphics_174,x:25.175,y:346.05}).wait(1).to({graphics:mask_graphics_175,x:8.125,y:345.65}).wait(1).to({graphics:mask_graphics_176,x:-7.475,y:345.3}).wait(1).to({graphics:mask_graphics_177,x:-21.775,y:344.95}).wait(1).to({graphics:mask_graphics_178,x:-34.875,y:344.65}).wait(1).to({graphics:mask_graphics_179,x:-46.75,y:344.4}).wait(1).to({graphics:mask_graphics_180,x:-57.55,y:344.15}).wait(1).to({graphics:mask_graphics_181,x:-67.325,y:343.95}).wait(1).to({graphics:mask_graphics_182,x:-76.125,y:343.75}).wait(1).to({graphics:mask_graphics_183,x:-84.05,y:343.55}).wait(1).to({graphics:mask_graphics_184,x:-91.125,y:343.4}).wait(1).to({graphics:mask_graphics_185,x:-97.45,y:343.25}).wait(1).to({graphics:mask_graphics_186,x:-103.05,y:343.1}).wait(1).to({graphics:mask_graphics_187,x:-108,y:343}).wait(1).to({graphics:mask_graphics_188,x:-112.3,y:342.9}).wait(1).to({graphics:mask_graphics_189,x:-116.1,y:342.8}).wait(1).to({graphics:mask_graphics_190,x:-119.4,y:342.75}).wait(1).to({graphics:mask_graphics_191,x:-122.2,y:342.7}).wait(1).to({graphics:mask_graphics_192,x:-124.6,y:342.65}).wait(1).to({graphics:mask_graphics_193,x:-126.65,y:342.6}).wait(1).to({graphics:mask_graphics_194,x:-128.35,y:342.55}).wait(1).to({graphics:mask_graphics_195,x:-129.8,y:342.5}).wait(1).to({graphics:mask_graphics_196,x:-130.95,y:342.5}).wait(1).to({graphics:mask_graphics_197,x:-131.9,y:342.45}).wait(1).to({graphics:mask_graphics_198,x:-132.65,y:342.45}).wait(1).to({graphics:mask_graphics_199,x:-133.2,y:342.45}).wait(1).to({graphics:mask_graphics_200,x:-133.65,y:342.4}).wait(1).to({graphics:mask_graphics_201,x:-134,y:342.4}).wait(1).to({graphics:mask_graphics_202,x:-134.2,y:342.4}).wait(1).to({graphics:mask_graphics_203,x:-134.35,y:342.4}).wait(1).to({graphics:mask_graphics_204,x:-134.45,y:342.4}).wait(1).to({graphics:mask_graphics_205,x:-134.55,y:342.4}).wait(1).to({graphics:mask_graphics_206,x:-134.55,y:342.4}).wait(1).to({graphics:mask_graphics_207,x:-134.6,y:342.4}).wait(1).to({graphics:mask_graphics_208,x:-134.6,y:342.4}).wait(1).to({graphics:mask_graphics_209,x:-134.6,y:342.4}).wait(1).to({graphics:mask_graphics_210,x:-134.6,y:342.4}).wait(70).to({graphics:mask_graphics_280,x:-134.6,y:342.95}).wait(1).to({graphics:mask_graphics_281,x:-134.5,y:342.95}).wait(1).to({graphics:mask_graphics_282,x:-134.2,y:342.95}).wait(1).to({graphics:mask_graphics_283,x:-133.7,y:342.95}).wait(1).to({graphics:mask_graphics_284,x:-132.95,y:342.95}).wait(1).to({graphics:mask_graphics_285,x:-131.95,y:342.95}).wait(1).to({graphics:mask_graphics_286,x:-130.7,y:342.95}).wait(1).to({graphics:mask_graphics_287,x:-129.15,y:342.95}).wait(1).to({graphics:mask_graphics_288,x:-127.3,y:342.95}).wait(1).to({graphics:mask_graphics_289,x:-125.1,y:343}).wait(1).to({graphics:mask_graphics_290,x:-122.55,y:343}).wait(1).to({graphics:mask_graphics_291,x:-119.575,y:343}).wait(1).to({graphics:mask_graphics_292,x:-116.2,y:343}).wait(1).to({graphics:mask_graphics_293,x:-112.375,y:343}).wait(1).to({graphics:mask_graphics_294,x:-108.075,y:343.05}).wait(1).to({graphics:mask_graphics_295,x:-103.325,y:343.05}).wait(1).to({graphics:mask_graphics_296,x:-98.075,y:343.05}).wait(1).to({graphics:mask_graphics_297,x:-92.375,y:343.1}).wait(1).to({graphics:mask_graphics_298,x:-86.275,y:343.1}).wait(1).to({graphics:mask_graphics_299,x:-79.775,y:343.1}).wait(1).to({graphics:mask_graphics_300,x:-73.075,y:343.15}).wait(1).to({graphics:mask_graphics_301,x:-66.175,y:343.15}).wait(1).to({graphics:mask_graphics_302,x:-59.3,y:343.2}).wait(1).to({graphics:mask_graphics_303,x:-52.525,y:343.2}).wait(1).to({graphics:mask_graphics_304,x:-45.975,y:343.25}).wait(1).to({graphics:mask_graphics_305,x:-39.75,y:343.25}).wait(1).to({graphics:mask_graphics_306,x:-33.925,y:343.25}).wait(1).to({graphics:mask_graphics_307,x:-28.525,y:343.3}).wait(1).to({graphics:mask_graphics_308,x:-23.575,y:343.3}).wait(1).to({graphics:mask_graphics_309,x:-19.075,y:343.3}).wait(1).to({graphics:mask_graphics_310,x:-15.025,y:343.35}).wait(1).to({graphics:mask_graphics_311,x:-11.375,y:343.35}).wait(1).to({graphics:mask_graphics_312,x:-8.15,y:343.35}).wait(1).to({graphics:mask_graphics_313,x:-5.3,y:343.35}).wait(1).to({graphics:mask_graphics_314,x:-2.8,y:343.35}).wait(1).to({graphics:mask_graphics_315,x:-0.625,y:343.35}).wait(1).to({graphics:mask_graphics_316,x:1.225,y:343.4}).wait(1).to({graphics:mask_graphics_317,x:2.825,y:343.4}).wait(1).to({graphics:mask_graphics_318,x:4.125,y:343.4}).wait(1).to({graphics:mask_graphics_319,x:5.225,y:343.4}).wait(1).to({graphics:mask_graphics_320,x:6.075,y:343.4}).wait(1).to({graphics:mask_graphics_321,x:6.675,y:343.4}).wait(1).to({graphics:mask_graphics_322,x:7.125,y:343.4}).wait(1).to({graphics:mask_graphics_323,x:7.375,y:343.4}).wait(1).to({graphics:mask_graphics_324,x:7.475,y:343.4}).wait(39).to({graphics:mask_graphics_363,x:7.475,y:343.4}).wait(1).to({graphics:mask_graphics_364,x:7.375,y:343.4}).wait(1).to({graphics:mask_graphics_365,x:7.075,y:343.4}).wait(1).to({graphics:mask_graphics_366,x:6.525,y:343.4}).wait(1).to({graphics:mask_graphics_367,x:5.725,y:343.4}).wait(1).to({graphics:mask_graphics_368,x:4.625,y:343.4}).wait(1).to({graphics:mask_graphics_369,x:3.175,y:343.4}).wait(1).to({graphics:mask_graphics_370,x:1.325,y:343.4}).wait(1).to({graphics:mask_graphics_371,x:-1.025,y:343.4}).wait(1).to({graphics:mask_graphics_372,x:-3.925,y:343.4}).wait(1).to({graphics:mask_graphics_373,x:-7.475,y:343.4}).wait(1).to({graphics:mask_graphics_374,x:-11.775,y:343.4}).wait(1).to({graphics:mask_graphics_375,x:-16.825,y:343.4}).wait(1).to({graphics:mask_graphics_376,x:-22.625,y:343.4}).wait(1).to({graphics:mask_graphics_377,x:-28.825,y:343.4}).wait(1).to({graphics:mask_graphics_378,x:-35.125,y:343.4}).wait(1).to({graphics:mask_graphics_379,x:-41.075,y:343.4}).wait(1).to({graphics:mask_graphics_380,x:-46.275,y:343.4}).wait(1).to({graphics:mask_graphics_381,x:-50.725,y:343.4}).wait(1).to({graphics:mask_graphics_382,x:-54.325,y:343.4}).wait(1).to({graphics:mask_graphics_383,x:-57.225,y:343.4}).wait(1).to({graphics:mask_graphics_384,x:-59.525,y:343.4}).wait(1).to({graphics:mask_graphics_385,x:-61.325,y:343.4}).wait(1).to({graphics:mask_graphics_386,x:-62.675,y:343.4}).wait(1).to({graphics:mask_graphics_387,x:-63.625,y:343.4}).wait(1).to({graphics:mask_graphics_388,x:-64.275,y:343.4}).wait(1).to({graphics:mask_graphics_389,x:-64.625,y:343.4}).wait(1).to({graphics:mask_graphics_390,x:-64.725,y:343.4}).wait(286));

	// Mac
	this.instance = new lib.Mac();
	this.instance.parent = this;
	this.instance.setTransform(151.7,583.05,1.0997,1.0997,0,0,0,144.2,120.2);
	this.instance.alpha = 0;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({regX:144,regY:120,x:151.45,y:567.2,alpha:0.0655},0).wait(1).to({y:550.7,alpha:0.1348},0).wait(1).to({y:533.6,alpha:0.2068},0).wait(1).to({y:516.15,alpha:0.28},0).wait(1).to({y:498.85,alpha:0.3528},0).wait(1).to({y:482.1,alpha:0.4233},0).wait(1).to({y:466.2,alpha:0.49},0).wait(1).to({y:451.45,alpha:0.5521},0).wait(1).to({y:437.95,alpha:0.6088},0).wait(1).to({y:425.75,alpha:0.6601},0).wait(1).to({y:414.8,alpha:0.7062},0).wait(1).to({y:405,alpha:0.7472},0).wait(1).to({y:396.3,alpha:0.7837},0).wait(1).to({y:388.65,alpha:0.8161},0).wait(1).to({y:381.85,alpha:0.8447},0).wait(1).to({y:375.85,alpha:0.8698},0).wait(1).to({y:370.6,alpha:0.892},0).wait(1).to({y:365.95,alpha:0.9113},0).wait(1).to({y:361.95,alpha:0.9282},0).wait(1).to({y:358.5,alpha:0.9428},0).wait(1).to({y:355.5,alpha:0.9553},0).wait(1).to({y:352.95,alpha:0.966},0).wait(1).to({y:350.8,alpha:0.975},0).wait(1).to({y:349.05,alpha:0.9824},0).wait(1).to({y:347.65,alpha:0.9884},0).wait(1).to({y:346.55,alpha:0.9931},0).wait(1).to({y:345.7,alpha:0.9965},0).wait(1).to({y:345.15,alpha:0.9988},0).wait(1).to({regX:144.2,regY:120.2,x:151.7,alpha:1},0).wait(645));

	// MacBookMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_170 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_171 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_172 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_173 = new cjs.Graphics().p("EghjAWFMAAAgsJMBDHAAAMAAAAsJg");
	var mask_1_graphics_174 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_175 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_176 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_177 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_178 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_179 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_180 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_181 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_182 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_183 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_184 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDIAAAMAAAAsJg");
	var mask_1_graphics_185 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDIAAAMAAAAsKg");
	var mask_1_graphics_186 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_187 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_188 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDIAAAMAAAAsLg");
	var mask_1_graphics_189 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_190 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_191 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDIAAAMAAAAsKg");
	var mask_1_graphics_192 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_193 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDIAAAMAAAAsKg");
	var mask_1_graphics_194 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_195 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_196 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_197 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_198 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_1_graphics_199 = new cjs.Graphics().p("EghjAWGMAAAgsLMBDHAAAMAAAAsLg");
	var mask_1_graphics_200 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_201 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_202 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_203 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDIAAAMAAAAsKg");
	var mask_1_graphics_204 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_205 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_206 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_207 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_208 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_209 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_210 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_280 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_281 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_282 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_283 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_284 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_285 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_286 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_287 = new cjs.Graphics().p("EghjAWFMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_288 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_289 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_290 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_291 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_292 = new cjs.Graphics().p("EghjAWGMAAAgsKMBDHAAAMAAAAsKg");
	var mask_1_graphics_293 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_294 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_295 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_296 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_297 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_298 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_299 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_300 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_301 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_302 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_303 = new cjs.Graphics().p("EghkAWGMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_304 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_305 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_306 = new cjs.Graphics().p("EghkAWFMAAAgsKMBDJAAAMAAAAsKg");
	var mask_1_graphics_307 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_308 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_309 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_310 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_311 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_312 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_313 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_314 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_315 = new cjs.Graphics().p("EghkAWGMAAAgsLMBDJAAAMAAAAsLg");
	var mask_1_graphics_316 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_317 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_318 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_319 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_320 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_321 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_322 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_323 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_324 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_363 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_364 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_365 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_366 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_367 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_368 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_369 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_370 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_371 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_372 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_373 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_374 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_375 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_376 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_377 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_378 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_379 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_380 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_381 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_382 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_383 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_384 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_385 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_386 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_387 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_388 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_389 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");
	var mask_1_graphics_390 = new cjs.Graphics().p("EghkAWFMAAAgsJMBDJAAAMAAAAsJg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(170).to({graphics:mask_1_graphics_170,x:538.625,y:347.95}).wait(1).to({graphics:mask_1_graphics_171,x:515.175,y:347.4}).wait(1).to({graphics:mask_1_graphics_172,x:493.475,y:346.9}).wait(1).to({graphics:mask_1_graphics_173,x:473.4,y:346.45}).wait(1).to({graphics:mask_1_graphics_174,x:454.9,y:346.05}).wait(1).to({graphics:mask_1_graphics_175,x:437.875,y:345.65}).wait(1).to({graphics:mask_1_graphics_176,x:422.25,y:345.3}).wait(1).to({graphics:mask_1_graphics_177,x:407.95,y:344.95}).wait(1).to({graphics:mask_1_graphics_178,x:394.875,y:344.65}).wait(1).to({graphics:mask_1_graphics_179,x:383,y:344.4}).wait(1).to({graphics:mask_1_graphics_180,x:372.2,y:344.15}).wait(1).to({graphics:mask_1_graphics_181,x:362.425,y:343.95}).wait(1).to({graphics:mask_1_graphics_182,x:353.6,y:343.75}).wait(1).to({graphics:mask_1_graphics_183,x:345.7,y:343.55}).wait(1).to({graphics:mask_1_graphics_184,x:338.6,y:343.4}).wait(1).to({graphics:mask_1_graphics_185,x:332.3,y:343.25}).wait(1).to({graphics:mask_1_graphics_186,x:326.7,y:343.1}).wait(1).to({graphics:mask_1_graphics_187,x:321.75,y:343}).wait(1).to({graphics:mask_1_graphics_188,x:317.45,y:342.9}).wait(1).to({graphics:mask_1_graphics_189,x:313.65,y:342.8}).wait(1).to({graphics:mask_1_graphics_190,x:310.35,y:342.75}).wait(1).to({graphics:mask_1_graphics_191,x:307.55,y:342.7}).wait(1).to({graphics:mask_1_graphics_192,x:305.15,y:342.65}).wait(1).to({graphics:mask_1_graphics_193,x:303.1,y:342.6}).wait(1).to({graphics:mask_1_graphics_194,x:301.4,y:342.55}).wait(1).to({graphics:mask_1_graphics_195,x:299.95,y:342.5}).wait(1).to({graphics:mask_1_graphics_196,x:298.8,y:342.5}).wait(1).to({graphics:mask_1_graphics_197,x:297.85,y:342.45}).wait(1).to({graphics:mask_1_graphics_198,x:297.1,y:342.45}).wait(1).to({graphics:mask_1_graphics_199,x:296.55,y:342.45}).wait(1).to({graphics:mask_1_graphics_200,x:296.1,y:342.4}).wait(1).to({graphics:mask_1_graphics_201,x:295.75,y:342.4}).wait(1).to({graphics:mask_1_graphics_202,x:295.55,y:342.4}).wait(1).to({graphics:mask_1_graphics_203,x:295.4,y:342.4}).wait(1).to({graphics:mask_1_graphics_204,x:295.3,y:342.4}).wait(1).to({graphics:mask_1_graphics_205,x:295.2,y:342.4}).wait(1).to({graphics:mask_1_graphics_206,x:295.2,y:342.4}).wait(1).to({graphics:mask_1_graphics_207,x:295.15,y:342.4}).wait(1).to({graphics:mask_1_graphics_208,x:295.15,y:342.4}).wait(1).to({graphics:mask_1_graphics_209,x:295.15,y:342.4}).wait(1).to({graphics:mask_1_graphics_210,x:295.15,y:342.4}).wait(70).to({graphics:mask_1_graphics_280,x:295.15,y:342.95}).wait(1).to({graphics:mask_1_graphics_281,x:295.25,y:342.95}).wait(1).to({graphics:mask_1_graphics_282,x:295.55,y:342.95}).wait(1).to({graphics:mask_1_graphics_283,x:296.05,y:342.95}).wait(1).to({graphics:mask_1_graphics_284,x:296.8,y:342.95}).wait(1).to({graphics:mask_1_graphics_285,x:297.8,y:342.95}).wait(1).to({graphics:mask_1_graphics_286,x:299.05,y:342.95}).wait(1).to({graphics:mask_1_graphics_287,x:300.6,y:342.95}).wait(1).to({graphics:mask_1_graphics_288,x:302.45,y:342.95}).wait(1).to({graphics:mask_1_graphics_289,x:304.65,y:343}).wait(1).to({graphics:mask_1_graphics_290,x:307.2,y:343}).wait(1).to({graphics:mask_1_graphics_291,x:310.175,y:343}).wait(1).to({graphics:mask_1_graphics_292,x:313.55,y:343}).wait(1).to({graphics:mask_1_graphics_293,x:317.375,y:343}).wait(1).to({graphics:mask_1_graphics_294,x:321.675,y:343.05}).wait(1).to({graphics:mask_1_graphics_295,x:326.425,y:343.05}).wait(1).to({graphics:mask_1_graphics_296,x:331.675,y:343.05}).wait(1).to({graphics:mask_1_graphics_297,x:337.375,y:343.1}).wait(1).to({graphics:mask_1_graphics_298,x:343.5,y:343.1}).wait(1).to({graphics:mask_1_graphics_299,x:349.975,y:343.1}).wait(1).to({graphics:mask_1_graphics_300,x:356.7,y:343.15}).wait(1).to({graphics:mask_1_graphics_301,x:363.575,y:343.15}).wait(1).to({graphics:mask_1_graphics_302,x:370.475,y:343.2}).wait(1).to({graphics:mask_1_graphics_303,x:377.225,y:343.2}).wait(1).to({graphics:mask_1_graphics_304,x:383.775,y:343.25}).wait(1).to({graphics:mask_1_graphics_305,x:390.025,y:343.25}).wait(1).to({graphics:mask_1_graphics_306,x:395.85,y:343.25}).wait(1).to({graphics:mask_1_graphics_307,x:401.25,y:343.3}).wait(1).to({graphics:mask_1_graphics_308,x:406.2,y:343.3}).wait(1).to({graphics:mask_1_graphics_309,x:410.7,y:343.3}).wait(1).to({graphics:mask_1_graphics_310,x:414.75,y:343.35}).wait(1).to({graphics:mask_1_graphics_311,x:418.4,y:343.35}).wait(1).to({graphics:mask_1_graphics_312,x:421.6,y:343.35}).wait(1).to({graphics:mask_1_graphics_313,x:424.475,y:343.35}).wait(1).to({graphics:mask_1_graphics_314,x:426.975,y:343.35}).wait(1).to({graphics:mask_1_graphics_315,x:429.15,y:343.35}).wait(1).to({graphics:mask_1_graphics_316,x:431,y:343.4}).wait(1).to({graphics:mask_1_graphics_317,x:432.6,y:343.4}).wait(1).to({graphics:mask_1_graphics_318,x:433.9,y:343.4}).wait(1).to({graphics:mask_1_graphics_319,x:435,y:343.4}).wait(1).to({graphics:mask_1_graphics_320,x:435.85,y:343.4}).wait(1).to({graphics:mask_1_graphics_321,x:436.45,y:343.4}).wait(1).to({graphics:mask_1_graphics_322,x:436.9,y:343.4}).wait(1).to({graphics:mask_1_graphics_323,x:437.15,y:343.4}).wait(1).to({graphics:mask_1_graphics_324,x:437.25,y:343.4}).wait(39).to({graphics:mask_1_graphics_363,x:437.25,y:343.4}).wait(1).to({graphics:mask_1_graphics_364,x:437.15,y:343.4}).wait(1).to({graphics:mask_1_graphics_365,x:436.85,y:343.4}).wait(1).to({graphics:mask_1_graphics_366,x:436.3,y:343.4}).wait(1).to({graphics:mask_1_graphics_367,x:435.5,y:343.4}).wait(1).to({graphics:mask_1_graphics_368,x:434.4,y:343.4}).wait(1).to({graphics:mask_1_graphics_369,x:432.95,y:343.4}).wait(1).to({graphics:mask_1_graphics_370,x:431.1,y:343.4}).wait(1).to({graphics:mask_1_graphics_371,x:428.75,y:343.4}).wait(1).to({graphics:mask_1_graphics_372,x:425.85,y:343.4}).wait(1).to({graphics:mask_1_graphics_373,x:422.3,y:343.4}).wait(1).to({graphics:mask_1_graphics_374,x:418,y:343.4}).wait(1).to({graphics:mask_1_graphics_375,x:412.95,y:343.4}).wait(1).to({graphics:mask_1_graphics_376,x:407.175,y:343.4}).wait(1).to({graphics:mask_1_graphics_377,x:400.95,y:343.4}).wait(1).to({graphics:mask_1_graphics_378,x:394.65,y:343.4}).wait(1).to({graphics:mask_1_graphics_379,x:388.725,y:343.4}).wait(1).to({graphics:mask_1_graphics_380,x:383.525,y:343.4}).wait(1).to({graphics:mask_1_graphics_381,x:379.075,y:343.4}).wait(1).to({graphics:mask_1_graphics_382,x:375.475,y:343.4}).wait(1).to({graphics:mask_1_graphics_383,x:372.575,y:343.4}).wait(1).to({graphics:mask_1_graphics_384,x:370.275,y:343.4}).wait(1).to({graphics:mask_1_graphics_385,x:368.475,y:343.4}).wait(1).to({graphics:mask_1_graphics_386,x:367.125,y:343.4}).wait(1).to({graphics:mask_1_graphics_387,x:366.175,y:343.4}).wait(1).to({graphics:mask_1_graphics_388,x:365.525,y:343.4}).wait(1).to({graphics:mask_1_graphics_389,x:365.175,y:343.4}).wait(1).to({graphics:mask_1_graphics_390,x:365.075,y:343.4}).wait(286));

	// Macbook
	this.instance_1 = new lib.Macbook_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(151.65,347.3,1.0935,1.0935,0,0,0,150.3,125.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(170).to({_off:false},0).wait(506));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,207.7,340.6,507.09999999999997);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSFT Logo
	this.logo = new lib.logo_1();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.55,193.2,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(284.1,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// Main Text
	this.smallPrint = new lib.txt_6();
	this.smallPrint.name = "smallPrint";
	this.smallPrint.parent = this;
	this.smallPrint.setTransform(181.1,239.95,0.4965,0.4965,0,0,0,0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.smallPrint).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(227.9,555.5,0.4964,0.4964);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(247.6,554.1,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Intro
	this.anim = new lib.Intro();
	this.anim.name = "anim";
	this.anim.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-11.8,-4,344.40000000000003,718.7), null);


// stage content:
(lib.O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		
		var flag1 = mc.anim.screen.flag1.flag
		var flag2 = mc.anim.screen.flag2.flag
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillFlag = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.anim.screen["flag"+aVar].flag.addChild(mc);
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		this.runBanner = function() {
		
			exportRoot.tlH1 = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if(i==0)exportRoot.tlH1.from(exportRoot.headline1[i], 0.7, {y: "+=35", alpha: 0, ease: Power4.easeOut});
				if(i!=0)exportRoot.tlH1.from(exportRoot.headline1[i], 0.7, {y: "+=35", alpha: 0, ease: Power4.easeOut}, "-=0.6");
			}
			exportRoot.tlH1.stop()
		
			
			exportRoot.tl1 = new TimelineLite();
			exportRoot.tl1.from(mc.replay_btn, 0.7, {alpha: 0,	x: "+=300",ease: Power4.easeOut})
			exportRoot.tl1.stop()
			
			exportRoot.tl2 = new TimelineLite();
			exportRoot.tl2.from(mc.txtCta, 0.7, {alpha: 0,	x: "+=300", ease: Power4.easeOut});
			exportRoot.tl2.from(mc.cta, 0.7, {alpha: 0,	x: "+=350",	ease: Power4.easeOut}, "-=0.7");
			exportRoot.tl2.stop()
		
			mc.logo.gotoAndPlay(1)
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(138.2,296,194.40000000000003,418.70000000000005);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_.png?1542127304581", id:"O365_MacUsrs_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;