(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_ONDRV_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_", frames: [[252,0,200,128],[0,0,250,510]]}
];


// symbols:



(lib.Laptop_728x90_resize = function() {
	this.initialize(ss["O365_ONDRV_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Phone_resize = function() {
	this.initialize(ss["O365_ONDRV_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.radialWipeWhole = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// RadialWipe (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_4 = new cjs.Graphics().p("A1UDOMAqpABSMgnxABWg");
	var mask_graphics_5 = new cjs.Graphics().p("A1ICxMAqRACAMgndAA0g");
	var mask_graphics_6 = new cjs.Graphics().p("A04COMApxAC3MgnEAAMg");
	var mask_graphics_7 = new cjs.Graphics().p("Ax/EpIimjWMApLAD4MgmlgAig");
	var mask_graphics_8 = new cjs.Graphics().p("AxxD0IidjqMAodAFBMgmAgBXg");
	var mask_graphics_9 = new cjs.Graphics().p("AxhC5IiRkBMAnlAGTMglUgCSg");
	var mask_graphics_10 = new cjs.Graphics().p("AxPB4IiAkcMAmfAHvMgkfgDTg");
	var mask_graphics_11 = new cjs.Graphics().p("Aw6AxIhsk5MAlNAJUMgjhgEbg");
	var mask_graphics_12 = new cjs.Graphics().p("AwigEIhTlaMAjrAK9MgiYgFjg");
	var mask_graphics_13 = new cjs.Graphics().p("AwIgaIgyl8MAh1AMtMghDgGxg");
	var mask_graphics_14 = new cjs.Graphics().p("AvrgvIgJmgIfpOfI/gn/g");
	var mask_graphics_15 = new cjs.Graphics().p("Au3hDIAonDIdHQNI9vpKg");
	var mask_graphics_16 = new cjs.Graphics().p("At4hVIBmnlIaLR1I7xqQg");
	var mask_graphics_17 = new cjs.Graphics().p("AsxhkICwoDIWzTPI5jrMg");
	var mask_graphics_18 = new cjs.Graphics().p("ArviWIDtn7ITyUjI3fsog");
	var mask_graphics_19 = new cjs.Graphics().p("AqmjIIExnpIQcVjI1Nt6g");
	var mask_graphics_20 = new cjs.Graphics().p("ApVj3IF5nMQgBABMzWGQyqu7gBAAg");
	var mask_graphics_21 = new cjs.Graphics().p("AnskiIHDmhQgBABI9WGQv/vnAAABg");
	var mask_graphics_22 = new cjs.Graphics().p("Ak9lJIINllQgBAAFEVdQtPv4gBAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AiSlpIJTkaQgBAABTUHQqkvugBABg");
	var mask_graphics_24 = new cjs.Graphics().p("AhGm9IKLjOQgBAAhiUXQonxJgBAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AgWoQIK5h1QAAAAkgULQmYyXgBABg");
	var mask_graphics_26 = new cjs.Graphics().p("AAmpgILdgRQgBAAneTjQj9zSgBAAgAMDpxIAAAAIAAAAg");
	var mask_graphics_27 = new cjs.Graphics().p("ABvp8ILxBbQgBAAqYSeQhXz5gBAAg");
	var mask_graphics_28 = new cjs.Graphics().p("ADDqEIL1DLQgBAAtHQ+QBU0JgBAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AEgqBILnE9QgBgBvlPHQEA0DgBAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AGCpzILKGsQgBgBxvM8QGnzmgBgBg");
	var mask_graphics_31 = new cjs.Graphics().p("AHppbIKdIWQgBgBziKiQJGy2AAgBg");
	var mask_graphics_32 = new cjs.Graphics().p("AJNo5IJkJ2QgBgB0+H+QLcxygBgBg");
	var mask_graphics_33 = new cjs.Graphics().p("ALOpGII2KNQAAAA3lIAQOwyMgBgBg");
	var mask_graphics_34 = new cjs.Graphics().p("ANTpGIIIKiQgBgB6SHsQSLyMAAgBg");
	var mask_graphics_35 = new cjs.Graphics().p("APZo5IHaKyQgBgB9CHCQVpxyAAgBg");
	var mask_graphics_36 = new cjs.Graphics().p("ARgofIGsLAQAAgB/1GAQZJw+AAgBg");
	var mask_graphics_37 = new cjs.Graphics().p("ATmn4IF/LLUAAAgABginAEnQcpvwgBgBg");
	var mask_graphics_38 = new cjs.Graphics().p("AVqnDIFSLTUAAAgABglWAC1UAgFgOGgABgABg");
	var mask_graphics_39 = new cjs.Graphics().p("AXIl5IEfLaUgABgABgmqAAaUAiMgLyAAAgABg");
	var mask_graphics_40 = new cjs.Graphics().p("ArpEDUAkJgJOAAAgABIDsLdUAAAgABgn1gCNg");
	var mask_graphics_41 = new cjs.Graphics().p("AsJCpUAl6gGbAAAgABIC6LdUAAAgABgo0gFAg");
	var mask_graphics_42 = new cjs.Graphics().p("AsiBLUAncgDcAAAgABICLLaUAAAgABgpngH8g");
	var mask_graphics_43 = new cjs.Graphics().p("As0gXUAovgASAAAgABIBcLUUAAAgABgqLgLAg");
	var mask_graphics_44 = new cjs.Graphics().p("As+h+UApwADEAAAgABIAvLLUAABAAAgqggOOg");
	var mask_graphics_45 = new cjs.Graphics().p("AtCjnUAqhAGjAAAgABIAELAUAAAgABgqlgRhg");
	var mask_graphics_46 = new cjs.Graphics().p("AsrkKUAp3AH0AAAAAAIgRK0UAAAgABgpmgSng");
	var mask_graphics_47 = new cjs.Graphics().p("AsUksUApJAJEAABgABIglKpUAAAgABgolgTrg");
	var mask_graphics_48 = new cjs.Graphics().p("Ar9lMUAobAKQAAAgABIg3KdUAAAgABgnkgUrg");
	var mask_graphics_49 = new cjs.Graphics().p("ArklrUAnpALaAABAAAIhKKQUAAAgABgmggVpg");
	var mask_graphics_50 = new cjs.Graphics().p("ArKmIUAm2AMiAAAgABIhbKDUAAAgABglbgWjg");
	var mask_graphics_51 = new cjs.Graphics().p("AqvmkUAmAANnAAAAAAIhsJ1UAAAgABgkUgXbg");
	var mask_graphics_52 = new cjs.Graphics().p("AqUm+UAlKAOqAAAgABIh9JnUAABgABgjOgYPg");
	var mask_graphics_53 = new cjs.Graphics().p("Ap3nXUAkQAPqAABAAAIiMJYUAAAgABgiFgZBg");
	var mask_graphics_54 = new cjs.Graphics().p("ApanvUAjWAQoAAAAAAIiaJJUAAAgABgg8gZwg");
	var mask_graphics_55 = new cjs.Graphics().p("Ao7oFMAiZARjIioI6I/x6dg");
	var mask_graphics_56 = new cjs.Graphics().p("AodoZMAhcASbIi0IqI+o7Fg");
	var mask_graphics_57 = new cjs.Graphics().p("An9osMAgdATQIjBIbI9c7rg");
	var mask_graphics_58 = new cjs.Graphics().p("Ando+IfdUDIjNILI8Q8Og");
	var mask_graphics_59 = new cjs.Graphics().p("Ai6obQWZS3AAAAImzIRQABgBvn7Hg");
	var mask_graphics_60 = new cjs.Graphics().p("AAqmCQPRPJABAAIqfHNQABAAk02Wg");
	var mask_graphics_61 = new cjs.Graphics().p("ABTmXQN/QvABAAIrMGRQABAAi13Ag");
	var mask_graphics_62 = new cjs.Graphics().p("ACCmnQMhSPABAAIrzFRQABAAgw3gg");
	var mask_graphics_63 = new cjs.Graphics().p("AC2mxQK5TnACgBIsVENQABAABZ3zg");
	var mask_graphics_64 = new cjs.Graphics().p("ADvm0QJIU0ABAAIsvDGQABgBDl35g");
	var mask_graphics_65 = new cjs.Graphics().p("AEsmxQHPV4ABAAItEB7QABAAFz3zg");
	var mask_graphics_66 = new cjs.Graphics().p("AiWQ4IAAAAIAAAAgAFsmnQFOWwABAAItRAvQABAAIB3fg");
	var mask_graphics_67 = new cjs.Graphics().p("AjjQaQACAAKP2+QDGXdABAAg");
	var mask_graphics_68 = new cjs.Graphics().p("AknQQQABAAM43wQhBZVABAAg");
	var mask_graphics_69 = new cjs.Graphics().p("AnZQHQAAAAPr4MQlPaeABABg");
	var mask_graphics_70 = new cjs.Graphics().p("ApQP8QAAABSh4SQpZa+ABAAg");
	var mask_graphics_71 = new cjs.Graphics().p("AqrPwIVX4CItba5g");
	var mask_graphics_72 = new cjs.Graphics().p("AsDPhIYH3hIxOaUg");
	var mask_graphics_73 = new cjs.Graphics().p("AtWPPIat2xI0tZYg");
	var mask_graphics_74 = new cjs.Graphics().p("AuiO6IdF11I31YKg");
	var mask_graphics_75 = new cjs.Graphics().p("AvoOjIfR0xI6oWxg");
	var mask_graphics_76 = new cjs.Graphics().p("AwnOLMAhPgTqI9EVTg");
	var mask_graphics_77 = new cjs.Graphics().p("AxdNzMAi7gSiI/HTzg");
	var mask_graphics_78 = new cjs.Graphics().p("AyMNbMAkZgRdMgg2ASZg");
	var mask_graphics_79 = new cjs.Graphics().p("AyzNFMAlngQeMgiRARHg");
	var mask_graphics_80 = new cjs.Graphics().p("AzSMyMAmlgPnMgjYAP/g");
	var mask_graphics_81 = new cjs.Graphics().p("AzqMiMAnVgO5MgkOAPEg");
	var mask_graphics_82 = new cjs.Graphics().p("Az7MWMAn3gOYMgk0AOZg");
	var mask_graphics_83 = new cjs.Graphics().p("AUGh3MglKAN/IjBAEMAoLgODg");
	var mask_graphics_84 = new cjs.Graphics().p("AUKh0MglSAN3IjBAGMAoTgN9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_4,x:-30.475,y:37.4131}).wait(1).to({graphics:mask_graphics_5,x:-29.2567,y:35.7355}).wait(1).to({graphics:mask_graphics_6,x:-27.7225,y:33.7366}).wait(1).to({graphics:mask_graphics_7,x:-25.8188,y:33.1328}).wait(1).to({graphics:mask_graphics_8,x:-23.4816,y:33.1364}).wait(1).to({graphics:mask_graphics_9,x:-20.6349,y:33.1407}).wait(1).to({graphics:mask_graphics_10,x:-17.1898,y:33.1455}).wait(1).to({graphics:mask_graphics_11,x:-13.0447,y:33.1511}).wait(1).to({graphics:mask_graphics_12,x:-8.0854,y:31.1744}).wait(1).to({graphics:mask_graphics_13,x:-2.1882,y:25.6255}).wait(1).to({graphics:mask_graphics_14,x:4.7746,y:19.9829}).wait(1).to({graphics:mask_graphics_15,x:10.9101,y:14.4431}).wait(1).to({graphics:mask_graphics_16,x:17.2809,y:9.2677}).wait(1).to({graphics:mask_graphics_17,x:24.2991,y:4.6767}).wait(1).to({graphics:mask_graphics_18,x:30.8947,y:0.4944}).wait(1).to({graphics:mask_graphics_19,x:38.2988,y:-2.6782}).wait(1).to({graphics:mask_graphics_20,x:46.4041,y:-4.4618}).wait(1).to({graphics:mask_graphics_21,x:53.1224,y:-4.4826}).wait(1).to({graphics:mask_graphics_22,x:53.1412,y:-2.4316}).wait(1).to({graphics:mask_graphics_23,x:53.1292,y:1.8616}).wait(1).to({graphics:mask_graphics_24,x:58.0793,y:1.1211}).wait(1).to({graphics:mask_graphics_25,x:67.5476,y:1.7}).wait(1).to({graphics:mask_graphics_26,x:77.0998,y:3.7031}).wait(1).to({graphics:mask_graphics_27,x:86.4099,y:2.5805}).wait(1).to({graphics:mask_graphics_28,x:95.1677,y:1.7535}).wait(1).to({graphics:mask_graphics_29,x:103.1093,y:2.074}).wait(1).to({graphics:mask_graphics_30,x:110.0369,y:3.5014}).wait(1).to({graphics:mask_graphics_31,x:115.8252,y:5.9471}).wait(1).to({graphics:mask_graphics_32,x:120.1139,y:9.1284}).wait(1).to({graphics:mask_graphics_33,x:128.4223,y:7.8914}).wait(1).to({graphics:mask_graphics_34,x:137.0501,y:7.8956}).wait(1).to({graphics:mask_graphics_35,x:145.8835,y:9.1796}).wait(1).to({graphics:mask_graphics_36,x:154.8045,y:11.7698}).wait(1).to({graphics:mask_graphics_37,x:163.6917,y:15.6812}).wait(1).to({graphics:mask_graphics_38,x:172.4116,y:20.8499}).wait(1).to({graphics:mask_graphics_39,x:176.6622,y:28.2365}).wait(1).to({graphics:mask_graphics_40,x:180.3936,y:40.1187}).wait(1).to({graphics:mask_graphics_41,x:183.5449,y:48.9965}).wait(1).to({graphics:mask_graphics_42,x:186.0564,y:58.3769}).wait(1).to({graphics:mask_graphics_43,x:187.8709,y:68.2123}).wait(1).to({graphics:mask_graphics_44,x:188.9354,y:78.4496}).wait(1).to({graphics:mask_graphics_45,x:189.0851,y:89.1363}).wait(1).to({graphics:mask_graphics_46,x:186.7935,y:92.629}).wait(1).to({graphics:mask_graphics_47,x:184.5627,y:95.9812}).wait(1).to({graphics:mask_graphics_48,x:182.2175,y:99.1917}).wait(1).to({graphics:mask_graphics_49,x:179.7628,y:102.2588}).wait(1).to({graphics:mask_graphics_50,x:177.2036,y:105.1812}).wait(1).to({graphics:mask_graphics_51,x:174.5451,y:107.9576}).wait(1).to({graphics:mask_graphics_52,x:171.7924,y:110.587}).wait(1).to({graphics:mask_graphics_53,x:168.9509,y:113.0688}).wait(1).to({graphics:mask_graphics_54,x:166.0258,y:115.4023}).wait(1).to({graphics:mask_graphics_55,x:163.0225,y:117.5872}).wait(1).to({graphics:mask_graphics_56,x:159.9464,y:119.6234}).wait(1).to({graphics:mask_graphics_57,x:156.8031,y:121.511}).wait(1).to({graphics:mask_graphics_58,x:153.5776,y:123.2033}).wait(1).to({graphics:mask_graphics_59,x:124.7455,y:119.6789}).wait(1).to({graphics:mask_graphics_60,x:102.0127,y:104.4198}).wait(1).to({graphics:mask_graphics_61,x:97.8834,y:106.5397}).wait(1).to({graphics:mask_graphics_62,x:93.2205,y:108.088}).wait(1).to({graphics:mask_graphics_63,x:88.0555,y:109.0341}).wait(1).to({graphics:mask_graphics_64,x:82.4252,y:109.3522}).wait(1).to({graphics:mask_graphics_65,x:76.3719,y:109.0217}).wait(1).to({graphics:mask_graphics_66,x:69.9428,y:108.0273}).wait(1).to({graphics:mask_graphics_67,x:62.9498,y:108.0964}).wait(1).to({graphics:mask_graphics_68,x:52.9653,y:114.1053}).wait(1).to({graphics:mask_graphics_69,x:52.98,y:117.784}).wait(1).to({graphics:mask_graphics_70,x:46.6557,y:119.3429}).wait(1).to({graphics:mask_graphics_71,x:37.6247,y:119.0574}).wait(1).to({graphics:mask_graphics_72,x:28.881,y:117.2419}).wait(1).to({graphics:mask_graphics_73,x:20.6036,y:114.2262}).wait(1).to({graphics:mask_graphics_74,x:12.9277,y:110.3381}).wait(1).to({graphics:mask_graphics_75,x:5.9472,y:105.8897}).wait(1).to({graphics:mask_graphics_76,x:-0.2799,y:101.1681}).wait(1).to({graphics:mask_graphics_77,x:-5.7253,y:96.4301}).wait(1).to({graphics:mask_graphics_78,x:-10.3837,y:91.8987}).wait(1).to({graphics:mask_graphics_79,x:-14.2661,y:87.7627}).wait(1).to({graphics:mask_graphics_80,x:-17.3933,y:84.1776}).wait(1).to({graphics:mask_graphics_81,x:-19.7903,y:81.2665}).wait(1).to({graphics:mask_graphics_82,x:-21.4817,y:79.1226}).wait(1).to({graphics:mask_graphics_83,x:-22.4876,y:78.0488}).wait(1).to({graphics:mask_graphics_84,x:-22.8102,y:77.7227}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Trimpath Radial
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DA3A00").ss(2,1,1).p("AjvpKQBchTDHgYQC9gYDZAlQDgAlCkBWQC1BgA1CCQB6hSCpAGQCXAFCUBIQCQBGBNBmQBTBrgdBiQCXg6CdAsQCOAoBtBvQBqBrAfB9QAiCFhDBfQhFBkkAAwQjlArk1gJQksgJjvg1Qj+g5hHhUQi7BYkKADQkCACjZhMQh2BwlNAtQkjAomDgSQlngQkgg4Qkng6g9hFQjaA5iHhqQh2hdgCihQgCigB1hYQCEhjDbBCQgXhmBGiJQBDiDB/htQCGh0CSgrQCkgwCMA5QB2iJC/g6QCngzC9ARQCuAQCCBDQCDBDAWBWg");
	this.shape.setTransform(104.4064,60.5869,0.9961,0.9865);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4).to({_off:false},0).wait(80).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-160.8,-22,530.5,165.2);


(lib.PhoneBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AuKS+MAAAgl7IcVAAMAAAAl7g");
	mask.setTransform(76.95,111.913);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("ApoDLIAAmUITRAAIAAGUg");
	this.shape.setTransform(80.45,106.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Phone_resize();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6356,0.6356);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.PhoneBG, new cjs.Rectangle(0,0,158.9,233.4), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.75,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.325,2.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.45,2.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.125,2.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.075,2.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.275,-5.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.3,2.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.475,0.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.625,5.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.675,5.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.625,-5.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.675,-5.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.laptop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Laptop_728x90_resize();
	this.instance.parent = this;
	this.instance.setTransform(-61.15,-15.05,2.1622,2.1622);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.1,-15,432.40000000000003,276.7);


(lib.Image3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlCE7IAAp1IKFAAIAAJ1g");
	mask.setTransform(191.875,167.8);

	// Layer_1
	this.instance = new lib.Phone_resize();
	this.instance.parent = this;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Image3, new cjs.Rectangle(159.6,136.4,64.6,62.900000000000006), null);


(lib.Image2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlCE7IAAp1IKFAAIAAJ1g");
	mask.setTransform(126.325,167.8);

	// Layer_1
	this.instance = new lib.Phone_resize();
	this.instance.parent = this;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Image2, new cjs.Rectangle(94.1,136.4,64.5,62.900000000000006), null);


(lib.Image1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlCE7IAAp1IKFAAIAAJ1g");
	mask.setTransform(61.475,167.8);

	// Layer_1
	this.instance = new lib.Phone_resize();
	this.instance.parent = this;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Image1, new cjs.Rectangle(29.2,136.4,64.6,62.900000000000006), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.cloud_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA3A00").s().p("AgaAfQgKgLAAgTQAAgMAGgKQAEgJAJgFQAJgGAJAAQARAAAJAKQAJAKAAASIAAAIIg1AAQAAALAHAGQAFAGALAAQAHAAAGgDQAGgBAFgEIAAAPQgFADgHACQgIACgJAAQgQAAgLgLgAgKgWQgFAGgCAJIAjAAQABgKgFgFQgEgFgJAAQgGAAgFAFg");
	this.shape.setTransform(171.15,69.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DA3A00").s().p("AgKAoIgdhPIAUAAIARA0QACAIAAAGIAAAAIADgNIASg1IATAAIgfBPg");
	this.shape_1.setTransform(162.8,69.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DA3A00").s().p("AgIA8IAAhPIARAAIAABPgAgHgpQgDgDAAgEQAAgEADgDQADgEAEAAQAFAAADAEQADADAAAEQAAAEgDADQgEAEgEAAQgEAAgDgEg");
	this.shape_2.setTransform(156.65,67.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DA3A00").s().p("AgWApIAAhPIASAAIAAAPQADgIAEgEQAFgFAIAAIAHABIAAASIgFgCIgGAAQgIAAgEAGQgEAHAAAKIAAApg");
	this.shape_3.setTransform(152.15,69.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DA3A00").s().p("AgvA4IAAhvIAjAAQAdAAAPAOQAPAOABAbQgBAPgHANQgHAOgOAHQgPAHgRAAgAgcAoIAPAAQATAAALgLQALgLAAgSQAAgTgLgKQgLgKgTAAIgPAAg");
	this.shape_4.setTransform(143.2,68.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DA3A00").s().p("AgaAfQgKgLAAgTQAAgMAGgKQAEgJAJgFQAJgGAJAAQARAAAJAKQAJAKAAASIAAAIIg1AAQAAALAHAGQAFAGALAAQAHAAAGgDQAGgBAFgEIAAAPQgFADgHACQgIACgJAAQgQAAgLgLgAgKgWQgFAGgCAJIAjAAQABgKgFgFQgEgFgJAAQgGAAgFAFg");
	this.shape_5.setTransform(132.9,69.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DA3A00").s().p("AASApIAAgsQAAgLgFgGQgDgFgJAAQgHAAgFAGQgFAGAAAJIAAAtIgSAAIAAhPIASAAIAAANQAJgPAQAAQAMAAAIAIQAHAJAAAQIAAAwg");
	this.shape_6.setTransform(124.05,69.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#DA3A00").s().p("AgbAzQgMgHgHgNQgHgNAAgQQAAgRAHgNQAHgOAMgIQANgHAPAAQAQAAAMAHQAMAHAGANQAHANAAARQAAARgHANQgHAOgMAGQgMAIgQAAQgPAAgMgHgAgYgdQgJAMAAARQAAAMAEAKQAFAJAHAGQAIAEAJAAQAQABAJgLQAJgLAAgTQAAgUgJgLQgJgKgPgBQgPAAgKAMg");
	this.shape_7.setTransform(113.225,68.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DA3A00").s().p("AgdAfQgLgLAAgTQAAgTALgMQAMgLASAAQATAAALALQAKALAAATQAAASgLANQgLALgTAAQgSAAgLgLgAgQgTQgFAHAAANQAAAMAFAHQAGAHAKAAQALAAAGgHQAGgGAAgOQgBgMgGgIQgFgGgLAAQgKAAgGAHg");
	this.shape_8.setTransform(98.7,69.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DA3A00").s().p("AgLAbIAAgoIgNAAIAAgPIANAAIAAgTIARgFIAAAYIATAAIAAAPIgTAAIAAAlQAAAIADADQACADAGAAIAEAAIAEgCIAAAOIgFACIgJABQgWAAAAgag");
	this.shape_9.setTransform(90.975,68.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DA3A00").s().p("AgPAoIgLgCIAAgRQAGADAFACQAGACAGAAQAMAAgBgJQAAgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBIgFgDIgIgFIgMgGQgDgDgDgDQgCgFAAgFQAAgLAJgHQAIgHANAAIAKABIAIACIAAAQQgDgCgFgBQgGgCgEAAQgFAAgDADQgDACAAAEQAAAEADACQACADAIAEQAMAEAEAEQAEAGAAAIQAAAMgIAGQgIAHgOAAIgLgCg");
	this.shape_10.setTransform(81.15,69.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DA3A00").s().p("AgdAfQgLgLAAgTQAAgTALgMQAMgLASAAQATAAALALQAKALAAATQAAASgLANQgLALgTAAQgSAAgLgLgAgQgTQgFAHAAANQAAAMAFAHQAGAHAKAAQALAAAGgHQAGgGAAgOQgBgMgGgIQgFgGgLAAQgKAAgGAHg");
	this.shape_11.setTransform(73.05,69.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DA3A00").s().p("AgLAbIAAgoIgNAAIAAgPIANAAIAAgTIARgFIAAAYIATAAIAAAPIgTAAIAAAlQAAAIADADQACADAGAAIAEAAIAEgCIAAAOIgFACIgJABQgWAAAAgag");
	this.shape_12.setTransform(65.325,68.75);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DA3A00").s().p("AgdAfQgLgLAAgTQAAgTALgMQAMgLASAAQATAAAKALQALALAAATQAAASgLANQgMALgSAAQgSAAgLgLgAgQgTQgFAHAAANQAAAMAFAHQAHAHAJAAQAMAAAFgHQAGgGAAgOQgBgMgFgIQgHgGgKAAQgJAAgHAHg");
	this.shape_13.setTransform(57.65,69.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DA3A00").s().p("AARA7IAAgtQAAgLgDgEQgEgGgIAAQgIAAgFAGQgFAFAAAJIAAAuIgSAAIAAh1IASAAIAAAzQAJgPAPAAQAOAAAHAJQAGAIAAAPIAAAxg");
	this.shape_14.setTransform(48.325,67.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#DA3A00").s().p("AgmA8IAAh0IASAAIAAAMQAKgPAQAAQAPAAAJAMQAJAKAAATQAAATgKALQgKAMgRABQgNgBgJgMIAAAwgAgOglQgGAGAAALIAAALQAAAIAGAFQAFAFAIAAQAKAAAFgHQAGgHAAgOQAAgMgFgGQgFgGgKgBQgIABgGAGg");
	this.shape_15.setTransform(39.025,71.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#DA3A00").s().p("AgdAxQgJgKAAgTQAAgUAKgLQAKgMARAAQAGAAAGADQAGADAEAGIAAgwIASAAIAAB1IgSAAIAAgMQgJAOgRAAQgPAAgJgLgAgNAAQgGAGAAAOQAAAMAFAHQAGAGAIAAQAJAAAGgGQAGgHAAgLIAAgJQAAgJgGgFQgFgGgJAAQgJAAgFAIg");
	this.shape_16.setTransform(167.875,50.475);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#DA3A00").s().p("AASApIAAgsQAAgLgFgGQgDgFgJAAQgHAAgFAGQgFAGAAAJIAAAtIgTAAIAAhPIATAAIAAANQAJgPAQAAQANAAAGAIQAIAJAAAQIAAAwg");
	this.shape_17.setTransform(158.8,52.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DA3A00").s().p("AgaAkQgGgHgBgLQABgLAGgHQAHgFAMgCIAXgEQAAgQgQAAQgGAAgHADQgGACgGAEIAAgQIANgFQAJgCAFAAQAQAAAIAIQAIAIAAAPIAAAyIgSAAIAAgLQgJANgPAAQgLAAgHgGgAAAADQgJABgCADQgEAEAAAFQAAAGAEACQADAEAHAAQAGAAAFgGQAGgGAAgHIAAgIg");
	this.shape_18.setTransform(149.8,52.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#DA3A00").s().p("AgPAoIgLgCIAAgRQAGADAGACQAFACAGAAQAMAAgBgJQAAgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBIgEgDIgJgFIgMgGQgEgDgBgDQgDgFAAgFQAAgLAJgHQAIgHANAAIAKABIAIACIAAAQQgEgCgEgBQgGgCgEAAQgFAAgDADQgDACAAAEQAAAEADACQACADAIAEQAMAEAEAEQAFAGgBAIQAAAMgIAGQgJAHgNAAIgLgCg");
	this.shape_19.setTransform(135.25,52.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#DA3A00").s().p("AgaAfQgKgLABgTQAAgMAEgKQAGgJAIgFQAJgGAJAAQARAAAJAKQAJAKAAASIAAAIIg1AAQAAALAHAGQAFAGALAAQAHAAAGgDQAGgBAFgEIAAAPQgFADgHACQgIACgJAAQgQAAgLgLgAgKgWQgFAGgCAJIAjAAQAAgKgEgFQgEgFgJAAQgGAAgFAFg");
	this.shape_20.setTransform(127.75,52.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#DA3A00").s().p("AgIA7IAAh1IARAAIAAB1g");
	this.shape_21.setTransform(121.35,50.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#DA3A00").s().p("AgIA8IAAhPIARAAIAABPgAgGgpQgEgDAAgEQAAgEAEgDQADgEADAAQAFAAADAEQADADAAAEQAAAEgDADQgEAEgEAAQgDAAgDgEg");
	this.shape_22.setTransform(117.1,50.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#DA3A00").s().p("AgMA8IAAhAIgNAAIAAgPIANAAIAAgLQAAgJAEgGQADgHAGgDQAGgEAJAAQAGAAAEABIAAAQQgEgCgEAAQgGAAgDADQgEAEAAAIIAAAKIASAAIAAAPIgSAAIAABAg");
	this.shape_23.setTransform(112.475,50.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#DA3A00").s().p("AgWApIAAhPIASAAIAAAPQADgIAFgEQAEgFAHAAIAIABIAAASIgFgCIgFAAQgIAAgFAGQgEAHAAAKIAAApg");
	this.shape_24.setTransform(103.3,52.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#DA3A00").s().p("AgbAgQgIgIAAgQIAAgwIATAAIAAAtQAAAVAQAAQAIAAAFgFQAFgGAAgKIAAgtIASAAIAABPIgSAAIAAgMIgBAAQgDAHgHADQgGAEgHAAQgOAAgHgJg");
	this.shape_25.setTransform(94.975,52.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#DA3A00").s().p("AgdAfQgLgLAAgTQAAgTALgMQAMgLASAAQATAAALALQAKALAAATQAAASgLAMQgLAMgTAAQgSAAgLgLgAgQgTQgFAHAAANQAAAMAFAHQAHAHAJAAQALAAAGgHQAGgGAAgOQgBgMgGgIQgFgGgLAAQgJAAgHAHg");
	this.shape_26.setTransform(85.65,52.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#DA3A00").s().p("AgkA6IAAgQQAFACAEAAQAJAAAFgKIAGgNIghhPIAVAAIATA5IABAGIABgGIAUg5IASAAIgjBZQgFAOgHAHQgIAHgKAAIgLgBg");
	this.shape_27.setTransform(76.8,54.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#DA3A00").s().p("AgZAfQgLgLAAgTQABgMAEgKQAFgJAJgFQAJgGAKAAQAQAAAJAKQAKAKAAASIAAAIIg2AAQABALAFAGQAHAGAKAAQAHAAAGgDQAHgBAEgEIAAAPQgEADgIACQgIACgIAAQgSAAgJgLgAgLgWQgEAGgCAJIAkAAQAAgKgFgFQgFgFgHAAQgHAAgGAFg");
	this.shape_28.setTransform(64.8,52.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#DA3A00").s().p("AgJAoIgehPIAUAAIARA0QACAIAAAGIABAAIACgNIASg1IATAAIgfBPg");
	this.shape_29.setTransform(56.45,52.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#DA3A00").s().p("AgaAkQgHgHAAgLQAAgLAHgHQAGgFANgCIAXgEQAAgQgQAAQgFAAgHADQgIACgFAEIAAgQIANgFQAJgCAFAAQAQAAAIAIQAIAIAAAPIAAAyIgSAAIAAgLQgJANgPAAQgLAAgHgGgAAAADQgJABgCADQgEAEAAAFQAAAGAEACQADAEAHAAQAGAAAFgGQAGgGAAgHIAAgIg");
	this.shape_30.setTransform(48.2,52.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DA3A00").s().p("AgVA4QgIgCgEgCIAAgVQAFAEAJAEQAIADAHAAQAIAAAFgEQAFgDgBgHQABgGgFgEQgFgGgLgGQgOgGgFgHQgHgIAAgKQABgJAEgIQAEgHAJgEQAJgEAKAAQAHAAAIACIAKADIAAATQgFgEgGgCQgHgCgHAAQgHAAgFAEQgFAEAAAGQAAAFACADQABADAEACQAEADAHAFQAQAHAGAIQAHAHAAALQAAAOgLAIQgKAJgTAAQgGAAgJgCg");
	this.shape_31.setTransform(40.35,50.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.5,37.3,372.2,43.10000000000001);


(lib.cloud_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AlYC3Qh8h1AUilQASiUB8glQAygPBWgDICqAAICpAAQBVADAyAQQB6AkAWCUQAWCah5B4QiCCAjbAAQjXAAiBh4g");
	this.shape.setTransform(45.1565,30.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90.3,60.7);


(lib.cloud_big = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AaxLvQkigKjggyQj0g3hGhTQi7BYkZACQkQACjahNQhDBlk8AwQkZArmEgLQl3gKkig2Qk2g5g/hSQjCA1hvhcQhhhQAMiHQANiHBwg9QCChHDDBWQgViIBBiLQA9iBB5hhQB5hiCNgiQCXgkCFAvQBahyCWhBQCNg8CigCQCjgDCKA7QCSA+BVB1QCJhLDSgQQDHgPDPApQDRApCTBWQCfBdAqB6QB3heCjABQCRACCOBJQCHBFBLBmQBOBqgaBcQDJgvCdA0QCDArBVBrQBIBbATBqQARBkglAuQhABPjxAmQisAbjWAAQg9AAhBgCg");
	this.shape.setTransform(255.5324,75.331);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud_big, new cjs.Rectangle(0,0,511.1,150.7), null);


(lib.cloud_2sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape.setTransform(37.6806,32.1838,0.7614,0.7679,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape_1.setTransform(14.8263,48.2099,0.5925,0.5975,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape_2.setTransform(109.4452,42.5016,0.8181,0.8251,0,0,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F6F6F6").s().p("AmHCbIAAk1IMPAAIAAE1g");
	this.shape_3.setTransform(62.2477,49.726,1.1959,0.8676,0,0,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape_4.setTransform(75.4911,31.5964,1.2896,1.264,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud_2sub, new cjs.Rectangle(0,0,129.9,63.2), null);


(lib.cloud_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak8DgQiDhdAAiDQAAiCCDhdQCDhdC5AAQC5AACEBdQCDBdAACCQAACDiDBdQiEBdi5AAQi5AAiDhdg");
	this.shape.setTransform(44.825,31.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,89.7,63.4);


(lib.cloud_1sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape.setTransform(65.7624,25.498,0.5904,0.6075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape_1.setTransform(77.6455,38.1942,0.4595,0.4727);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape_2.setTransform(15.8762,33.8106,0.6344,0.6527);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F6F6F6").s().p("AmHCbIAAk1IMPAAIAAE1g");
	this.shape_3.setTransform(48.0969,37.8815,0.7534,0.7823);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F6F6F6").s().p("AiwCxQhJhJAAhoQAAhmBJhKQBKhJBmAAQBoAABIBJQBKBKAABmQAABohKBJQhIBJhoAAQhmAAhKhJg");
	this.shape_4.setTransform(42.2,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloud_1sub, new cjs.Rectangle(0,0,89.2,50.2), null);


(lib.arrow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA3A00").s().p("AhjE6IAApyIDHAAIAAJyg");
	this.shape.setTransform(43.65,51.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DA3A00").s().p("AAAgJIkrErIiMiMIG3m3IG4G3IiMCMg");
	this.shape_1.setTransform(43.975,28.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_sub, new cjs.Rectangle(0,0,88,82.6), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Access_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.2,-7.3,221.60000000000002,21.8);


(lib.ScreenImages = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 copy 2
	this.instance = new lib.Image3();
	this.instance.parent = this;
	this.instance.setTransform(191.9,167.85,0.01,0.01,0,0,0,190.1,170.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).to({regX:190.2,regY:170.2,scaleX:1,scaleY:1,x:191.95,y:167.9},19,cjs.Ease.get(1)).wait(5));

	// Layer_1 copy
	this.instance_1 = new lib.Image2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(126.25,167.85,0.01,0.01,0,0,0,125,170.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({regX:125.1,regY:170.2,scaleX:1,scaleY:1,y:167.9},19,cjs.Ease.get(1)).wait(8));

	// Layer_1
	this.instance_2 = new lib.Image1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(61.35,167.85,0.01,0.01,0,0,0,60.1,170.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({regY:170.2,scaleX:1,scaleY:1,x:61.4,y:167.9},19,cjs.Ease.get(1)).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2.3,251.8,510);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.65,16.55,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.199999999999996,30.5);


(lib.phone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenImages
	this.instance = new lib.ScreenImages("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(78.45,157.65,0.636,0.636,0,0,0,125.1,255);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(40));

	// Layer_2
	this.instance_1 = new lib.PhoneBG("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.5,157.6,1,1,0,0,0,79.5,162.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-4.5,158.9,233.4);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.025,5.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.325,5.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.025,-5.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.325,-5.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.375,7.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.675,7.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.375,-4.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.675,-4.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_Logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo.cache(-101,-22,202,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_68 = function() {
		//exportRoot.tl1.play()
		exportRoot.mainMC.anim.gotoAndPlay(1)
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(68).call(this.frame_68).wait(6).call(this.frame_74).wait(4));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(983.1,82.9,0.2717,0.2717,0,0,0,-40,1.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:4.4931,scaleY:4.4931,x:983.2,y:82.75},13,cjs.Ease.quadOut).to({x:804.9},12,cjs.Ease.quadInOut).to({_off:true},1).wait(51));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EA0jAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_15 = new cjs.Graphics().p("EA0WAKSIAAvIMA5GAAAIAAPIg");
	var mask_graphics_16 = new cjs.Graphics().p("EAzxAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_17 = new cjs.Graphics().p("EAyzAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_18 = new cjs.Graphics().p("EAxbAKSIAAvIMA5GAAAIAAPIg");
	var mask_graphics_19 = new cjs.Graphics().p("EAvrAKSIAAvIMA5GAAAIAAPIg");
	var mask_graphics_20 = new cjs.Graphics().p("EAtiAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_21 = new cjs.Graphics().p("EArZAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_22 = new cjs.Graphics().p("EAppAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_23 = new cjs.Graphics().p("EAoRAKSIAAvIMA5GAAAIAAPIg");
	var mask_graphics_24 = new cjs.Graphics().p("EAnTAKSIAAvIMA5FAAAIAAPIg");
	var mask_graphics_25 = new cjs.Graphics().p("EAmtAKSIAAvIMA5GAAAIAAPIg");
	var mask_graphics_26 = new cjs.Graphics().p("EAmhAKSIAAvIMA5GAAAIAAPIg");
	var mask_graphics_51 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_52 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_53 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_54 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_55 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_56 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_57 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_58 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_59 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_60 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_61 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_62 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_63 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_64 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_65 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_66 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_67 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_68 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_69 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_70 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_71 = new cjs.Graphics().p("Ei3NAXYMAAAguvMFubAAAMAAAAuvg");
	var mask_graphics_72 = new cjs.Graphics().p("EjIOAXYMAAAguvMFubAAAMAAAAuvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:701.625,y:65.825}).wait(1).to({graphics:mask_graphics_15,x:700.3781,y:65.825}).wait(1).to({graphics:mask_graphics_16,x:696.6375,y:65.825}).wait(1).to({graphics:mask_graphics_17,x:690.4031,y:65.825}).wait(1).to({graphics:mask_graphics_18,x:681.675,y:65.825}).wait(1).to({graphics:mask_graphics_19,x:670.4531,y:65.825}).wait(1).to({graphics:mask_graphics_20,x:656.7375,y:65.825}).wait(1).to({graphics:mask_graphics_21,x:643.0219,y:65.825}).wait(1).to({graphics:mask_graphics_22,x:631.8,y:65.825}).wait(1).to({graphics:mask_graphics_23,x:623.0719,y:65.825}).wait(1).to({graphics:mask_graphics_24,x:616.8375,y:65.825}).wait(1).to({graphics:mask_graphics_25,x:613.0969,y:65.825}).wait(1).to({graphics:mask_graphics_26,x:611.85,y:65.825}).wait(1).to({graphics:null,x:0,y:0}).wait(24).to({graphics:mask_graphics_51,x:987.6189,y:82.9443}).wait(1).to({graphics:mask_graphics_52,x:982.2259,y:82.9443}).wait(1).to({graphics:mask_graphics_53,x:966.0471,y:82.9443}).wait(1).to({graphics:mask_graphics_54,x:939.0823,y:82.9443}).wait(1).to({graphics:mask_graphics_55,x:901.3317,y:82.9443}).wait(1).to({graphics:mask_graphics_56,x:852.7951,y:82.9443}).wait(1).to({graphics:mask_graphics_57,x:793.4726,y:82.9443}).wait(1).to({graphics:mask_graphics_58,x:723.3643,y:82.9443}).wait(1).to({graphics:mask_graphics_59,x:642.47,y:82.9443}).wait(1).to({graphics:mask_graphics_60,x:550.7898,y:82.9443}).wait(1).to({graphics:mask_graphics_61,x:448.3237,y:82.9443}).wait(1).to({graphics:mask_graphics_62,x:335.0718,y:82.9443}).wait(1).to({graphics:mask_graphics_63,x:211.0339,y:82.9443}).wait(1).to({graphics:mask_graphics_64,x:76.2101,y:82.9443}).wait(1).to({graphics:mask_graphics_65,x:-69.3996,y:82.9443}).wait(1).to({graphics:mask_graphics_66,x:-225.7952,y:82.9443}).wait(1).to({graphics:mask_graphics_67,x:-392.9767,y:82.9443}).wait(1).to({graphics:mask_graphics_68,x:-570.9441,y:82.9443}).wait(1).to({graphics:mask_graphics_69,x:-759.6974,y:82.9443}).wait(1).to({graphics:mask_graphics_70,x:-959.2366,y:82.9443}).wait(1).to({graphics:mask_graphics_71,x:-1169.5617,y:82.9443}).wait(1).to({graphics:mask_graphics_72,x:-1281.525,y:82.9443}).wait(6));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(805.5,77.35,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(985.05,77.35,4.4931,4.4931,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[{t:this.instance_2}]},25).wait(27));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:985.05},12,cjs.Ease.quadInOut).wait(52));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(987.65,82.85,2.4154,0.3677,0,0,0,485.5,406.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({regX:485.4,x:-1390.6},21,cjs.Ease.quadIn).wait(6));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(987.65,82.85,2.4154,0.3677,0,0,0,485.5,406.7);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({regX:485.4,x:-1390.6},21,cjs.Ease.quadIn).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2563,-66.7,4723.3,299.4);


(lib.cloud_bk_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.cloud.cache(-130,-63,260,126,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cloud = new lib.cloud_2sub();
	this.cloud.name = "cloud";
	this.cloud.parent = this;
	this.cloud.setTransform(-187.05,16,1,1,0,0,0,65,31.6);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-252,-15.6,129.9,63.2);


(lib.cloud_bk_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.cloud.cache(-89,-50,178,100,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cloud = new lib.cloud_1sub();
	this.cloud.name = "cloud";
	this.cloud.parent = this;
	this.cloud.setTransform(44.6,25.1,1,1,0,0,0,44.6,25.1);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,89.2,50.2);


(lib.cloud = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.cloud.cache(-511,-151,1022,302,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Fill
	this.cloud = new lib.cloud_big();
	this.cloud.name = "cloud";
	this.cloud.parent = this;
	this.cloud.setTransform(104,60.1,1,1,0,0,0,255.5,75.3);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151.5,-15.2,511.1,150.7);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arrow_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.arrow.cache(-89,-83,178,166,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.arrow = new lib.arrow_sub();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(44,41.3,1,1,0,0,0,44,41.3);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_mc, new cjs.Rectangle(0,0,88,82.6), null);


(lib.anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_271 = function() {
		exportRoot.tl1.play()
		exportRoot.finalHeadline.play()
	}
	this.frame_285 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(271).call(this.frame_271).wait(14).call(this.frame_285).wait(1));

	// laptop
	this.instance = new lib.laptop("single",0);
	this.instance.parent = this;
	this.instance.setTransform(131.95,-17.2,0.312,0.312,0,0,0,145.6,80.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({mode:"synched",startPosition:7,loop:false},0).wait(1).to({regX:155.1,regY:123.3,x:134.95,y:-3.6,startPosition:8},0).wait(1).to({y:-3.45,startPosition:9},0).wait(1).to({y:-3.25,startPosition:10},0).wait(1).to({y:-3,startPosition:11},0).wait(1).to({y:-2.75,startPosition:12},0).wait(1).to({y:-2.5,startPosition:13},0).wait(1).to({y:-2.15,startPosition:14},0).wait(1).to({y:-1.8,startPosition:15},0).wait(1).to({y:-1.35,startPosition:16},0).wait(1).to({y:-0.9,startPosition:17},0).wait(1).to({y:-0.3,startPosition:18},0).wait(1).to({regX:145.6,regY:80.2,x:131.95,y:-13.1,startPosition:19},0).wait(1).to({regX:155.1,regY:123.3,scaleX:0.3119,scaleY:0.3119,x:134.9,y:1.75,startPosition:20},0).wait(1).to({y:3.35,startPosition:21},0).wait(1).to({y:5.15,startPosition:22},0).wait(1).to({y:7.3,startPosition:23},0).wait(1).to({y:9.75,startPosition:24},0).wait(1).to({regX:145.7,regY:80,x:131.95,y:-0.9,startPosition:25},0).wait(1).to({regX:155.1,regY:123.3,x:134.9,y:15.85,startPosition:26},0).wait(1).to({y:19.5,startPosition:27},0).wait(1).to({y:23.6,startPosition:28},0).wait(1).to({y:28.2,startPosition:29},0).wait(1).to({y:33.2,startPosition:30},0).wait(1).to({y:38.55,startPosition:31},0).wait(1).to({y:44.35,startPosition:32},0).wait(1).to({y:50.45,startPosition:33},0).wait(1).to({y:56.85,startPosition:34},0).wait(1).to({y:63.45,startPosition:35},0).wait(1).to({y:70.25,startPosition:36},0).wait(1).to({regX:145.6,regY:80.6,scaleX:0.312,scaleY:0.312,x:131.95,y:63.75,mode:"single",startPosition:39},0).wait(230).to({startPosition:39},0).wait(1));

	// text 2
	this.frame2 = new lib.Access_txt();
	this.frame2.name = "frame2";
	this.frame2.parent = this;
	this.frame2.setTransform(235.7,120.3,1,1,0,0,0,106,66);
	this.frame2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.frame2).wait(201).to({regX:0,regY:0,x:129.815,y:46.0111,alpha:0.1},0).wait(1).to({x:129.9276,y:37.8962,alpha:0.1979},0).wait(1).to({x:130.0354,y:30.1256,alpha:0.2916},0).wait(1).to({x:130.1363,y:22.8504,alpha:0.3794},0).wait(1).to({x:130.2288,y:16.1775,alpha:0.4599},0).wait(1).to({x:130.3123,y:10.1596,alpha:0.5325},0).wait(1).to({x:130.3867,y:4.8002,alpha:0.5971},0).wait(1).to({x:130.4523,y:0.0681,alpha:0.6542},0).wait(1).to({x:130.51,y:-4.0876,alpha:0.7043},0).wait(1).to({x:130.5604,y:-7.7255,alpha:0.7482},0).wait(1).to({x:130.6045,y:-10.9046,alpha:0.7865},0).wait(1).to({x:130.643,y:-13.6796,alpha:0.82},0).wait(1).to({x:130.6766,y:-16.0999,alpha:0.8492},0).wait(1).to({x:130.7059,y:-18.2088,alpha:0.8747},0).wait(1).to({x:130.7313,y:-20.0435,alpha:0.8968},0).wait(1).to({x:130.7534,y:-21.6364,alpha:0.916},0).wait(1).to({x:130.7725,y:-23.015,alpha:0.9326},0).wait(1).to({x:130.789,y:-24.2032,alpha:0.947},0).wait(1).to({x:130.8031,y:-25.2214,alpha:0.9592},0).wait(1).to({x:130.8151,y:-26.0871,alpha:0.9697},0).wait(1).to({x:130.8252,y:-26.8157,alpha:0.9785},0).wait(1).to({x:130.8336,y:-27.4204,alpha:0.9858},0).wait(1).to({x:130.8405,y:-27.9128,alpha:0.9917},0).wait(1).to({x:130.8459,y:-28.303,alpha:0.9964},0).wait(1).to({regX:106,regY:66,x:236.85,y:37.4,alpha:1},0).wait(29).to({alpha:0},16,cjs.Ease.quadOut).wait(16));

	// cloud text
	this.frame1 = new lib.cloud_txt();
	this.frame1.name = "frame1";
	this.frame1.parent = this;
	this.frame1.setTransform(129.4,-108.75,1,1,0,0,0,106.2,65.9);

	this.timeline.addTween(cjs.Tween.get(this.frame1).wait(68).to({regX:106,regY:66,x:129.3},0).wait(1).to({regX:105,regY:60.9,x:128.25,y:-107.4},0).wait(1).to({y:-101.05},0).wait(1).to({y:-94.8},0).wait(1).to({y:-88.65},0).wait(1).to({y:-82.7},0).wait(1).to({y:-76.95},0).wait(1).to({y:-71.45},0).wait(1).to({y:-66.25},0).wait(1).to({y:-61.3},0).wait(1).to({y:-56.65},0).wait(1).to({y:-52.35},0).wait(1).to({y:-48.3},0).wait(1).to({y:-44.5},0).wait(1).to({y:-41},0).wait(1).to({y:-37.8},0).wait(1).to({y:-34.8},0).wait(1).to({y:-32},0).wait(1).to({y:-29.45},0).wait(1).to({y:-27.05},0).wait(1).to({y:-24.85},0).wait(1).to({y:-22.85},0).wait(1).to({y:-20.95},0).wait(1).to({y:-19.2},0).wait(1).to({y:-17.65},0).wait(1).to({y:-16.15},0).wait(1).to({y:-14.8},0).wait(1).to({y:-13.55},0).wait(1).to({y:-12.4},0).wait(1).to({y:-11.35},0).wait(1).to({y:-10.35},0).wait(1).to({y:-9.45},0).wait(1).to({y:-8.65},0).wait(1).to({y:-7.9},0).wait(1).to({y:-7.25},0).wait(1).to({y:-6.6},0).wait(1).to({y:-6.05},0).wait(1).to({y:-5.55},0).wait(1).to({y:-5.15},0).wait(1).to({y:-4.75},0).wait(1).to({y:-4.4},0).wait(1).to({y:-4.1},0).wait(1).to({regX:106.2,regY:66,x:129.4,y:1.25},0).wait(54).to({regY:65.8,y:-113.6},30,cjs.Ease.cubicIn).wait(92));

	// cloud 2
	this.instance_1 = new lib.cloud_2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(125.5,-115.9,0.5626,0.5626,0,0,0,44.9,31.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(68).to({_off:false},0).wait(1).to({regX:44.8,regY:31.7,x:125.45,y:-109.05},0).wait(1).to({y:-102.35},0).wait(1).to({y:-95.75},0).wait(1).to({y:-89.3},0).wait(1).to({y:-83},0).wait(1).to({y:-76.95},0).wait(1).to({y:-71.2},0).wait(1).to({y:-65.7},0).wait(1).to({y:-60.5},0).wait(1).to({y:-55.6},0).wait(1).to({y:-51.05},0).wait(1).to({y:-46.75},0).wait(1).to({y:-42.8},0).wait(1).to({y:-39.1},0).wait(1).to({y:-35.7},0).wait(1).to({y:-32.55},0).wait(1).to({y:-29.6},0).wait(1).to({y:-26.9},0).wait(1).to({y:-24.4},0).wait(1).to({y:-22.1},0).wait(1).to({y:-19.95},0).wait(1).to({y:-17.95},0).wait(1).to({y:-16.15},0).wait(1).to({y:-14.45},0).wait(1).to({y:-12.9},0).wait(1).to({y:-11.45},0).wait(1).to({y:-10.15},0).wait(1).to({y:-8.95},0).wait(1).to({y:-7.8},0).wait(1).to({y:-6.8},0).wait(1).to({y:-5.85},0).wait(1).to({y:-5},0).wait(1).to({y:-4.2},0).wait(1).to({y:-3.5},0).wait(1).to({y:-2.85},0).wait(1).to({y:-2.3},0).wait(1).to({y:-1.75},0).wait(1).to({y:-1.3},0).wait(1).to({y:-0.85},0).wait(1).to({y:-0.5},0).wait(1).to({y:-0.2},0).wait(1).to({regX:44.9,regY:31.8,x:125.5,y:0},0).wait(54).to({startPosition:0},0).to({regY:31.6,y:-118.95},30,cjs.Ease.cubicIn).wait(92));

	// cloud shade
	this.instance_2 = new lib.cloud_shadow("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(125.45,-110.3,0.5626,0.5626,0,0,0,45.1,30.2);
	this.instance_2.alpha = 0.3906;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(68).to({_off:false},0).wait(1).to({regX:45.2,regY:30.3,x:125.55,y:-103.45,alpha:0.3679},0).wait(1).to({y:-96.75,alpha:0.3453},0).wait(1).to({y:-90.15,alpha:0.323},0).wait(1).to({y:-83.7,alpha:0.3012},0).wait(1).to({y:-77.4,alpha:0.2801},0).wait(1).to({y:-71.35,alpha:0.2597},0).wait(1).to({y:-65.6,alpha:0.2402},0).wait(1).to({y:-60.1,alpha:0.2216},0).wait(1).to({y:-54.9,alpha:0.2041},0).wait(1).to({y:-50,alpha:0.1877},0).wait(1).to({y:-45.45,alpha:0.1723},0).wait(1).to({y:-41.15,alpha:0.1579},0).wait(1).to({y:-37.2,alpha:0.1445},0).wait(1).to({y:-33.5,alpha:0.1321},0).wait(1).to({y:-30.1,alpha:0.1206},0).wait(1).to({y:-26.95,alpha:0.1099},0).wait(1).to({y:-24,alpha:0.1001},0).wait(1).to({y:-21.3,alpha:0.0909},0).wait(1).to({y:-18.8,alpha:0.0825},0).wait(1).to({y:-16.5,alpha:0.0747},0).wait(1).to({y:-14.35,alpha:0.0675},0).wait(1).to({y:-12.35,alpha:0.0608},0).wait(1).to({y:-10.55,alpha:0.0547},0).wait(1).to({y:-8.85,alpha:0.049},0).wait(1).to({y:-7.3,alpha:0.0438},0).wait(1).to({y:-5.85,alpha:0.039},0).wait(1).to({y:-4.55,alpha:0.0345},0).wait(1).to({y:-3.35,alpha:0.0304},0).wait(1).to({y:-2.2,alpha:0.0267},0).wait(1).to({y:-1.2,alpha:0.0232},0).wait(1).to({y:-0.25,alpha:0.02},0).wait(1).to({y:0.6,alpha:0.0172},0).wait(1).to({y:1.4,alpha:0.0145},0).wait(1).to({y:2.1,alpha:0.0121},0).wait(1).to({y:2.75,alpha:0.0099},0).wait(1).to({y:3.3,alpha:0.008},0).wait(1).to({y:3.85,alpha:0.0062},0).wait(1).to({y:4.3,alpha:0.0046},0).wait(1).to({y:4.75,alpha:0.0032},0).wait(1).to({y:5.1,alpha:0.002},0).wait(1).to({y:5.4,alpha:0.0009},0).wait(1).to({regX:45.1,regY:30.4,x:125.45,y:5.6,alpha:0},0).wait(54).to({startPosition:0},0).to({regY:30.3,y:-113.35},30,cjs.Ease.cubicIn).wait(92));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AFlD5IAAnxIGOAAIAAHxg");
	var mask_graphics_1 = new cjs.Graphics().p("AFlD4IAAnvIGOAAIAAHvg");
	var mask_graphics_2 = new cjs.Graphics().p("AFlD3IAAntIGOAAIAAHtg");
	var mask_graphics_3 = new cjs.Graphics().p("AFlD2IAAnrIGOAAIAAHrg");
	var mask_graphics_4 = new cjs.Graphics().p("AFlD2IAAnrIGOAAIAAHrg");
	var mask_graphics_5 = new cjs.Graphics().p("AFlD1IAAnpIGOAAIAAHpg");
	var mask_graphics_6 = new cjs.Graphics().p("AFlD0IAAnnIGOAAIAAHng");
	var mask_graphics_7 = new cjs.Graphics().p("AFlDzIAAnlIGOAAIAAHlg");
	var mask_graphics_8 = new cjs.Graphics().p("AFlDzIAAnlIGOAAIAAHlg");
	var mask_graphics_9 = new cjs.Graphics().p("AFlDyIAAnjIGOAAIAAHjg");
	var mask_graphics_10 = new cjs.Graphics().p("AFlDxIAAnhIGOAAIAAHhg");
	var mask_graphics_11 = new cjs.Graphics().p("AFlDxIAAnhIGOAAIAAHhg");
	var mask_graphics_12 = new cjs.Graphics().p("AFlDwIAAnfIGOAAIAAHfg");
	var mask_graphics_13 = new cjs.Graphics().p("AFlDvIAAndIGOAAIAAHdg");
	var mask_graphics_14 = new cjs.Graphics().p("AFlDuIAAnbIGOAAIAAHbg");
	var mask_graphics_15 = new cjs.Graphics().p("AFlDuIAAnbIGOAAIAAHbg");
	var mask_graphics_16 = new cjs.Graphics().p("AFlDtIAAnZIGOAAIAAHZg");
	var mask_graphics_17 = new cjs.Graphics().p("AFlDsIAAnXIGOAAIAAHXg");
	var mask_graphics_18 = new cjs.Graphics().p("AFlDrIAAnVIGOAAIAAHVg");
	var mask_graphics_19 = new cjs.Graphics().p("AFlDrIAAnVIGOAAIAAHVg");
	var mask_graphics_20 = new cjs.Graphics().p("AFlDqIAAnTIGOAAIAAHTg");
	var mask_graphics_21 = new cjs.Graphics().p("AFlDpIAAnRIGOAAIAAHRg");
	var mask_graphics_22 = new cjs.Graphics().p("AFlDoIAAnPIGOAAIAAHPg");
	var mask_graphics_23 = new cjs.Graphics().p("AFlDoIAAnPIGOAAIAAHPg");
	var mask_graphics_24 = new cjs.Graphics().p("AFlDnIAAnNIGOAAIAAHNg");
	var mask_graphics_25 = new cjs.Graphics().p("AFlDmIAAnLIGOAAIAAHLg");
	var mask_graphics_26 = new cjs.Graphics().p("AFlDmIAAnLIGOAAIAAHLg");
	var mask_graphics_27 = new cjs.Graphics().p("AFlDlIAAnJIGOAAIAAHJg");
	var mask_graphics_28 = new cjs.Graphics().p("AFlDkIAAnHIGOAAIAAHHg");
	var mask_graphics_29 = new cjs.Graphics().p("AFlDjIAAnFIGOAAIAAHFg");
	var mask_graphics_30 = new cjs.Graphics().p("AFlDjIAAnFIGOAAIAAHFg");
	var mask_graphics_31 = new cjs.Graphics().p("AFlDiIAAnDIGOAAIAAHDg");
	var mask_graphics_32 = new cjs.Graphics().p("AFlDhIAAnBIGOAAIAAHBg");
	var mask_graphics_33 = new cjs.Graphics().p("AFlDgIAAm/IGOAAIAAG/g");
	var mask_graphics_34 = new cjs.Graphics().p("AFlDgIAAm/IGOAAIAAG/g");
	var mask_graphics_35 = new cjs.Graphics().p("AFlDfIAAm9IGOAAIAAG9g");
	var mask_graphics_36 = new cjs.Graphics().p("AFlDeIAAm7IGOAAIAAG7g");
	var mask_graphics_37 = new cjs.Graphics().p("AFlDeIAAm6IGOAAIAAG6g");
	var mask_graphics_38 = new cjs.Graphics().p("AFlDdIAAm5IGOAAIAAG5g");
	var mask_graphics_39 = new cjs.Graphics().p("AFlDcIAAm3IGOAAIAAG3g");
	var mask_graphics_40 = new cjs.Graphics().p("AFlDbIAAm1IGOAAIAAG1g");
	var mask_graphics_41 = new cjs.Graphics().p("AFlDbIAAm1IGOAAIAAG1g");
	var mask_graphics_42 = new cjs.Graphics().p("AFlDaIAAmzIGOAAIAAGzg");
	var mask_graphics_43 = new cjs.Graphics().p("AFlDZIAAmxIGOAAIAAGxg");
	var mask_graphics_44 = new cjs.Graphics().p("AFlDYIAAmvIGOAAIAAGvg");
	var mask_graphics_45 = new cjs.Graphics().p("AFlDYIAAmvIGOAAIAAGvg");
	var mask_graphics_46 = new cjs.Graphics().p("AFlDXIAAmtIGOAAIAAGtg");
	var mask_graphics_47 = new cjs.Graphics().p("AFlDWIAAmrIGOAAIAAGrg");
	var mask_graphics_48 = new cjs.Graphics().p("AFlDVIAAmpIGOAAIAAGpg");
	var mask_graphics_49 = new cjs.Graphics().p("AFlDVIAAmpIGOAAIAAGpg");
	var mask_graphics_50 = new cjs.Graphics().p("AFlDUIAAmnIGOAAIAAGng");
	var mask_graphics_51 = new cjs.Graphics().p("AFlDTIAAmlIGOAAIAAGlg");
	var mask_graphics_52 = new cjs.Graphics().p("AFlDTIAAmlIGOAAIAAGlg");
	var mask_graphics_53 = new cjs.Graphics().p("AFlDSIAAmjIGOAAIAAGjg");
	var mask_graphics_54 = new cjs.Graphics().p("AFlDRIAAmhIGOAAIAAGhg");
	var mask_graphics_55 = new cjs.Graphics().p("AFlDQIAAmfIGOAAIAAGfg");
	var mask_graphics_56 = new cjs.Graphics().p("AFlDQIAAmfIGOAAIAAGfg");
	var mask_graphics_57 = new cjs.Graphics().p("AFlDPIAAmdIGOAAIAAGdg");
	var mask_graphics_58 = new cjs.Graphics().p("AFlDOIAAmbIGOAAIAAGbg");
	var mask_graphics_59 = new cjs.Graphics().p("AFlDNIAAmZIGOAAIAAGZg");
	var mask_graphics_60 = new cjs.Graphics().p("AFlDNIAAmZIGOAAIAAGZg");
	var mask_graphics_61 = new cjs.Graphics().p("AFlDMIAAmXIGOAAIAAGXg");
	var mask_graphics_62 = new cjs.Graphics().p("AFlDLIAAmVIGOAAIAAGVg");
	var mask_graphics_63 = new cjs.Graphics().p("AFlDKIAAmTIGOAAIAAGTg");
	var mask_graphics_64 = new cjs.Graphics().p("AFlDKIAAmTIGOAAIAAGTg");
	var mask_graphics_65 = new cjs.Graphics().p("AFlDJIAAmRIGOAAIAAGRg");
	var mask_graphics_66 = new cjs.Graphics().p("AFlDIIAAmPIGOAAIAAGPg");
	var mask_graphics_67 = new cjs.Graphics().p("AFlDIIAAmPIGOAAIAAGPg");
	var mask_graphics_68 = new cjs.Graphics().p("AFlDHIAAmNIGOAAIAAGNg");
	var mask_graphics_69 = new cjs.Graphics().p("AFlDGIAAmLIGOAAIAAGLg");
	var mask_graphics_70 = new cjs.Graphics().p("AFlDFIAAmJIGOAAIAAGJg");
	var mask_graphics_71 = new cjs.Graphics().p("AFlDFIAAmJIGOAAIAAGJg");
	var mask_graphics_72 = new cjs.Graphics().p("AFlDEIAAmHIGOAAIAAGHg");
	var mask_graphics_73 = new cjs.Graphics().p("AFlDDIAAmFIGOAAIAAGFg");
	var mask_graphics_74 = new cjs.Graphics().p("AFlDCIAAmDIGOAAIAAGDg");
	var mask_graphics_75 = new cjs.Graphics().p("AFlDCIAAmDIGOAAIAAGDg");
	var mask_graphics_76 = new cjs.Graphics().p("AFlDBIAAmBIGOAAIAAGBg");
	var mask_graphics_77 = new cjs.Graphics().p("AFlDBIAAmBIGOAAIAAGBg");
	var mask_graphics_78 = new cjs.Graphics().p("AFlDAIAAl/IGOAAIAAF/g");
	var mask_graphics_79 = new cjs.Graphics().p("AFlC/IAAl9IGOAAIAAF9g");
	var mask_graphics_80 = new cjs.Graphics().p("AFlC9IAAl5IGOAAIAAF5g");
	var mask_graphics_81 = new cjs.Graphics().p("AFlC7IAAl1IGOAAIAAF1g");
	var mask_graphics_82 = new cjs.Graphics().p("AFlC4IAAlvIGOAAIAAFvg");
	var mask_graphics_83 = new cjs.Graphics().p("AFlC1IAAlpIGOAAIAAFpg");
	var mask_graphics_84 = new cjs.Graphics().p("AFlCxIAAlhIGOAAIAAFhg");
	var mask_graphics_85 = new cjs.Graphics().p("AFlCtIAAlZIGOAAIAAFZg");
	var mask_graphics_86 = new cjs.Graphics().p("AFlCpIAAlRIGOAAIAAFRg");
	var mask_graphics_87 = new cjs.Graphics().p("AFlCjIAAlFIGOAAIAAFFg");
	var mask_graphics_88 = new cjs.Graphics().p("AFlCeIAAk7IGOAAIAAE7g");
	var mask_graphics_89 = new cjs.Graphics().p("AFlCYIAAkvIGOAAIAAEvg");
	var mask_graphics_90 = new cjs.Graphics().p("AFlCRIAAkhIGOAAIAAEhg");
	var mask_graphics_91 = new cjs.Graphics().p("AFlCKIAAkTIGOAAIAAETg");
	var mask_graphics_92 = new cjs.Graphics().p("AFlCDIAAkFIGOAAIAAEFg");
	var mask_graphics_93 = new cjs.Graphics().p("AFlB6IAAjzIGOAAIAADzg");
	var mask_graphics_94 = new cjs.Graphics().p("AFlByIAAjjIGOAAIAADjg");
	var mask_graphics_95 = new cjs.Graphics().p("AFlBpIAAjRIGOAAIAADRg");
	var mask_graphics_96 = new cjs.Graphics().p("AFlBfIAAi9IGOAAIAAC9g");
	var mask_graphics_97 = new cjs.Graphics().p("AFlBVIAAipIGOAAIAACpg");
	var mask_graphics_98 = new cjs.Graphics().p("AFlBLIAAiVIGOAAIAACVg");
	var mask_graphics_99 = new cjs.Graphics().p("AFlBGIAAh/IGOAAIAAB/g");
	var mask_graphics_100 = new cjs.Graphics().p("AFlBHIAAhoIGOAAIAABog");
	var mask_graphics_101 = new cjs.Graphics().p("AFlBIIAAhRIGOAAIAABRg");
	var mask_graphics_102 = new cjs.Graphics().p("AFlBIIAAg4IGOAAIAAA4g");
	var mask_graphics_182 = new cjs.Graphics().p("AFlCvIAAldIGOAAIAAFdg");
	var mask_graphics_183 = new cjs.Graphics().p("AFlDPIAAmdIGOAAIAAGdg");
	var mask_graphics_184 = new cjs.Graphics().p("AFlDuIAAnbIGOAAIAAHbg");
	var mask_graphics_185 = new cjs.Graphics().p("AFlEOIAAobIGOAAIAAIbg");
	var mask_graphics_186 = new cjs.Graphics().p("AFlELIAAoVIGOAAIAAIVg");
	var mask_graphics_187 = new cjs.Graphics().p("AFlEJIAAoRIGOAAIAAIRg");
	var mask_graphics_188 = new cjs.Graphics().p("AFlEGIAAoLIGOAAIAAILg");
	var mask_graphics_189 = new cjs.Graphics().p("AFlEEIAAoHIGOAAIAAIHg");
	var mask_graphics_190 = new cjs.Graphics().p("AFlEBIAAoBIGOAAIAAIBg");
	var mask_graphics_191 = new cjs.Graphics().p("AFlD/IAAn9IGNAAIAAH9g");
	var mask_graphics_192 = new cjs.Graphics().p("AFlD8IAAn3IGNAAIAAH3g");
	var mask_graphics_193 = new cjs.Graphics().p("AFlD6IAAnzIGNAAIAAHzg");
	var mask_graphics_194 = new cjs.Graphics().p("AFlD3IAAntIGNAAIAAHtg");
	var mask_graphics_195 = new cjs.Graphics().p("AFlD0IAAnnIGNAAIAAHng");
	var mask_graphics_196 = new cjs.Graphics().p("AFlDyIAAnjIGNAAIAAHjg");
	var mask_graphics_197 = new cjs.Graphics().p("AFlDvIAAndIGNAAIAAHdg");
	var mask_graphics_198 = new cjs.Graphics().p("AFlDtIAAnZIGNAAIAAHZg");
	var mask_graphics_199 = new cjs.Graphics().p("AFlDqIAAnTIGNAAIAAHTg");
	var mask_graphics_200 = new cjs.Graphics().p("AFlDoIAAnPIGNAAIAAHPg");
	var mask_graphics_201 = new cjs.Graphics().p("AFlDlIAAnJIGNAAIAAHJg");
	var mask_graphics_202 = new cjs.Graphics().p("AFlDjIAAnFIGNAAIAAHFg");
	var mask_graphics_203 = new cjs.Graphics().p("AFlDgIAAm/IGOAAIAAG/g");
	var mask_graphics_226 = new cjs.Graphics().p("AFsFCIAAqDIGOAAIAAKDg");
	var mask_graphics_244 = new cjs.Graphics().p("AFsFCIAAqDIGOAAIAAKDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:75.4598,y:12.2112}).wait(1).to({graphics:mask_graphics_1,x:75.4598,y:11.9584}).wait(1).to({graphics:mask_graphics_2,x:75.4598,y:11.7055}).wait(1).to({graphics:mask_graphics_3,x:75.4598,y:11.4526}).wait(1).to({graphics:mask_graphics_4,x:75.4598,y:11.1997}).wait(1).to({graphics:mask_graphics_5,x:75.4598,y:10.9468}).wait(1).to({graphics:mask_graphics_6,x:75.4598,y:10.694}).wait(1).to({graphics:mask_graphics_7,x:75.4598,y:10.4411}).wait(1).to({graphics:mask_graphics_8,x:75.4598,y:10.1882}).wait(1).to({graphics:mask_graphics_9,x:75.4598,y:9.9353}).wait(1).to({graphics:mask_graphics_10,x:75.4598,y:9.6824}).wait(1).to({graphics:mask_graphics_11,x:75.4598,y:9.4296}).wait(1).to({graphics:mask_graphics_12,x:75.4598,y:9.1767}).wait(1).to({graphics:mask_graphics_13,x:75.4598,y:8.9238}).wait(1).to({graphics:mask_graphics_14,x:75.4598,y:8.6709}).wait(1).to({graphics:mask_graphics_15,x:75.4598,y:8.418}).wait(1).to({graphics:mask_graphics_16,x:75.4598,y:8.1651}).wait(1).to({graphics:mask_graphics_17,x:75.4598,y:7.9123}).wait(1).to({graphics:mask_graphics_18,x:75.4598,y:7.6594}).wait(1).to({graphics:mask_graphics_19,x:75.4598,y:7.4065}).wait(1).to({graphics:mask_graphics_20,x:75.4598,y:7.1536}).wait(1).to({graphics:mask_graphics_21,x:75.4598,y:6.9007}).wait(1).to({graphics:mask_graphics_22,x:75.4598,y:6.6479}).wait(1).to({graphics:mask_graphics_23,x:75.4598,y:6.395}).wait(1).to({graphics:mask_graphics_24,x:75.4598,y:6.1421}).wait(1).to({graphics:mask_graphics_25,x:75.4598,y:5.8892}).wait(1).to({graphics:mask_graphics_26,x:75.4598,y:5.6363}).wait(1).to({graphics:mask_graphics_27,x:75.4598,y:5.3835}).wait(1).to({graphics:mask_graphics_28,x:75.4598,y:5.1306}).wait(1).to({graphics:mask_graphics_29,x:75.4598,y:4.8777}).wait(1).to({graphics:mask_graphics_30,x:75.4598,y:4.6248}).wait(1).to({graphics:mask_graphics_31,x:75.4598,y:4.3719}).wait(1).to({graphics:mask_graphics_32,x:75.4598,y:4.1191}).wait(1).to({graphics:mask_graphics_33,x:75.4598,y:3.8662}).wait(1).to({graphics:mask_graphics_34,x:75.4598,y:3.6133}).wait(1).to({graphics:mask_graphics_35,x:75.4598,y:3.3604}).wait(1).to({graphics:mask_graphics_36,x:75.4598,y:3.1075}).wait(1).to({graphics:mask_graphics_37,x:75.4598,y:2.8546}).wait(1).to({graphics:mask_graphics_38,x:75.4598,y:2.6018}).wait(1).to({graphics:mask_graphics_39,x:75.4598,y:2.3489}).wait(1).to({graphics:mask_graphics_40,x:75.4598,y:2.096}).wait(1).to({graphics:mask_graphics_41,x:75.4598,y:1.8431}).wait(1).to({graphics:mask_graphics_42,x:75.4598,y:1.5902}).wait(1).to({graphics:mask_graphics_43,x:75.4598,y:1.3374}).wait(1).to({graphics:mask_graphics_44,x:75.4598,y:1.0845}).wait(1).to({graphics:mask_graphics_45,x:75.4598,y:0.8316}).wait(1).to({graphics:mask_graphics_46,x:75.4598,y:0.5787}).wait(1).to({graphics:mask_graphics_47,x:75.4598,y:0.3258}).wait(1).to({graphics:mask_graphics_48,x:75.4598,y:0.073}).wait(1).to({graphics:mask_graphics_49,x:75.4598,y:-0.1799}).wait(1).to({graphics:mask_graphics_50,x:75.4598,y:-0.4328}).wait(1).to({graphics:mask_graphics_51,x:75.4598,y:-0.6857}).wait(1).to({graphics:mask_graphics_52,x:75.4598,y:-0.9386}).wait(1).to({graphics:mask_graphics_53,x:75.4598,y:-1.1915}).wait(1).to({graphics:mask_graphics_54,x:75.4598,y:-1.4443}).wait(1).to({graphics:mask_graphics_55,x:75.4598,y:-1.6972}).wait(1).to({graphics:mask_graphics_56,x:75.4598,y:-1.9501}).wait(1).to({graphics:mask_graphics_57,x:75.4598,y:-2.203}).wait(1).to({graphics:mask_graphics_58,x:75.4598,y:-2.4559}).wait(1).to({graphics:mask_graphics_59,x:75.4598,y:-2.7087}).wait(1).to({graphics:mask_graphics_60,x:75.4598,y:-2.9616}).wait(1).to({graphics:mask_graphics_61,x:75.4598,y:-3.2145}).wait(1).to({graphics:mask_graphics_62,x:75.4598,y:-3.4674}).wait(1).to({graphics:mask_graphics_63,x:75.4598,y:-3.7203}).wait(1).to({graphics:mask_graphics_64,x:75.4598,y:-3.9731}).wait(1).to({graphics:mask_graphics_65,x:75.4598,y:-4.226}).wait(1).to({graphics:mask_graphics_66,x:75.4598,y:-4.4789}).wait(1).to({graphics:mask_graphics_67,x:75.4598,y:-4.7318}).wait(1).to({graphics:mask_graphics_68,x:75.4598,y:-4.9847}).wait(1).to({graphics:mask_graphics_69,x:75.4598,y:-5.2376}).wait(1).to({graphics:mask_graphics_70,x:75.4598,y:-5.4904}).wait(1).to({graphics:mask_graphics_71,x:75.4598,y:-5.7433}).wait(1).to({graphics:mask_graphics_72,x:75.4598,y:-5.9962}).wait(1).to({graphics:mask_graphics_73,x:75.4598,y:-6.2491}).wait(1).to({graphics:mask_graphics_74,x:75.4598,y:-6.502}).wait(1).to({graphics:mask_graphics_75,x:75.4598,y:-6.7548}).wait(1).to({graphics:mask_graphics_76,x:75.4598,y:-7.0077}).wait(1).to({graphics:mask_graphics_77,x:75.4598,y:-6.9801}).wait(1).to({graphics:mask_graphics_78,x:75.4598,y:-6.8973}).wait(1).to({graphics:mask_graphics_79,x:75.4598,y:-6.7592}).wait(1).to({graphics:mask_graphics_80,x:75.4598,y:-6.5659}).wait(1).to({graphics:mask_graphics_81,x:75.4598,y:-6.3175}).wait(1).to({graphics:mask_graphics_82,x:75.4598,y:-6.0137}).wait(1).to({graphics:mask_graphics_83,x:75.4598,y:-5.6548}).wait(1).to({graphics:mask_graphics_84,x:75.4598,y:-5.2406}).wait(1).to({graphics:mask_graphics_85,x:75.4598,y:-4.7713}).wait(1).to({graphics:mask_graphics_86,x:75.4598,y:-4.2466}).wait(1).to({graphics:mask_graphics_87,x:75.4598,y:-3.6668}).wait(1).to({graphics:mask_graphics_88,x:75.4598,y:-3.0318}).wait(1).to({graphics:mask_graphics_89,x:75.4598,y:-2.3415}).wait(1).to({graphics:mask_graphics_90,x:75.4598,y:-1.596}).wait(1).to({graphics:mask_graphics_91,x:75.4598,y:-0.7953}).wait(1).to({graphics:mask_graphics_92,x:75.4598,y:0.0606}).wait(1).to({graphics:mask_graphics_93,x:75.4598,y:0.9718}).wait(1).to({graphics:mask_graphics_94,x:75.4598,y:1.9382}).wait(1).to({graphics:mask_graphics_95,x:75.4598,y:2.9598}).wait(1).to({graphics:mask_graphics_96,x:75.4598,y:4.0366}).wait(1).to({graphics:mask_graphics_97,x:75.4598,y:5.1686}).wait(1).to({graphics:mask_graphics_98,x:75.4598,y:6.3559}).wait(1).to({graphics:mask_graphics_99,x:75.4598,y:6.9973}).wait(1).to({graphics:mask_graphics_100,x:75.4598,y:7.0733}).wait(1).to({graphics:mask_graphics_101,x:75.4598,y:7.1525}).wait(1).to({graphics:mask_graphics_102,x:75.4598,y:7.1877}).wait(77).to({graphics:null,x:0,y:0}).wait(3).to({graphics:mask_graphics_182,x:75.4598,y:-1.8602}).wait(1).to({graphics:mask_graphics_183,x:75.4696,y:-4.9993}).wait(1).to({graphics:mask_graphics_184,x:75.4794,y:-8.1383}).wait(1).to({graphics:mask_graphics_185,x:75.4591,y:-11.2774}).wait(1).to({graphics:mask_graphics_186,x:75.4574,y:-11.4486}).wait(1).to({graphics:mask_graphics_187,x:75.4558,y:-11.6197}).wait(1).to({graphics:mask_graphics_188,x:75.4542,y:-11.7909}).wait(1).to({graphics:mask_graphics_189,x:75.4525,y:-11.9621}).wait(1).to({graphics:mask_graphics_190,x:75.4509,y:-12.1332}).wait(1).to({graphics:mask_graphics_191,x:75.4493,y:-12.3044}).wait(1).to({graphics:mask_graphics_192,x:75.4476,y:-12.4756}).wait(1).to({graphics:mask_graphics_193,x:75.446,y:-12.6467}).wait(1).to({graphics:mask_graphics_194,x:75.4444,y:-12.8179}).wait(1).to({graphics:mask_graphics_195,x:75.4427,y:-12.9891}).wait(1).to({graphics:mask_graphics_196,x:75.4411,y:-13.1603}).wait(1).to({graphics:mask_graphics_197,x:75.4395,y:-13.3314}).wait(1).to({graphics:mask_graphics_198,x:75.4378,y:-13.5026}).wait(1).to({graphics:mask_graphics_199,x:75.4362,y:-13.6738}).wait(1).to({graphics:mask_graphics_200,x:75.4346,y:-13.8449}).wait(1).to({graphics:mask_graphics_201,x:75.4329,y:-14.0161}).wait(1).to({graphics:mask_graphics_202,x:75.4313,y:-14.1873}).wait(1).to({graphics:mask_graphics_203,x:75.4598,y:-14.3257}).wait(1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_226,x:76.2098,y:-9.4988}).wait(18).to({graphics:mask_graphics_244,x:76.2098,y:-9.4988}).wait(42));

	// arrow
	this.instance_3 = new lib.arrow_mc();
	this.instance_3.parent = this;
	this.instance_3.setTransform(131.2,12.15,0.3631,0.3631,0,0,0,44.4,41.1);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regY:41.3,y:-14.55},102).wait(77).to({regX:43.6,regY:41.1,rotation:180,y:-8.7},0).to({regY:41.3,y:-16.7},31).to({regY:41.1,x:130.95,y:51.25},24,cjs.Ease.quadIn).wait(52));

	// cloud
	this.instance_4 = new lib.cloud();
	this.instance_4.parent = this;
	this.instance_4.setTransform(129.35,-119.05,0.534,0.534,0,0,0,106.1,65.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(69).to({regX:104,regY:60.1,x:128.25,y:-115.7},0).wait(1).to({y:-109.35},0).wait(1).to({y:-103.1},0).wait(1).to({y:-96.95},0).wait(1).to({y:-91},0).wait(1).to({y:-85.25},0).wait(1).to({y:-79.75},0).wait(1).to({y:-74.55},0).wait(1).to({y:-69.6},0).wait(1).to({y:-64.95},0).wait(1).to({y:-60.65},0).wait(1).to({y:-56.6},0).wait(1).to({y:-52.8},0).wait(1).to({y:-49.3},0).wait(1).to({y:-46.1},0).wait(1).to({y:-43.05},0).wait(1).to({y:-40.3},0).wait(1).to({y:-37.75},0).wait(1).to({y:-35.35},0).wait(1).to({y:-33.15},0).wait(1).to({y:-31.1},0).wait(1).to({y:-29.25},0).wait(1).to({y:-27.5},0).wait(1).to({y:-25.9},0).wait(1).to({y:-24.45},0).wait(1).to({y:-23.1},0).wait(1).to({y:-21.85},0).wait(1).to({y:-20.7},0).wait(1).to({y:-19.65},0).wait(1).to({y:-18.65},0).wait(1).to({y:-17.75},0).wait(1).to({y:-16.95},0).wait(1).to({y:-16.2},0).wait(1).to({y:-15.55},0).wait(1).to({y:-14.9},0).wait(1).to({y:-14.35},0).wait(1).to({y:-13.85},0).wait(1).to({y:-13.4},0).wait(1).to({y:-13.05},0).wait(1).to({y:-12.7},0).wait(1).to({y:-12.4},0).wait(1).to({regX:106.1,regY:66,x:129.35,y:-9.05},0).wait(54).to({regX:106,x:129.3,mode:"synched",startPosition:0,loop:false},0).to({regY:65.8,y:-123.9},30,cjs.Ease.cubicIn).wait(92));

	// cloud outline
	this.instance_5 = new lib.radialWipeWhole("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(79,-150.25,0.534,0.534,0,0,0,11.8,7.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(68).to({_off:false},0).wait(1).to({regX:104.4,regY:60.6,x:128.45,y:-114.4},0).wait(1).to({y:-107},0).wait(1).to({y:-99.75},0).wait(1).to({y:-92.75},0).wait(1).to({y:-85.95},0).wait(1).to({y:-79.55},0).wait(1).to({y:-73.5},0).wait(1).to({y:-67.8},0).wait(1).to({y:-62.55},0).wait(1).to({y:-57.7},0).wait(1).to({y:-53.25},0).wait(1).to({y:-49.15},0).wait(1).to({y:-45.35},0).wait(1).to({y:-41.95},0).wait(1).to({y:-38.8},0).wait(1).to({y:-35.95},0).wait(1).to({y:-33.35},0).wait(1).to({y:-30.95},0).wait(1).to({y:-28.8},0).wait(1).to({y:-26.8},0).wait(1).to({y:-25},0).wait(1).to({y:-23.35},0).wait(1).to({y:-21.85},0).wait(1).to({regX:11.8,regY:7.6,x:79,y:-48.9,mode:"synched",loop:false},0).wait(1).to({regX:104.4,regY:60.6,x:128.45,y:-19.45,startPosition:1},0).wait(1).to({y:-18.4,startPosition:2},0).wait(1).to({y:-17.45,startPosition:3},0).wait(1).to({y:-16.65,startPosition:4},0).wait(1).to({y:-15.9,startPosition:5},0).wait(1).to({y:-15.2,startPosition:6},0).wait(1).to({y:-14.6,startPosition:7},0).wait(1).to({y:-14.1,startPosition:8},0).wait(1).to({y:-13.65,startPosition:9},0).wait(1).to({y:-13.25,startPosition:10},0).wait(1).to({y:-12.9,startPosition:11},0).wait(1).to({y:-12.6,startPosition:12},0).wait(1).to({y:-12.35,startPosition:13},0).wait(1).to({y:-12.2,startPosition:14},0).wait(1).to({y:-12.05,startPosition:15},0).wait(1).to({y:-11.95,startPosition:16},0).wait(1).to({y:-11.9,startPosition:17},0).wait(1).to({regX:11.8,regY:7.7,x:79,y:-40.2,startPosition:18},0).wait(176));

	// cloud back 2 copy
	this.instance_6 = new lib.cloud_bk_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(481.05,-75.5,0.5313,0.5313,0,0,0,44.6,24.9);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(61).to({_off:false},0).to({regY:25.2,y:65.15},29,cjs.Ease.none).wait(84).to({scaleX:0.4272,scaleY:0.4272,x:428.05,y:75.8},0).to({regY:24.9,y:-80.6},26,cjs.Ease.none).wait(86));

	// cloud back 2
	this.instance_7 = new lib.cloud_bk_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-41.75,-78.3,0.534,0.534,0,0,0,44.6,24.9);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(58).to({_off:false},0).to({regY:25.1,y:67},16,cjs.Ease.none).wait(118).to({regY:25.2,x:0.65,y:85.45},0).to({regY:25,y:-91.85},16,cjs.Ease.none).wait(78));

	// cloud back 1
	this.instance_8 = new lib.cloud_bk_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(224.35,-70.1,0.534,0.534,0,0,0,44.6,25);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(44).to({_off:false},0).to({regY:25.2,y:52.45},21,cjs.Ease.none).wait(133).to({x:68.15,y:69.65},0).to({regY:25,y:-96.1},17,cjs.Ease.none).wait(71));

	// cloud back 1 copy
	this.instance_9 = new lib.cloud_bk_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-96.55,-71.7,0.534,0.534,0,0,0,44.6,25);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(49).to({_off:false},0).to({regY:25.1,y:54},21,cjs.Ease.none).wait(125).to({regX:44.7,scaleX:0.6607,scaleY:0.6607,x:212.2,y:72.8},0).to({regY:24.9,y:-79},17,cjs.Ease.none).wait(74));

	// phone
	this.instance_10 = new lib.phone("single",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(130.25,109.8,0.4804,0.4804,0,0,0,78.6,76.1);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(200).to({_off:false},0).wait(1).to({regX:78.5,regY:112.2,x:130.2,y:120.4},0).wait(1).to({y:113.8},0).wait(1).to({y:107.4},0).wait(1).to({y:101.35},0).wait(1).to({y:95.7},0).wait(1).to({y:90.55},0).wait(1).to({y:85.9},0).wait(1).to({y:81.7},0).wait(1).to({y:78},0).wait(1).to({y:74.7},0).wait(1).to({y:71.75},0).wait(1).to({y:69.15},0).wait(1).to({y:66.85},0).wait(1).to({y:64.8},0).wait(1).to({y:63.05},0).wait(1).to({y:61.45},0).wait(1).to({y:60.05},0).wait(1).to({y:58.85},0).wait(1).to({y:57.8},0).wait(1).to({y:56.85},0).wait(1).to({y:56.05},0).wait(1).to({y:55.35},0).wait(1).to({y:54.75},0).wait(1).to({y:54.25},0).wait(1).to({regX:78.6,regY:76,x:130.25,y:36.5,mode:"synched",startPosition:11,loop:false},0).wait(30).to({regX:69,regY:66.6,scaleX:0.4805,scaleY:0.4803,x:125.65,y:32,mode:"single",startPosition:39},0).wait(1).to({regX:78.5,regY:112.2,scaleX:0.4809,scaleY:0.4808,x:129.5,y:53.8},0).wait(1).to({scaleX:0.4817,scaleY:0.4816,x:128.2,y:53.5},0).wait(1).to({scaleX:0.483,scaleY:0.4829,x:126.15,y:53.1},0).wait(1).to({scaleX:0.4848,scaleY:0.4846,x:123.35,y:52.45},0).wait(1).to({scaleX:0.4871,scaleY:0.4869,x:119.75,y:51.75},0).wait(1).to({scaleX:0.4899,scaleY:0.4898,x:115.2,y:50.75},0).wait(1).to({scaleX:0.4934,scaleY:0.4932,x:109.8,y:49.6},0).wait(1).to({scaleX:0.4974,scaleY:0.4972,x:103.35,y:48.25},0).wait(1).to({scaleX:0.502,scaleY:0.5019,x:96,y:46.7},0).wait(1).to({scaleX:0.5072,scaleY:0.507,x:87.75,y:44.95},0).wait(1).to({scaleX:0.5129,scaleY:0.5127,x:78.8,y:43.05},0).wait(1).to({scaleX:0.5189,scaleY:0.5187,x:69.25,y:41.05},0).wait(1).to({scaleX:0.5251,scaleY:0.5249,x:59.35,y:38.95},0).wait(1).to({scaleX:0.5313,scaleY:0.5312,x:49.45,y:36.85},0).wait(1).to({scaleX:0.5374,scaleY:0.5373,x:39.85,y:34.85},0).wait(1).to({scaleX:0.5432,scaleY:0.5431,x:30.7,y:32.9},0).wait(1).to({scaleX:0.5486,scaleY:0.5484,x:22.15,y:31.1},0).wait(1).to({scaleX:0.5534,scaleY:0.5533,x:14.5,y:29.5},0).wait(1).to({scaleX:0.5577,scaleY:0.5576,x:7.65,y:28},0).wait(1).to({scaleX:0.5615,scaleY:0.5613,x:1.7,y:26.8},0).wait(1).to({scaleX:0.5647,scaleY:0.5645,x:-3.35,y:25.7},0).wait(1).to({scaleX:0.5674,scaleY:0.5672,x:-7.65,y:24.8},0).wait(1).to({scaleX:0.5695,scaleY:0.5694,x:-11.1,y:24.1},0).wait(1).to({scaleX:0.5713,scaleY:0.5711,x:-13.85,y:23.5},0).wait(1).to({scaleX:0.5726,scaleY:0.5724,x:-15.9,y:23.05},0).wait(1).to({regX:68.9,regY:66.5,scaleX:0.5735,scaleY:0.5733,x:-22.8,y:-3.4},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-255.9,-167.1,817,350.29999999999995);


(lib.logos_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance_5 = new lib.MSFT_Logo();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-16.4,10.95,2.2463,2.2463);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.logos_1, new cjs.Rectangle(-130.5,-10.1,226.7,48.4), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(25.65,4.5,0.9269,0.9581,0,0,0,11.1,7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-0.65,1,1.0075,1.0414,0,0,0,57.2,15);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA3A00").s().p("AofCNIAAkYIRAAAIAAEYg");
	this.shape.setTransform(-5.25,2.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-59.7,-11.1,108.9,28.1), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSFT Logo
	this.logo = new lib.logos();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.9,19.15,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(710.1,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(667.6,44.6,0.4964,0.4964);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(682.45,42.15,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// anim
	this.instance = new lib.logos_1();
	this.instance.parent = this;
	this.instance.setTransform(56.9,19.15,0.312,0.312);

	this.anim = new lib.anim();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(378.3,134.1,1,1,0,0,0,145.3,80.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.anim},{t:this.instance}]}).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("A3vT0MAAAgnnMAvfAAAMAAAAnng");
	this.shape.setTransform(365.5103,46.6278,2.418,0.3836);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-1.9,-108.4,734.9,216.60000000000002), null);


// stage content:
(lib.O365_ONDRV_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC

		this.initBanner = function (data) {

			Object.keys = function(obj) {
				var keys = [];

				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)

				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "fram" && data[keys[i]].length > 1) {
							exportRoot.fillFrame(data[keys[i]], keys[i])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}


		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillFrame = function (txtDetails, aKey) {
			console.log(aKey)
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)

				this.mainMC.anim[aKey].addChild(mc);
			}
		}


		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}


		//exportRoot.tlanim = new TimelineLite();


		var mc = exportRoot.mainMC


		this.runBanner = function() {



			exportRoot.finalHeadline = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.finalHeadline.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Sine.easeOut});
				if (i!=0) exportRoot.finalHeadline.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Sine.easeOut}, "-=0.35");

				}
			exportRoot.finalHeadline.stop()




			exportRoot.tl1 = new TimelineLite();

			exportRoot.tl1.from(mc.replay_btn, 0.7, {alpha: 1,	x: "+=300",ease: Power4.easeOut}, "-=0.5")

			exportRoot.tl1.from(mc.txtCta, 0.7, {alpha: 1,	x: "+=300", ease: Power4.easeOut}, "-=0.3");
			exportRoot.tl1.from(mc.cta, 0.7, {alpha: 1,	x: "+=300",	ease: Power4.easeOut}, "-=0.7");


			exportRoot.tl1.stop()

			mc.logo.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(362.1,-63.4,370.9,171.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_ONDRV_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_.png?1541781099858", id:"O365_ONDRV_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
