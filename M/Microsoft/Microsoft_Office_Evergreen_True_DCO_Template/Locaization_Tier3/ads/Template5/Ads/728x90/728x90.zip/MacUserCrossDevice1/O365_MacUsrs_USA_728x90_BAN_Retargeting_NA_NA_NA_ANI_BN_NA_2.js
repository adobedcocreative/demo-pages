(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2_atlas_", frames: [[0,0,300,250],[0,252,300,250],[0,504,265,166]]}
];


// symbols:



(lib.IPhone = function() {
	this.initialize(ss["O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.mac = function() {
	this.initialize(ss["O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.macbookscreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteShape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg5UAHKIAAuTMBypAAAIAAOTg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteShape, new cjs.Rectangle(-366.9,-45.8,733.8,91.6), null);


(lib.shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#333333","rgba(37,37,37,0)"],[0.639,1],0,0,0,0,0,388.9).s().p("EgqlAqmQxpxpAA49QAA48RpxpQRpxpY8AAQY9AARpRpQRpRpAAY8QAAY9xpRpQxpRp49AAQ48AAxpxpg");
	this.shape.setTransform(385.5,385.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow_sub, new cjs.Rectangle(0,0,771,771), null);


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(94.757,9.9667,1.4103,1.4103);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(79.7377,13.0693,1.4103,1.4103);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(67.3627,13.0693,1.4103,1.4103);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(54.8466,13.0693,1.4103,1.4103);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(44.1639,12.9283,1.4103,1.4103);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(32.9523,13.0693,1.4103,1.4103);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(24.2086,2.7744,1.4103,1.4103);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(24.1734,13.0341,1.4103,1.4103);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(9.824,10.4603,1.4103,1.4103);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(0,0,102.8,19.9), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MacBookScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.macbookscreen();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5397,0.5397);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.MacBookScreen, new cjs.Rectangle(0,0,143,89.6), null);


(lib.Mac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mac();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.67,0.67);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mac, new cjs.Rectangle(0,0,201,167.5), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape.setTransform(23.175,23.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape_1.setTransform(7.225,23.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F25022").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape_2.setTransform(7.225,7.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7CBB01").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape_3.setTransform(23.175,7.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(0,0,30.4,30.4), null);


(lib.lid_tip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#CFCFCF","#E3E3E3"],[0,0.855],-109.8,-3.8,-109.8,-21.5).s().p("EA0rAChMh4hgACQgBhaAKgkQAOg3A1g1QA0g0BtgXQBJgQBZgCMB7lAAAQDdAFBWBXQA1A0AMA6QAHAigEBkIAAABg");
	this.shape.setTransform(440.2562,16.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#CDCDCD","#CBCBCB"],[0,1],-169.8,-122.7,167.6,-295.1).s().p("EBD6ACoQAEhkgHgiQgMg6g1g0QhWhXjdgFIAcAAQDuAABbBcQA1A0AMA6QAHAigEBlgEhEtACfQgBhaAKgkQAOg3A1g1QA0g0BtgXQBRgSBoAAIAlAAQhZAChJAQQhtAXg0A0Qg1A1gOA3QgKAkABBag");
	this.shape_1.setTransform(439.7565,16.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lid_tip, new cjs.Rectangle(0,0,879.5,33.8), null);


(lib.lid_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CBCBCB").s().p("AD6AqQgcgCkSgnQkcgnATgBIAAAAQBCgBB+AGIDIgHQAdgBBNANQBIANAhAKQAaAGAFALQAGAKgPAJIgtAKIgLACIAAAAIgCAAg");
	this.shape.setTransform(451.4504,19.622);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F6F6F6").s().p("AjtBAQgDgFAXgFIA7gMQAfgGBDgDQAygCAYAAQAHAGgrAJQgpAJgiADIhUAHIgmACQgQAAgCgDgAlCAZQhegFAJgEIBGgMQA8gJAGgJQADgFgMgEQgNgGgdgDQg0gHgKABQAfgIBBgJQBTgKAugBQgTABEbAoQETAnAcABIgsAEQhNAHg5ABQgjABhXgDQhVgDgNABIjUAGIgMAAQgiAAhKgEg");
	this.shape_1.setTransform(435.6605,22.3191);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#CFCECE","#BABAB9","#EBEBEB","#E6E6E6","#BBBABC","#D5D4D5"],[0.039,0.176,0.494,0.569,0.788,0.937],-388.1,223.7,373.5,-221.7).s().p("EhEBADdQgNgKACgIIAFgFIOzmaQATgHAjgHQAHgBATgBIAbgBMBm1AAAQAYgBAkADQAWACgFgBIBAAPIOyGbQAFAOgLAGQgKAGgkACMiGoAACIgGAAQgeAAgMgJgAhFAaQhDADgfAGIg7AMQgWAFADAFQADAFA1gEIBTgHQAjgDApgJQArgJgIgGIgJAAIhBACgAlKgnQAcADANAGQAMAEgDAFQgFAJg9AKIhFALQgJAEBdAFQBZAFAfgBIDVgGQANgBBUADQBYADAigBQA5gBBOgHIAsgEIACAAIALgCIAsgJQAPgJgFgKQgGgLgagHQghgKhHgNQhNgNgdABIjJAHQh+gGhBABIAAAAQgvABhSAKQhBAJggAIIAEAAQANAAAuAGg");
	this.shape_2.setTransform(436.5042,23.017);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lid_sub, new cjs.Rectangle(0,0,873,46), null);


(lib.lid_open_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgWAXQgKgJAAgOQAAgMAKgKQAKgJAMAAQANAAAKAJQAKAKAAAMQAAAOgKAJQgKAKgNAAQgMAAgKgKg");
	this.shape.setTransform(339.25,13.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#191919").s().p("AgNAOQgFgGAAgIQAAgHAFgFQAGgGAHAAQAIAAAFAGQAGAFAAAHQAAAIgGAGQgFAFgIAAQgHAAgGgFg");
	this.shape_1.setTransform(414.65,12.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E0E0E0").s().p("EgwTAebMAAAg81MBgnAAAMAAAA81g");
	this.shape_2.setTransform(339.775,222.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#090909","#252525"],[0,1],-168.7,86.3,168.7,-86.2).s().p("Eg0jAidQgXg/AAhHMAAAg8lQAAilB1h0QB0h1ClAAMBdaAAAQCkAAB0B1QB1B0AAClMAAAA8lQAABHgWA/gEgwIAeyMBgnAAAMAAAg81MhgnAAAgEgAQgguQgKAKAAANQAAAOAKAJQAJAKANAAQANAAAKgKQAJgJAAgOQAAgNgJgKQgKgJgNAAQgNAAgJAJgEALqggqQgFAGAAAIQAAAIAFAFQAGAGAIAAQAIAAAFgGQAGgFAAgIQAAgIgGgGQgFgFgIAAQgIAAgGAFg");
	this.shape_3.setTransform(338.675,220.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lid_open_sub, new cjs.Rectangle(0,0,677.4,441), null);


(lib.keyboard_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#999999","#FFFFFF"],[0,0.078,0.647],-217.3,-15.3,-84.3,-15.3).s().p("EgimAAQIAAgfMBFNAAAIAAAfIofgDMg7vAADg");
	this.shape.setTransform(221.475,13.1375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#656565","#333333"],[0.196,0.306],-191,-6.9,11.1,-6.9).s().p("EghjAAtIDqgtQELgzAAACUAABAAEA7vgACIAABfUhCJAAAgB6AACIAegFg");
	this.shape_1.setTransform(218.175,4.9943);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#656565","#333333"],[0.196,0.306],210.5,5.5,-49.4,5.5).s().p("EgioAAxIAAhfMA8sgACQIiBZAEAFMhCiAABIiJACIgnAAg");
	this.shape_2.setTransform(657.7,4.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#D5D5D5","#E3E3E3","#CCCCCC"],[0,0.682,1],0,13.6,0,-13.7).s().p("Eg4lABdQh3AAiFgOQirgTh6glQhzghhEgnQgsgagDgLQABgBA9gBMA7wgAEIIeADII1gDMA1pAAFQFwAGgBAFQgCAUhsAqQhwAriFAdQhOARjtALIjhAHg");
	this.shape_3.setTransform(439.725,23.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAgAKMhFMAAAIAAgIIAAgLIAiAAIgeAFUAB6gADBCJAAAIAnAAICIgBMBCjgABIAAALIAAAIg");
	this.shape_4.setTransform(439.725,10.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#999999","#FFFFFF"],[0.463,0.941,1],42.1,6.5,213,6.5).s().p("A5RAMIo0ADIAAgfMBEMAAAIAAAfIlwACg");
	this.shape_5.setTransform(661.2,13.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.keyboard_sub, new cjs.Rectangle(0,0,879.5,33.1), null);


(lib.Iphone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IPhone();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.588,0.588);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Iphone, new cjs.Rectangle(0,0,176.4,147), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shapeMC.cache(-700,-90,1400,180,0.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shapeMC = new lib.whiteShape();
	this.shapeMC.name = "shapeMC";
	this.shapeMC.parent = this;
	this.shapeMC.setTransform(-194.5,279.25);

	this.timeline.addTween(cjs.Tween.get(this.shapeMC).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(-561.4,233.5,733.8,91.60000000000002), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow.cache(-771,-771,1542,1542,0.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.shadow = new lib.shadow_sub();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(0,0,1,1,0,0,0,385.5,385.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(-385.5,-385.5,771,771), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo_box2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-31,-31,62,62,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(15.2,15.2,1,1,0,0,0,15.2,15.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box2, new cjs.Rectangle(0,0,30.4,30.4), null);


(lib.lid_shut = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.lid.cache(-873,-46,1746,92,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lid = new lib.lid_sub();
	this.lid.name = "lid";
	this.lid.parent = this;
	this.lid.setTransform(436.5,23,1,1,0,0,0,436.5,23);

	this.timeline.addTween(cjs.Tween.get(this.lid).wait(1));

}).prototype = getMCSymbolPrototype(lib.lid_shut, new cjs.Rectangle(0,0,873,46), null);


(lib.lid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.lid.cache(-880,-34,1760,68,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.lid = new lib.lid_tip();
	this.lid.name = "lid";
	this.lid.parent = this;
	this.lid.setTransform(0.05,0.05,1,1,0,0,0,439.8,16.9);

	this.timeline.addTween(cjs.Tween.get(this.lid).wait(1));

}).prototype = getMCSymbolPrototype(lib.lid, new cjs.Rectangle(-439.7,-16.8,879.5,33.7), null);


(lib.laptop2_sub2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.keyboard = new lib.keyboard_sub();
	this.keyboard.name = "keyboard";
	this.keyboard.parent = this;
	this.keyboard.setTransform(451.85,451,1,1,0,0,0,439.7,16.5);

	this.lid = new lib.lid_open_sub();
	this.lid.name = "lid";
	this.lid.parent = this;
	this.lid.setTransform(450.8,220.5,1,1,0,0,0,338.7,220.5);

	this.shadow = new lib.shadow_sub();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(644.65,464.35,0.6721,0.0244,0,0,0,385.5,385.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#333333","rgba(37,37,37,0)"],[0.639,1],0,0,0,0,0,270).s().p("A9kBCQsQgbAAgnQAAgmMQgbQMQgcRUAAQG7AAGGAEQJNAHHXARQMQAbAAAmQAAAnsQAbQnXARpNAHQmGAEm7AAQxUAAsQgcg");
	this.shape.setTransform(267.675,464.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#333333","rgba(37,37,37,0)"],[0.639,1],-106.8,0,0,-106.8,0,313.2).s().p("A/zBaQJNgHHXgRQMQgbAAgnQAAgmsQgbQnXgRpNgHQHFgEICAAQUFAAONAcQOOAbAAAmQAAAnuOAbQuNAc0FAAQoCAAnFgEg");
	this.shape_1.setTransform(554.575,464.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.shadow},{t:this.lid},{t:this.keyboard}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop2_sub2, new cjs.Rectangle(0,0,903.8,473.8), null);


(lib.laptop2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop2.cache(-904,-474,1808,948,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.laptop2 = new lib.laptop2_sub2();
	this.laptop2.name = "laptop2";
	this.laptop2.parent = this;
	this.laptop2.setTransform(451.9,236.8,1,1,0,0,0,451.9,236.8);

	this.timeline.addTween(cjs.Tween.get(this.laptop2).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop2_sub, new cjs.Rectangle(0,0,903.8,473.8), null);


(lib.laptop2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.screenMC2 = new lib.MacBookScreen();
	this.screenMC2.name = "screenMC2";
	this.screenMC2.parent = this;
	this.screenMC2.setTransform(-3.55,-0.2,4.3434,4.3434,0,0,0,71.1,44.6);

	this.timeline.addTween(cjs.Tween.get(this.screenMC2).wait(1));

	// keyboard
	this.instance = new lib.laptop2_sub();
	this.instance.parent = this;
	this.instance.setTransform(-0.45,14.85,1,1,0,0,0,451.9,236.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop2, new cjs.Rectangle(-452.3,-221.9,903.7,473.70000000000005), null);


(lib.keyboard = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.keyboard.cache(-880,-33,1760,66,0.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.keyboard = new lib.keyboard_sub();
	this.keyboard.name = "keyboard";
	this.keyboard.parent = this;
	this.keyboard.setTransform(439.7,16.5,1,1,0,0,0,439.7,16.5);

	this.timeline.addTween(cjs.Tween.get(this.keyboard).wait(1));

}).prototype = getMCSymbolPrototype(lib.keyboard, new cjs.Rectangle(0,0,879.5,33.1), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-103,-20,206,40,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(24.65,1.9,1,1,0,0,0,51.4,10);

	this.timeline.addTween(cjs.Tween.get(this.ms).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape.setTransform(-43.025,10.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape_1.setTransform(-58.975,10.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape_2.setTransform(-43.025,-5.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AhHBIIAAiPICPAAIAACPg");
	this.shape_3.setTransform(-58.975,-5.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-66.2,-12.7,142.3,30.4), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_68 = function() {
		exportRoot.mainTimeline.play()
	}
	this.frame_72 = function() {
		exportRoot.tl1.play()
	}
	this.frame_82 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(68).call(this.frame_68).wait(4).call(this.frame_72).wait(10).call(this.frame_82).wait(1));

	// Layer 3
	this.instance = new lib.logo_box2();
	this.instance.parent = this;
	this.instance.setTransform(179.65,-42.2,0.0692,0.0692,0,0,0,15.2,15.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:1,scaleY:1,x:179.6,y:-42.25},13,cjs.Ease.quadInOut).to({x:129.65},12,cjs.Ease.quadInOut).to({_off:true},1).wait(56));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AGrALIAAksIRsAAIAAEsg");
	var mask_graphics_15 = new cjs.Graphics().p("AGnALIAAksIRtAAIAAEsg");
	var mask_graphics_16 = new cjs.Graphics().p("AGdALIAAksIRtAAIAAEsg");
	var mask_graphics_17 = new cjs.Graphics().p("AGMALIAAksIRtAAIAAEsg");
	var mask_graphics_18 = new cjs.Graphics().p("AF0ALIAAksIRtAAIAAEsg");
	var mask_graphics_19 = new cjs.Graphics().p("AFVALIAAksIRtAAIAAEsg");
	var mask_graphics_20 = new cjs.Graphics().p("AEwALIAAksIRsAAIAAEsg");
	var mask_graphics_21 = new cjs.Graphics().p("AEKALIAAksIRtAAIAAEsg");
	var mask_graphics_22 = new cjs.Graphics().p("ADrALIAAksIRtAAIAAEsg");
	var mask_graphics_23 = new cjs.Graphics().p("ADTALIAAksIRtAAIAAEsg");
	var mask_graphics_24 = new cjs.Graphics().p("ADCALIAAksIRtAAIAAEsg");
	var mask_graphics_25 = new cjs.Graphics().p("AC4ALIAAksIRsAAIAAEsg");
	var mask_graphics_26 = new cjs.Graphics().p("AC0ALIAAksIRsAAIAAEsg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:155.9419,y:-28.9593}).wait(1).to({graphics:mask_graphics_15,x:155.5996,y:-28.9593}).wait(1).to({graphics:mask_graphics_16,x:154.5726,y:-28.9594}).wait(1).to({graphics:mask_graphics_17,x:152.8609,y:-28.9595}).wait(1).to({graphics:mask_graphics_18,x:150.4647,y:-28.9597}).wait(1).to({graphics:mask_graphics_19,x:147.3837,y:-28.9599}).wait(1).to({graphics:mask_graphics_20,x:143.6181,y:-28.9602}).wait(1).to({graphics:mask_graphics_21,x:139.8525,y:-28.9605}).wait(1).to({graphics:mask_graphics_22,x:136.7716,y:-28.9607}).wait(1).to({graphics:mask_graphics_23,x:134.3753,y:-28.9609}).wait(1).to({graphics:mask_graphics_24,x:132.6637,y:-28.961}).wait(1).to({graphics:mask_graphics_25,x:131.6367,y:-28.961}).wait(1).to({graphics:mask_graphics_26,x:131.2169,y:-28.9843}).wait(1).to({graphics:null,x:0,y:0}).wait(56));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.parent = this;
	this.instance_1.setTransform(117.5,-44.65,1,1,0,0,0,0.3,0.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({regX:0.2,x:180.85},12,cjs.Ease.quadInOut).wait(25).to({regX:0,regY:0,scaleX:0.4984,scaleY:0.4984,x:-129.35,y:-64.8},21,cjs.Ease.quadInOut).wait(11));

	// white
	this.instance_2 = new lib.white();
	this.instance_2.parent = this;
	this.instance_2.setTransform(863.9,86.05,1,1,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(51).to({x:114.35},29,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(863.9,86.05,1,1,0,0,0,485.4,406.9);
	this.instance_3.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(53).to({x:130.65},29,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-932.5,-87.4,1483.4,91.60000000000001);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(20.15,2.75,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.05,0.4,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AoiChIAAlBIRFAAIAAFBg");
	this.shape.setTransform(-10.075,1.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-64.8,-14.6,109.5,32.1), null);


(lib.laptop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_22 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(22).call(this.frame_22).wait(1));

	// LidGrey closed vector
	this.instance = new lib.lid_shut();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,188.2,1,1,0,0,0,436.5,23);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(22));

	// lid open
	this.instance_1 = new lib.lid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.5,211.4,1,0.7062);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-0.1,regY:0.1,scaleX:1.0141,scaleY:0.7722,x:-4.6,y:145.15},1).to({y:124.1},1).to({regX:0,regY:0,scaleX:0.9853,scaleY:0.3227,x:-0.5,y:-35.25},4).to({_off:true},1).wait(16));

	// keyboard
	this.instance_2 = new lib.keyboard();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.5,229.05,1,1,0,0,0,439.7,16.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23));

	// Layer_13
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("EgwTACxIywlhMCGHAAAIywFhg");
	this.shape.setTransform(-0.475,177.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("EgwVAFbIyIq1MCE7AAAIyMK1g");
	this.shape_1.setTransform(-0.275,160.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("EgwXAIFIxgwJMCDvAAAIxoQJg");
	this.shape_2.setTransform(-0.075,143.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("EgwZAKvIw41dMCCjAAAIxEVdg");
	this.shape_3.setTransform(0.125,126.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("EgwbANZIwQ6xMCBXAAAIwgaxg");
	this.shape_4.setTransform(0.325,109.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("EgwdAQDMgPoggFMCALAAAMgP8AgFg");
	this.shape_5.setTransform(0.525,92.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("EgwdAS1MgOTglpMB9hAAAMgOnAlpg");
	this.shape_6.setTransform(0.525,75.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("EgwdAVmMgM+grLMB63AAAMgNSArLg");
	this.shape_7.setTransform(0.525,57.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#333333").s().p("EgwdAYYMgLpgwvMB4NAAAMgL9Awvg");
	this.shape_8.setTransform(0.525,39.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("EgwdAbJMgKUg2RMB1jAAAMgKoA2Rg");
	this.shape_9.setTransform(0.525,21.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("EgwdAchMgHVg5BMBvlAAAMgHpA5Bg");
	this.shape_10.setTransform(0.525,13.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("EgwdAdsMgEzg7XMBqhAAAMgFHA7Xg");
	this.shape_11.setTransform(0.525,5.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("EgwdAeeMgDGg87MBnHAAAMgDaA87g");
	this.shape_12.setTransform(0.525,0.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("EgwdAevMgCgg9dMBl7AAAMgC0A9dg");
	this.shape_13.setTransform(0.525,-1.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("EgwbAerMgB6g9UMBksAAAMgCKA9Ug");
	this.shape_14.setTransform(0.3,-0.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("EgwZAenMgBag9MMBjnAAAMgBlA9Mg");
	this.shape_15.setTransform(0.1,-0.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("EgwXAejMgA/g9FMBitAAAMgBHA9Fg");
	this.shape_16.setTransform(-0.075,0.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("EgwWAegMgAog8/MBh9AAAMgAtA8/g");
	this.shape_17.setTransform(-0.225,0.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("EgwVAeeMgAWg87MBhXAAAMgAZA87g");
	this.shape_18.setTransform(-0.325,0.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("EgwUAedMgAKg84MBg9AAAMgALA84g");
	this.shape_19.setTransform(-0.4,0.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("EgwTAecMgADg83MBgtAAAMgADA83g");
	this.shape_20.setTransform(-0.45,0.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("EgwTAebMAAAg81MBgnAAAMAAAA81g");
	this.shape_21.setTransform(-0.475,0.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).wait(1));

	// Layer 9
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#191919").s().p("AgMAOQgGgGAAgIQAAgHAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAHQAAAIgFAGQgGAFgIAAQgHAAgFgFg");
	this.shape_22.setTransform(74.4,152.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AgWAXQgJgJAAgOQAAgMAJgKQAKgJAMAAQAOAAAJAJQAKAKAAAMQAAAOgKAJQgJAJgOAAQgMAAgKgJg");
	this.shape_23.setTransform(-1,153.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("AgWAXQgJgKAAgNQAAgNAJgJQAKgKAMAAQAOAAAJAKQAKAJAAANQAAANgKAKQgJAKgOgBQgMABgKgKg");
	this.shape_24.setTransform(-1,117.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#191919").s().p("AgLAMQgGgFAAgHQAAgIAGgGQAUgFAGAFQAFAVgFAFQgGAGgIAAQgHAAgFgGg");
	this.shape_25.setTransform(74.2625,117.3375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AgWAXQgJgJAAgOQAAgMAJgKQAKgJAMAAQAOAAAJAJQAKAKAAAMQAAAOgKAJQgJAKgOAAQgMAAgKgKg");
	this.shape_26.setTransform(-1,82.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("AgWAXQgJgKAAgNQAAgNAJgJQAKgKAMAAQAOAAAJAKQAKAJAAANQAAANgKAKQgJAJgOAAQgMAAgKgJg");
	this.shape_27.setTransform(-1,46.55);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#333333").s().p("AgWAXQgJgJAAgOQAAgMAJgKQAKgKAMABQAOgBAJAKQAKAKAAAMQAAAOgKAJQgJAKgOAAQgMAAgKgKg");
	this.shape_28.setTransform(-1,10.95);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#191919").s().p("AgMANQgGgFAAgIQAAgHAGgGQAFgFAHAAQAIAAAGAFQAFAGAAAHQAAAIgFAFQgGAGgIAAQgHAAgFgGg");
	this.shape_29.setTransform(74.4,-25.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AgWAXQgJgKAAgNQAAgNAJgJQAKgJAMAAQAOAAAJAJQAKAJAAANQAAANgKAKQgJAJgOAAQgMAAgKgJg");
	this.shape_30.setTransform(-1,-182.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_23},{t:this.shape_22,p:{y:152.8}}]},1).to({state:[{t:this.shape_25,p:{y:117.3375}},{t:this.shape_24,p:{y:117.75}}]},1).to({state:[{t:this.shape_26,p:{y:82.15}},{t:this.shape_25,p:{y:81.7375}}]},1).to({state:[{t:this.shape_25,p:{y:46.1375}},{t:this.shape_27,p:{y:46.55}}]},1).to({state:[{t:this.shape_25,p:{y:10.5375}},{t:this.shape_28,p:{y:10.95}}]},1).to({state:[{t:this.shape_27,p:{y:-24.65}},{t:this.shape_29,p:{y:-25.2}}]},1).to({state:[{t:this.shape_25,p:{y:-60.5625}},{t:this.shape_28,p:{y:-60.15}}]},1).to({state:[{t:this.shape_25,p:{y:-96.0625}},{t:this.shape_27,p:{y:-95.65}}]},1).to({state:[{t:this.shape_26,p:{y:-131.15}},{t:this.shape_25,p:{y:-131.5625}}]},1).to({state:[{t:this.shape_24,p:{y:-166.65}},{t:this.shape_29,p:{y:-167.2}}]},1).to({state:[{t:this.shape_25,p:{y:-183.1125}},{t:this.shape_30}]},1).to({state:[{t:this.shape_25,p:{y:-196.7625}},{t:this.shape_24,p:{y:-196.35}}]},1).to({state:[{t:this.shape_27,p:{y:-205.45}},{t:this.shape_25,p:{y:-205.8625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_22,p:{y:-209.2}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_25,p:{y:-209.0625}}]},1).to({state:[{t:this.shape_28,p:{y:-208.65}},{t:this.shape_22,p:{y:-209.2}}]},1).wait(1));

	// Layer 8
	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#090909","#252525"],[0,1],-166.7,-90.7,170.7,-263.2).s().p("Eg0PAGzQgXg/AAhHIxqlRQAAilB1h0QB0h1ClAAMCAGAAAQCkAAB0B1QB1B0AAClIxCFRQAABHgWA/g");
	this.shape_31.setTransform(-3.575,175.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#090909","#252525"],[0,1],-167.9,-73.7,169.5,-246.2).s().p("Eg0bAJdQgXg/AAhHIxWqlQAAilB1h0QB0h1ClAAMB/2AAAQCkAAB0B1QB1B0AAClIxGKlQAABHgWA/g");
	this.shape_32.setTransform(-2.375,158.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#090909","#252525"],[0,1],-169.1,-56.7,168.3,-229.2).s().p("Eg0nAMHQgXg/AAhHIxCv5QAAilB1h0QB0h1ClAAMB/mAAAQCkAAB0B1QB1B0AAClIxKP5QAABHgWA/g");
	this.shape_33.setTransform(-1.175,141.525);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#090909","#252525"],[0,1],-170.3,-39.7,167.1,-212.2).s().p("Eg0zAOxQgXg/AAhHIwu1NQAAilB1h0QB0h1ClAAMB/WAAAQCkAAB0B1QB1B0AAClIxOVNQAABHgWA/g");
	this.shape_34.setTransform(0.025,124.525);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#090909","#252525"],[0,1],-171.5,-22.7,165.9,-195.2).s().p("Eg0/ARbQgXg/AAhHIwa6hQAAilB1h0QB0h1ClAAMB/GAAAQCkAAB0B1QB1B0AAClIxSahQAABHgWA/g");
	this.shape_35.setTransform(1.225,107.525);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#090909","#252525"],[0,1],-172.7,-5.7,164.7,-178.2).s().p("Eg1LAUFQgXg/AAhHIwG/1QAAilB1h0QB0h1ClAAMB+2AAAQCkAAB0B1QB1B0AAClIxWf1QAABHgWA/g");
	this.shape_36.setTransform(2.425,90.525);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#090909","#252525"],[0,1],-172.7,17,164.7,-155.5).s().p("Eg1MAXoQgWg/AAhHMgOagm7QAAilB1h0QB0h1ClAAMB7eAAAQCkAAB0B1QB1B0AAClMgPrAm7QAABHgVA/g");
	this.shape_37.setTransform(2.475,67.825);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#090909","#252525"],[0,1],-172.8,38,164.6,-134.4).s().p("Eg1MAa6QgWg+gBhIMgM1gtgQAAikB1h1QB0h1ClABMB4VAAAQClgBBzB1QB1B1AACkMgOGAtgQAABIgVA+g");
	this.shape_38.setTransform(2.5,46.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#090909","#252525"],[0,1],-172.8,55.1,164.6,-117.4).s().p("Eg1NAdlQgWg+AAhIMgLjgy2QAAikB0h1QB1h0CkAAMB10AAAQCkAAB0B0QB1B1AACkMgM2Ay2QgBBIgVA+g");
	this.shape_39.setTransform(2.55,29.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#090909","#252525"],[0,1],-172.8,67.7,164.6,-104.7).s().p("Eg1NAfjQgWg+AAhIMgKog2yQAAikB1h1QB1h0CkAAMBz7AAAQClAABzB0QB2B1gBCkMgL5A2yQgBBIgVA+g");
	this.shape_40.setTransform(2.55,17.075);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#090909","#252525"],[0,1],-171.5,76.9,165.9,-95.6).s().p("Eg0/Ag/QgXg/AAhHMgHPg5pQAAilB0h0QB1h1CkAAMBsxAAAQClAABzB1QB1B0AAClMgIHA5pQAABHgWA/g");
	this.shape_41.setTransform(1.225,7.925);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#090909","#252525"],[0,1],-170.6,83.1,166.8,-89.3).s().p("Eg02Ah9QgXg+AAhIMgE7g7mQAAilB1h0QB0h1ClAAMBn2AAAQCkAAB0B1QB1B0AAClMgFhA7mQAABIgWA+g");
	this.shape_42.setTransform(0.325,1.65);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#090909","#252525"],[0,1],-170,87.1,167.4,-85.4).s().p("Eg0wAilQgXg+AAhIMgDdg82QAAikB1h1QB0h0ClAAMBkuAAAQCkAAB0B0QB1B1AACkMgD3A82QAABIgWA+g");
	this.shape_43.setTransform(-0.275,-2.325);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#090909","#252525"],[0,1],-169.7,89.2,167.7,-83.2).s().p("Eg0tAi7QgXg/AAhHMgCqg9hQAAilB1h0QB0h1ClAAMBjCAAAQCkAAB0B1QB1B0AAClMgC+A9hQAABHgWA/g");
	this.shape_44.setTransform(-0.575,-4.475);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#090909","#252525"],[0,1],-169.5,88.5,167.9,-83.9).s().p("Eg0rAi0QgWg/gBhHMgCCg9TQABilB0h0QB0h1ClAAMBhtAAAQClAABzB1QB2B0gBClMgCRA9TQAABHgVA/g");
	this.shape_45.setTransform(-0.8,-3.775);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#090909","#252525"],[0,1],-169.3,87.9,168.1,-84.5).s().p("Eg0pAitQgWg+gBhIMgBfg9GQAAikB1h1QB0h1CkABMBglAAAQClgBBzB1QB1B1AACkMgBrA9GQAABIgVA+g");
	this.shape_46.setTransform(-1,-3.15);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#090909","#252525"],[0,1],-169.1,87.4,168.3,-85).s().p("Eg0nAioQgWg+gBhIMgBCg88QAAikB0h1QB1h0CkAAMBfnAAAQCkAAB0B0QB1B1AACkMgBKA88QAABIgVA+g");
	this.shape_47.setTransform(-1.2,-2.65);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#090909","#252525"],[0,1],-168.9,87,168.5,-85.5).s().p("Eg0mAikQgWg+AAhIMgArg80QAAikB1h1QB0h0ClAAMBe0AAAQCkAAB0B0QB1B1AACkMgAwA80QAABIgVA+g");
	this.shape_48.setTransform(-1.325,-2.225);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#090909","#252525"],[0,1],-168.8,86.7,168.6,-85.8).s().p("Eg0lAihQgWg+AAhIMgAYg8uQAAikB0h0QB1h1CkAAMBeNAAAQCkAAB0B1QB1B0AACkMgAaA8uQgBBIgVA+g");
	this.shape_49.setTransform(-1.45,-1.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#090909","#252525"],[0,1],-168.8,86.4,168.6,-86).s().p("Eg0kAieQgWg+gBhIMgAKg8oQAAilB0h0QB1h0CkgBMBdxAAAQCkABB0B0QB1B0AAClMgAMA8oQAABIgVA+g");
	this.shape_50.setTransform(-1.5,-1.65);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#090909","#252525"],[0,1],-168.7,86.3,168.7,-86.2).s().p("Eg0kAidQgWg+AAhIMgACg8mQgBikB1h1QB1h0CkAAMBdgAAAQCkAAB0B0QB1B1AACkMgADA8mQgBBIgVA+g");
	this.shape_51.setTransform(-1.55,-1.525);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#090909","#252525"],[0,1],-168.7,86.3,168.7,-86.2).s().p("Eg0jAidQgXg/AAhHMAAAg8lQAAilB1h0QB0h1ClAAMBdaAAAQCkAAB0B1QB1B0AAClMAAAA8lQAABHgWA/g");
	this.shape_52.setTransform(-1.575,-1.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).wait(1));

	// shadow
	this.instance_3 = new lib.shadow();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-184.7,242.4,0.6944,0.0244);

	this.instance_4 = new lib.shadow();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-4.7,242.4,0.8055,0.0244);

	this.instance_5 = new lib.shadow();
	this.instance_5.parent = this;
	this.instance_5.setTransform(192.3,242.4,0.6721,0.0244);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(23));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-453.2,-227.9,904.5999999999999,479.70000000000005);


(lib.Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Phone
	this.iPhone = new lib.Iphone();
	this.iPhone.name = "iPhone";
	this.iPhone.parent = this;
	this.iPhone.setTransform(172,155.95,0.61,0.61,0,0,0,88.5,73.7);

	this.timeline.addTween(cjs.Tween.get(this.iPhone).wait(1));

	// MacbookScreen
	this.screenMC = new lib.MacBookScreen();
	this.screenMC.name = "screenMC";
	this.screenMC.parent = this;
	this.screenMC.setTransform(151.2,150.9,0.737,0.737,0,0,0,71.9,44.9);

	this.timeline.addTween(cjs.Tween.get(this.screenMC).wait(1));

	// MacVector
	this.laptopMC = new lib.laptop();
	this.laptopMC.name = "laptopMC";
	this.laptopMC.parent = this;
	this.laptopMC.setTransform(151.05,150.7,0.17,0.17,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.laptopMC).wait(1));

	// laptop2
	this.laptop2 = new lib.laptop2();
	this.laptop2.name = "laptop2";
	this.laptop2.parent = this;
	this.laptop2.setTransform(95.4,172.35,0.085,0.085,0,0,0,1.2,2.4);

	this.timeline.addTween(cjs.Tween.get(this.laptop2).wait(1));

	// Mac
	this.macPro2 = new lib.Mac();
	this.macPro2.name = "macPro2";
	this.macPro2.parent = this;
	this.macPro2.setTransform(66.25,156.5,0.53,0.53,0,0,0,100.5,84);

	this.timeline.addTween(cjs.Tween.get(this.macPro2).wait(1));

	// Mac
	this.macPro = new lib.Mac();
	this.macPro.name = "macPro";
	this.macPro.parent = this;
	this.macPro.setTransform(151.45,161.85,0.63,0.63,0,0,0,100.7,83.9);

	this.timeline.addTween(cjs.Tween.get(this.macPro).wait(1));

}).prototype = getMCSymbolPrototype(lib.Intro, new cjs.Rectangle(13,109,214.7,105.5), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSFT Logo
	this.logo = new lib.logos();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(178.75,87.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(712.1,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txtCta
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(667.75,59.65,0.4964,0.4964);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// cta
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(688.35,57.7,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Intro
	this.anim = new lib.Intro();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(441.85,141.8,1,1,0,0,0,300,250.2);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-4.2,-0.1,734.6,106.19999999999999), null);


// stage content:
(lib.O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		this.runBanner = function() {
		
		
			exportRoot.tlH1 = new TimelineLite();
			for (var i = 0; i < exportRoot.headline4.length; i++) {
				if (i==0) exportRoot.tlH1.from(exportRoot.headline4[i], 0.6, {x: "+=100",	alpha: 0, ease: Power4.easeOut});
				if (i!=0) exportRoot.tlH1.from(exportRoot.headline4[i], 0.6, {x: "+=100",	alpha: 0, ease: Power4.easeOut}, "-=0.4");
			}
			exportRoot.tlH1.stop()
		
			
				exportRoot.tlH1I = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tlH1I.from(exportRoot.headline1[i], 0.8, { y: "+=10", alpha: 0, ease:Power4.easeOut});
				if (i!=0) exportRoot.tlH1I.from(exportRoot.headline1[i], 0.8, { y: "+=10", alpha: 0, ease:Power4.easeOut}, "-=0.7");
			}
			exportRoot.tlH1I.stop()
			
			exportRoot.tlH1O = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				exportRoot.tlH1O.to(exportRoot.headline1[i], 0.8, {	x: "-=20", alpha: 0, ease:Power4.easeIn}, "-=0.35");
			}
			exportRoot.tlH1O.stop()	
			
			
			exportRoot.tlH2I = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tlH2I.from(exportRoot.headline2[i], 0.8, { x: "+=50",	alpha: 0,ease:Power4.easeOut});
				if (i!=0) exportRoot.tlH2I.from(exportRoot.headline2[i], 0.8, { x: "+=50",	alpha: 0,ease:Power4.easeOut}, "-=0.7");
			}
			exportRoot.tlH2I.stop()
			
			exportRoot.tlH2O = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				exportRoot.tlH2O.to(exportRoot.headline2[i], 0.8, { x: "-=20",	alpha: 0,ease:Power4.easeIn}, "-=0.35");
			}
			exportRoot.tlH2O.stop()		
			
			
			exportRoot.tlH3I = new TimelineLite();
			for (var i = 0; i < exportRoot.headline3.length; i++) {
				if (i==0) exportRoot.tlH3I.from(exportRoot.headline3[i], 0.8, {	x: "+=50",	alpha: 0,ease:Power4.easeOut});
				if (i!=0) exportRoot.tlH3I.from(exportRoot.headline3[i], 0.8, {	x: "+=50",	alpha: 0,ease:Power4.easeOut}, "-=0.7");
			}
			exportRoot.tlH3I.stop()
			
			exportRoot.tlH3O = new TimelineLite();
			for (var i = 0; i < exportRoot.headline3.length; i++) {
				exportRoot.tlH3O.to(exportRoot.headline3[i], 0.8, {	x: "-=20",	alpha: 0,ease:Power4.easeIn}, "-=0.35");
			}
			exportRoot.tlH3O.stop()	
			
			this.tl1 = new TimelineLite();
		
			exportRoot.tl1.from(mc.txtCta, 0.7, {alpha: 0,	x: "+=300", ease: Power4.easeOut}, "-=0.3");
			exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0,	x: "+=350",	ease: Power4.easeOut}, "-=0.7");
			
			this.tl1.stop()
			
			exportRoot.tl2 = new TimelineLite();
		
			exportRoot.tl2.from(mc.replay_btn, 0.7, {alpha: 0,	x: "+=300",	ease: Power4.easeOut})
		
			exportRoot.tl2.stop()
		
			mc.logo.gotoAndPlay(1)
			
			
			
			
			exportRoot.mainTimeline = new TimelineLite();
			
			
			TweenLite.delayedCall(2.1, function(){mc.anim.laptopMC.play()})
			exportRoot.mainTimeline.from(mc.anim.screenMC, 0.5, {alpha:0, onStart: function(){exportRoot.tlH1I.play()}}, "+=1.2")
			exportRoot.mainTimeline.to(mc.anim.laptopMC, 0.6, {x:"-=100", alpha:0, ease: Power3.easeIn}, "+=2")
		    exportRoot.mainTimeline.to(mc.anim.screenMC, 0.6, {x:"-=100", alpha:0, ease: Power3.easeIn, onStart: function(){exportRoot.tlH1O.play()}}, "-=0.6")
			exportRoot.mainTimeline.from(mc.anim.macPro, 0.6, {x:"+=100", alpha:0, ease: Power4.easeOut, onStart: function(){exportRoot.tlH2I.play()}}, "+=0.4")
			exportRoot.mainTimeline.to(mc.anim.macPro, 0.6, {x:"-=100", alpha:0, ease: Power3.easeIn, onStart: function(){exportRoot.tlH2O.play()}}, "+=1.7")
			exportRoot.mainTimeline.from(mc.anim.iPhone, 0.6, {x:"+=100", alpha:0, ease: Power3.easeOut, onStart: function(){exportRoot.tlH3I.play()}}, "+=0.3")
		
			exportRoot.mainTimeline.to(mc.anim.iPhone, 0.8, {x:41, y:177, scaleX:0.27, scaleY:0.27, alpha:1, ease: Power1.easeInOut, onStart: function(){exportRoot.tlH3O.play()}}, "+=1.9")
		    exportRoot.mainTimeline.from(mc.anim.laptop2, 0.8, {x:"+=140", y:"-=30", scaleX:0.25, scaleY:0.25, alpha:0, ease: Power1.easeInOut}, "-=0.6")
			exportRoot.mainTimeline.from(mc.anim.macPro2, 0.8, {x:"+=140", y:"-=30", scaleX:1.2, scaleY:1.2, alpha:0, ease: Power1.easeInOut}, "-=0.8")
			TweenLite.delayedCall(13, function(){exportRoot.tlH1.play()})
			TweenLite.delayedCall(13, function(){exportRoot.tl2.play()})
		
			
			
			exportRoot.mainTimeline.stop()
		
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(359.8,45,370.59999999999997,61.099999999999994);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2_atlas_.png?1542203906946", id:"O365_MacUsrs_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_2_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;