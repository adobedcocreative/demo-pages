(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_", frames: [[0,0,404,333],[612,495,100,100],[102,539,100,100],[918,526,100,100],[510,437,100,100],[204,437,100,100],[102,437,100,100],[0,437,100,100],[0,539,100,100],[306,437,100,100],[204,539,100,100],[714,495,100,100],[408,437,100,100],[816,526,100,100],[612,393,100,100],[816,424,100,100],[714,393,100,100],[882,322,100,100],[918,424,100,100],[0,335,100,100],[102,335,100,100],[204,335,100,100],[306,335,100,100],[408,335,100,100],[510,335,100,100],[705,0,221,320],[705,322,175,69],[406,0,297,333]]}
];


// symbols:



(lib._300x250_bg = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00013 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00014 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00015 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00016 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00017 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00018 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00019 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00020 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00021 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00022 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00023 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00024 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00025 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00026 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00027 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00028 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00029 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00030 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00031 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00032 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00033 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00034 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00035 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00036 = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.man = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.tablet_man = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.tractor = function() {
	this.spriteSheet = ss["O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"];
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.5,407,1,2.387);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,-564.3,971,1942.5), null);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.3,0.1,0.877,0.877,135,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tractor_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.tractor();
	this.instance.parent = this;
	this.instance.setTransform(-119,-21,0.895,0.895);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tractor_1, new cjs.Rectangle(-119,-21,266,298.2), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.8,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3,2.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.5,2.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1,2.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.1,2.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.3,-5.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.3,2.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.5,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.2,0,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.3,8.4), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.cta, null, null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.7,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6,-5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.7,-5.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.6), null);


(lib.Hand_animation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_10
	this.instance = new lib.Comp1_00013();
	this.instance.parent = this;
	this.instance.setTransform(199,-26);

	this.instance_1 = new lib.Comp1_00014();
	this.instance_1.parent = this;
	this.instance_1.setTransform(199,-26);

	this.instance_2 = new lib.Comp1_00015();
	this.instance_2.parent = this;
	this.instance_2.setTransform(199,-26);

	this.instance_3 = new lib.Comp1_00016();
	this.instance_3.parent = this;
	this.instance_3.setTransform(199,-26);

	this.instance_4 = new lib.Comp1_00017();
	this.instance_4.parent = this;
	this.instance_4.setTransform(199,-26);

	this.instance_5 = new lib.Comp1_00018();
	this.instance_5.parent = this;
	this.instance_5.setTransform(199,-26);

	this.instance_6 = new lib.Comp1_00019();
	this.instance_6.parent = this;
	this.instance_6.setTransform(199,-26);

	this.instance_7 = new lib.Comp1_00020();
	this.instance_7.parent = this;
	this.instance_7.setTransform(199,-26);

	this.instance_8 = new lib.Comp1_00021();
	this.instance_8.parent = this;
	this.instance_8.setTransform(199,-26);

	this.instance_9 = new lib.Comp1_00022();
	this.instance_9.parent = this;
	this.instance_9.setTransform(199,-26);

	this.instance_10 = new lib.Comp1_00023();
	this.instance_10.parent = this;
	this.instance_10.setTransform(199,-26);

	this.instance_11 = new lib.Comp1_00024();
	this.instance_11.parent = this;
	this.instance_11.setTransform(199,-26);

	this.instance_12 = new lib.Comp1_00025();
	this.instance_12.parent = this;
	this.instance_12.setTransform(199,-26);

	this.instance_13 = new lib.Comp1_00026();
	this.instance_13.parent = this;
	this.instance_13.setTransform(199,-26);

	this.instance_14 = new lib.Comp1_00027();
	this.instance_14.parent = this;
	this.instance_14.setTransform(199,-26);

	this.instance_15 = new lib.Comp1_00028();
	this.instance_15.parent = this;
	this.instance_15.setTransform(199,-26);

	this.instance_16 = new lib.Comp1_00029();
	this.instance_16.parent = this;
	this.instance_16.setTransform(199,-26);

	this.instance_17 = new lib.Comp1_00030();
	this.instance_17.parent = this;
	this.instance_17.setTransform(199,-26);

	this.instance_18 = new lib.Comp1_00031();
	this.instance_18.parent = this;
	this.instance_18.setTransform(199,-26);

	this.instance_19 = new lib.Comp1_00032();
	this.instance_19.parent = this;
	this.instance_19.setTransform(199,-26);

	this.instance_20 = new lib.Comp1_00033();
	this.instance_20.parent = this;
	this.instance_20.setTransform(199,-26);

	this.instance_21 = new lib.Comp1_00034();
	this.instance_21.parent = this;
	this.instance_21.setTransform(199,-26);

	this.instance_22 = new lib.Comp1_00035();
	this.instance_22.parent = this;
	this.instance_22.setTransform(199,-26);

	this.instance_23 = new lib.Comp1_00036();
	this.instance_23.parent = this;
	this.instance_23.setTransform(199,-26);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},101).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_16}]},2).to({state:[{t:this.instance_17}]},2).to({state:[{t:this.instance_18}]},2).to({state:[{t:this.instance_19}]},2).to({state:[{t:this.instance_20}]},2).to({state:[{t:this.instance_21}]},2).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_22}]},10).to({state:[{t:this.instance_21}]},2).to({state:[{t:this.instance_20}]},2).to({state:[{t:this.instance_19}]},2).to({state:[{t:this.instance_18}]},2).to({state:[{t:this.instance_17}]},2).to({state:[{t:this.instance_16}]},2).to({state:[{t:this.instance_15}]},2).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(199,-26,100,100);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib._300x250_bg();
	this.instance.parent = this;
	this.instance.setTransform(-39,-24,0.91,0.91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(-39,-24,367.6,303), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.4,15.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.4,15.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.circle_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.circle_bg, null, null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6,4.2,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.1,16.7,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.6,y:16.6,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,2.9,32.2,27.7);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.1,0.1,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.2},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.4},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1},0).wait(1).to({x:-0.9},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.1},0).wait(1).to({x:0.3},0).wait(1).to({x:0.5},0).wait(1).to({x:0.6},0).wait(2).to({x:0.4},0).wait(1).to({x:0.3},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(3).to({x:0.1},0).wait(2).to({x:0.2},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.2,0.1,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.1},8,cjs.Ease.get(1)).wait(2).to({x:19.9},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.4,-4.1,11.3,8.4);


(lib.man_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_169 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(169).call(this.frame_169).wait(1));

	// Tablet
	this.instance = new lib.tablet_man();
	this.instance.parent = this;
	this.instance.setTransform(137,158,0.811,0.811);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(170));

	// Hand
	this.instance_1 = new lib.Hand_animation("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(195.5,171.9,0.765,0.765,4.1,0,0,259.5,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(169).to({startPosition:169},0).wait(1));

	// Man
	this.instance_2 = new lib.man();
	this.instance_2.parent = this;
	this.instance_2.setTransform(99,-4,0.815,0.815);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(170));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(99,-4,180.1,260.8);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34,-5.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3,-5.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.6), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.3,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.5,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(13.7,1.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.4,7.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.7,7.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.4,-4.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.7,-4.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.msft_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 3
	this.instance = new lib.MSFT_Logocopy();
	this.instance.parent = this;
	this.instance.setTransform(34.6,60.8,2.289,2.289,0,0,0,0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.msft_logo, new cjs.Rectangle(-82.2,39.1,231,49.3), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_66 = function() {
		exportRoot.tl1.play()
	}
	this.frame_86 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(66).call(this.frame_66).wait(20).call(this.frame_86).wait(1));

	// Layer_2
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.parent = this;
	this.instance_1.setTransform(302.7,339.4,0.328,0.328,0,0,0,-39.9,1.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.42,scaleY:5.42,x:302.8,y:339.2},13,cjs.Ease.quadOut).to({x:87.8},12,cjs.Ease.quadInOut).to({_off:true},1).wait(60));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AlmfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_15 = new cjs.Graphics().p("AnAfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_16 = new cjs.Graphics().p("AoafHIAAyRMBE0AAAIAASRg");
	var mask_graphics_17 = new cjs.Graphics().p("Ap0fHIAAyRMBE0AAAIAASRg");
	var mask_graphics_18 = new cjs.Graphics().p("ArPfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_19 = new cjs.Graphics().p("AspfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_20 = new cjs.Graphics().p("AuDfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_21 = new cjs.Graphics().p("AvdfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_22 = new cjs.Graphics().p("Aw4fHIAAyRMBE0AAAIAASRg");
	var mask_graphics_23 = new cjs.Graphics().p("AySfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_24 = new cjs.Graphics().p("AzsfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_25 = new cjs.Graphics().p("A1GfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_26 = new cjs.Graphics().p("A2gfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_62 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_63 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_64 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_65 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_66 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_67 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_68 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_69 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_70 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_71 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_72 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_73 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_74 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_75 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_76 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_77 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_78 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_79 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_80 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_81 = new cjs.Graphics().p("EhM1CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_graphics_82 = new cjs.Graphics().p("EhTjCXxMAAAkvhMCXsAAAMAAAEvhg");
	var mask_graphics_83 = new cjs.Graphics().p("EhaoCXxMAAAkvhMCXtAAAMAAAEvhg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:404.6,y:199.1}).wait(1).to({graphics:mask_graphics_15,x:395.6,y:199.1}).wait(1).to({graphics:mask_graphics_16,x:386.6,y:199.1}).wait(1).to({graphics:mask_graphics_17,x:377.6,y:199.1}).wait(1).to({graphics:mask_graphics_18,x:368.5,y:199.1}).wait(1).to({graphics:mask_graphics_19,x:359.5,y:199.1}).wait(1).to({graphics:mask_graphics_20,x:350.5,y:199.1}).wait(1).to({graphics:mask_graphics_21,x:341.5,y:199.1}).wait(1).to({graphics:mask_graphics_22,x:332.4,y:199.1}).wait(1).to({graphics:mask_graphics_23,x:323.4,y:199.1}).wait(1).to({graphics:mask_graphics_24,x:314.4,y:199.1}).wait(1).to({graphics:mask_graphics_25,x:305.4,y:199.1}).wait(1).to({graphics:mask_graphics_26,x:296.4,y:199.1}).wait(1).to({graphics:null,x:0,y:0}).wait(35).to({graphics:mask_graphics_62,x:298,y:339.4}).wait(1).to({graphics:mask_graphics_63,x:295.8,y:339.4}).wait(1).to({graphics:mask_graphics_64,x:289.2,y:339.4}).wait(1).to({graphics:mask_graphics_65,x:278.2,y:339.4}).wait(1).to({graphics:mask_graphics_66,x:262.8,y:339.4}).wait(1).to({graphics:mask_graphics_67,x:242.9,y:339.4}).wait(1).to({graphics:mask_graphics_68,x:218.6,y:339.4}).wait(1).to({graphics:mask_graphics_69,x:190,y:339.4}).wait(1).to({graphics:mask_graphics_70,x:156.9,y:339.4}).wait(1).to({graphics:mask_graphics_71,x:119.4,y:339.4}).wait(1).to({graphics:mask_graphics_72,x:77.5,y:339.4}).wait(1).to({graphics:mask_graphics_73,x:31.2,y:339.4}).wait(1).to({graphics:mask_graphics_74,x:-19.6,y:339.4}).wait(1).to({graphics:mask_graphics_75,x:-74.7,y:339.4}).wait(1).to({graphics:mask_graphics_76,x:-134.2,y:339.4}).wait(1).to({graphics:mask_graphics_77,x:-198.2,y:339.4}).wait(1).to({graphics:mask_graphics_78,x:-266.6,y:339.4}).wait(1).to({graphics:mask_graphics_79,x:-339.4,y:339.4}).wait(1).to({graphics:mask_graphics_80,x:-416.6,y:339.4}).wait(1).to({graphics:mask_graphics_81,x:-491.8,y:339.4}).wait(1).to({graphics:mask_graphics_82,x:-534.8,y:339.4}).wait(1).to({graphics:mask_graphics_83,x:-580,y:339.4}).wait(4));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logocopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(88.6,332.7,5.417,5.417,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(305,332.7,5.417,5.417,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},14).to({state:[{t:this.instance_3}]},12).to({state:[]},58).wait(3));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({_off:true,x:305},12,cjs.Ease.quadInOut).wait(61));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(298,339.3,1,1,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(62).to({x:-674.7},21,cjs.Ease.quadIn).to({_off:true},1).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(298,339.3,1,1,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.602;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(63).to({x:-674.7},21,cjs.Ease.quadIn).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.4,-631.9,971,1942.5);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.8,10.8);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.8,10.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.3,6.6,11.3,8.4);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(28.7,1.5,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.1,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AqwCZIAAkxIVhAAIAAExg");
	this.shape.setTransform(6.5,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-62.4,-15.1,137.8,30.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(284.1,-170.2,0.348,0.348,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSFT Logo intro
	this.logo = new lib.logo_1();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.9,19.2,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// MSFT Logo
	this.msft_logo = new lib.msft_logo();
	this.msft_logo.name = "msft_logo";
	this.msft_logo.parent = this;
	this.msft_logo.setTransform(56.9,-155.8,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.msft_logo).wait(1));

	// CTA text
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(222.7,381.5,0.496,0.496,0,0,0,2,2.4);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// circle Bonus
	this.bg_circle = new lib.circle_bg();
	this.bg_circle.name = "bg_circle";
	this.bg_circle.parent = this;
	this.bg_circle.setTransform(29.6,371.9);

	this.timeline.addTween(cjs.Tween.get(this.bg_circle).wait(1));

	// CTA
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(237.9,380,0.943,0.943,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// white
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgZiAvUIAAx6MAzFAAAIAAR6gA5iyFIAA9OMAzFAAAIAAdOg");
	this.shape.setTransform(152.5,128.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// image tractor
	this.image_1 = new lib.tractor_1();
	this.image_1.name = "image_1";
	this.image_1.parent = this;
	this.image_1.setTransform(148,168.1,1.2,1.2,0,0,0,130.4,130.7);

	this.timeline.addTween(cjs.Tween.get(this.image_1).wait(1));

	// image man
	this.image_2 = new lib.man_1();
	this.image_2.name = "image_2";
	this.image_2.parent = this;
	this.image_2.setTransform(148,168,1.25,1.25,0,0,0,133.9,124.3);

	this.timeline.addTween(cjs.Tween.get(this.image_2).wait(1));

	// image bg
	this.image_3 = new lib.bg();
	this.image_3.name = "image_3";
	this.image_3.parent = this;
	this.image_3.setTransform(148.1,168,1.1,1.1,0,0,0,146.2,130.9);

	this.timeline.addTween(cjs.Tween.get(this.image_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-151.3,-178,500,609.1), null);


// stage content:
(lib.O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "cost" && data[keys[i]].length > 1) {
							exportRoot.fillPriceMc(data[keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillPriceMc = function (txtDetails) {
		
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
		
				this.mainMC.bg_circle.addChild(mc);
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
		
			
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		
		exportRoot.tlFH = new TimelineLite();
		exportRoot.tlSH = new TimelineLite();
		
		
		exportRoot.tl1 = new TimelineLite();
		var mc = exportRoot.mainMC
		
		this.runBanner = function() {
			
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				exportRoot.tlFH.from(exportRoot.headline1[i], 0.6, {	x: "+=300",	alpha: 0, ease:Power4.easeOut}, "-=0.4");
			}
			exportRoot.tlFH.stop()
		
			
			TweenLite.delayedCall(3, function(){exportRoot.tlFH.play()})
			
		    
			exportRoot.tl1.to(mc.msft_logo, 1, { x: "-=300",ease:Power1.easeOut}, "+=1")
		
			exportRoot.tl1.to(mc.image_1, 1.3, { scaleX:1, scaleY:1, x: "+=20", y: "+=0", ease:Power1.easeInOut}, "-=1.3")
			exportRoot.tl1.to(mc.image_2, 1.3, { scaleX:1.11, scaleY:1.11, x: "-=10", y: "+=0", ease:Power1.easeInOut}, "-=1.3")
			exportRoot.tl1.to(mc.image_3, 1.3, { scaleX:1, scaleY:1, x: "-=0", y: "+=0", ease:Power1.easeInOut}, "-=1.3")
		
		
			exportRoot.tl1.to(mc.bg_circle, 0.7, { alpha: 1,	x: "-=300",	 ease:Power4.easeOut}, "+=0.2")
			exportRoot.tl1.to(mc.txtCta, 0.7, { alpha: 1,	x: "-=300",	 ease:Power4.easeOut}, "-=0.5");
			exportRoot.tl1.to(mc.cta, 0.7, {	alpha: 1,	x: "-=300",	 ease:Power4.easeOut}, "-=0.7");
			
			
			this.tl1.stop()
		
			mc.logo.gotoAndPlay(1)
		
		}
		mc.msft_logo.x +=300
		mc.image_1.y -=0 
		mc.image_2.y -=0 
		mc.image_3.y -=0
		mc.bg_circle.x += 300; mc.bg_circle.alpha = 0
		mc.txtCta.x += 300; mc.txtCta.alpha = 0
		mc.cta.x += 300; mc.cta.alpha = 0
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,175.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.3,297,500,609.2);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_.png?1535015172263", id:"O365SMB_BKNGSHM_USA_300x600_BAN_Bookings_English_1250_NA_ANI_CH_T1_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;