(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,0,463,280],[0,282,463,133],[376,625,67,18],[0,417,382,154],[500,166,10,9],[0,573,89,160],[500,91,7,12],[498,134,12,14],[465,201,15,10],[208,610,49,38],[465,134,31,30],[91,573,115,117],[309,573,65,52],[384,417,104,206],[465,0,43,89],[465,166,33,18],[445,625,57,11],[498,150,10,14],[490,186,19,19],[465,186,22,13],[465,91,33,41],[208,573,99,35]]}
];


// symbols:



(lib.BG3 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BG4 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BG_1 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BG_2 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.blink = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0000_Upperarm_L = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0000s_0000_Mid_3 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0000s_0001_Mid_2 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0000s_0002_Mid_1 = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0001_Forearm_L = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0002_Hand_L = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0003_Head = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0004_Neckcopy = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0005_Body = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0006_Upperarm_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0007_Thumb_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0008_Pen_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0009_ForeFinger_3_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0010_ForeFinger_2_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0011_ForeFinger_1_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0012_Palm_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Surface__0013_Forearm_R = function() {
	this.initialize(ss["O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.4824,406.9504,1,2.3867);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,-564.3,971,1942.5), null);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.blink();
	this.instance.parent = this;
	this.instance.setTransform(-29,17);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({_off:true},6).wait(80));

	// Layer_1
	this.instance_1 = new lib.Surface__0003_Head();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-57.5,-58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.5,-58.5,115,117);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0012_Palm_R();
	this.instance.parent = this;
	this.instance.setTransform(-16.5,-20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.5,-20.5,33,41);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0006_Upperarm_R();
	this.instance.parent = this;
	this.instance.setTransform(-21.5,-44.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.5,-44.5,43,89);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0013_Forearm_R();
	this.instance.parent = this;
	this.instance.setTransform(-49.5,-17.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.5,-17.5,99,35);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0005_Body();
	this.instance.parent = this;
	this.instance.setTransform(-52,-103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52,-103,104,206);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0004_Neckcopy();
	this.instance.parent = this;
	this.instance.setTransform(-32.5,-26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-26,65,52);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0001_Forearm_L();
	this.instance.parent = this;
	this.instance.setTransform(-24.5,-19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.5,-19,49,38);


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0000_Upperarm_L();
	this.instance.parent = this;
	this.instance.setTransform(-44.5,-80);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.5,-80,89,160);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Thumb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0007_Thumb_R();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Thumb, new cjs.Rectangle(0,0,33,18), null);


(lib.Pen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0008_Pen_R();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Pen, new cjs.Rectangle(0,0,57,11), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Mid_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0000s_0000_Mid_3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mid_3, new cjs.Rectangle(0,0,7,12), null);


(lib.Mid_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0000s_0001_Mid_2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mid_2, new cjs.Rectangle(0,0,12,14), null);


(lib.Mid_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0000s_0002_Mid_1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mid_1, new cjs.Rectangle(0,0,15,10), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Hand_L = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0002_Hand_L();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Hand_L, new cjs.Rectangle(0,0,31,30), null);


(lib.Fore_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0009_ForeFinger_3_R();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Fore_3, new cjs.Rectangle(0,0,10,14), null);


(lib.Fore_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0010_ForeFinger_2_R();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Fore_2, new cjs.Rectangle(0,0,19,19), null);


(lib.Fore_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Surface__0011_ForeFinger_1_R();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Fore_1, new cjs.Rectangle(0,0,22,13), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.circle_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.BG_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.BG4();
	this.instance.parent = this;
	this.instance.setTransform(-50,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_4
	this.instance_1 = new lib.BG4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-50,4);

	this.instance_2 = new lib.BG4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-50,91);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// Layer_2
	this.instance_3 = new lib.BG4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-50,187);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.BG_4, new cjs.Rectangle(-50,4,463,316), null);


(lib.BG_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3 copy
	this.instance = new lib.BG3();
	this.instance.parent = this;
	this.instance.setTransform(-50,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.BG3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-50,564,1,1,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.BG_3, new cjs.Rectangle(-50,4,463,560), null);


(lib.BG_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.BG_2();
	this.instance.parent = this;
	this.instance.setTransform(-50,158);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.BG_2_1, new cjs.Rectangle(-50,158,382,154), null);


(lib.BG_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.BG_1();
	this.instance.parent = this;
	this.instance.setTransform(314,293);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.BG_1_1, new cjs.Rectangle(314,293,67,18), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.head = new lib.Tween20();
	this.head.name = "head";
	this.head.parent = this;
	this.head.setTransform(41.6,25.3,1,1,0,0,0,41.6,25.3);

	this.timeline.addTween(cjs.Tween.get(this.head).wait(43).to({regX:41.8,rotation:1.9509,x:41.85},20,cjs.Ease.quadInOut).wait(11).to({regX:41.7,rotation:-4.0005,x:41.7},24,cjs.Ease.quadInOut).wait(7).to({regX:41.6,rotation:0,x:41.6},29,cjs.Ease.quadInOut).wait(18).to({regY:25.4,rotation:-1.9999,y:25.35},19,cjs.Ease.quadInOut).wait(4).to({regY:25.3,rotation:0,y:25.3},18,cjs.Ease.quadInOut).wait(38).to({regX:41.8,rotation:1.9509,x:41.85},27,cjs.Ease.quadInOut).wait(21).to({regX:41.6,rotation:0,x:41.6},18,cjs.Ease.quadInOut).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.1,-61.8,123.5,127.2);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Palm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{DownIn:1,DownOut:7,OffIn:15,OffOut:29});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_14 = function() {
		this.stop();
	}
	this.frame_28 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(6).call(this.frame_6).wait(8).call(this.frame_14).wait(14).call(this.frame_28).wait(9));

	// Thumb
	this.instance = new lib.Thumb();
	this.instance.parent = this;
	this.instance.setTransform(11.25,23.8,1,1,0,0,0,26.4,10.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:16.5,regY:9,scaleY:1.0001,rotation:-0.1847,x:1.4,y:22},0).wait(1).to({scaleX:0.9998,scaleY:1.0002,rotation:0,skewX:-0.6886,skewY:-0.5278,x:1.3,y:22.15},0).wait(1).to({scaleX:0.9996,scaleY:1.0004,skewX:-1.5716,skewY:-1.2046,x:1.25,y:22.3},0).wait(1).to({scaleX:0.9992,scaleY:1.0007,skewX:-2.8002,skewY:-2.1464,x:1.15,y:22.6},0).wait(1).to({scaleX:0.9987,scaleY:1.001,skewX:-4.146,skewY:-3.178,x:1.05,y:22.9},0).wait(1).to({regX:26.4,regY:10.9,scaleX:0.9984,scaleY:1.0013,skewX:-5.2986,skewY:-4.0614,x:11,y:24.3},0).to({regY:10.8,scaleX:1,scaleY:1,skewX:0,skewY:0,x:11.25,y:23.8},8,cjs.Ease.quadInOut).to({regY:11.1,scaleX:0.9946,scaleY:1.0085,skewX:8.8773,skewY:4.3393,x:13.95,y:21.55},14,cjs.Ease.sineInOut).to({regY:10.8,scaleX:1,scaleY:1,skewX:0,skewY:0,x:11.25,y:23.8},8,cjs.Ease.quadIn).wait(1));

	// Pen
	this.instance_1 = new lib.Pen();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-12.05,16.6,1,1,0,0,0,16.1,8.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:28.5,regY:5.5,scaleX:0.9999,scaleY:1.0001,rotation:-0.0713,x:0.3,y:13.55},0).wait(1).to({scaleX:0.9997,scaleY:1.0003,rotation:0,skewX:-0.2657,skewY:-0.1301,x:0.15,y:13.65},0).wait(1).to({scaleX:0.9993,scaleY:1.0007,skewX:-0.6065,skewY:-0.2969,x:-0.25,y:13.8},0).wait(1).to({scaleX:0.9988,scaleY:1.0013,skewX:-1.0806,skewY:-0.5289,x:-0.8,y:14.1},0).wait(1).to({scaleX:0.9982,scaleY:1.0019,skewX:-1.6,skewY:-0.7831,x:-1.35,y:14.35},0).wait(1).to({regX:16.1,regY:8.6,scaleX:0.9976,scaleY:1.0024,skewX:-2.0448,skewY:-1.0008,x:-14.1,y:17.95},0).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:-12.05,y:16.6},8,cjs.Ease.quadInOut).to({regX:15.9,regY:8.7,scaleX:0.9946,scaleY:1.0084,skewX:0.1032,skewY:-4.4337,x:-8.4,y:10.8},14,cjs.Ease.sineInOut).to({regX:16.1,regY:8.6,scaleX:1,scaleY:1,skewX:0,skewY:0,x:-12.05,y:16.6},8,cjs.Ease.quadIn).wait(1));

	// Fore_3
	this.instance_2 = new lib.Fore_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-12.15,5.7,1,1,0,0,0,6,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regX:5,regY:7,scaleX:1.0002,scaleY:0.9999,rotation:0.2458,x:-13.2,y:8.1},0).wait(1).to({scaleX:1.0005,scaleY:0.9994,rotation:0,skewX:0.9164,skewY:1.0741,x:-13.35,y:8.35},0).wait(1).to({scaleX:1.0012,scaleY:0.9987,skewX:2.0915,skewY:2.4516,x:-13.7,y:8.75},0).wait(1).to({scaleX:1.0021,scaleY:0.9976,skewX:3.7265,skewY:4.368,x:-14.1,y:9.35},0).wait(1).to({scaleX:1.0031,scaleY:0.9964,skewX:5.5176,skewY:6.4674,x:-14.55,y:10.05},0).wait(1).to({regX:6,regY:4.8,scaleX:1.0039,scaleY:0.9954,skewX:7.0515,skewY:8.2653,x:-13.8,y:8.55},0).to({regY:4.7,scaleX:1,scaleY:1,skewX:0,skewY:0,x:-12.15,y:5.7},8,cjs.Ease.quadInOut).to({rotation:1.4497,x:-4.75,y:0.45},14,cjs.Ease.sineInOut).to({rotation:0,x:-12.15,y:5.7},8,cjs.Ease.quadIn).wait(1));

	// Fore_2
	this.instance_3 = new lib.Fore_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-5.15,-0.3,1,1,0,0,0,13,3.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({regX:9.5,regY:9.5,rotation:-0.0185,x:-8.7,y:5.6},0).wait(1).to({scaleX:1.0001,scaleY:0.9999,rotation:0,skewX:-0.0688,skewY:0.0678,x:-8.85,y:5.85},0).wait(1).to({scaleX:1.0003,scaleY:0.9998,skewX:-0.157,skewY:0.1547,x:-9.05,y:6.35},0).wait(1).to({scaleX:1.0005,scaleY:0.9997,skewX:-0.2797,skewY:0.2756,x:-9.45,y:6.9},0).wait(1).to({scaleX:1.0007,scaleY:0.9995,skewX:-0.4142,skewY:0.4081,x:-9.85,y:7.55},0).wait(1).to({regX:13,regY:3.7,scaleX:1.0009,scaleY:0.9993,skewX:-0.5293,skewY:0.5215,x:-6.75,y:2.35},0).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:-5.15,y:-0.3},8,cjs.Ease.quadInOut).to({regX:12.9,regY:3.6,scaleX:0.9946,scaleY:1.0085,skewX:16.865,skewY:12.3271,x:3.75,y:-4.45},14,cjs.Ease.sineInOut).to({regX:13,regY:3.7,scaleX:1,scaleY:1,skewX:0,skewY:0,x:-5.15,y:-0.3},8,cjs.Ease.quadIn).wait(1));

	// Fore_1
	this.instance_4 = new lib.Fore_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(6.25,4,1,1,0,0,0,16.4,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({regX:11,regY:6.5,scaleX:0.9999,scaleY:1.0002,rotation:-0.4021,x:0.85,y:2.6},0).wait(1).to({scaleX:0.9994,scaleY:1.0005,rotation:0,skewX:-1.4988,skewY:-1.3408,x:0.65,y:2.75},0).wait(1).to({scaleX:0.9986,scaleY:1.0011,skewX:-3.4207,skewY:-3.0601,x:0.45,y:3.05},0).wait(1).to({scaleX:0.9975,scaleY:1.002,skewX:-6.0948,skewY:-5.4524,x:0.1,y:3.5},0).wait(1).to({scaleX:0.9963,scaleY:1.003,skewX:-9.0242,skewY:-8.0729,x:-0.3,y:3.9},0).wait(1).to({regX:16.3,regY:8,scaleX:0.9952,scaleY:1.0038,skewX:-11.5328,skewY:-10.3172,x:4.95,y:4.8},0).to({regX:16.4,scaleX:1,scaleY:1,skewX:0,skewY:0,x:6.25,y:4},8,cjs.Ease.quadInOut).to({regX:16.3,regY:7.9,scaleX:0.9946,scaleY:1.0085,skewX:10.1184,skewY:5.5798,x:14.1,y:1.2},14,cjs.Ease.sineInOut).to({regX:16.4,regY:8,scaleX:1,scaleY:1,skewX:0,skewY:0,x:6.25,y:4},8,cjs.Ease.quadIn).wait(1));

	// Mid_1
	this.instance_5 = new lib.Mid_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-3,5.5,1,1,0,0,0,7.5,5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({scaleY:1.0001,rotation:-0.1403},0).wait(1).to({scaleX:0.9999,rotation:0,skewX:-0.5231,skewY:-0.3621,x:-3.1,y:5.6},0).wait(1).to({scaleX:0.9997,scaleY:1.0003,skewX:-1.194,skewY:-0.8265,x:-3.25,y:5.8},0).wait(1).to({scaleX:0.9995,scaleY:1.0004,skewX:-2.1273,skewY:-1.4726,x:-3.4,y:6},0).wait(1).to({scaleX:0.9993,scaleY:1.0006,skewX:-3.1497,skewY:-2.1803,x:-3.65,y:6.25},0).wait(1).to({scaleX:0.9991,scaleY:1.0008,skewX:-4.0254,skewY:-2.7865,x:-3.8,y:6.55},0).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:-3,y:5.5},8,cjs.Ease.quadInOut).to({scaleX:0.9946,scaleY:1.0085,skewX:34.2922,skewY:29.7539,x:5.4,y:0.4},14,cjs.Ease.sineInOut).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:-3,y:5.5},8,cjs.Ease.quadIn).wait(1));

	// Mid_2
	this.instance_6 = new lib.Mid_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-9.5,8.5,1,1,0,0,0,6,7);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({scaleX:1.0002,scaleY:0.9999,rotation:0.1929},0).wait(1).to({scaleX:1.0004,scaleY:0.9995,rotation:0,skewX:0.7192,skewY:0.878,x:-9.6,y:8.6},0).wait(1).to({scaleX:1.001,scaleY:0.9989,skewX:1.6415,skewY:2.004,x:-9.75,y:8.7},0).wait(1).to({scaleX:1.0018,scaleY:0.998,skewX:2.9248,skewY:3.5706,x:-9.95,y:8.85},0).wait(1).to({scaleX:1.0026,scaleY:0.997,skewX:4.3305,skewY:5.2868,x:-10.25,y:9.05},0).wait(1).to({scaleX:1.0034,scaleY:0.9961,skewX:5.5344,skewY:6.7565,x:-10.4,y:9.2},0).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:-9.5,y:8.5},8,cjs.Ease.quadInOut).to({regX:5.9,scaleX:0.9946,scaleY:1.0084,skewX:42.7742,skewY:38.2362,x:-1.8,y:-0.9},14,cjs.Ease.sineInOut).to({regX:6,scaleX:1,scaleY:1,skewX:0,skewY:0,x:-9.5,y:8.5},8,cjs.Ease.quadIn).wait(1));

	// Mid_3
	this.instance_7 = new lib.Mid_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-12,15,1,1,0,0,0,3.5,3.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({regY:6,scaleX:1.0003,scaleY:0.9998,rotation:0.115,y:17.45},0).wait(1).to({scaleX:1.001,scaleY:0.999,rotation:0,skewX:0.4287,skewY:0.5536,x:-12.15,y:17.5},0).wait(1).to({scaleX:1.0022,scaleY:0.9977,skewX:0.9784,skewY:1.2636,x:-12.4},0).wait(1).to({scaleX:1.0039,scaleY:0.9959,skewX:1.7433,skewY:2.2513,x:-12.75,y:17.4},0).wait(1).to({scaleX:1.0058,scaleY:0.994,skewX:2.5812,skewY:3.3334,x:-13.1},0).wait(1).to({regY:3.5,scaleX:1.0074,scaleY:0.9923,skewX:3.2987,skewY:4.2601,x:-13.3,y:14.9},0).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:-12,y:15},8,cjs.Ease.quadInOut).to({regX:3.3,regY:3.6,scaleX:0.9946,scaleY:1.0084,skewX:11.2985,skewY:6.7603,x:-7.9,y:2.9},14,cjs.Ease.sineInOut).to({regX:3.5,regY:3.5,scaleX:1,scaleY:1,skewX:0,skewY:0,x:-12,y:15},8,cjs.Ease.quadIn).wait(1));

	// Surface__0012_Palm_R.png
	this.instance_8 = new lib.Tween19("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(16.5,20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({rotation:-0.0876,x:16.4844,y:20.5104},0).wait(1).to({rotation:0,skewX:-0.3267,skewY:-0.1655,x:16.4418,y:20.5388},0).wait(1).to({scaleY:1.0001,skewX:-0.7457,skewY:-0.3776,x:16.3672,y:20.5886},0).wait(1).to({skewX:-1.3286,skewY:-0.6728,x:16.2633,y:20.6579},0).wait(1).to({scaleX:0.9999,skewX:-1.9671,skewY:-0.9962,x:16.1496,y:20.7338},0).wait(1).to({skewX:-2.514,skewY:-1.2732,x:16,y:20.75},0).to({scaleX:1,scaleY:1,skewX:0,skewY:0,x:16.5,y:20.5},8,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,scaleX:1.0012,skewX:14.9644,skewY:12.1791,x:19.8,y:19.1},14,cjs.Ease.sineInOut).to({regX:0,regY:0,scaleX:1,skewX:0,skewY:0,x:16.5,y:20.5},8,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.4,-10.7,71.6,53.099999999999994);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_77 = function() {
		exportRoot.tl1.play()
	}
	this.frame_84 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(77).call(this.frame_77).wait(7).call(this.frame_84).wait(1));

	// Layer_2
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.parent = this;
	this.instance_1.setTransform(302.7,339.4,0.3276,0.3276,0,0,0,-39.9,1.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.4173,scaleY:5.4173,x:302.75,y:339.2},13,cjs.Ease.quadOut).to({x:87.75},12,cjs.Ease.quadInOut).to({_off:true},1).wait(58));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AlmfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_15 = new cjs.Graphics().p("Al1fHIAAyRMBE0AAAIAASRg");
	var mask_graphics_16 = new cjs.Graphics().p("AmifHIAAyRMBE0AAAIAASRg");
	var mask_graphics_17 = new cjs.Graphics().p("AntfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_18 = new cjs.Graphics().p("ApWfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_19 = new cjs.Graphics().p("ArefHIAAyRMBE0AAAIAASRg");
	var mask_graphics_20 = new cjs.Graphics().p("AuDfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_21 = new cjs.Graphics().p("AwofHIAAyRMBE0AAAIAASRg");
	var mask_graphics_22 = new cjs.Graphics().p("AywfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_23 = new cjs.Graphics().p("A0ZfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_24 = new cjs.Graphics().p("A1kfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_25 = new cjs.Graphics().p("A2RfHIAAyRMBE0AAAIAASRg");
	var mask_graphics_26 = new cjs.Graphics().p("A2gfHIAAyRMBE0AAAIAASRg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:404.6146,y:199.0879}).wait(1).to({graphics:mask_graphics_15,x:403.1112,y:199.0879}).wait(1).to({graphics:mask_graphics_16,x:398.6008,y:199.0879}).wait(1).to({graphics:mask_graphics_17,x:391.0834,y:199.0879}).wait(1).to({graphics:mask_graphics_18,x:380.5591,y:199.0879}).wait(1).to({graphics:mask_graphics_19,x:367.0278,y:199.0879}).wait(1).to({graphics:mask_graphics_20,x:350.4896,y:199.0879}).wait(1).to({graphics:mask_graphics_21,x:333.9514,y:199.0879}).wait(1).to({graphics:mask_graphics_22,x:320.4202,y:199.0879}).wait(1).to({graphics:mask_graphics_23,x:309.8959,y:199.0879}).wait(1).to({graphics:mask_graphics_24,x:302.3785,y:199.0879}).wait(1).to({graphics:mask_graphics_25,x:297.8681,y:199.0879}).wait(1).to({graphics:mask_graphics_26,x:296.3646,y:199.0879}).wait(1).to({graphics:null,x:0,y:0}).wait(58));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logocopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(88.55,332.7,5.4173,5.4173,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(305,332.7,5.4173,5.4173,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({_off:true,x:305},12,cjs.Ease.quadInOut).wait(59));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},12,cjs.Ease.quadInOut).wait(32).to({scaleX:2.3001,scaleY:2.3001,x:34.8,y:-503.85},22,cjs.Ease.quadInOut).wait(5));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,339.3,1,1,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(62).to({x:-674.7},21,cjs.Ease.quadIn).wait(2));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(297.95,339.3,1,1,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(63).to({x:-674.7},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160.1,-631.9,1943.6,1942.5);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownIn");
	}
	this.frame_9 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownOut");
	}
	this.frame_19 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownIn");
	}
	this.frame_29 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownOut");
	}
	this.frame_41 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("OffIn");
	}
	this.frame_52 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("OffOut");
	}
	this.frame_63 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownIn");
	}
	this.frame_103 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownOut");
	}
	this.frame_120 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("OffIn");
	}
	this.frame_130 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("OffOut");
	}
	this.frame_140 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownIn");
	}
	this.frame_148 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownOut");
	}
	this.frame_164 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownIn");
	}
	this.frame_174 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownOut");
	}
	this.frame_202 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownIn");
	}
	this.frame_212 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("DownOut");
	}
	this.frame_233 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("OffIn");
	}
	this.frame_291 = function() {
		exportRoot.mainMC.image_1.arm.hand.gotoAndPlay("OffOut");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(10).call(this.frame_19).wait(10).call(this.frame_29).wait(12).call(this.frame_41).wait(11).call(this.frame_52).wait(11).call(this.frame_63).wait(40).call(this.frame_103).wait(17).call(this.frame_120).wait(10).call(this.frame_130).wait(10).call(this.frame_140).wait(8).call(this.frame_148).wait(16).call(this.frame_164).wait(10).call(this.frame_174).wait(28).call(this.frame_202).wait(10).call(this.frame_212).wait(21).call(this.frame_233).wait(58).call(this.frame_291).wait(9));

	// Hand
	this.hand = new lib.Palm();
	this.hand.name = "hand";
	this.hand.parent = this;
	this.hand.setTransform(-102.6,30.45,1,1,0,0,0,23.1,32.5);

	this.timeline.addTween(cjs.Tween.get(this.hand).wait(49).to({rotation:-3.9539,x:-104.35,y:23.85},12,cjs.Ease.quadInOut).wait(9).to({regX:23,regY:32.6,rotation:-13.549,x:-77.7,y:41.05},31,cjs.Ease.quadInOut).wait(19).to({regX:23.1,regY:32.5,rotation:0,x:-102.6,y:30.45},25,cjs.Ease.quadInOut).to({x:-84.9,y:36.95},21,cjs.Ease.quadInOut).wait(11).to({x:-110.95,y:28.4},27,cjs.Ease.quadInOut).wait(25).to({regX:22.9,regY:32.4,rotation:-13.6516,x:-98.5,y:23.75},14,cjs.Ease.quadIn).to({regX:23.1,regY:32.5,rotation:-18.9876,x:-82.15,y:12.65},15,cjs.Ease.quadOut).wait(22).to({rotation:0,x:-102.6,y:30.45},19,cjs.Ease.quadInOut).wait(1));

	// Tween 15
	this.instance = new lib.Tween15("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-15.3,36.85,1,1,0,0,0,44.9,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:0},49,cjs.Ease.quadInOut).to({regY:0.5,rotation:4.2116,x:-19.8,y:36.25},12,cjs.Ease.quadInOut).to({startPosition:0},9,cjs.Ease.quadInOut).to({regY:0.6,scaleX:0.8458,rotation:-4.266,x:-5.05,y:41},31,cjs.Ease.quadInOut).to({rotation:-4.266},19,cjs.Ease.quadInOut).to({regY:0.4,scaleX:1,rotation:0,x:-15.3,y:36.85},25,cjs.Ease.quadInOut).to({regY:0.6,scaleX:0.9303,skewX:-4.4878,skewY:-3.3034,x:-3.65,y:38.7},21,cjs.Ease.quadInOut).to({startPosition:0},11,cjs.Ease.quadInOut).to({regY:0.4,scaleX:1,skewX:0,skewY:0,x:-23.65,y:34.8},27,cjs.Ease.quadInOut).to({startPosition:0},25,cjs.Ease.quadInOut).to({regY:0.5,rotation:6.1967,x:-14.4,y:37.9},14,cjs.Ease.quadIn).to({regX:44.6,regY:0.6,scaleX:0.952,rotation:0,skewX:11.7602,skewY:18.5479,x:-6.35,y:42.4},15,cjs.Ease.quadOut).to({startPosition:0},22,cjs.Ease.quadInOut).to({regX:44.9,regY:0.4,scaleX:1,skewX:0,skewY:0,x:-15.3,y:36.85},19,cjs.Ease.quadInOut).wait(1));

	// Surface__0006_Upperarm_R.png
	this.instance_1 = new lib.Tween18("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(15.3,-41.6,1,1,0,0,0,15.3,-41.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},49,cjs.Ease.quadInOut).to({regX:15.2,rotation:3.9663,x:15.25,y:-41.65},12,cjs.Ease.quadInOut).to({startPosition:0},9,cjs.Ease.quadInOut).to({regX:15.3,rotation:-3.9671,x:18.2,y:-41.7},31,cjs.Ease.quadInOut).to({startPosition:0},19,cjs.Ease.quadInOut).to({rotation:0,x:15.3,y:-41.6},25,cjs.Ease.quadInOut).to({regX:15.4,scaleY:1.0041,skewX:-7.1853,skewY:-1.9762,x:15.4,y:-41.65},21,cjs.Ease.quadInOut).to({startPosition:0},11,cjs.Ease.quadInOut).to({regX:15.2,scaleY:1,rotation:5.9575,skewX:0,skewY:0,x:11.15},27,cjs.Ease.quadInOut).to({startPosition:0},25,cjs.Ease.quadInOut).to({regX:15.3,rotation:-3.7182,x:16.1},29,cjs.Ease.quadInOut).to({rotation:-3.7182},22,cjs.Ease.quadInOut).to({rotation:0,x:15.3,y:-41.6},19,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-162.2,-48.3,194.5,112.1);


(lib.people = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(1));

	// Surface__0000_Upperarm_L.png
	this.instance = new lib.Tween10("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(180.95,143.4,1,1,0,0,0,18.6,-48.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:188.7},59,cjs.Ease.quadInOut).wait(1));

	// Surface__0001_Forearm_L.png
	this.instance_1 = new lib.Tween11("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(135.3,257.25,1,1.0377,0,11.2699,0,3.3,8.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleY:1,skewX:0,x:140.4,y:257.2},59,cjs.Ease.quadInOut).wait(1));

	// Surface__0000_Hand_L
	this.instance_2 = new lib.Hand_L();
	this.instance_2.parent = this;
	this.instance_2.setTransform(125.35,241.9,1,1.0034,0,3.8094,0,15.6,27.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:15.5,scaleY:1,skewX:0,x:125.85,y:241.85},59,cjs.Ease.quadInOut).wait(1));

	// Surface__0003_Head.png
	this.head = new lib.Tween12();
	this.head.name = "head";
	this.head.parent = this;
	this.head.setTransform(140.2,96.1,1,1,1.0422,0,0,42.3,28.5);

	this.timeline.addTween(cjs.Tween.get(this.head).to({regX:42.1,regY:28.4,rotation:0,x:145.6,y:94.9},59,cjs.Ease.quadInOut).wait(1));

	// Surface__0004_Neck-copy.png
	this.instance_3 = new lib.Tween13("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(162.35,108.15,1,1,1.0422,0,0,13.3,8.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:13.2,rotation:0,x:166.7,y:106.7},59,cjs.Ease.quadInOut).wait(1));

	// Surface__0005_Body.png
	this.instance_4 = new lib.Tween14("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(226.95,294.35,1,1,-1.4497,0,0,34.6,102.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({rotation:0,x:226.6,y:294.6},59,cjs.Ease.quadInOut).wait(1));

	// Surface__0006_Upperarm_R.png
	this.arm = new lib.Tween16();
	this.arm.name = "arm";
	this.arm.parent = this;
	this.arm.setTransform(166.25,135.9,1,1,0,0,0,17.7,-46.6);

	this.timeline.addTween(cjs.Tween.get(this.arm).to({x:161.25},59,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-227.7,-13,472,309.9);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(28.45,1.7,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.05,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AqwCeIAAk7IVhAAIAAE7g");
	this.shape.setTransform(10.5,0.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-58.4,-15.6,137.8,31.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(284.1,-170.2,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSFT Logo intro
	this.logo = new lib.logo_1();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.9,19.15,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// CTA text
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(222.65,381.45,0.4964,0.4964,0,0,0,2,2.4);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// circle Bonus
	this.bg_circle = new lib.circle_bg();
	this.bg_circle.name = "bg_circle";
	this.bg_circle.parent = this;
	this.bg_circle.setTransform(29.55,371.9);

	this.timeline.addTween(cjs.Tween.get(this.bg_circle).wait(1));

	// CTA
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(237.85,379.95,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// white
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgZiAyFIAAxCMAzFAAAIAARCgA5it+MAAAgkHMAzFAAAMAAAAkHg");
	this.shape.setTransform(152.5,123.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BG1
	this.image_0 = new lib.BG_1_1();
	this.image_0.name = "image_0";
	this.image_0.parent = this;
	this.image_0.setTransform(373.15,26.75,0.9896,0.9896,0,0,180,-0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.image_0).wait(1));

	// image ppl
	this.image_1 = new lib.people();
	this.image_1.name = "image_1";
	this.image_1.parent = this;
	this.image_1.setTransform(207.55,45.2,0.9796,0.9794,0,0,180,-2.6,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.image_1).wait(1));

	// BG2
	this.image_2 = new lib.BG_2_1();
	this.image_2.name = "image_2";
	this.image_2.parent = this;
	this.image_2.setTransform(368.8,30.3,0.9796,0.9796,0,0,180,-0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.image_2).wait(1));

	// BG3
	this.image_3 = new lib.BG_3();
	this.image_3.name = "image_3";
	this.image_3.parent = this;
	this.image_3.setTransform(356.55,30.3,0.9796,0.9796,0,0,180,-1,0.8);

	this.timeline.addTween(cjs.Tween.get(this.image_3).wait(1));

	// BG4
	this.image_4 = new lib.BG_4();
	this.image_4.name = "image_4";
	this.image_4.parent = this;
	this.image_4.setTransform(332.3,30.3,0.9796,0.9796,0,0,180,-1,0.8);

	this.timeline.addTween(cjs.Tween.get(this.image_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-73.2,-197.4,490.2,779.4), null);


// stage content:
(lib.O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
		
			
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		
		var mc = exportRoot.mainMC
		
		this.runBanner = function() {
			
			exportRoot.tlFH = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tlFH.from(exportRoot.headline1[i], 0.6, { x: "+=300", alpha: 0, ease:Power4.easeOut});
				if (i!=0) exportRoot.tlFH.from(exportRoot.headline1[i], 0.6, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.5");
			}
			exportRoot.tlFH.stop()
			
			exportRoot.tlSH = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tlFH.from(exportRoot.headline2[i], 0.6, { x: "+=300", alpha: 0, ease:Power4.easeOut});
				if (i!=0) exportRoot.tlFH.from(exportRoot.headline2[i], 0.6, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.5");
			
				}
				
			exportRoot.tlSH.stop()
		
			TweenLite.delayedCall(3, function(){exportRoot.tlFH.play()})
			TweenLite.delayedCall(3.5, function(){exportRoot.tlSH.play()})		
				
				exportRoot.tl1 = new TimelineLite();
		
		
			exportRoot.tl1.from(mc.image_0, 1.5, { scaleX:1.4, scaleY:1.4, x: "+=129", y: "-=65", ease:Sine.easeInOut}, "+=0.6")
			exportRoot.tl1.from(mc.image_1, 1.5, { scaleX:1.35, scaleY:1.35, x: "+=75", y: "-=60", ease:Sine.easeInOut, onStart:function(){mc.image_1.gotoAndPlay(1)}}, "-=1.5")
			exportRoot.tl1.from(mc.image_2, 1.5, { scaleX:1.35, scaleY:1.35, x: "+=125", y: "-=60", ease:Sine.easeInOut}, "-=1.5")
			exportRoot.tl1.from(mc.image_3, 1.5, { scaleX:1.15, scaleY:1.15, x: "+=60", y: "-=30", ease:Sine.easeInOut}, "-=1.5")	
			exportRoot.tl1.from(mc.image_4, 1.5, { scaleX:1.05, scaleY:1.05, x: "+=25", y: "-=10", ease:Sine.easeInOut}, "-=1.5")
		
			exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 1,	x: "+=300",	 ease:Sine.easeOut}, "-=0.5");
			exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 1,	x: "+=300",	 ease:Sine.easeOut}, "-=0.7");
			
			exportRoot.tl1.from(mc.logo, .1, { alpha: 1, ease:Sine.easeInOut, onStart:function(){mc.image_1.stop(), mc.image_1.head.stop(), mc.image_1.head.head.stop(), mc.image_1.arm.stop()}}, "+5.2")
		
			
			this.tl1.stop()
		
			mc.logo.gotoAndPlay(1)
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,175.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(76.8,277.6,340.2,479.4);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_.png?1541782171499", id:"O365_CARTABNDMCOMM_USA_300x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;