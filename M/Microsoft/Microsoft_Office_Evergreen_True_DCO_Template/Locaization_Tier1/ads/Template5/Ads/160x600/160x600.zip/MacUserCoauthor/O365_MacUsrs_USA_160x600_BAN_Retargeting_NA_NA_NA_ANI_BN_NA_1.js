(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_", frames: [[513,491,169,85],[366,252,171,85],[173,339,171,85],[519,404,171,85],[193,252,171,85],[692,404,171,85],[0,335,171,85],[346,339,171,85],[684,491,169,85],[171,513,169,85],[855,491,169,85],[171,426,169,85],[342,426,169,85],[0,509,169,85],[0,422,169,85],[684,665,169,85],[684,578,169,85],[513,665,169,85],[171,600,169,85],[342,513,169,85],[0,596,169,85],[342,600,169,85],[855,578,169,85],[513,578,169,85],[302,0,300,250],[0,0,300,250],[604,0,300,202],[604,204,300,198],[0,252,191,81]]}
];


// symbols:



(lib.Bitmap10 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.mac = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Macbook = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.macbookscreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.MacScreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.transform = function() {
	this.initialize(ss["O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.txt_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.txt_6, new cjs.Rectangle(0,0,0,0), null);


(lib.Text_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.parent = this;

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.parent = this;

	this.instance_2 = new lib.Bitmap4();
	this.instance_2.parent = this;

	this.instance_3 = new lib.Bitmap5();
	this.instance_3.parent = this;

	this.instance_4 = new lib.Bitmap6();
	this.instance_4.parent = this;

	this.instance_5 = new lib.Bitmap7();
	this.instance_5.parent = this;

	this.instance_6 = new lib.Bitmap8();
	this.instance_6.parent = this;

	this.instance_7 = new lib.Bitmap9();
	this.instance_7.parent = this;

	this.instance_8 = new lib.Bitmap10();
	this.instance_8.parent = this;

	this.instance_9 = new lib.Bitmap11();
	this.instance_9.parent = this;

	this.instance_10 = new lib.Bitmap12();
	this.instance_10.parent = this;

	this.instance_11 = new lib.Bitmap13();
	this.instance_11.parent = this;

	this.instance_12 = new lib.Bitmap14();
	this.instance_12.parent = this;

	this.instance_13 = new lib.Bitmap15();
	this.instance_13.parent = this;

	this.instance_14 = new lib.Bitmap16();
	this.instance_14.parent = this;

	this.instance_15 = new lib.Bitmap17();
	this.instance_15.parent = this;

	this.instance_16 = new lib.Bitmap18();
	this.instance_16.parent = this;

	this.instance_17 = new lib.Bitmap19();
	this.instance_17.parent = this;

	this.instance_18 = new lib.Bitmap20();
	this.instance_18.parent = this;

	this.instance_19 = new lib.Bitmap21();
	this.instance_19.parent = this;

	this.instance_20 = new lib.Bitmap22();
	this.instance_20.parent = this;

	this.instance_21 = new lib.Bitmap23();
	this.instance_21.parent = this;

	this.instance_22 = new lib.Bitmap24();
	this.instance_22.parent = this;

	this.instance_23 = new lib.Bitmap25();
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Screen_ScreenFill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenFill
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A4GOGIAA8LMAwNAAAIAAcLg");
	this.shape.setTransform(145.325,104.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(573));

}).prototype = p = new cjs.MovieClip();


(lib.Screen_ScreenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenBG
	this.instance = new lib.MacScreen();
	this.instance.parent = this;
	this.instance.setTransform(-75,-54.45,1.5,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(573));

}).prototype = p = new cjs.MovieClip();


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.person = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiDB+IAAgFQAAgXANgQQANgRAbgKQAJgEAbgCQACgHABgLQgPgMgJgTQgIgTAAgXQAAgqALgRQAPgYAtAAQAtAAAQAYQALASAAApQAAAXgJATQgJAUgPAMQABAMADAGQAYACALADQA2APAAAzIAAAFg");
	this.shape.setTransform(0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.person, new cjs.Rectangle(-13.1,-12.6,26.299999999999997,25.2), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.75,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1,2.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.325,2.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.45,2.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.125,2.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.075,2.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.275,-5.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.3,2.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.475,0.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,0,0), null);


(lib.mainMC_BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgNHAvHMAAAhdoQgFACgFgBQgKgBgFgIIgDgGQgBgEACgGQACgGAEgCQAGgFAIAAIgBgBQAGABAFAEQAFADACAEQAFALgHAJIakAAMAAABdug");
	this.shape.setTransform(-58.2062,298.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_BG, null, null);


(lib.Macbook_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Macbook();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Macbook_1, new cjs.Rectangle(0,0,300,250), null);


(lib.Mac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mac();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.96,0.96);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mac, new cjs.Rectangle(0,0,288,240), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.625,5.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.675,5.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.625,-5.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.675,-5.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Intro_Whitebar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Whitebar
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOLEIAA2HIAdAAIAAWHg");
	this.shape.setTransform(249.675,155.375);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOLEIAA2HIAeAAIAAWHg");
	this.shape_1.setTransform(187.45,155.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPLEIAA2HIAfAAIAAWHg");
	this.shape_2.setTransform(177.8,155.375);
	this.shape_2._off = true;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPLEIAA2HIAeAAIAAWHg");
	this.shape_3.setTransform(168.95,155.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},170).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:187.45}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3,p:{x:168.95}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3,p:{x:101}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},70).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:106.4}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:140.2}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_1,p:{x:155.5}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},39).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:194.2}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},25).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(170).to({_off:false},0).wait(1).to({x:235.175},0).wait(1).to({x:221.775},0).wait(1).to({x:209.375},0).wait(1).to({x:197.975},0).to({_off:true},1).wait(3).to({_off:false,x:160.9},0).wait(1).to({x:153.55},0).wait(1).to({x:146.875},0).wait(1).to({x:140.85},0).to({_off:true},1).wait(1).to({_off:false,x:130.5},0).to({_off:true},1).wait(2).to({_off:false,x:118.8},0).wait(1).to({x:115.75},0).wait(1).to({x:113.05},0).wait(1).to({x:110.725},0).wait(1).to({x:108.7},0).to({_off:true},1).wait(2).to({_off:false,x:104.2},0).wait(1).to({x:103.15},0).wait(1).to({x:102.25},0).to({_off:true},1).wait(3).to({_off:false,x:100.15},0).wait(1).to({x:99.9},0).wait(1).to({x:99.7},0).wait(1).to({x:99.55},0).wait(1).to({x:99.45},0).to({_off:true},1).wait(1).to({_off:false,x:99.35},0).to({_off:true},1).wait(75).to({_off:false},0).to({_off:true},1).wait(3).to({_off:false,x:101.25},0).to({_off:true},1).wait(2).to({_off:false,x:104.75},0).to({_off:true},1).wait(2).to({_off:false,x:110.5},0).wait(1).to({x:113.05},0).wait(1).to({x:115.9},0).to({_off:true},1).wait(1).to({_off:false,x:122.65},0).wait(1).to({x:126.55},0).to({_off:true},1).wait(1).to({_off:false,x:135.375},0).to({_off:true},1).wait(1).to({_off:false,x:145.225},0).to({_off:true},1).wait(2).to({_off:false,x:160.55},0).wait(1).to({x:165.425},0).wait(1).to({x:170.075},0).wait(1).to({x:174.425},0).wait(1).to({x:178.475},0).wait(1).to({x:182.175},0).wait(1).to({x:185.525},0).wait(1).to({x:188.525},0).wait(1).to({x:191.25},0).wait(1).to({x:193.675},0).wait(1).to({x:195.775},0).wait(1).to({x:197.675},0).wait(1).to({x:199.275},0).wait(1).to({x:200.675},0).wait(1).to({x:201.875},0).wait(1).to({x:202.825},0).wait(1).to({x:203.625},0).wait(1).to({x:204.275},0).wait(1).to({x:204.725},0).wait(1).to({x:205.075},0).wait(1).to({x:205.275},0).wait(1).to({x:205.325},0).wait(40).to({x:205.275},0).wait(1).to({x:205.025},0).wait(1).to({x:204.625},0).wait(1).to({x:204.025},0).wait(1).to({x:203.225},0).wait(1).to({x:202.125},0).wait(1).to({x:200.775},0).wait(1).to({x:199.025},0).wait(1).to({x:196.85},0).to({_off:true},1).wait(1).to({_off:false,x:191.025},0).to({_off:true},1).wait(1).to({_off:false,x:182.975},0).to({_off:true},1).wait(4).to({_off:false,x:162.1},0).wait(1).to({x:159.4},0).to({_off:true},1).wait(65));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(176).to({_off:false},0).to({_off:true},1).wait(5).to({_off:false,x:135.4},0).to({_off:true},1).wait(1).to({_off:false,x:126.15},0).wait(1).to({x:122.25},0).to({_off:true},1).wait(5).to({_off:false,x:106.95},0).wait(1).to({x:105.45},0).to({_off:true},1).wait(3).to({_off:false,x:101.55},0).to({_off:true},1).wait(1).to({_off:false,x:100.5},0).to({_off:true},1).wait(5).to({_off:false,x:99.4},0).to({_off:true},1).wait(1).to({_off:false,x:99.3},0).wait(74).to({_off:true},1).wait(1).to({_off:false,x:99.6},0).wait(1).to({x:99.95},0).wait(1).to({x:100.5},0).to({_off:true},1).wait(1).to({_off:false,x:102.2},0).wait(1).to({x:103.35},0).to({_off:true},1).wait(2).to({_off:false,x:108.3},0).to({_off:true},1).wait(3).to({_off:false,x:119.1},0).to({_off:true},1).wait(2).to({_off:false,x:130.8},0).to({_off:true},1).wait(3).to({_off:false,x:150.35},0).to({_off:true},1).wait(73).to({_off:false,x:187.25},0).to({_off:true},1).wait(1).to({_off:false,x:178.35},0).wait(1).to({x:173.65},0).wait(1).to({x:169.25},0).wait(1).to({x:165.375},0).to({_off:true},1).wait(2).to({_off:false,x:157.225},0).wait(1).to({x:155.525},0).wait(1).to({x:154.225},0).wait(1).to({x:153.225},0).wait(1).to({x:152.475},0).wait(1).to({x:152.025},0).wait(1).to({x:151.775},0).wait(1).to({x:151.675},0).wait(58));

}).prototype = p = new cjs.MovieClip();


(lib.Image = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Transform
	this.instance = new lib.transform();
	this.instance.parent = this;
	this.instance.setTransform(56.4,55.15,0.9714,1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("As5FDIAAqFIZzAAIAAKFg");
	var mask_graphics_1 = new cjs.Graphics().p("As5FDIAAqFIZzAAIAAKFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:150.15,y:96}).wait(1).to({graphics:mask_graphics_1,x:150.15,y:96}).wait(1));

	// Layer_1
	this.instance_1 = new lib.macbookscreen();
	this.instance_1.parent = this;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(56.4,55.2,185.6,80.99999999999999);


(lib.flag_2_name = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.txt = new cjs.Text("", "32px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 43;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-11.5,-22.55);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("AoWDBIAAmBIQtAAIAAGBg");
	this.shape.setTransform(35.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],-1.4,-2,-1.4,2).s().p("AoWAUIAAgnIQtAAIAAAng");
	this.shape_1.setTransform(35.5,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_2_name, new cjs.Rectangle(-18,-24.5,108.5,47.8), null);


(lib.flag_1_name = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.txt = new cjs.Text("", "32px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 43;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-11.5,-22.55);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("AoWDBIAAmBIQtAAIAAGBg");
	this.shape.setTransform(35.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],-1.4,-2,-1.4,2).s().p("AoWAUIAAgnIQtAAIAAAng");
	this.shape_1.setTransform(35.5,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_1_name, new cjs.Rectangle(-18,-24.5,108.5,47.8), null);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("AglELIAAoVIBLAAIAAIVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.7,7.5,53.5);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("AglELIAAoVIBLAAIAAIVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.7,7.5,53.5);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_24 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(24).call(this.frame_24).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.Text_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,171,85);


(lib.Screen_ScreenText = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenText
	this.instance = new lib.Text("single",1);
	this.instance.parent = this;
	this.instance.setTransform(144.75,160.1,1.5,1.5,0,0,0,84.5,42.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(78).to({startPosition:1},0).to({y:208.4},28,cjs.Ease.cubicInOut).wait(61).to({startPosition:1},0).wait(4).to({startPosition:2},0).wait(5).to({startPosition:3},0).wait(5).to({startPosition:4},0).wait(5).to({startPosition:5},0).wait(70).to({startPosition:6},0).wait(4).to({startPosition:7},0).wait(5).to({startPosition:8},0).wait(5).to({startPosition:9},0).wait(5).to({startPosition:10},0).wait(31).to({startPosition:11},0).wait(3).to({startPosition:12},0).wait(4).to({startPosition:13},0).wait(4).to({startPosition:14},0).wait(4).to({startPosition:15},0).wait(4).to({startPosition:16},0).wait(5).to({startPosition:17},0).wait(14).to({startPosition:18},0).wait(3).to({startPosition:19},0).wait(4).to({startPosition:20},0).wait(5).to({startPosition:21},0).wait(4).to({startPosition:22},0).wait(4).to({startPosition:23},0).wait(4).to({startPosition:24},0).wait(205));

}).prototype = p = new cjs.MovieClip();


(lib.Screen_Image = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Image
	this.instance = new lib.Image("single",0);
	this.instance.parent = this;
	this.instance.setTransform(83.8,69.9,0.7686,0.7686,0,0,0,150,101.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(68).to({startPosition:1},0).wait(10).to({startPosition:1},0).to({regY:101,scaleX:1.5363,scaleY:1.5363,x:147.05,y:98.45},28,cjs.Ease.cubicInOut).wait(7).to({startPosition:0},0).wait(460));

}).prototype = p = new cjs.MovieClip();


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.mainMC_smallPrint = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// smallPrint
	this.smallPrint = new lib.txt_6();
	this.smallPrint.name = "smallPrint";
	this.smallPrint.parent = this;
	this.smallPrint.setTransform(45.2,572.95,0.4965,0.4965,0,0,0,0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.smallPrint).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_smallPrint, null, null);


(lib.mainMC_replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(4.1,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_replay, null, null);


(lib.mainMC_CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(-42.15,571.35,0.4964,0.4964);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_CTA, null, null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.025,5.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.325,5.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.025,-5.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.325,-5.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.Intro_Macbook = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Macbook
	this.instance = new lib.Macbook_1();
	this.instance.parent = this;
	this.instance.setTransform(152.35,153.65,0.618,0.618,0,0,0,150.3,125.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(170).to({_off:false},0).wait(278));

}).prototype = p = new cjs.MovieClip();


(lib.Intro_Mac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mac
	this.instance = new lib.Mac();
	this.instance.parent = this;
	this.instance.setTransform(152.45,150.8,0.6216,0.6216,0,0,0,144.3,120.3);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({x:152.6,y:318.95},0).wait(1).to({regX:144,regY:120,x:152.4,y:299.7,alpha:0.1141},0).wait(1).to({y:279.2,alpha:0.2369},0).wait(1).to({y:258.45,alpha:0.3612},0).wait(1).to({y:238.85,alpha:0.4786},0).wait(1).to({y:221.4,alpha:0.5828},0).wait(1).to({y:206.6,alpha:0.6714},0).wait(1).to({y:194.35,alpha:0.745},0).wait(1).to({y:184.3,alpha:0.8051},0).wait(1).to({y:176.15,alpha:0.8539},0).wait(1).to({y:169.55,alpha:0.8932},0).wait(1).to({y:164.35,alpha:0.9244},0).wait(1).to({y:160.25,alpha:0.9489},0).wait(1).to({y:157.1,alpha:0.9677},0).wait(1).to({y:154.8,alpha:0.9816},0).wait(1).to({y:153.2,alpha:0.9913},0).wait(1).to({y:152.2,alpha:0.9973},0).wait(1).to({regX:144.3,regY:120.3,x:152.6,y:151.9,alpha:1},0).wait(384).to({regY:120.4,scaleY:0.6215,y:152},0).wait(33));

}).prototype = p = new cjs.MovieClip();


(lib.flag_2_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("Ai9DBIAAmBIF7AAIAAGBg");
	this.shape.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],35.1,-2,35.1,2).s().p("Ai9AUIAAgnIF7AAIAAAng");
	this.shape_1.setTransform(-1,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_2_square, new cjs.Rectangle(-20,-19.2,38,42.5), null);


(lib.flag_1_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.person();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("Ai9DBIAAmBIF7AAIAAGBg");
	this.shape.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],35.4,-2,35.4,2).s().p("AjAAUIAAgnIGBAAIAAAng");
	this.shape_1.setTransform(-1.25,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_1_square, new cjs.Rectangle(-20.5,-19.2,38.5,42.5), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.375,7.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.675,7.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.375,-4.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.675,-4.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_63 = function() {
		exportRoot.mainMC.anim.gotoAndPlay(1)
	}
	this.frame_78 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(63).call(this.frame_63).wait(15).call(this.frame_78).wait(4));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(77.05,874.4,0.2353,0.2353,0,0,0,-39.5,2.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.8923,scaleY:3.8923,x:77,y:874},13,cjs.Ease.quadOut).to({x:-77.5},12,cjs.Ease.quadInOut).to({_off:true},1).wait(55));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgPABHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_14 = new cjs.Graphics().p("EgPABHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_15 = new cjs.Graphics().p("EgPLBHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_16 = new cjs.Graphics().p("EgPrBHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_17 = new cjs.Graphics().p("EgQhBHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_18 = new cjs.Graphics().p("EgRsBHmIAAtIMAxbAAAIAANIg");
	var mask_graphics_19 = new cjs.Graphics().p("EgTOBHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_20 = new cjs.Graphics().p("EgVEBHmIAAtIMAxbAAAIAANIg");
	var mask_graphics_21 = new cjs.Graphics().p("EgW7BHmIAAtIMAxcAAAIAANIg");
	var mask_graphics_22 = new cjs.Graphics().p("EgYcBHmIAAtIMAxbAAAIAANIg");
	var mask_graphics_23 = new cjs.Graphics().p("EgYtBHmIAAtIMAxbAAAIAANIg");
	var mask_graphics_24 = new cjs.Graphics().p("EgYtBHmIAAtIMAxbAAAIAANIg");
	var mask_graphics_25 = new cjs.Graphics().p("EgYtBHmIAAtIMAxbAAAIAANIg");
	var mask_graphics_26 = new cjs.Graphics().p("EgYtBHmIAAtIMAxbAAAIAANIg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:220.4062,y:458.1814}).wait(14).to({graphics:mask_graphics_14,x:220.4062,y:458.1814}).wait(1).to({graphics:mask_graphics_15,x:219.3266,y:458.1814}).wait(1).to({graphics:mask_graphics_16,x:216.0877,y:458.1814}).wait(1).to({graphics:mask_graphics_17,x:210.6897,y:458.1814}).wait(1).to({graphics:mask_graphics_18,x:203.1324,y:458.1814}).wait(1).to({graphics:mask_graphics_19,x:193.416,y:458.1814}).wait(1).to({graphics:mask_graphics_20,x:181.5403,y:458.1814}).wait(1).to({graphics:mask_graphics_21,x:169.6646,y:458.1814}).wait(1).to({graphics:mask_graphics_22,x:159.9482,y:458.1814}).wait(1).to({graphics:mask_graphics_23,x:146.5412,y:458.1814}).wait(1).to({graphics:mask_graphics_24,x:135.7451,y:458.1814}).wait(1).to({graphics:mask_graphics_25,x:129.2675,y:458.1814}).wait(1).to({graphics:mask_graphics_26,x:127.0217,y:458.1814}).wait(1).to({graphics:null,x:0,y:0}).wait(55));

	// Layer_3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-76.7,869.7,3.8923,3.8923,0,0,0,0.1,0.3);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(78.6,869.7,3.8923,3.8923,0,0,0,0.1,0.3);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:78.6},12,cjs.Ease.quadInOut).wait(56));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},12,cjs.Ease.quadInOut).wait(25).to({regX:-0.1,regY:0.5,scaleX:2.2317,scaleY:2.2317,x:-16.9,y:11.95},22,cjs.Ease.quadInOut).wait(9));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(75.1,903,0.5403,2.3826,0,0,0,485.1,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(55).to({regX:484.9,x:-450.5},21,cjs.Ease.quadIn).wait(6));

	// white_copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(75.1,903,0.5403,2.3826,0,0,0,485.1,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(56).to({regX:484.9,x:-450.5},22,cjs.Ease.quadIn).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-712.5,-66.5,1050.1,1939.2);


(lib.cta_arrow_mo_Layer_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

}).prototype = p = new cjs.MovieClip();


(lib.cta_arrow_mo_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();


(lib.aFlagMC_B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"in":1,"out":40});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_39 = function() {
		this.stop()
	}
	this.frame_64 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(25).call(this.frame_64).wait(1));

	// mask_idn
	this.instance = new lib.Tween2();
	this.instance.parent = this;
	this.instance.setTransform(0,0.5,1,0.0187,0,0,0,0,26.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({regY:0,scaleY:0.1468,y:-0.0326},0).wait(1).to({scaleY:0.2742,y:-0.0651},0).wait(1).to({scaleY:0.3953,y:-0.0959},0).wait(1).to({scaleY:0.5069,y:-0.1244},0).wait(1).to({scaleY:0.6072,y:-0.1499},0).wait(1).to({scaleY:0.6955,y:-0.1724},0).wait(1).to({scaleY:0.7716,y:-0.1918},0).wait(1).to({scaleY:0.8357,y:-0.2081},0).wait(1).to({scaleY:0.8884,y:-0.2216},0).wait(1).to({scaleY:0.9301,y:-0.2322},0).wait(1).to({scaleY:0.9615,y:-0.2402},0).wait(1).to({scaleY:0.9833,y:-0.2457},0).wait(1).to({scaleY:0.9959,y:-0.249},0).wait(1).to({regY:26.5,scaleY:1,y:26.5},0).to({_off:true},49).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AobDVIAAmoIQ3AAIAAGog");
	mask.setTransform(98.775,-5.5);

	// Layer_1
	this.flag = new lib.flag_2_name();
	this.flag.name = "flag";
	this.flag.parent = this;
	this.flag.setTransform(-46.15,-7.5);

	var maskedShapeInstanceList = [this.flag];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flag).wait(27).to({regX:35.5,regY:0.3,x:6.65,y:-7.2},0).wait(1).to({x:21.95},0).wait(1).to({x:35.55},0).wait(1).to({x:47.7},0).wait(1).to({x:58.4},0).wait(1).to({x:67.8},0).wait(1).to({x:75.9},0).wait(1).to({x:82.75},0).wait(1).to({x:88.3},0).wait(1).to({x:92.65},0).wait(1).to({x:95.75},0).wait(1).to({x:97.6},0).wait(1).to({regX:0,regY:0,x:62.75,y:-7.5},0).wait(1).to({regX:35.5,regY:0.3,x:97.45,y:-7.2},0).wait(1).to({x:95.25},0).wait(1).to({x:91.75},0).wait(1).to({x:87.05},0).wait(1).to({x:81.2},0).wait(1).to({x:74.3},0).wait(1).to({x:66.35},0).wait(1).to({x:57.3},0).wait(1).to({x:47.1},0).wait(1).to({x:35.65},0).wait(1).to({x:22.8},0).wait(1).to({x:7.9},0).wait(1).to({regX:0,regY:0,x:-46.15,y:-7.5},0).wait(13));

	// Layer_1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("Ai9DVIAAmoIF7AAIAAGog");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:21.775,y:-5.5}).wait(49).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.instance_1 = new lib.flag_2_square();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.25,-7.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(1).to({regX:-1,regY:2,x:-14.9,y:-5.5},0).wait(1).to({x:-13.95},0).wait(1).to({x:-12.45},0).wait(1).to({x:-10.45},0).wait(1).to({x:-7.95},0).wait(1).to({x:-4.95},0).wait(1).to({x:-1.4},0).wait(1).to({x:2.7},0).wait(1).to({x:7.55},0).wait(1).to({x:13.3},0).wait(1).to({regX:0,regY:0,x:21.75,y:-7.5},0).wait(26).to({x:-11},10).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.8,156.5,53.6);


(lib.aFlagMC_A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"in":1,"out":40});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_39 = function() {
		this.stop()
	}
	this.frame_64 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(25).call(this.frame_64).wait(1));

	// mask_idn
	this.instance = new lib.Tween1();
	this.instance.parent = this;
	this.instance.setTransform(0,0.5,1,0.0187,0,0,0,0,26.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({regY:0,scaleY:0.1468,y:-0.0326},0).wait(1).to({scaleY:0.2742,y:-0.0651},0).wait(1).to({scaleY:0.3953,y:-0.0959},0).wait(1).to({scaleY:0.5069,y:-0.1244},0).wait(1).to({scaleY:0.6072,y:-0.1499},0).wait(1).to({scaleY:0.6955,y:-0.1724},0).wait(1).to({scaleY:0.7716,y:-0.1918},0).wait(1).to({scaleY:0.8357,y:-0.2081},0).wait(1).to({scaleY:0.8884,y:-0.2216},0).wait(1).to({scaleY:0.9301,y:-0.2322},0).wait(1).to({scaleY:0.9615,y:-0.2402},0).wait(1).to({scaleY:0.9833,y:-0.2457},0).wait(1).to({scaleY:0.9959,y:-0.249},0).wait(1).to({regY:26.5,scaleY:1,y:26.5},0).to({_off:true},49).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AobDVIAAmoIQ3AAIAAGog");
	mask.setTransform(98.775,-5.5);

	// Layer_1
	this.flag = new lib.flag_1_name();
	this.flag.name = "flag";
	this.flag.parent = this;
	this.flag.setTransform(-46.15,-7.5);

	var maskedShapeInstanceList = [this.flag];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flag).wait(27).to({regX:35.5,regY:0.3,x:6.65,y:-7.2},0).wait(1).to({x:21.95},0).wait(1).to({x:35.55},0).wait(1).to({x:47.7},0).wait(1).to({x:58.4},0).wait(1).to({x:67.8},0).wait(1).to({x:75.9},0).wait(1).to({x:82.75},0).wait(1).to({x:88.3},0).wait(1).to({x:92.65},0).wait(1).to({x:95.75},0).wait(1).to({x:97.6},0).wait(1).to({regX:0,regY:0,x:62.75,y:-7.5},0).wait(1).to({regX:35.5,regY:0.3,x:97.45,y:-7.2},0).wait(1).to({x:95.25},0).wait(1).to({x:91.75},0).wait(1).to({x:87.05},0).wait(1).to({x:81.2},0).wait(1).to({x:74.3},0).wait(1).to({x:66.35},0).wait(1).to({x:57.3},0).wait(1).to({x:47.1},0).wait(1).to({x:35.65},0).wait(1).to({x:22.8},0).wait(1).to({x:7.9},0).wait(1).to({regX:0,regY:0,x:-46.15,y:-7.5},0).wait(13));

	// Layer_1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("Ai9DVIAAmoIF7AAIAAGog");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:21.775,y:-5.5}).wait(49).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.instance_1 = new lib.flag_1_square();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.25,-7.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(1).to({regX:-1.3,regY:2,x:-15.2,y:-5.5},0).wait(1).to({x:-14.25},0).wait(1).to({x:-12.75},0).wait(1).to({x:-10.75},0).wait(1).to({x:-8.25},0).wait(1).to({x:-5.25},0).wait(1).to({x:-1.7},0).wait(1).to({x:2.4},0).wait(1).to({x:7.25},0).wait(1).to({x:13},0).wait(1).to({regX:0,regY:0,x:21.75,y:-7.5},0).wait(26).to({x:-11},10).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.8,156.5,53.6);


(lib.Screen_flag2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// flag2
	this.flag2 = new lib.aFlagMC_B();
	this.flag2.name = "flag2";
	this.flag2.parent = this;
	this.flag2.setTransform(147.45,77.4,0.5502,0.5502,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.flag2).wait(78).to({x:274.2,y:127},28,cjs.Ease.cubicInOut).wait(31).to({x:128.55,y:140.8},19,cjs.Ease.quadInOut).wait(15).to({x:138},0).wait(5).to({x:146.95},0).wait(5).to({x:155.35},0).wait(5).to({x:163.35,y:140.5},0).wait(100).to({x:143.1,y:166.15},14,cjs.Ease.quadInOut).wait(9).to({x:147.3},0).wait(4).to({x:153.6},0).wait(4).to({x:160.45},0).wait(4).to({x:165.7},0).wait(4).to({x:173.05},0).wait(5).to({x:178.45,y:165.4},0).wait(243));

}).prototype = p = new cjs.MovieClip();


(lib.Screen_flag1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// flag1
	this.flag1 = new lib.aFlagMC_A();
	this.flag1.name = "flag1";
	this.flag1.parent = this;
	this.flag1.setTransform(262.75,153.3,0.5502,0.5502,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.flag1).wait(220).to({x:44.85,y:165.3},25,cjs.Ease.quadInOut).wait(15).to({x:51.7},0).wait(5).to({x:58},0).wait(5).to({x:63.75},0).wait(5).to({x:71.1},0).wait(49).to({x:15.7,y:176.7},14,cjs.Ease.quadInOut).wait(9).to({x:21.45},0).wait(4).to({x:29.85},0).wait(5).to({x:36.15},0).wait(4).to({x:42.45},0).wait(4).to({x:50.85},0).wait(4).to({x:57.7},0).wait(205));

}).prototype = p = new cjs.MovieClip();


(lib.Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
		this.stop();
	}
	this.frame_34 = function() {
		this.flag2.gotoAndPlay('in')
	}
	this.frame_78 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_106 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_137 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_156 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_167 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_171 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_176 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_181 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_186 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_193 = function() {
		this.flag1.gotoAndPlay('in')
	}
	this.frame_206 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_220 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_245 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_256 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_260 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_265 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_270 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_275 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_286 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_300 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_306 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_309 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_313 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_317 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_321 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_324 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_325 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_330 = function() {
		if(this.flag2.parent == undefined || this.flag2.parent == this)
		this.flag2 = this.flag2.flag2;
	}
	this.frame_338 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_344 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_347 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_351 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_356 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_360 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_364 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_368 = function() {
		if(this.flag1.parent == undefined || this.flag1.parent == this)
		this.flag1 = this.flag1.flag1;
	}
	this.frame_451 = function() {
		this.stop()
	}
	this.frame_572 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(44).call(this.frame_78).wait(28).call(this.frame_106).wait(31).call(this.frame_137).wait(19).call(this.frame_156).wait(11).call(this.frame_167).wait(4).call(this.frame_171).wait(5).call(this.frame_176).wait(5).call(this.frame_181).wait(5).call(this.frame_186).wait(7).call(this.frame_193).wait(13).call(this.frame_206).wait(14).call(this.frame_220).wait(25).call(this.frame_245).wait(11).call(this.frame_256).wait(4).call(this.frame_260).wait(5).call(this.frame_265).wait(5).call(this.frame_270).wait(5).call(this.frame_275).wait(11).call(this.frame_286).wait(14).call(this.frame_300).wait(6).call(this.frame_306).wait(3).call(this.frame_309).wait(4).call(this.frame_313).wait(4).call(this.frame_317).wait(4).call(this.frame_321).wait(3).call(this.frame_324).wait(1).call(this.frame_325).wait(5).call(this.frame_330).wait(8).call(this.frame_338).wait(6).call(this.frame_344).wait(3).call(this.frame_347).wait(4).call(this.frame_351).wait(5).call(this.frame_356).wait(4).call(this.frame_360).wait(4).call(this.frame_364).wait(4).call(this.frame_368).wait(83).call(this.frame_451).wait(121).call(this.frame_572).wait(1));

	// flag1_obj_
	this.flag1 = new lib.Screen_flag1();
	this.flag1.name = "flag1";
	this.flag1.parent = this;
	this.flag1.setTransform(287,148.8,1,1,0,0,0,287,148.8);
	this.flag1.depth = 0;
	this.flag1.isAttachedToCamera = 0
	this.flag1.isAttachedToMask = 0
	this.flag1.layerDepth = 0
	this.flag1.layerIndex = 0
	this.flag1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.flag1).wait(573));

	// flag2_obj_
	this.flag2 = new lib.Screen_flag2();
	this.flag2.name = "flag2";
	this.flag2.parent = this;
	this.flag2.setTransform(171.7,72.8,1,1,0,0,0,171.7,72.8);
	this.flag2.depth = 0;
	this.flag2.isAttachedToCamera = 0
	this.flag2.isAttachedToMask = 0
	this.flag2.layerDepth = 0
	this.flag2.layerIndex = 1
	this.flag2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.flag2).wait(573));

	// Image_obj_
	this.Image = new lib.Screen_Image();
	this.Image.name = "Image";
	this.Image.parent = this;
	this.Image.setTransform(83.8,69.8,1,1,0,0,0,83.8,69.8);
	this.Image.depth = 0;
	this.Image.isAttachedToCamera = 0
	this.Image.isAttachedToMask = 0
	this.Image.layerDepth = 0
	this.Image.layerIndex = 2
	this.Image.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Image).wait(573));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AVzRUIAAh0MgwVAAAIAAgpIgLAAIAA8eIgLAAIAAjsMA0xAAAIAADsIghAAIAAbLIBhAAIAAB8IhhAAIAAB0gA4mNkMAuZAAAIAA7LMguZAAAgA1rqGIAAjKIL2AAIAADKg");
	mask.setTransform(152.275,104.675);

	// ScreenBG_obj_
	this.ScreenBG = new lib.Screen_ScreenBG();
	this.ScreenBG.name = "ScreenBG";
	this.ScreenBG.parent = this;
	this.ScreenBG.setTransform(150,94,1,1,0,0,0,150,94);
	this.ScreenBG.depth = 0;
	this.ScreenBG.isAttachedToCamera = 0
	this.ScreenBG.isAttachedToMask = 0
	this.ScreenBG.layerDepth = 0
	this.ScreenBG.layerIndex = 3
	this.ScreenBG.maskLayerName = 0

	var maskedShapeInstanceList = [this.ScreenBG];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ScreenBG).wait(573));

	// Layer_3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A44O+IAA1VMAxxAAAIAAVVg");
	mask_1.setTransform(144.4114,95.7809);

	// ScreenText_obj_
	this.ScreenText = new lib.Screen_ScreenText();
	this.ScreenText.name = "ScreenText";
	this.ScreenText.parent = this;
	this.ScreenText.setTransform(144.8,159.7,1,1,0,0,0,144.8,159.7);
	this.ScreenText.depth = 0;
	this.ScreenText.isAttachedToCamera = 0
	this.ScreenText.isAttachedToMask = 0
	this.ScreenText.layerDepth = 0
	this.ScreenText.layerIndex = 4
	this.ScreenText.maskLayerName = 0

	var maskedShapeInstanceList = [this.ScreenText];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.ScreenText).wait(573));

	// ScreenFill_obj_
	this.ScreenFill = new lib.Screen_ScreenFill();
	this.ScreenFill.name = "ScreenFill";
	this.ScreenFill.parent = this;
	this.ScreenFill.setTransform(145.3,104.3,1,1,0,0,0,145.3,104.3);
	this.ScreenFill.depth = 0;
	this.ScreenFill.isAttachedToCamera = 0
	this.ScreenFill.isAttachedToMask = 0
	this.ScreenFill.layerDepth = 0
	this.ScreenFill.layerIndex = 5
	this.ScreenFill.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.ScreenFill).wait(573));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.8,-6.1,378,221.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.___loopingOver___ = true;
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer_4_obj_
	this.Layer_4 = new lib.cta_arrow_mo_Layer_4();
	this.Layer_4.name = "Layer_4";
	this.Layer_4.parent = this;
	this.Layer_4.depth = 0;
	this.Layer_4.isAttachedToCamera = 0
	this.Layer_4.isAttachedToMask = 0
	this.Layer_4.layerDepth = 0
	this.Layer_4.layerIndex = 0
	this.Layer_4.maskLayerName = 0

	var maskedShapeInstanceList = [this.Layer_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Layer_4).wait(21).to({regX:-8,x:-8},0).wait(5).to({regX:0,x:0},0).wait(1).to({regX:-8,x:-8},0).wait(5).to({regX:0,x:0},0).wait(1).to({regX:-8,x:-8},0).wait(5).to({regX:0,x:0},0).wait(1).to({regX:-8,x:-8},0).wait(4).to({regX:0,x:0},0).wait(10));

	// Layer_2_obj_
	this.Layer_2 = new lib.cta_arrow_mo_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(0.1,0,1,1,0,0,0,0.1,0);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 1
	this.Layer_2.maskLayerName = 0

	var maskedShapeInstanceList = [this.Layer_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(53));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mainMC_MSFT_Logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSFT_Logo
	this.logo = new lib.logos();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-82.85,19.05,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_MSFT_Logo, null, null);


(lib.Intro_Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Screen
	this.screen = new lib.Screen();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(152.95,306.15,0.4113,0.4113,0,0,0,150.8,99.5);
	this.screen.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(15).to({regX:168.9,regY:104.7,x:160.35,y:289.2,alpha:0.1141},0).wait(1).to({y:268.65,alpha:0.2369},0).wait(1).to({x:160.3,y:247.85,alpha:0.3612},0).wait(1).to({y:228.25,alpha:0.4786},0).wait(1).to({y:210.8,alpha:0.5828},0).wait(1).to({y:196,alpha:0.6714},0).wait(1).to({x:160.25,y:183.7,alpha:0.745},0).wait(1).to({y:173.65,alpha:0.8051},0).wait(1).to({y:165.45,alpha:0.8539},0).wait(1).to({y:158.9,alpha:0.8932},0).wait(1).to({y:153.7,alpha:0.9244},0).wait(1).to({y:149.6,alpha:0.9489},0).wait(1).to({y:146.45,alpha:0.9677},0).wait(1).to({y:144.1,alpha:0.9816},0).wait(1).to({y:142.5,alpha:0.9913},0).wait(1).to({y:141.5,alpha:0.9973},0).wait(1).to({regX:150.4,regY:99.1,x:152.8,y:138.95,alpha:1},0).wait(417));

}).prototype = p = new cjs.MovieClip();


(lib.Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.screen = this.Screen.screen;
		this.stop()
	}
	this.frame_7 = function() {
		exportRoot.tlH1.play()
	}
	this.frame_9 = function() {
		exportRoot.tl2.play()
	}
	this.frame_14 = function() {
		this.screen = undefined;this.screen = this.Screen.screen;
		this.screen.play(1)
	}
	this.frame_31 = function() {
		this.screen = undefined;this.screen = this.Screen.screen;
	}
	this.frame_409 = function() {
		exportRoot.tl1.play()
	}
	this.frame_415 = function() {
		this.screen = undefined;this.screen = this.Screen.screen;
	}
	this.frame_440 = function() {
		this.stop()
	}
	this.frame_447 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7).call(this.frame_7).wait(2).call(this.frame_9).wait(5).call(this.frame_14).wait(17).call(this.frame_31).wait(378).call(this.frame_409).wait(6).call(this.frame_415).wait(25).call(this.frame_440).wait(7).call(this.frame_447).wait(1));

	// Whitebar_obj_
	this.Whitebar = new lib.Intro_Whitebar();
	this.Whitebar.name = "Whitebar";
	this.Whitebar.parent = this;
	this.Whitebar.depth = 0;
	this.Whitebar.isAttachedToCamera = 0
	this.Whitebar.isAttachedToMask = 0
	this.Whitebar.layerDepth = 0
	this.Whitebar.layerIndex = 0
	this.Whitebar.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Whitebar).wait(448));

	// Screen_obj_
	this.Screen = new lib.Intro_Screen();
	this.Screen.name = "Screen";
	this.Screen.parent = this;
	this.Screen.setTransform(152.7,303.9,1,1,0,0,0,152.7,303.9);
	this.Screen.depth = 0;
	this.Screen.isAttachedToCamera = 0
	this.Screen.isAttachedToMask = 0
	this.Screen.layerDepth = 0
	this.Screen.layerIndex = 1
	this.Screen.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Screen).wait(15).to({regX:160.3,regY:224.8,x:160.3,y:224.8},0).wait(16).to({regX:152.7,regY:303.9,x:152.7,y:303.9},0).wait(417));

	// MacMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_170 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_171 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_172 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_173 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_174 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_175 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_176 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_177 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_178 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_179 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_180 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_181 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_182 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_183 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_184 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_185 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_186 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_187 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_188 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_189 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_190 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_191 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_192 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_193 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_194 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_195 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_196 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_197 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_198 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_199 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_200 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_201 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_202 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_203 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_204 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_205 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_206 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_207 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_208 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_209 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_210 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_280 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_281 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_282 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_283 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_284 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_285 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_286 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_287 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_288 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_289 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_290 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_291 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_292 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_293 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_294 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_295 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_296 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_297 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_298 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_299 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_300 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_301 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_302 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_303 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_304 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_305 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_306 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_307 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_308 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_309 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_310 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_311 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_312 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_313 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_314 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_315 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_graphics_316 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_317 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_318 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_319 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_320 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_321 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_322 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_323 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_324 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_363 = new cjs.Graphics().p("Ay+SSIAA4+MAl8AAAIAAY+g");
	var mask_graphics_364 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_365 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_366 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_367 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_368 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_369 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_370 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_371 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_372 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_373 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_374 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_375 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_376 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_377 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_378 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_379 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_380 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_381 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_graphics_382 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_383 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_384 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_385 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_386 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_387 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_388 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_389 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_390 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_graphics_415 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(170).to({graphics:mask_graphics_170,x:128.2,y:154}).wait(1).to({graphics:mask_graphics_171,x:113.725,y:154}).wait(1).to({graphics:mask_graphics_172,x:100.3,y:154}).wait(1).to({graphics:mask_graphics_173,x:87.925,y:154}).wait(1).to({graphics:mask_graphics_174,x:76.5,y:154}).wait(1).to({graphics:mask_graphics_175,x:65.975,y:154}).wait(1).to({graphics:mask_graphics_176,x:56.325,y:154}).wait(1).to({graphics:mask_graphics_177,x:47.5,y:154}).wait(1).to({graphics:mask_graphics_178,x:39.425,y:154}).wait(1).to({graphics:mask_graphics_179,x:32.075,y:154}).wait(1).to({graphics:mask_graphics_180,x:25.425,y:154}).wait(1).to({graphics:mask_graphics_181,x:19.4,y:154}).wait(1).to({graphics:mask_graphics_182,x:13.95,y:154}).wait(1).to({graphics:mask_graphics_183,x:9.05,y:154}).wait(1).to({graphics:mask_graphics_184,x:4.7,y:154}).wait(1).to({graphics:mask_graphics_185,x:0.8,y:154}).wait(1).to({graphics:mask_graphics_186,x:-2.65,y:154}).wait(1).to({graphics:mask_graphics_187,x:-5.7,y:154}).wait(1).to({graphics:mask_graphics_188,x:-8.4,y:154}).wait(1).to({graphics:mask_graphics_189,x:-10.725,y:154}).wait(1).to({graphics:mask_graphics_190,x:-12.75,y:154}).wait(1).to({graphics:mask_graphics_191,x:-14.5,y:154}).wait(1).to({graphics:mask_graphics_192,x:-16,y:154}).wait(1).to({graphics:mask_graphics_193,x:-17.25,y:154}).wait(1).to({graphics:mask_graphics_194,x:-18.3,y:154}).wait(1).to({graphics:mask_graphics_195,x:-19.2,y:154}).wait(1).to({graphics:mask_graphics_196,x:-19.9,y:154}).wait(1).to({graphics:mask_graphics_197,x:-20.45,y:154}).wait(1).to({graphics:mask_graphics_198,x:-20.95,y:154}).wait(1).to({graphics:mask_graphics_199,x:-21.3,y:154}).wait(1).to({graphics:mask_graphics_200,x:-21.55,y:154}).wait(1).to({graphics:mask_graphics_201,x:-21.75,y:154}).wait(1).to({graphics:mask_graphics_202,x:-21.9,y:154}).wait(1).to({graphics:mask_graphics_203,x:-22,y:154}).wait(1).to({graphics:mask_graphics_204,x:-22.05,y:154}).wait(1).to({graphics:mask_graphics_205,x:-22.1,y:154}).wait(1).to({graphics:mask_graphics_206,x:-22.15,y:154}).wait(1).to({graphics:mask_graphics_207,x:-22.15,y:154}).wait(1).to({graphics:mask_graphics_208,x:-22.15,y:154}).wait(1).to({graphics:mask_graphics_209,x:-22.15,y:154}).wait(1).to({graphics:mask_graphics_210,x:-22.15,y:154}).wait(70).to({graphics:mask_graphics_280,x:-22.15,y:154}).wait(1).to({graphics:mask_graphics_281,x:-22.1,y:154}).wait(1).to({graphics:mask_graphics_282,x:-21.85,y:154}).wait(1).to({graphics:mask_graphics_283,x:-21.5,y:154}).wait(1).to({graphics:mask_graphics_284,x:-20.95,y:154}).wait(1).to({graphics:mask_graphics_285,x:-20.2,y:154}).wait(1).to({graphics:mask_graphics_286,x:-19.25,y:154}).wait(1).to({graphics:mask_graphics_287,x:-18.1,y:154}).wait(1).to({graphics:mask_graphics_288,x:-16.7,y:154}).wait(1).to({graphics:mask_graphics_289,x:-15.05,y:154}).wait(1).to({graphics:mask_graphics_290,x:-13.15,y:154}).wait(1).to({graphics:mask_graphics_291,x:-10.95,y:154}).wait(1).to({graphics:mask_graphics_292,x:-8.4,y:154}).wait(1).to({graphics:mask_graphics_293,x:-5.55,y:154}).wait(1).to({graphics:mask_graphics_294,x:-2.35,y:154}).wait(1).to({graphics:mask_graphics_295,x:1.2,y:154}).wait(1).to({graphics:mask_graphics_296,x:5.1,y:154}).wait(1).to({graphics:mask_graphics_297,x:9.35,y:154}).wait(1).to({graphics:mask_graphics_298,x:13.9,y:154}).wait(1).to({graphics:mask_graphics_299,x:18.75,y:154}).wait(1).to({graphics:mask_graphics_300,x:23.75,y:154}).wait(1).to({graphics:mask_graphics_301,x:28.9,y:154}).wait(1).to({graphics:mask_graphics_302,x:34.05,y:154}).wait(1).to({graphics:mask_graphics_303,x:39.1,y:154}).wait(1).to({graphics:mask_graphics_304,x:43.95,y:154}).wait(1).to({graphics:mask_graphics_305,x:48.6,y:154}).wait(1).to({graphics:mask_graphics_306,x:52.95,y:154}).wait(1).to({graphics:mask_graphics_307,x:57,y:154}).wait(1).to({graphics:mask_graphics_308,x:60.7,y:154}).wait(1).to({graphics:mask_graphics_309,x:64.05,y:154}).wait(1).to({graphics:mask_graphics_310,x:67.05,y:154}).wait(1).to({graphics:mask_graphics_311,x:69.8,y:154}).wait(1).to({graphics:mask_graphics_312,x:72.2,y:154}).wait(1).to({graphics:mask_graphics_313,x:74.3,y:154}).wait(1).to({graphics:mask_graphics_314,x:76.2,y:154}).wait(1).to({graphics:mask_graphics_315,x:77.8,y:154}).wait(1).to({graphics:mask_graphics_316,x:79.2,y:154}).wait(1).to({graphics:mask_graphics_317,x:80.4,y:154}).wait(1).to({graphics:mask_graphics_318,x:81.35,y:154}).wait(1).to({graphics:mask_graphics_319,x:82.15,y:154}).wait(1).to({graphics:mask_graphics_320,x:82.8,y:154}).wait(1).to({graphics:mask_graphics_321,x:83.25,y:154}).wait(1).to({graphics:mask_graphics_322,x:83.6,y:154}).wait(1).to({graphics:mask_graphics_323,x:83.8,y:154}).wait(1).to({graphics:mask_graphics_324,x:83.85,y:154}).wait(39).to({graphics:mask_graphics_363,x:83.85,y:116.95}).wait(1).to({graphics:mask_graphics_364,x:83.8,y:154}).wait(1).to({graphics:mask_graphics_365,x:83.55,y:154}).wait(1).to({graphics:mask_graphics_366,x:83.15,y:154}).wait(1).to({graphics:mask_graphics_367,x:82.55,y:154}).wait(1).to({graphics:mask_graphics_368,x:81.75,y:154}).wait(1).to({graphics:mask_graphics_369,x:80.65,y:154}).wait(1).to({graphics:mask_graphics_370,x:79.3,y:154}).wait(1).to({graphics:mask_graphics_371,x:77.55,y:154}).wait(1).to({graphics:mask_graphics_372,x:75.375,y:154}).wait(1).to({graphics:mask_graphics_373,x:72.725,y:154}).wait(1).to({graphics:mask_graphics_374,x:69.55,y:154}).wait(1).to({graphics:mask_graphics_375,x:65.775,y:154}).wait(1).to({graphics:mask_graphics_376,x:61.5,y:154}).wait(1).to({graphics:mask_graphics_377,x:56.85,y:154}).wait(1).to({graphics:mask_graphics_378,x:52.175,y:154}).wait(1).to({graphics:mask_graphics_379,x:47.775,y:154}).wait(1).to({graphics:mask_graphics_380,x:43.875,y:154}).wait(1).to({graphics:mask_graphics_381,x:40.6,y:154}).wait(1).to({graphics:mask_graphics_382,x:37.925,y:154}).wait(1).to({graphics:mask_graphics_383,x:35.725,y:154}).wait(1).to({graphics:mask_graphics_384,x:34.025,y:154}).wait(1).to({graphics:mask_graphics_385,x:32.725,y:154}).wait(1).to({graphics:mask_graphics_386,x:31.725,y:154}).wait(1).to({graphics:mask_graphics_387,x:30.975,y:154}).wait(1).to({graphics:mask_graphics_388,x:30.525,y:154}).wait(1).to({graphics:mask_graphics_389,x:30.275,y:154}).wait(1).to({graphics:mask_graphics_390,x:30.175,y:154}).wait(25).to({graphics:mask_graphics_415,x:30.175,y:154}).wait(33));

	// Mac_obj_
	this.Mac = new lib.Intro_Mac();
	this.Mac.name = "Mac";
	this.Mac.parent = this;
	this.Mac.setTransform(152.3,150.6,1,1,0,0,0,152.3,150.6);
	this.Mac.depth = 0;
	this.Mac.isAttachedToCamera = 0
	this.Mac.isAttachedToMask = 0
	this.Mac.layerDepth = 0
	this.Mac.layerIndex = 2
	this.Mac.maskLayerName = 0

	var maskedShapeInstanceList = [this.Mac];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Mac).wait(15).to({regY:234.7,y:234.7},0).wait(16).to({regY:150.6,y:150.6},0).wait(417));

	// MacBookMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_170 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_171 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_172 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_173 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_174 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_175 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_176 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_177 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_178 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_179 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_180 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_181 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_182 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_183 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_184 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_185 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_186 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_187 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_188 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_189 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_190 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_191 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_192 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_193 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_194 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_195 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_196 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_197 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_198 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_199 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_200 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_201 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_202 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_203 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_204 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_205 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_206 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_207 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_208 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_209 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_210 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_280 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_281 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_282 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_283 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_284 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_285 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_286 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_287 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_288 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_289 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_290 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_291 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_292 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_293 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_294 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_295 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_296 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_297 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_298 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_299 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_300 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_301 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_302 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_303 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_304 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_305 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_306 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_307 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_308 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_309 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_310 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_311 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_312 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_313 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_314 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_315 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_316 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_317 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_318 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_319 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_320 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_321 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_322 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_323 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_324 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_363 = new cjs.Graphics().p("Ai7SSIAA4+MAl8AAAIAAY+g");
	var mask_1_graphics_364 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_365 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_366 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_367 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_368 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_369 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_370 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_371 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_372 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_373 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_374 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_375 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_376 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_377 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_378 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_379 = new cjs.Graphics().p("Ay9MfIAA49MAl7AAAIAAY9g");
	var mask_1_graphics_380 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_381 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_382 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_383 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_384 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_385 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_386 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_387 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_388 = new cjs.Graphics().p("Ay9MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_389 = new cjs.Graphics().p("Ay+MfIAA49MAl8AAAIAAY9g");
	var mask_1_graphics_390 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");
	var mask_1_graphics_415 = new cjs.Graphics().p("Ay+MfIAA49MAl9AAAIAAY9g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(170).to({graphics:mask_1_graphics_170,x:371.05,y:154}).wait(1).to({graphics:mask_1_graphics_171,x:356.6,y:154}).wait(1).to({graphics:mask_1_graphics_172,x:343.15,y:154}).wait(1).to({graphics:mask_1_graphics_173,x:330.8,y:154}).wait(1).to({graphics:mask_1_graphics_174,x:319.35,y:154}).wait(1).to({graphics:mask_1_graphics_175,x:308.85,y:154}).wait(1).to({graphics:mask_1_graphics_176,x:299.2,y:154}).wait(1).to({graphics:mask_1_graphics_177,x:290.4,y:154}).wait(1).to({graphics:mask_1_graphics_178,x:282.3,y:154}).wait(1).to({graphics:mask_1_graphics_179,x:274.95,y:154}).wait(1).to({graphics:mask_1_graphics_180,x:268.3,y:154}).wait(1).to({graphics:mask_1_graphics_181,x:262.3,y:154}).wait(1).to({graphics:mask_1_graphics_182,x:256.85,y:154}).wait(1).to({graphics:mask_1_graphics_183,x:251.95,y:154}).wait(1).to({graphics:mask_1_graphics_184,x:247.6,y:154}).wait(1).to({graphics:mask_1_graphics_185,x:243.7,y:154}).wait(1).to({graphics:mask_1_graphics_186,x:240.25,y:154}).wait(1).to({graphics:mask_1_graphics_187,x:237.2,y:154}).wait(1).to({graphics:mask_1_graphics_188,x:234.5,y:154}).wait(1).to({graphics:mask_1_graphics_189,x:232.15,y:154}).wait(1).to({graphics:mask_1_graphics_190,x:230.15,y:154}).wait(1).to({graphics:mask_1_graphics_191,x:228.4,y:154}).wait(1).to({graphics:mask_1_graphics_192,x:226.9,y:154}).wait(1).to({graphics:mask_1_graphics_193,x:225.65,y:154}).wait(1).to({graphics:mask_1_graphics_194,x:224.6,y:154}).wait(1).to({graphics:mask_1_graphics_195,x:223.7,y:154}).wait(1).to({graphics:mask_1_graphics_196,x:223,y:154}).wait(1).to({graphics:mask_1_graphics_197,x:222.45,y:154}).wait(1).to({graphics:mask_1_graphics_198,x:221.95,y:154}).wait(1).to({graphics:mask_1_graphics_199,x:221.6,y:154}).wait(1).to({graphics:mask_1_graphics_200,x:221.35,y:154}).wait(1).to({graphics:mask_1_graphics_201,x:221.15,y:154}).wait(1).to({graphics:mask_1_graphics_202,x:221,y:154}).wait(1).to({graphics:mask_1_graphics_203,x:220.9,y:154}).wait(1).to({graphics:mask_1_graphics_204,x:220.85,y:154}).wait(1).to({graphics:mask_1_graphics_205,x:220.8,y:154}).wait(1).to({graphics:mask_1_graphics_206,x:220.75,y:154}).wait(1).to({graphics:mask_1_graphics_207,x:220.75,y:154}).wait(1).to({graphics:mask_1_graphics_208,x:220.75,y:154}).wait(1).to({graphics:mask_1_graphics_209,x:220.75,y:154}).wait(1).to({graphics:mask_1_graphics_210,x:220.75,y:154}).wait(70).to({graphics:mask_1_graphics_280,x:220.75,y:154}).wait(1).to({graphics:mask_1_graphics_281,x:220.8,y:154}).wait(1).to({graphics:mask_1_graphics_282,x:221.05,y:154}).wait(1).to({graphics:mask_1_graphics_283,x:221.4,y:154}).wait(1).to({graphics:mask_1_graphics_284,x:221.95,y:154}).wait(1).to({graphics:mask_1_graphics_285,x:222.7,y:154}).wait(1).to({graphics:mask_1_graphics_286,x:223.65,y:154}).wait(1).to({graphics:mask_1_graphics_287,x:224.8,y:154}).wait(1).to({graphics:mask_1_graphics_288,x:226.2,y:154}).wait(1).to({graphics:mask_1_graphics_289,x:227.85,y:154}).wait(1).to({graphics:mask_1_graphics_290,x:229.75,y:154}).wait(1).to({graphics:mask_1_graphics_291,x:231.95,y:154}).wait(1).to({graphics:mask_1_graphics_292,x:234.5,y:154}).wait(1).to({graphics:mask_1_graphics_293,x:237.35,y:154}).wait(1).to({graphics:mask_1_graphics_294,x:240.55,y:154}).wait(1).to({graphics:mask_1_graphics_295,x:244.1,y:154}).wait(1).to({graphics:mask_1_graphics_296,x:248,y:154}).wait(1).to({graphics:mask_1_graphics_297,x:252.25,y:154}).wait(1).to({graphics:mask_1_graphics_298,x:256.85,y:154}).wait(1).to({graphics:mask_1_graphics_299,x:261.65,y:154}).wait(1).to({graphics:mask_1_graphics_300,x:266.7,y:154}).wait(1).to({graphics:mask_1_graphics_301,x:271.8,y:154}).wait(1).to({graphics:mask_1_graphics_302,x:276.95,y:154}).wait(1).to({graphics:mask_1_graphics_303,x:282,y:154}).wait(1).to({graphics:mask_1_graphics_304,x:286.9,y:154}).wait(1).to({graphics:mask_1_graphics_305,x:291.55,y:154}).wait(1).to({graphics:mask_1_graphics_306,x:295.9,y:154}).wait(1).to({graphics:mask_1_graphics_307,x:299.95,y:154}).wait(1).to({graphics:mask_1_graphics_308,x:303.65,y:154}).wait(1).to({graphics:mask_1_graphics_309,x:307,y:154}).wait(1).to({graphics:mask_1_graphics_310,x:310,y:154}).wait(1).to({graphics:mask_1_graphics_311,x:312.7,y:154}).wait(1).to({graphics:mask_1_graphics_312,x:315.15,y:154}).wait(1).to({graphics:mask_1_graphics_313,x:317.25,y:154}).wait(1).to({graphics:mask_1_graphics_314,x:319.15,y:154}).wait(1).to({graphics:mask_1_graphics_315,x:320.75,y:154}).wait(1).to({graphics:mask_1_graphics_316,x:322.15,y:154}).wait(1).to({graphics:mask_1_graphics_317,x:323.35,y:154}).wait(1).to({graphics:mask_1_graphics_318,x:324.3,y:154}).wait(1).to({graphics:mask_1_graphics_319,x:325.1,y:154}).wait(1).to({graphics:mask_1_graphics_320,x:325.75,y:154}).wait(1).to({graphics:mask_1_graphics_321,x:326.2,y:154}).wait(1).to({graphics:mask_1_graphics_322,x:326.55,y:154}).wait(1).to({graphics:mask_1_graphics_323,x:326.75,y:154}).wait(1).to({graphics:mask_1_graphics_324,x:326.8,y:154}).wait(39).to({graphics:mask_1_graphics_363,x:224.125,y:116.95}).wait(1).to({graphics:mask_1_graphics_364,x:326.75,y:154}).wait(1).to({graphics:mask_1_graphics_365,x:326.5,y:154}).wait(1).to({graphics:mask_1_graphics_366,x:326.1,y:154}).wait(1).to({graphics:mask_1_graphics_367,x:325.5,y:154}).wait(1).to({graphics:mask_1_graphics_368,x:324.7,y:154}).wait(1).to({graphics:mask_1_graphics_369,x:323.6,y:154}).wait(1).to({graphics:mask_1_graphics_370,x:322.25,y:154}).wait(1).to({graphics:mask_1_graphics_371,x:320.5,y:154}).wait(1).to({graphics:mask_1_graphics_372,x:318.3,y:154}).wait(1).to({graphics:mask_1_graphics_373,x:315.65,y:154}).wait(1).to({graphics:mask_1_graphics_374,x:312.5,y:154}).wait(1).to({graphics:mask_1_graphics_375,x:308.7,y:154}).wait(1).to({graphics:mask_1_graphics_376,x:304.45,y:154}).wait(1).to({graphics:mask_1_graphics_377,x:299.8,y:154}).wait(1).to({graphics:mask_1_graphics_378,x:295.1,y:154}).wait(1).to({graphics:mask_1_graphics_379,x:290.7,y:154}).wait(1).to({graphics:mask_1_graphics_380,x:286.8,y:154}).wait(1).to({graphics:mask_1_graphics_381,x:283.55,y:154}).wait(1).to({graphics:mask_1_graphics_382,x:280.85,y:154}).wait(1).to({graphics:mask_1_graphics_383,x:278.65,y:154}).wait(1).to({graphics:mask_1_graphics_384,x:276.95,y:154}).wait(1).to({graphics:mask_1_graphics_385,x:275.65,y:154}).wait(1).to({graphics:mask_1_graphics_386,x:274.65,y:154}).wait(1).to({graphics:mask_1_graphics_387,x:273.9,y:154}).wait(1).to({graphics:mask_1_graphics_388,x:273.45,y:154}).wait(1).to({graphics:mask_1_graphics_389,x:273.2,y:154}).wait(1).to({graphics:mask_1_graphics_390,x:273.1,y:154}).wait(25).to({graphics:mask_1_graphics_415,x:273.1,y:154}).wait(33));

	// Macbook_obj_
	this.Macbook = new lib.Intro_Macbook();
	this.Macbook.name = "Macbook";
	this.Macbook.parent = this;
	this.Macbook.depth = 0;
	this.Macbook.isAttachedToCamera = 0
	this.Macbook.isAttachedToMask = 0
	this.Macbook.layerDepth = 0
	this.Macbook.layerIndex = 3
	this.Macbook.maskLayerName = 0

	var maskedShapeInstanceList = [this.Macbook];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.Macbook).wait(448));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(60.1,75.8,191.1,317.59999999999997);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(22.15,2.45,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.05,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AolCfIAAk9IRLAAIAAE9g");
	this.shape.setTransform(-7.15,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-62.2,-14.9,110.1,31.9), null);


(lib.mainMC_Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Intro
	this.anim = new lib.Intro();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(-212.05,150);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_Intro, null, null);


(lib.mainMC_CTA_BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(-23.55,568.65,0.9433,0.9401,0,0,0,0.1,0.4);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC_CTA_BG, null, null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo = this.MSFT_Logo.logo;
		this.replay_btn = this.replay.replay_btn;
		this.txtCta = this.CTA.txtCta;
		this.cta = this.CTA_BG.cta;
		this.anim = this.Intro.anim;
		if(this.smallPrint.parent == undefined || this.smallPrint.parent == this)
		this.smallPrint = this.smallPrint.smallPrint;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// MSFT_Logo_obj_
	this.MSFT_Logo = new lib.mainMC_MSFT_Logo();
	this.MSFT_Logo.name = "MSFT_Logo";
	this.MSFT_Logo.parent = this;
	this.MSFT_Logo.setTransform(-43.3,300.9,1,1,0,0,0,-43.3,300.9);
	this.MSFT_Logo.depth = 0;
	this.MSFT_Logo.isAttachedToCamera = 0
	this.MSFT_Logo.isAttachedToMask = 0
	this.MSFT_Logo.layerDepth = 0
	this.MSFT_Logo.layerIndex = 0
	this.MSFT_Logo.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.MSFT_Logo).wait(1));

	// replay_obj_
	this.replay = new lib.mainMC_replay();
	this.replay.name = "replay";
	this.replay.parent = this;
	this.replay.setTransform(10,9.6,1,1,0,0,0,10,9.6);
	this.replay.depth = 0;
	this.replay.isAttachedToCamera = 0
	this.replay.isAttachedToMask = 0
	this.replay.layerDepth = 0
	this.replay.layerIndex = 1
	this.replay.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.replay).wait(1));

	// CTA_obj_
	this.CTA = new lib.mainMC_CTA();
	this.CTA.name = "CTA";
	this.CTA.parent = this;
	this.CTA.setTransform(-42.1,571.4,1,1,0,0,0,-42.1,571.4);
	this.CTA.depth = 0;
	this.CTA.isAttachedToCamera = 0
	this.CTA.isAttachedToMask = 0
	this.CTA.layerDepth = 0
	this.CTA.layerIndex = 2
	this.CTA.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.CTA).wait(1));

	// CTA_BG_obj_
	this.CTA_BG = new lib.mainMC_CTA_BG();
	this.CTA_BG.name = "CTA_BG";
	this.CTA_BG.parent = this;
	this.CTA_BG.setTransform(-30.4,569.1,1,1,0,0,0,-30.4,569.1);
	this.CTA_BG.depth = 0;
	this.CTA_BG.isAttachedToCamera = 0
	this.CTA_BG.isAttachedToMask = 0
	this.CTA_BG.layerDepth = 0
	this.CTA_BG.layerIndex = 3
	this.CTA_BG.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.CTA_BG).wait(1));

	// Intro_obj_
	this.Intro = new lib.mainMC_Intro();
	this.Intro.name = "Intro";
	this.Intro.parent = this;
	this.Intro.setTransform(-89.5,332.5,1,1,0,0,0,-89.5,332.5);
	this.Intro.depth = 0;
	this.Intro.isAttachedToCamera = 0
	this.Intro.isAttachedToMask = 0
	this.Intro.layerDepth = 0
	this.Intro.layerIndex = 4
	this.Intro.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Intro).wait(1));

	// smallPrint_obj_
	this.smallPrint = new lib.mainMC_smallPrint();
	this.smallPrint.name = "smallPrint";
	this.smallPrint.parent = this;
	this.smallPrint.setTransform(45.2,572.9,1,1,0,0,0,45.2,572.9);
	this.smallPrint.depth = 0;
	this.smallPrint.isAttachedToCamera = 0
	this.smallPrint.isAttachedToMask = 0
	this.smallPrint.layerDepth = 0
	this.smallPrint.layerIndex = 5
	this.smallPrint.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.smallPrint).wait(1));

	// BG_obj_
	this.BG = new lib.mainMC_BG();
	this.BG.name = "BG";
	this.BG.parent = this;
	this.BG.setTransform(-58.2,298.5,1,1,0,0,0,-58.2,298.5);
	this.BG.depth = 0;
	this.BG.isAttachedToCamera = 0
	this.BG.isAttachedToMask = 0
	this.BG.layerDepth = 0
	this.BG.layerIndex = 6
	this.BG.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.BG).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-151.9,-3,206.60000000000002,606.5), null);


(lib.Scene_1_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(140,0);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_1, null, null);


// stage content:
(lib.O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_0 = function() {
		this.mainMC = this.Layer_1.mainMC;
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillFlag = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.anim.screen["flag"+aVar].flag.addChild(mc);
			}
		}
		
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = this.mainMC
		
		this.runBanner = function() {
		
			exportRoot.tlH1 = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if(i==0)exportRoot.tlH1.from(exportRoot.headline1[i], 0.7, {y: "+=30", alpha: 0, ease: Power4.easeOut});
				if(i!=0)exportRoot.tlH1.from(exportRoot.headline1[i], 0.7, {y: "+=30", alpha: 0, ease: Power4.easeOut}, "-=0.6");
			}
			exportRoot.tlH1.stop()
		
			
			exportRoot.tl1 = new TimelineLite();
			exportRoot.tl1.from(mc.replay_btn, 0.7, {alpha: 0,	x: "+=300",ease: Power4.easeOut})
			exportRoot.tl1.stop()
			
			exportRoot.tl2 = new TimelineLite();
			exportRoot.tl2.from(mc.txtCta, 0.7, {alpha: 0,	x: "+=300", ease: Power4.easeOut});
			exportRoot.tl2.from(mc.cta, 0.7, {alpha: 0,	x: "+=350",	ease: Power4.easeOut}, "-=0.7");
			exportRoot.tl2.stop()
		
			mc.logo.gotoAndPlay(1)
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.Scene_1_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(61.3,300.2,1,1,0,0,0,61.3,300.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68,297,126.69999999999999,306.5);
// library properties:
lib.properties = {
	id: 'EAB1CA27B62F25459736EE056474EF10',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_.png?1542127136565", id:"O365_MacUsrs_USA_160x600_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EAB1CA27B62F25459736EE056474EF10'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;