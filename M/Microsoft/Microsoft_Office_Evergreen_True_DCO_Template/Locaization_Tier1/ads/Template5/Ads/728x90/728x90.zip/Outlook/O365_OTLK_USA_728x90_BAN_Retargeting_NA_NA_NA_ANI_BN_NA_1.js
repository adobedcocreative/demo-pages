(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,812,324,150],[0,0,400,480],[0,482,342,328],[326,812,45,84],[0,964,167,44]]}
];


// symbols:



(lib.monitorSmall = function() {
	this.initialize(ss["O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.phone_300250 = function() {
	this.initialize(ss["O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.phoneScreen_300250 = function() {
	this.initialize(ss["O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.phoneSmall = function() {
	this.initialize(ss["O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.shadowSmall = function() {
	this.initialize(ss["O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wifi4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BBD62F").s().p("ABoAIQgxgXg3gBQg2ABgxAXQgvAXgiApIgngnQApgwA6gbQA7gdBBAAQBCAAA7AdQA6AbApAwIgnAnQgigpgvgXg");
	this.shape.setTransform(22.45,7.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wifi4, new cjs.Rectangle(0,0,44.9,14.5), null);


(lib.wifi3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BBD62F").s().p("ABJAKQgjgRgmAAQglAAgjARQggARgXAeIgigiQAdgkApgVQAsgVAvgBQAwABAsAVQApAVAdAkIgiAiQgXgegggRg");
	this.shape.setTransform(16.2,5.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wifi3, new cjs.Rectangle(0,0,32.4,11.4), null);


(lib.wifi2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BBD62F").s().p("AJiEnQkVi3lNgJQlMAJkVC3QkPCziLEkIp8p8QETmWGujtQG7j1H7gHQH9AHG7D1QGtDtETGWIp8J8QiLkkkPizg");
	this.shape.setTransform(10.2988,4.7464,0.0621,0.0621);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wifi2, new cjs.Rectangle(0,0,20.6,9.5), null);


(lib.wifi1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BBD62F").s().p("AgWAhQgNgJgEgRQgDgPAKgOQAJgOARgDQAPgDAOAKQAOAJADARQADAPgJAOQgKAOgQADIgIABQgLAAgLgIg");
	this.shape.setTransform(4.0361,4.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wifi1, new cjs.Rectangle(0,0,8.1,8.1), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(-563.35,403.05,2.4094,0.4263,0,0,0,-488,-9.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(-557.2,233.5,2339.4,347), null);


(lib.txt_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.surface = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.monitorSmall();
	this.instance.parent = this;
	this.instance.setTransform(-205,-65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.surface, new cjs.Rectangle(-205,-65,324,150), null);


(lib.screen_subEmail2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.txt.text = exportRoot.emailTime4
		//this.txt2.text = exportRoot.emailTime5
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 3
	this.txt2 = new cjs.Text("1:28 PM", "12px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.textAlign = "right";
	this.txt2.lineHeight = 18;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(161,4.85);

	this.txt = new cjs.Text("1:41 PM", "12px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.textAlign = "right";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(161,-95.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt2}]}).wait(1));

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8F8F8").s().p("AjvJBIAAi9IIBAAIAAC9gAkQmsIAAiUIIRAAIAACUg");
	this.shape.setTransform(138.5,-35.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A6rQMMAAAggXMA1XAAAMAAAAgXg");
	mask.setTransform(-0.025,0.025);

	// Layer 2
	this.instance = new lib.phone_300250();
	this.instance.parent = this;
	this.instance.setTransform(-198,-360);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_subEmail2, new cjs.Rectangle(-170.8,-103.6,341.6,207.3), null);


(lib.screen_subEmail = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.txt.text = exportRoot.emailTime2
		//this.txt2.text = exportRoot.emailTime3
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 3
	this.txt2 = new cjs.Text("1:56 PM", "12px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.textAlign = "right";
	this.txt2.lineHeight = 18;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(161,4.85);

	this.txt = new cjs.Text("2:03 PM", "12px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.textAlign = "right";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(161,-95.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt2}]}).wait(1));

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8F8F8").s().p("AjvJBIAAi9IIBAAIAAC9gAkQmsIAAiUIIRAAIAACUg");
	this.shape.setTransform(138.5,-35.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A6rQMMAAAggXMA1XAAAMAAAAgXg");
	mask.setTransform(-0.025,0.025);

	// Layer 2
	this.instance = new lib.phone_300250();
	this.instance.parent = this;
	this.instance.setTransform(-198,-360);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_subEmail, new cjs.Rectangle(-170.8,-103.6,341.6,207.3), null);


(lib.screen_Email = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.txt.text = exportRoot.emailTime1
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 4
	this.txt = new cjs.Text("2:17 PM", "12px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.textAlign = "right";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(161,-200.4);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8F8F8").s().p("Aj+BJIAAiRIH9AAIAACRg");
	this.shape.setTransform(138.75,-191.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A6rIGIAAwLMA1XAAAIAAQLg");
	mask.setTransform(-0.025,-155.675);

	// Layer 2
	this.instance = new lib.phone_300250();
	this.instance.parent = this;
	this.instance.setTransform(-198,-360);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_Email, new cjs.Rectangle(-170.8,-207.5,341.6,103.7), null);


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.red_x = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(2.1,1,1).p("AAAAAIgoAnAglgmIAlAmIApAnAAlgmIglAm");
	this.shape.setTransform(4.075,3.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.red_x, new cjs.Rectangle(-1,-1,10.2,9.9), null);


(lib.pen3d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.phoneSmall();
	this.instance.parent = this;
	this.instance.setTransform(-23,-42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 5
	this.instance_1 = new lib.shadowSmall();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-123,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.pen3d, new cjs.Rectangle(-123,-42,167,105), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Inner_C = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(44,129,186,0)","#2C81BA","rgba(44,129,186,0.008)"],[0.553,0.769,0.969],0,0,0,0,0,80.5).s().p("Ao0I0QjpjpAAlLQAAlJDpjqQDrjqFJAAQFKAADqDqQDqDqAAFJQAAFLjqDpQjqDqlKAAQlJAAjrjqg");
	this.shape.setTransform(79.8,79.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Inner_C, new cjs.Rectangle(0,0,159.6,159.7), null);


(lib.emailScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//this.txt.text = exportRoot.emailTime1
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 3
	this.txt = new cjs.Text("2:03 PM", "14px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.lineHeight = 21;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-78,-66.25);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak0BMIAAiXIJpAAIAACXg");
	this.shape.setTransform(-51.975,-55.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1
	this.instance = new lib.phoneScreen_300250();
	this.instance.parent = this;
	this.instance.setTransform(-171,-164);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.emailScreen, new cjs.Rectangle(-171,-164,342,328), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bg_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AsGCUIAAkoIYNAAIAAEog");
	this.shape.setTransform(77.475,14.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_cta, new cjs.Rectangle(0,0,155,29.7), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.x = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.red_x.cache(-8,-8,16,16,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.red_x = new lib.red_x();
	this.red_x.name = "red_x";
	this.red_x.parent = this;
	this.red_x.setTransform(-0.1,0,1,1,0,0,0,4,3.9);

	this.timeline.addTween(cjs.Tween.get(this.red_x).wait(1));

}).prototype = getMCSymbolPrototype(lib.x, new cjs.Rectangle(-5.1,-4.9,10.2,9.9), null);


(lib.signal_bar_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.wifi4.cache(-45,-14,90,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.wifi4 = new lib.wifi4();
	this.wifi4.name = "wifi4";
	this.wifi4.parent = this;
	this.wifi4.setTransform(-0.05,-0.05,1,1,0,0,0,22.4,7.2);

	this.timeline.addTween(cjs.Tween.get(this.wifi4).wait(1));

}).prototype = getMCSymbolPrototype(lib.signal_bar_4, new cjs.Rectangle(-22.4,-7.2,44.9,14.4), null);


(lib.signal_bar_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.wifi3.cache(-32,-11,64,22,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.wifi3 = new lib.wifi3();
	this.wifi3.name = "wifi3";
	this.wifi3.parent = this;
	this.wifi3.setTransform(0,0,1,1,0,0,0,16.2,5.7);

	this.timeline.addTween(cjs.Tween.get(this.wifi3).wait(1));

}).prototype = getMCSymbolPrototype(lib.signal_bar_3, new cjs.Rectangle(-16.2,-5.7,32.4,11.4), null);


(lib.signal_bar_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.wifi2.cache(-21,-10,42,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.wifi2 = new lib.wifi2();
	this.wifi2.name = "wifi2";
	this.wifi2.parent = this;
	this.wifi2.setTransform(0,0.05,1,1,0,0,0,10.3,4.8);

	this.timeline.addTween(cjs.Tween.get(this.wifi2).wait(1));

}).prototype = getMCSymbolPrototype(lib.signal_bar_2, new cjs.Rectangle(-10.3,-4.7,20.6,9.5), null);


(lib.signal_bar_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.wifi1.cache(-8,-8,16,16,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.wifi1 = new lib.wifi1();
	this.wifi1.name = "wifi1";
	this.wifi1.parent = this;
	this.wifi1.setTransform(-0.05,-0.05,1,1,0,0,0,4,4);

	this.timeline.addTween(cjs.Tween.get(this.wifi1).wait(1));

}).prototype = getMCSymbolPrototype(lib.signal_bar_1, new cjs.Rectangle(-4,-4,8.1,8.1), null);


(lib.signal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.x();
	this.instance.parent = this;
	this.instance.setTransform(-17.1,10.65,1.1656,1.1656,0,0,0,-0.1,0);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({alpha:1},3).wait(27));

	// signal_bar_4
	this.instance_1 = new lib.signal_bar_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(126).to({alpha:0},3).to({alpha:1},2).wait(1).to({alpha:0},3).to({alpha:1},2).wait(6).to({alpha:0},3).wait(66));

	// signal_bar_3
	this.instance_2 = new lib.signal_bar_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,-2.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(148).to({alpha:0},3).to({alpha:1},2).wait(3).to({alpha:0},2).wait(54));

	// signal_bar_2
	this.instance_3 = new lib.signal_bar_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,5.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(161).to({alpha:0},2).wait(49));

	// signal_bar_1
	this.instance_4 = new lib.signal_bar_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,12.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(165).to({alpha:0},2).wait(3).to({alpha:1},3).to({alpha:0},2).wait(37));

	// Layer 6
	this.instance_5 = new lib.signal_bar_4();
	this.instance_5.parent = this;
	this.instance_5.setTransform(0,-9.5);
	this.instance_5.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 102, 102, 0)];
	this.instance_5.cache(-24,-9,49,18);

	this.instance_6 = new lib.signal_bar_3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,-2.25);
	this.instance_6.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 102, 102, 0)];
	this.instance_6.cache(-18,-8,36,15);

	this.instance_7 = new lib.signal_bar_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0,5.1);
	this.instance_7.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 102, 102, 0)];
	this.instance_7.cache(-12,-7,25,14);

	this.instance_8 = new lib.signal_bar_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0,12.7);
	this.instance_8.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 102, 102, 0)];
	this.instance_8.cache(-6,-6,12,12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(212));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.9,-16.7,45.4,33.5);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_72 = function() {
		exportRoot.mainMC.anim.screen.gotoAndPlay(1)
	}
	this.frame_89 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(17).call(this.frame_89).wait(2));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(982.25,81.35,0.2717,0.2717,0,0,0,-40,1.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:4.4931,scaleY:4.4931,x:982.35,y:81.2},13,cjs.Ease.quadOut).to({x:804.05},12,cjs.Ease.quadInOut).to({_off:true},1).wait(64));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EA0eAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_15 = new cjs.Graphics().p("EA0SAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_16 = new cjs.Graphics().p("EAztAKLIAAvJMA5FAAAIAAPJg");
	var mask_graphics_17 = new cjs.Graphics().p("EAyuAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_18 = new cjs.Graphics().p("EAxXAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_19 = new cjs.Graphics().p("EAvnAKLIAAvJMA5FAAAIAAPJg");
	var mask_graphics_20 = new cjs.Graphics().p("EAteAKLIAAvJMA5FAAAIAAPJg");
	var mask_graphics_21 = new cjs.Graphics().p("EArUAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_22 = new cjs.Graphics().p("EApkAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_23 = new cjs.Graphics().p("EAoNAKLIAAvJMA5FAAAIAAPJg");
	var mask_graphics_24 = new cjs.Graphics().p("EAnPAKLIAAvJMA5FAAAIAAPJg");
	var mask_graphics_25 = new cjs.Graphics().p("EAmpAKLIAAvJMA5GAAAIAAPJg");
	var mask_graphics_26 = new cjs.Graphics().p("EAmdAKLIAAvJMA5FAAAIAAPJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:701.2014,y:65.0504}).wait(1).to({graphics:mask_graphics_15,x:699.9545,y:65.0504}).wait(1).to({graphics:mask_graphics_16,x:696.2139,y:65.0504}).wait(1).to({graphics:mask_graphics_17,x:689.9795,y:65.0504}).wait(1).to({graphics:mask_graphics_18,x:681.2514,y:65.0504}).wait(1).to({graphics:mask_graphics_19,x:670.0295,y:65.0504}).wait(1).to({graphics:mask_graphics_20,x:656.3139,y:65.0504}).wait(1).to({graphics:mask_graphics_21,x:642.5983,y:65.0504}).wait(1).to({graphics:mask_graphics_22,x:631.3764,y:65.0504}).wait(1).to({graphics:mask_graphics_23,x:622.6483,y:65.0504}).wait(1).to({graphics:mask_graphics_24,x:616.4139,y:65.0504}).wait(1).to({graphics:mask_graphics_25,x:612.6733,y:65.0504}).wait(1).to({graphics:mask_graphics_26,x:611.4264,y:65.0504}).wait(1).to({graphics:null,x:0,y:0}).wait(64));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(804.65,75.8,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(984.2,75.8,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:984.2},12,cjs.Ease.quadInOut).wait(65));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},12,cjs.Ease.quadInOut).wait(28).to({scaleX:2.2699,scaleY:2.2699,x:-14.6,y:11.2},28,cjs.Ease.quadInOut).to({_off:true},8).wait(1));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(863.9,86.05,1,1,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({x:-1497.65},36,cjs.Ease.quadIn).to({_off:true},3).wait(1));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(863.9,86.05,1,1,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-1481.35},36,cjs.Ease.quadIn).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2540.3,-87.4,4701,347);


(lib.cta_background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{bg_cta:0});

	// timeline functions:
	this.frame_0 = function() {
		this.bg_cta.cache(-155,-30,310,60,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg_cta = new lib.bg_cta();
	this.bg_cta.name = "bg_cta";
	this.bg_cta.parent = this;
	this.bg_cta.setTransform(77.5,14.8,1,1,0,0,0,77.5,14.8);

	this.timeline.addTween(cjs.Tween.get(this.bg_cta).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_background, new cjs.Rectangle(0,0,155,29.7), null);


(lib.circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.inner_c.cache(-160,-160,320,320,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.inner_c = new lib.Inner_C();
	this.inner_c.name = "inner_c";
	this.inner_c.parent = this;
	this.inner_c.setTransform(0,0,1,1,0,0,0,79.8,79.8);

	this.timeline.addTween(cjs.Tween.get(this.inner_c).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle, new cjs.Rectangle(-79.8,-79.8,159.6,159.7), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(23.35,2.45,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.05,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.instance = new lib.cta_background();
	this.instance.parent = this;
	this.instance.setTransform(12.7,1,1,1,0,0,0,77.5,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-64.8,-13.8,155,29.700000000000003), null);


(lib.circleAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.circle();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.0364,0.0364);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({scaleX:0.1688,scaleY:0.1688},12).to({scaleX:0.2019,scaleY:0.2019,alpha:0.6719},3).to({scaleX:0.2682,scaleY:0.2682,alpha:0},6).to({_off:true},1).wait(7));

	// Layer 1
	this.instance_1 = new lib.circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.0364,0.0364);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.1688,scaleY:0.1688},12).to({scaleX:0.2682,scaleY:0.2682,alpha:0},9).to({_off:true},1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.3,-21.3,42.8,42.8);


(lib.screens = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		exportRoot.tlH1I.play()
	}
	this.frame_119 = function() {
		exportRoot.tlH1O.play()
	}
	this.frame_139 = function() {
		exportRoot.tlH2I.play()
	}
	this.frame_227 = function() {
		exportRoot.phoneU.play()
	}
	this.frame_274 = function() {
		exportRoot.tlH2O.play()
	}
	this.frame_294 = function() {
		exportRoot.finalframe.play()
	}
	this.frame_341 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(110).call(this.frame_119).wait(20).call(this.frame_139).wait(88).call(this.frame_227).wait(47).call(this.frame_274).wait(20).call(this.frame_294).wait(47).call(this.frame_341).wait(1));

	// Layer 6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_231 = new cjs.Graphics().p("A6tZoMAAAgzPMA1bAAAMAAAAzPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(231).to({graphics:mask_graphics_231,x:43,y:144}).wait(111));

	// Layer 2
	this.instance = new lib.emailScreen();
	this.instance.parent = this;
	this.instance.setTransform(396.8,144);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(231).to({_off:false},0).to({x:43},16,cjs.Ease.get(1)).wait(95));

	// Layer 5
	this.instance_1 = new lib.circleAnim("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(59.45,35.6,4.3241,4.3241);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(205).to({_off:false},0).wait(137));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(16,111,188,0.137)").s().p("A58IQIAAwfMAz5AAAIAAQfg");
	this.shape.setTransform(48.375,31.825);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(211).to({_off:false},0).wait(131));

	// wifi
	this.instance_2 = new lib.signal("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(181.45,-85.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(342));

	// screen_subEmail
	this.instance_3 = new lib.screen_subEmail();
	this.instance_3.parent = this;
	this.instance_3.setTransform(43.4,82.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({y:82.8841},0).wait(1).to({y:84.0751},0).wait(1).to({y:86.1286},0).wait(1).to({y:89.093},0).wait(1).to({y:93.0016},0).wait(1).to({y:97.8627},0).wait(1).to({y:103.6474},0).wait(1).to({y:110.277},0).wait(1).to({y:117.6139},0).wait(1).to({y:125.4607},0).wait(1).to({y:133.5722},0).wait(1).to({y:141.6797},0).wait(1).to({y:149.5213},0).wait(1).to({y:156.8707},0).wait(1).to({y:163.5544},0).wait(1).to({y:169.4572},0).wait(1).to({y:174.5167},0).wait(1).to({y:178.7129},0).wait(1).to({y:182.0562},0).wait(1).to({y:184.5769},0).wait(1).to({y:186.3173},0).wait(1).to({y:187.3251},0).wait(1).to({y:187.65},0).wait(280));

	// screen_subEmail2
	this.instance_4 = new lib.screen_subEmail2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(43.4,287.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(40).to({y:287.8841},0).wait(1).to({y:289.0751},0).wait(1).to({y:291.1286},0).wait(1).to({y:294.093},0).wait(1).to({y:298.0016},0).wait(1).to({y:302.8627},0).wait(1).to({y:308.6474},0).wait(1).to({y:315.277},0).wait(1).to({y:322.6139},0).wait(1).to({y:330.4607},0).wait(1).to({y:338.5722},0).wait(1).to({y:346.6797},0).wait(1).to({y:354.5213},0).wait(1).to({y:361.8707},0).wait(1).to({y:368.5544},0).wait(1).to({y:374.4572},0).wait(1).to({y:379.5167},0).wait(1).to({y:383.7129},0).wait(1).to({y:387.0562},0).wait(1).to({y:389.5769},0).wait(1).to({y:391.3173},0).wait(1).to({y:392.325},0).wait(1).to({y:392.65},0).wait(280));

	// screen_NEW_Email
	this.instance_5 = new lib.screen_Email();
	this.instance_5.parent = this;
	this.instance_5.setTransform(45.4,177.95,1,1,0,0,0,2,-120);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(40).to({regX:0,regY:-155.7,x:43.4,y:141.75},0).wait(1).to({y:140.3},0).wait(1).to({y:137.85},0).wait(1).to({y:134.4},0).wait(1).to({y:130},0).wait(1).to({y:124.65},0).wait(1).to({y:118.45},0).wait(1).to({y:111.55},0).wait(1).to({y:104.05},0).wait(1).to({y:96.15},0).wait(1).to({y:88.1},0).wait(1).to({y:80.1},0).wait(1).to({y:72.3},0).wait(1).to({y:64.95},0).wait(1).to({y:58.15},0).wait(1).to({y:52.05},0).wait(1).to({y:46.75},0).wait(1).to({y:42.2},0).wait(1).to({y:38.55},0).wait(1).to({y:35.7},0).wait(1).to({y:33.75},0).wait(1).to({y:32.55},0).wait(1).to({regX:2,regY:-120,x:45.4,y:67.9},0).wait(280));

	// Layer 10
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAFAFA").s().p("A6tZ7MAAAgz1MA1bAAAMAAAAz1g");
	this.shape_1.setTransform(43.2,146.225);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(342));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-154.6,-277.5,400,790.2);


(lib.Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// screen
	this.screen = new lib.screens();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(57.7,124.35,0.445,0.445,0,0,0,0.1,0.5);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// phone_300250.png
	this.instance = new lib.phone_300250();
	this.instance.parent = this;
	this.instance.setTransform(-11.1,47.5,0.445,0.445);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Intro, new cjs.Rectangle(-11.1,0.7,178,309.40000000000003), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSFT Logo
	this.logo = new lib.logos();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.9,19.15,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(712.1,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(667,60,0.4964,0.4964);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(688.1,58.2,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// device_2
	this.device_2 = new lib.pen3d();
	this.device_2.name = "device_2";
	this.device_2.parent = this;
	this.device_2.setTransform(257.5,63.6,0.5134,0.5134,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.device_2).wait(1));

	// device_1
	this.device_1 = new lib.surface();
	this.device_1.name = "device_1";
	this.device_1.parent = this;
	this.device_1.setTransform(216.6,37.75,0.5134,0.5134,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.device_1).wait(1));

	// Intro
	this.anim = new lib.Intro();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(170.15,-32.1,0.76,0.76,0,0,0,0.2,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// Main Text
	this.smallPrint = new lib.txt_6();
	this.smallPrint.name = "smallPrint";
	this.smallPrint.parent = this;
	this.smallPrint.setTransform(199.4,239.95,0.4965,0.4965,0,0,0,0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.smallPrint).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-31.5,773,235.2), null);


// stage content:
(lib.O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "cost" && data[keys[i]].length > 1) {
							exportRoot.fillPriceMc(data[keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillPriceMc = function (txtDetails) {
		
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
		
				this.mainMC.bg_circle.addChild(mc);
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		/*exportRoot.finalframe = new TimelineLite();
			exportRoot.finalframe.to(mc.anim, 1, {y: "+=140", ease: Power4.easeIn}, "-=.8")
			for (var i = 0; i < exportRoot.headline3_1.length; i++) {
				exportRoot.finalframe.from(exportRoot.headline3_1[i], 0.5, {x: "+=300",	alpha: 0, ease: Power2.easeOut}, "-=0.3");
			}
			exportRoot.finalframe.from(mc.device_1, 1, {y: "-=100", ease: Power4.easeOut}, "-=.5")
			exportRoot.finalframe.from(mc.device_2, 1, {y: "-=100", ease: Power4.easeOut}, "-=.9")
			exportRoot.finalframe.to(mc.bg_circle, 0.7, { alpha: 1,	x: "-=300",	 ease:Power4.easeOut}, "-=1.8")
			exportRoot.finalframe.to(mc.txtCta, 0.7, { alpha: 1,	x: "-=300",	 ease:Power4.easeOut}, "-=0.7");
			exportRoot.finalframe.to(mc.cta, 0.7, {	alpha: 1,	x: "-=300",	 ease:Power4.easeOut}, "-=0.7");*/
		this.runBanner = function() {
		
			exportRoot.finalframe = new TimelineLite();
			for (var i = 0; i < exportRoot.headline3.length; i++) {
				if (i==0) exportRoot.finalframe.from(exportRoot.headline3[i], 0.4, {x: "+=300", alpha:0, ease: Power2.easeOut});
				if (i!=0) exportRoot.finalframe.from(exportRoot.headline3[i], 0.4, {x: "+=300", alpha:0, ease: Power2.easeOut}, "-=0.35");
			}
			exportRoot.finalframe.from(mc.device_1, 1, {y: "-=100", ease: Power4.easeOut}, "-=.4")
			exportRoot.finalframe.from(mc.device_2, 1, {y: "-=100", ease: Power4.easeOut}, "-=.9")
			exportRoot.finalframe.from(mc.replay_btn, 0.7, {alpha: 0, ease: Power4.easeOut}, "-=0.5")
			exportRoot.finalframe.from(mc.txtCta, 0.7, { alpha: 0,	x: "+=300",	 ease:Power4.easeOut}, "-=0.7");
			exportRoot.finalframe.from(mc.cta, 0.7, {	alpha: 0,	x: "+=300",	 ease:Power4.easeOut}, "-=0.7");
		
			exportRoot.finalframe.stop()
			
			exportRoot.tlH1I = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tlH1I.from(exportRoot.headline1[i], 0.4, { x: "+=20", alpha: 0, ease:Sine.easeOut});
				if (i!=0) exportRoot.tlH1I.from(exportRoot.headline1[i], 0.4, { x: "+=20", alpha: 0, ease:Sine.easeOut}, "-=0.35");
			}
			exportRoot.tlH1I.stop()
			
			exportRoot.tlH1O = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tlH1O.to(exportRoot.headline1[i], 0.3, {alpha: 0, ease:Sine.easeIn});
				if (i!=0) exportRoot.tlH1O.to(exportRoot.headline1[i], 0.3, {alpha: 0, ease:Sine.easeIn}, "-=0.28");
			}
			exportRoot.tlH1O.stop()	
				
			exportRoot.tlH2I = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tlH2I.from(exportRoot.headline2[i], 0.4, { x: "+=20", alpha: 0, ease:Sine.easeOut});
				if (i!=0) exportRoot.tlH2I.from(exportRoot.headline2[i], 0.4, { x: "+=20", alpha: 0, ease:Sine.easeOut}, "-=0.35");
			}
			exportRoot.tlH2I.stop()
			
			exportRoot.tlH2O = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tlH2O.to(exportRoot.headline2[i], 0.3, {alpha: 0, ease:Sine.easeIn, onStart: function(){exportRoot.phoneO.play()}});
				if (i!=0) exportRoot.tlH2O.to(exportRoot.headline2[i], 0.3, {alpha: 0, ease:Sine.easeIn}, "-=0.28");
			}
			exportRoot.tlH2O.stop()	
			
			exportRoot.phoneU = new TimelineLite();
				exportRoot.phoneU.to(mc.anim, .8, {y: "-=40", ease: Power2.easeInOut})
			exportRoot.phoneU.stop()	
			
			exportRoot.phoneO = new TimelineLite();
				exportRoot.phoneO.to(mc.anim, .8, {y: "+=140", ease: Power4.easeIn})
			exportRoot.phoneO.stop()	
		
			mc.logo.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,13.5,409,226.3);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_.png?1542128626748", id:"O365_OTLK_USA_728x90_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;