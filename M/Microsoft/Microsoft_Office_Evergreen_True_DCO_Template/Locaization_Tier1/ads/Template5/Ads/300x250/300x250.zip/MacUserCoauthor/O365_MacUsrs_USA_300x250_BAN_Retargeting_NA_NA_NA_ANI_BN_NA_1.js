(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_", frames: [[342,426,169,85],[193,252,171,85],[519,404,171,85],[0,335,171,85],[346,339,171,85],[692,404,171,85],[173,339,171,85],[366,252,171,85],[0,509,169,85],[171,513,169,85],[513,491,169,85],[0,422,169,85],[171,426,169,85],[855,491,169,85],[684,491,169,85],[684,665,169,85],[0,596,169,85],[342,600,169,85],[513,665,169,85],[342,513,169,85],[513,578,169,85],[171,600,169,85],[684,578,169,85],[855,578,169,85],[302,0,300,250],[0,0,300,250],[604,0,300,202],[604,204,300,198],[0,252,191,81]]}
];


// symbols:



(lib.Bitmap10 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap11 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap12 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap13 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap14 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap15 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap16 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap17 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap19 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap22 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap7 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap8 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap9 = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.mac = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Macbook = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.macbookscreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.MacScreen = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.transform = function() {
	this.initialize(ss["O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.txt_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap2();
	this.instance.parent = this;

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.parent = this;

	this.instance_2 = new lib.Bitmap4();
	this.instance_2.parent = this;

	this.instance_3 = new lib.Bitmap5();
	this.instance_3.parent = this;

	this.instance_4 = new lib.Bitmap6();
	this.instance_4.parent = this;

	this.instance_5 = new lib.Bitmap7();
	this.instance_5.parent = this;

	this.instance_6 = new lib.Bitmap8();
	this.instance_6.parent = this;

	this.instance_7 = new lib.Bitmap9();
	this.instance_7.parent = this;

	this.instance_8 = new lib.Bitmap10();
	this.instance_8.parent = this;

	this.instance_9 = new lib.Bitmap11();
	this.instance_9.parent = this;

	this.instance_10 = new lib.Bitmap12();
	this.instance_10.parent = this;

	this.instance_11 = new lib.Bitmap13();
	this.instance_11.parent = this;

	this.instance_12 = new lib.Bitmap14();
	this.instance_12.parent = this;

	this.instance_13 = new lib.Bitmap15();
	this.instance_13.parent = this;

	this.instance_14 = new lib.Bitmap16();
	this.instance_14.parent = this;

	this.instance_15 = new lib.Bitmap17();
	this.instance_15.parent = this;

	this.instance_16 = new lib.Bitmap18();
	this.instance_16.parent = this;

	this.instance_17 = new lib.Bitmap19();
	this.instance_17.parent = this;

	this.instance_18 = new lib.Bitmap20();
	this.instance_18.parent = this;

	this.instance_19 = new lib.Bitmap21();
	this.instance_19.parent = this;

	this.instance_20 = new lib.Bitmap22();
	this.instance_20.parent = this;

	this.instance_21 = new lib.Bitmap23();
	this.instance_21.parent = this;

	this.instance_22 = new lib.Bitmap24();
	this.instance_22.parent = this;

	this.instance_23 = new lib.Bitmap25();
	this.instance_23.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,171,85);


(lib.replay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.person = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiDB+IAAgFQAAgXANgQQANgRAbgKQAJgEAbgCQACgHABgLQgPgMgJgTQgIgTAAgXQAAgqALgRQAPgYAtAAQAtAAAQAYQALASAAApQAAAXgJATQgJAUgPAMQABAMADAGQAYACALADQA2APAAAzIAAAFg");
	this.shape.setTransform(0.025,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.person, new cjs.Rectangle(-13.1,-12.6,26.299999999999997,25.2), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Macbook_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Macbook();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Macbook_1, new cjs.Rectangle(0,0,300,250), null);


(lib.Mac = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mac();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.96,0.96);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Mac, new cjs.Rectangle(0,0,288,240), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Image = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Transform
	this.instance = new lib.transform();
	this.instance.parent = this;
	this.instance.setTransform(56.4,55.15,0.9714,1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("As5FDIAAqFIZzAAIAAKFg");
	var mask_graphics_1 = new cjs.Graphics().p("As5FDIAAqFIZzAAIAAKFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:150.15,y:96}).wait(1).to({graphics:mask_graphics_1,x:150.15,y:96}).wait(1));

	// Layer_1
	this.instance_1 = new lib.macbookscreen();
	this.instance_1.parent = this;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(56.4,55.2,185.6,80.99999999999999);


(lib.flag_2_name = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.txt = new cjs.Text("", "32px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 43;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-11.5,-22.55);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("AoWDBIAAmBIQtAAIAAGBg");
	this.shape.setTransform(35.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],-1.4,-2,-1.4,2).s().p("AoWAUIAAgnIQtAAIAAAng");
	this.shape_1.setTransform(35.5,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_2_name, new cjs.Rectangle(-18,-24.5,108.5,47.8), null);


(lib.flag_1_name = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.txt = new cjs.Text("", "32px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 43;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(-11.5,-22.55);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("AoWDBIAAmBIQtAAIAAGBg");
	this.shape.setTransform(35.5,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],-1.4,-2,-1.4,2).s().p("AoWAUIAAgnIQtAAIAAAng");
	this.shape_1.setTransform(35.5,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_1_name, new cjs.Rectangle(-18,-24.5,108.5,47.8), null);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("AglELIAAoVIBLAAIAAIVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.7,7.5,53.5);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("AglELIAAoVIBLAAIAAIVg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.7,7.5,53.5);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replay("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.flag_2_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.person();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1BB194").s().p("Ai9DBIAAmBIF7AAIAAGBg");
	this.shape.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],35.1,-2,35.1,2).s().p("Ai9AUIAAgnIF7AAIAAAng");
	this.shape_1.setTransform(-1,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_2_square, new cjs.Rectangle(-20,-19.2,38,42.5), null);


(lib.flag_1_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.person();
	this.instance.parent = this;
	this.instance.setTransform(-1.5,-0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9694D").s().p("Ai9DBIAAmBIF7AAIAAGBg");
	this.shape.setTransform(-1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.2)","rgba(0,0,0,0)"],[0,1],35.4,-2,35.4,2).s().p("AjAAUIAAgnIGBAAIAAAng");
	this.shape_1.setTransform(-1.25,21.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.flag_1_square, new cjs.Rectangle(-20.5,-19.2,38.5,42.5), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_63 = function() {
		exportRoot.mainMC.anim.gotoAndPlay(1)
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(63).call(this.frame_63).wait(11).call(this.frame_74).wait(10));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298.95,339.4,0.2717,0.2717,0,0,0,-40,1.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:4.4931,scaleY:4.4931,x:299.05,y:339.25},13,cjs.Ease.quadOut).to({x:120.75},12,cjs.Ease.quadInOut).to({_off:true},1).wait(57));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ag5eVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_14 = new cjs.Graphics().p("Ag5eVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_15 = new cjs.Graphics().p("AhGeVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_16 = new cjs.Graphics().p("AhreVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_17 = new cjs.Graphics().p("AipeVIAAvKMA5EAAAIAAPKg");
	var mask_graphics_18 = new cjs.Graphics().p("AkBeVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_19 = new cjs.Graphics().p("AlxeVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_20 = new cjs.Graphics().p("An6eVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_21 = new cjs.Graphics().p("AqDeVIAAvKMA5EAAAIAAPKg");
	var mask_graphics_22 = new cjs.Graphics().p("ArzeVIAAvKMA5EAAAIAAPKg");
	var mask_graphics_23 = new cjs.Graphics().p("AtLeVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_24 = new cjs.Graphics().p("AuJeVIAAvKMA5FAAAIAAPKg");
	var mask_graphics_25 = new cjs.Graphics().p("AuueVIAAvKMA5EAAAIAAPKg");
	var mask_graphics_26 = new cjs.Graphics().p("Au7eVIAAvKMA5FAAAIAAPKg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:359.5514,y:194.0754}).wait(14).to({graphics:mask_graphics_14,x:359.5514,y:194.0754}).wait(1).to({graphics:mask_graphics_15,x:358.3045,y:194.0754}).wait(1).to({graphics:mask_graphics_16,x:354.5639,y:194.0754}).wait(1).to({graphics:mask_graphics_17,x:348.3295,y:194.0754}).wait(1).to({graphics:mask_graphics_18,x:339.6014,y:194.0754}).wait(1).to({graphics:mask_graphics_19,x:328.3795,y:194.0754}).wait(1).to({graphics:mask_graphics_20,x:314.6639,y:194.0754}).wait(1).to({graphics:mask_graphics_21,x:300.9483,y:194.0754}).wait(1).to({graphics:mask_graphics_22,x:289.7264,y:194.0754}).wait(1).to({graphics:mask_graphics_23,x:280.9983,y:194.0754}).wait(1).to({graphics:mask_graphics_24,x:274.7639,y:194.0754}).wait(1).to({graphics:mask_graphics_25,x:271.0233,y:194.0754}).wait(1).to({graphics:mask_graphics_26,x:269.7764,y:194.0754}).wait(1).to({graphics:null,x:0,y:0}).wait(57));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(121.35,333.85,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.9,333.85,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:300.9},12,cjs.Ease.quadInOut).wait(58));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},12,cjs.Ease.quadInOut).wait(25).to({regY:0.4,scaleX:2.2638,scaleY:2.2638,x:-14.75,y:11.6},21,cjs.Ease.quadInOut).to({_off:true},9).wait(3));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(297.95,339.3,1,1,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({x:-674.7},21,cjs.Ease.quadIn).to({_off:true},9).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,339.3,1,1,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-674.7},21,cjs.Ease.quadIn).to({_off:true},9).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160.1,-67.6,1943.6,813.9);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.aFlagMC_B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"in":1,"out":40});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_39 = function() {
		this.stop()
	}
	this.frame_64 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(25).call(this.frame_64).wait(1));

	// mask_idn
	this.instance = new lib.Tween2();
	this.instance.parent = this;
	this.instance.setTransform(0,0.5,1,0.0187,0,0,0,0,26.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({regY:0,scaleY:0.1468,y:-0.0326},0).wait(1).to({scaleY:0.2742,y:-0.0651},0).wait(1).to({scaleY:0.3953,y:-0.0959},0).wait(1).to({scaleY:0.5069,y:-0.1244},0).wait(1).to({scaleY:0.6072,y:-0.1499},0).wait(1).to({scaleY:0.6955,y:-0.1724},0).wait(1).to({scaleY:0.7716,y:-0.1918},0).wait(1).to({scaleY:0.8357,y:-0.2081},0).wait(1).to({scaleY:0.8884,y:-0.2216},0).wait(1).to({scaleY:0.9301,y:-0.2322},0).wait(1).to({scaleY:0.9615,y:-0.2402},0).wait(1).to({scaleY:0.9833,y:-0.2457},0).wait(1).to({scaleY:0.9959,y:-0.249},0).wait(1).to({regY:26.5,scaleY:1,y:26.5},0).to({_off:true},49).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AobDVIAAmoIQ3AAIAAGog");
	mask.setTransform(98.775,-5.5);

	// Layer 1
	this.flag = new lib.flag_2_name();
	this.flag.name = "flag";
	this.flag.parent = this;
	this.flag.setTransform(-46.15,-7.5);

	var maskedShapeInstanceList = [this.flag];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flag).wait(27).to({regX:35.5,regY:0.3,x:6.65,y:-7.2},0).wait(1).to({x:21.95},0).wait(1).to({x:35.55},0).wait(1).to({x:47.7},0).wait(1).to({x:58.4},0).wait(1).to({x:67.8},0).wait(1).to({x:75.9},0).wait(1).to({x:82.75},0).wait(1).to({x:88.3},0).wait(1).to({x:92.65},0).wait(1).to({x:95.75},0).wait(1).to({x:97.6},0).wait(1).to({regX:0,regY:0,x:62.75,y:-7.5},0).wait(1).to({regX:35.5,regY:0.3,x:97.45,y:-7.2},0).wait(1).to({x:95.25},0).wait(1).to({x:91.75},0).wait(1).to({x:87.05},0).wait(1).to({x:81.2},0).wait(1).to({x:74.3},0).wait(1).to({x:66.35},0).wait(1).to({x:57.3},0).wait(1).to({x:47.1},0).wait(1).to({x:35.65},0).wait(1).to({x:22.8},0).wait(1).to({x:7.9},0).wait(1).to({regX:0,regY:0,x:-46.15,y:-7.5},0).wait(13));

	// Layer 1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("Ai9DVIAAmoIF7AAIAAGog");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:21.775,y:-5.5}).wait(49).to({graphics:null,x:0,y:0}).wait(1));

	// Layer 1
	this.instance_1 = new lib.flag_2_square();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.25,-7.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(1).to({regX:-1,regY:2,x:-14.9,y:-5.5},0).wait(1).to({x:-13.95},0).wait(1).to({x:-12.45},0).wait(1).to({x:-10.45},0).wait(1).to({x:-7.95},0).wait(1).to({x:-4.95},0).wait(1).to({x:-1.4},0).wait(1).to({x:2.7},0).wait(1).to({x:7.55},0).wait(1).to({x:13.3},0).wait(1).to({regX:0,regY:0,x:21.75,y:-7.5},0).wait(26).to({x:-11},10).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.8,156.5,53.6);


(lib.aFlagMC_A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"in":1,"out":40});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_39 = function() {
		this.stop()
	}
	this.frame_64 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(25).call(this.frame_64).wait(1));

	// mask_idn
	this.instance = new lib.Tween1();
	this.instance.parent = this;
	this.instance.setTransform(0,0.5,1,0.0187,0,0,0,0,26.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({regY:0,scaleY:0.1468,y:-0.0326},0).wait(1).to({scaleY:0.2742,y:-0.0651},0).wait(1).to({scaleY:0.3953,y:-0.0959},0).wait(1).to({scaleY:0.5069,y:-0.1244},0).wait(1).to({scaleY:0.6072,y:-0.1499},0).wait(1).to({scaleY:0.6955,y:-0.1724},0).wait(1).to({scaleY:0.7716,y:-0.1918},0).wait(1).to({scaleY:0.8357,y:-0.2081},0).wait(1).to({scaleY:0.8884,y:-0.2216},0).wait(1).to({scaleY:0.9301,y:-0.2322},0).wait(1).to({scaleY:0.9615,y:-0.2402},0).wait(1).to({scaleY:0.9833,y:-0.2457},0).wait(1).to({scaleY:0.9959,y:-0.249},0).wait(1).to({regY:26.5,scaleY:1,y:26.5},0).to({_off:true},49).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AobDVIAAmoIQ3AAIAAGog");
	mask.setTransform(98.775,-5.5);

	// Layer 1
	this.flag = new lib.flag_1_name();
	this.flag.name = "flag";
	this.flag.parent = this;
	this.flag.setTransform(-46.15,-7.5);

	var maskedShapeInstanceList = [this.flag];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.flag).wait(27).to({regX:35.5,regY:0.3,x:6.65,y:-7.2},0).wait(1).to({x:21.95},0).wait(1).to({x:35.55},0).wait(1).to({x:47.7},0).wait(1).to({x:58.4},0).wait(1).to({x:67.8},0).wait(1).to({x:75.9},0).wait(1).to({x:82.75},0).wait(1).to({x:88.3},0).wait(1).to({x:92.65},0).wait(1).to({x:95.75},0).wait(1).to({x:97.6},0).wait(1).to({regX:0,regY:0,x:62.75,y:-7.5},0).wait(1).to({regX:35.5,regY:0.3,x:97.45,y:-7.2},0).wait(1).to({x:95.25},0).wait(1).to({x:91.75},0).wait(1).to({x:87.05},0).wait(1).to({x:81.2},0).wait(1).to({x:74.3},0).wait(1).to({x:66.35},0).wait(1).to({x:57.3},0).wait(1).to({x:47.1},0).wait(1).to({x:35.65},0).wait(1).to({x:22.8},0).wait(1).to({x:7.9},0).wait(1).to({regX:0,regY:0,x:-46.15,y:-7.5},0).wait(13));

	// Layer 1 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("Ai9DVIAAmoIF7AAIAAGog");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:21.775,y:-5.5}).wait(49).to({graphics:null,x:0,y:0}).wait(1));

	// Layer 1
	this.instance_1 = new lib.flag_1_square();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-14.25,-7.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(1).to({regX:-1.3,regY:2,x:-15.2,y:-5.5},0).wait(1).to({x:-14.25},0).wait(1).to({x:-12.75},0).wait(1).to({x:-10.75},0).wait(1).to({x:-8.25},0).wait(1).to({x:-5.25},0).wait(1).to({x:-1.7},0).wait(1).to({x:2.4},0).wait(1).to({x:7.25},0).wait(1).to({x:13},0).wait(1).to({regX:0,regY:0,x:21.75,y:-7.5},0).wait(26).to({x:-11},10).to({_off:true},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-26.8,156.5,53.6);


(lib.Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_34 = function() {
		this.flag2.gotoAndPlay('in')
	}
	this.frame_193 = function() {
		this.flag1.gotoAndPlay('in')
	}
	this.frame_399 = function() {
		//this.flag1.gotoAndPlay('out')
	}
	this.frame_402 = function() {
		//this.flag2.gotoAndPlay('out')
	}
	this.frame_451 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(159).call(this.frame_193).wait(206).call(this.frame_399).wait(3).call(this.frame_402).wait(49).call(this.frame_451).wait(122));

	// flag1
	this.flag1 = new lib.aFlagMC_A();
	this.flag1.name = "flag1";
	this.flag1.parent = this;
	this.flag1.setTransform(262.75,153.3,0.5502,0.5502,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.flag1).wait(220).to({x:44.85,y:165.3},25,cjs.Ease.quadInOut).wait(15).to({x:51.7},0).wait(5).to({x:58},0).wait(5).to({x:63.75},0).wait(5).to({x:71.1},0).wait(49).to({x:15.7,y:176.7},14,cjs.Ease.quadInOut).wait(9).to({x:21.45},0).wait(4).to({x:29.85},0).wait(5).to({x:36.15},0).wait(4).to({x:42.45},0).wait(4).to({x:50.85},0).wait(4).to({x:57.7},0).wait(205));

	// flag2
	this.flag2 = new lib.aFlagMC_B();
	this.flag2.name = "flag2";
	this.flag2.parent = this;
	this.flag2.setTransform(147.45,77.4,0.5502,0.5502,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.flag2).wait(78).to({x:274.2,y:127},28,cjs.Ease.cubicInOut).wait(31).to({x:128.55,y:140.8},19,cjs.Ease.quadInOut).wait(15).to({x:138},0).wait(5).to({x:146.95},0).wait(5).to({x:155.35},0).wait(5).to({x:163.35,y:140.5},0).wait(100).to({x:143.1,y:166.15},14,cjs.Ease.quadInOut).wait(9).to({x:147.3},0).wait(4).to({x:153.6},0).wait(4).to({x:160.45},0).wait(4).to({x:165.7},0).wait(4).to({x:173.05},0).wait(5).to({x:178.45,y:165.4},0).wait(243));

	// Image
	this.instance = new lib.Image("single",0);
	this.instance.parent = this;
	this.instance.setTransform(83.8,69.9,0.7686,0.7686,0,0,0,150,101.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(68).to({startPosition:1},0).wait(10).to({startPosition:1},0).to({regY:101,scaleX:1.5363,scaleY:1.5363,x:147.05,y:98.45},28,cjs.Ease.cubicInOut).wait(7).to({startPosition:0},0).wait(460));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AVzRUIAAh0MgwVAAAIAAgpIgLAAIAA8eIgLAAIAAjsMA0xAAAIAADsIghAAIAAbLIBhAAIAAB8IhhAAIAAB0gA4mNkMAuZAAAIAA7LMguZAAAgA1rqGIAAjKIL2AAIAADKg");
	mask.setTransform(152.275,104.675);

	// ScreenBG
	this.instance_1 = new lib.MacScreen();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-75,-54.45,1.5,1.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(573));

	// Layer_3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A44O+IAA1VMAxxAAAIAAVVg");
	mask_1.setTransform(144.4114,95.7809);

	// ScreenText
	this.instance_2 = new lib.Text("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(144.75,160.1,1.5,1.5,0,0,0,84.5,42.8);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(78).to({startPosition:1},0).to({y:208.4},28,cjs.Ease.cubicInOut).wait(61).to({startPosition:1},0).wait(4).to({startPosition:2},0).wait(5).to({startPosition:3},0).wait(5).to({startPosition:4},0).wait(5).to({startPosition:5},0).wait(70).to({startPosition:6},0).wait(4).to({startPosition:7},0).wait(5).to({startPosition:8},0).wait(5).to({startPosition:9},0).wait(5).to({startPosition:10},0).wait(31).to({startPosition:11},0).wait(3).to({startPosition:12},0).wait(4).to({startPosition:13},0).wait(4).to({startPosition:14},0).wait(4).to({startPosition:15},0).wait(4).to({startPosition:16},0).wait(5).to({startPosition:17},0).wait(14).to({startPosition:18},0).wait(3).to({startPosition:19},0).wait(4).to({startPosition:20},0).wait(5).to({startPosition:21},0).wait(4).to({startPosition:22},0).wait(4).to({startPosition:23},0).wait(4).to({startPosition:24},0).wait(205));

	// ScreenFill
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A4GOGIAA8LMAwNAAAIAAcLg");
	this.shape.setTransform(145.325,104.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(573));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.8,-6.1,378,221.6);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(24.2,1.55,0.92,0.92,0,0,0,10.9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(0.05,0.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("AsDCQIAAkfIYHAAIAAEfg");
	this.shape.setTransform(13,0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-64.2,-13.6,154.4,28.799999999999997), null);


(lib.Intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_7 = function() {
		exportRoot.tlH1.play()
	}
	this.frame_14 = function() {
		this.screen.play(1)
	}
	this.frame_409 = function() {
		exportRoot.tl1.play()
		exportRoot.tlH1m.play()
	}
	this.frame_423 = function() {
		exportRoot.tlH3.play()
		exportRoot.tlH2.play()
	}
	this.frame_440 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(7).call(this.frame_7).wait(7).call(this.frame_14).wait(395).call(this.frame_409).wait(14).call(this.frame_423).wait(17).call(this.frame_440).wait(236));

	// Whitebar
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVP3IAA/tIArAAIAAftg");
	this.shape.setTransform(283.35,155.325);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVP1IAA/pIArAAIAAfpg");
	this.shape_1.setTransform(149.775,155.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVPyIAA/jIArAAIAAfjg");
	this.shape_2.setTransform(149.175,155.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgVPvIAA/dIArAAIAAfdg");
	this.shape_3.setTransform(148.3,155.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVPqIAA/TIArAAIAAfTg");
	this.shape_4.setTransform(147.2,155.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVPkIAA/HIArAAIAAfHg");
	this.shape_5.setTransform(145.85,155.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVPdIAA+5IArAAIAAe5g");
	this.shape_6.setTransform(144.275,155.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVPWIAA+qIAqAAIAAeqg");
	this.shape_7.setTransform(142.4,155.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUPNIAA+YIApAAIAAeYg");
	this.shape_8.setTransform(140.325,155.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgUPCIAA+EIApAAIAAeEg");
	this.shape_9.setTransform(138,156.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgUO4IAA9vIApAAIAAdvg");
	this.shape_10.setTransform(135.425,156.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgTOrIAA9VIAnAAIAAdVg");
	this.shape_11.setTransform(132.6,156.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgTOeIAA87IAnAAIAAc7g");
	this.shape_12.setTransform(129.525,156.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgTOQIAA8fIAnAAIAAcfg");
	this.shape_13.setTransform(126.2,156.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgTOAIAA7/IAmAAIAAb/g");
	this.shape_14.setTransform(122.65,156.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgTNwIAA7fIAnAAIAAbfg");
	this.shape_15.setTransform(118.9,157.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgSNhIAA7BIAlAAIAAbBg");
	this.shape_16.setTransform(115.35,157.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgSNTIAA6lIAlAAIAAalg");
	this.shape_17.setTransform(112.025,157.575);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSNFIAA6KIAkAAIAAaKg");
	this.shape_18.setTransform(108.95,157.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgRM5IAA5xIAjAAIAAZxg");
	this.shape_19.setTransform(106.125,157.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgRMuIAA5bIAjAAIAAZbg");
	this.shape_20.setTransform(103.55,158.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgRMkIAA5HIAjAAIAAZHg");
	this.shape_21.setTransform(101.225,158.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgRMbIAA41IAiAAIAAY1g");
	this.shape_22.setTransform(99.15,158.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgQMUIAA4mIAhAAIAAYmg");
	this.shape_23.setTransform(97.275,158.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgQMNIAA4ZIAhAAIAAYZg");
	this.shape_24.setTransform(95.7,158.55);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgQMHIAA4NIAhAAIAAYNg");
	this.shape_25.setTransform(94.35,158.625);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgQMCIAA4DIAhAAIAAYDg");
	this.shape_26.setTransform(93.25,158.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgQL+IAA37IAhAAIAAX7g");
	this.shape_27.setTransform(92.375,158.725);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgQL8IAA33IAhAAIAAX3g");
	this.shape_28.setTransform(91.775,158.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgQL6IAA3zIAhAAIAAXzg");
	this.shape_29.setTransform(91.375,158.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},170).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},70).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},39).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29,p:{x:91.375}}]},1).to({state:[{t:this.shape_29,p:{x:91.275}}]},1).wait(236));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(170).to({_off:false},0).wait(1).to({x:263.7},0).wait(1).to({x:245.475},0).wait(1).to({x:228.65},0).wait(1).to({x:213.15},0).wait(1).to({x:198.85},0).wait(1).to({x:185.75},0).wait(1).to({x:173.75},0).wait(1).to({x:162.8},0).wait(1).to({x:152.825},0).wait(1).to({x:143.775},0).wait(1).to({x:135.575},0).wait(1).to({x:128.2},0).wait(1).to({x:121.575},0).wait(1).to({x:115.625},0).wait(1).to({x:110.325},0).wait(1).to({x:105.625},0).wait(1).to({x:101.475},0).wait(1).to({x:97.875},0).wait(1).to({x:94.675},0).wait(1).to({x:91.925},0).wait(1).to({x:89.575},0).wait(1).to({x:87.55},0).wait(1).to({x:85.825},0).wait(1).to({x:84.425},0).wait(1).to({x:83.225},0).wait(1).to({x:82.225},0).wait(1).to({x:81.475},0).wait(1).to({x:80.825},0).wait(1).to({x:80.325},0).wait(1).to({x:79.975},0).wait(1).to({x:79.675},0).wait(1).to({x:79.525},0).wait(1).to({x:79.375},0).wait(1).to({x:79.275},0).wait(1).to({x:79.225},0).wait(1).to({x:79.175},0).wait(74).to({x:79.1761,y:155.3274},0).wait(1).to({x:79.275,y:155.325},0).wait(1).to({x:79.575},0).wait(1).to({x:80.075},0).wait(1).to({x:80.825},0).wait(1).to({x:81.875},0).wait(1).to({x:83.125},0).wait(1).to({x:84.725},0).wait(1).to({x:86.625},0).wait(1).to({x:88.875},0).wait(1).to({x:91.475},0).wait(1).to({x:94.525},0).wait(1).to({x:97.975},0).wait(1).to({x:101.875},0).wait(1).to({x:106.25},0).wait(1).to({x:111.125},0).wait(1).to({x:116.475},0).wait(1).to({x:122.275},0).wait(1).to({x:128.525},0).wait(1).to({x:135.15},0).wait(1).to({x:142.025},0).wait(1).to({x:149.025},0).wait(1).to({x:156.075},0).wait(1).to({x:163},0).wait(1).to({x:169.675},0).wait(1).to({x:176.025},0).wait(1).to({x:181.975},0).wait(1).to({x:187.5},0).wait(1).to({x:192.55},0).wait(1).to({x:197.15},0).wait(1).to({x:201.3},0).wait(1).to({x:205},0).wait(1).to({x:208.3},0).wait(1).to({x:211.2},0).wait(1).to({x:213.75},0).wait(1).to({x:215.975},0).wait(1).to({x:217.9},0).wait(1).to({x:219.5},0).wait(1).to({x:220.85},0).wait(1).to({x:221.95},0).wait(1).to({x:222.8},0).wait(1).to({x:223.45},0).wait(1).to({x:223.9},0).wait(1).to({x:224.15},0).wait(1).to({x:224.2535,y:155.3274},0).wait(40).to({x:224.15,y:155.325},0).wait(1).to({x:223.85},0).wait(1).to({x:223.3},0).wait(1).to({x:222.5},0).wait(1).to({x:221.35},0).wait(1).to({x:219.85},0).wait(1).to({x:217.95},0).wait(1).to({x:215.55},0).wait(1).to({x:212.55},0).wait(1).to({x:208.925},0).wait(1).to({x:204.525},0).wait(1).to({x:199.35},0).wait(1).to({x:193.425},0).wait(1).to({x:187.05},0).wait(1).to({x:180.575},0).wait(1).to({x:174.525},0).wait(1).to({x:169.175},0).wait(1).to({x:164.625},0).wait(1).to({x:160.925},0).wait(1).to({x:157.925},0).wait(1).to({x:155.575},0).wait(1).to({x:153.775},0).wait(1).to({x:152.375},0).wait(1).to({x:151.425},0).wait(1).to({x:150.775},0).wait(1).to({x:150.375},0).wait(1).to({x:150.275},0).wait(20).to({x:150.175},0).to({_off:true},1).wait(265));

	// Screen
	this.screen = new lib.Screen();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(152.2,359.85,0.5513,0.5513,0,0,0,150.6,99.4);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(3).to({regX:168.9,regY:104.7,x:162.2,y:348.05},0).wait(1).to({y:332.5},0).wait(1).to({y:316.35},0).wait(1).to({y:299.95},0).wait(1).to({y:283.65},0).wait(1).to({x:162.15,y:267.85},0).wait(1).to({y:252.9},0).wait(1).to({y:239},0).wait(1).to({y:226.25},0).wait(1).to({y:214.75},0).wait(1).to({y:204.45},0).wait(1).to({x:162.1,y:195.25},0).wait(1).to({y:187.05},0).wait(1).to({y:179.8},0).wait(1).to({y:173.4},0).wait(1).to({y:167.75},0).wait(1).to({y:162.8},0).wait(1).to({y:158.45},0).wait(1).to({y:154.7},0).wait(1).to({y:151.4},0).wait(1).to({y:148.6},0).wait(1).to({y:146.2},0).wait(1).to({y:144.2},0).wait(1).to({y:142.5},0).wait(1).to({y:141.2},0).wait(1).to({y:140.15},0).wait(1).to({y:139.4},0).wait(1).to({y:138.85},0).wait(1).to({regX:150.3,regY:99.2,x:152,y:135.75},0).wait(378).to({regX:150.7,regY:99.7,scaleX:0.4487,scaleY:0.4487,x:92.8,y:141.7},31,cjs.Ease.quadInOut).wait(236));

	// MacMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_170 = new cjs.Graphics().p("A5bUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_171 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_172 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_173 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_174 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_175 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_176 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_177 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_178 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_179 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_180 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_181 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_182 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_183 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_184 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_185 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_186 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_187 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_188 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_189 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_190 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_191 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_192 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_193 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_194 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_195 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_196 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_197 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_198 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_199 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_200 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_201 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_202 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_203 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_204 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_205 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_206 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_207 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_208 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_209 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_210 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_280 = new cjs.Graphics().p("A5bUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_281 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_282 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_283 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_284 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_285 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_286 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_287 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_288 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_289 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_290 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_291 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_292 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_293 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_294 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_295 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_296 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_297 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_298 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_299 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_300 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_301 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_302 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_303 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_304 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_305 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_306 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_307 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_308 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_309 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_310 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_311 = new cjs.Graphics().p("A5aQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_312 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_313 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_314 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_315 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_316 = new cjs.Graphics().p("A5aQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_317 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_318 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_319 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_320 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_321 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_322 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_323 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_324 = new cjs.Graphics().p("A5bUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_363 = new cjs.Graphics().p("A5bUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_364 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_365 = new cjs.Graphics().p("A5aQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_366 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_367 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_368 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_369 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_370 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_371 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_372 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_373 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_374 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_375 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_376 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_377 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_378 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_379 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_380 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_381 = new cjs.Graphics().p("A5bQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_382 = new cjs.Graphics().p("A5aQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_383 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_384 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_385 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_386 = new cjs.Graphics().p("A5aQvMAAAghdMAy1AAAMAAAAhdg");
	var mask_graphics_387 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_388 = new cjs.Graphics().p("A5aQvMAAAghdMAy2AAAMAAAAhdg");
	var mask_graphics_389 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_390 = new cjs.Graphics().p("A5bUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_409 = new cjs.Graphics().p("A5bUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_graphics_410 = new cjs.Graphics().p("A5aQuMAAAghbMAy1AAAMAAAAhbg");
	var mask_graphics_411 = new cjs.Graphics().p("A5YQtMAAAghZMAyxAAAMAAAAhZg");
	var mask_graphics_412 = new cjs.Graphics().p("A5VQrMAAAghVMAyqAAAMAAAAhVg");
	var mask_graphics_413 = new cjs.Graphics().p("A5QQoMAAAghPMAyhAAAMAAAAhPg");
	var mask_graphics_414 = new cjs.Graphics().p("A5KQkMAAAghHMAyVAAAMAAAAhHg");
	var mask_graphics_415 = new cjs.Graphics().p("A5CQfMAAAgg9MAyFAAAMAAAAg9g");
	var mask_graphics_416 = new cjs.Graphics().p("A46QZMAAAggxMAx1AAAMAAAAgxg");
	var mask_graphics_417 = new cjs.Graphics().p("A4wQTMAAAgglMAxhAAAMAAAAglg");
	var mask_graphics_418 = new cjs.Graphics().p("A4lQLMAAAggVMAxKAAAMAAAAgVg");
	var mask_graphics_419 = new cjs.Graphics().p("A4YQDMAAAggFMAwxAAAMAAAAgFg");
	var mask_graphics_420 = new cjs.Graphics().p("A4KP6IAA/yMAwVAAAIAAfyg");
	var mask_graphics_421 = new cjs.Graphics().p("A36PvIAA/eMAv1AAAIAAfeg");
	var mask_graphics_422 = new cjs.Graphics().p("A3pPkIAA/HMAvTAAAIAAfHg");
	var mask_graphics_423 = new cjs.Graphics().p("A3XPZIAA+xMAuvAAAIAAexg");
	var mask_graphics_424 = new cjs.Graphics().p("A3EPMIAA+XMAuJAAAIAAeXg");
	var mask_graphics_425 = new cjs.Graphics().p("A2wO/IAA98MAthAAAIAAd8g");
	var mask_graphics_426 = new cjs.Graphics().p("A2dOxIAA9iMAs7AAAIAAdig");
	var mask_graphics_427 = new cjs.Graphics().p("A2LOmIAA9LMAsWAAAIAAdLg");
	var mask_graphics_428 = new cjs.Graphics().p("A16ObIAA81MAr1AAAIAAc1g");
	var mask_graphics_429 = new cjs.Graphics().p("A1qORIAA8hMArVAAAIAAchg");
	var mask_graphics_430 = new cjs.Graphics().p("A1cOIIAA8PMAq5AAAIAAcPg");
	var mask_graphics_431 = new cjs.Graphics().p("A1PN/IAA79MAqgAAAIAAb9g");
	var mask_graphics_432 = new cjs.Graphics().p("A1EN3IAA7tMAqJAAAIAAbtg");
	var mask_graphics_433 = new cjs.Graphics().p("A06NxIAA7hMAp1AAAIAAbhg");
	var mask_graphics_434 = new cjs.Graphics().p("A0yNrIAA7VMAplAAAIAAbVg");
	var mask_graphics_435 = new cjs.Graphics().p("A0qNmIAA7MMApVAAAIAAbMg");
	var mask_graphics_436 = new cjs.Graphics().p("A0kNjIAA7EMApJAAAIAAbEg");
	var mask_graphics_437 = new cjs.Graphics().p("A0fNfIAA69MApAAAAIAAa9g");
	var mask_graphics_438 = new cjs.Graphics().p("A0cNdIAA65MAo5AAAIAAa5g");
	var mask_graphics_439 = new cjs.Graphics().p("A0aNcIAA63MAo1AAAIAAa3g");
	var mask_graphics_440 = new cjs.Graphics().p("A0aNbIAA62MAo0AAAIAAa2g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(170).to({graphics:mask_graphics_170,x:118.9836,y:131.4718}).wait(1).to({graphics:mask_graphics_171,x:99.575,y:155.875}).wait(1).to({graphics:mask_graphics_172,x:81.575,y:155.875}).wait(1).to({graphics:mask_graphics_173,x:64.975,y:155.875}).wait(1).to({graphics:mask_graphics_174,x:49.675,y:155.875}).wait(1).to({graphics:mask_graphics_175,x:35.575,y:155.875}).wait(1).to({graphics:mask_graphics_176,x:22.65,y:155.875}).wait(1).to({graphics:mask_graphics_177,x:10.8,y:155.875}).wait(1).to({graphics:mask_graphics_178,x:0,y:155.875}).wait(1).to({graphics:mask_graphics_179,x:-9.85,y:155.875}).wait(1).to({graphics:mask_graphics_180,x:-18.8,y:155.875}).wait(1).to({graphics:mask_graphics_181,x:-26.875,y:155.875}).wait(1).to({graphics:mask_graphics_182,x:-34.15,y:155.875}).wait(1).to({graphics:mask_graphics_183,x:-40.7,y:155.875}).wait(1).to({graphics:mask_graphics_184,x:-46.575,y:155.875}).wait(1).to({graphics:mask_graphics_185,x:-51.8,y:155.875}).wait(1).to({graphics:mask_graphics_186,x:-56.45,y:155.875}).wait(1).to({graphics:mask_graphics_187,x:-60.5,y:155.875}).wait(1).to({graphics:mask_graphics_188,x:-64.1,y:155.875}).wait(1).to({graphics:mask_graphics_189,x:-67.25,y:155.875}).wait(1).to({graphics:mask_graphics_190,x:-69.95,y:155.875}).wait(1).to({graphics:mask_graphics_191,x:-72.3,y:155.875}).wait(1).to({graphics:mask_graphics_192,x:-74.3,y:155.875}).wait(1).to({graphics:mask_graphics_193,x:-75.95,y:155.875}).wait(1).to({graphics:mask_graphics_194,x:-77.4,y:155.875}).wait(1).to({graphics:mask_graphics_195,x:-78.55,y:155.875}).wait(1).to({graphics:mask_graphics_196,x:-79.5,y:155.875}).wait(1).to({graphics:mask_graphics_197,x:-80.3,y:155.875}).wait(1).to({graphics:mask_graphics_198,x:-80.9,y:155.875}).wait(1).to({graphics:mask_graphics_199,x:-81.4,y:155.875}).wait(1).to({graphics:mask_graphics_200,x:-81.75,y:155.875}).wait(1).to({graphics:mask_graphics_201,x:-82.05,y:155.875}).wait(1).to({graphics:mask_graphics_202,x:-82.25,y:155.875}).wait(1).to({graphics:mask_graphics_203,x:-82.35,y:155.875}).wait(1).to({graphics:mask_graphics_204,x:-82.45,y:155.875}).wait(1).to({graphics:mask_graphics_205,x:-82.5,y:155.875}).wait(1).to({graphics:mask_graphics_206,x:-82.55,y:155.875}).wait(1).to({graphics:mask_graphics_207,x:-82.55,y:155.875}).wait(1).to({graphics:mask_graphics_208,x:-82.55,y:155.875}).wait(1).to({graphics:mask_graphics_209,x:-82.55,y:155.875}).wait(1).to({graphics:mask_graphics_210,x:-82.55,y:155.875}).wait(70).to({graphics:mask_graphics_280,x:-82.5601,y:131.4718}).wait(1).to({graphics:mask_graphics_281,x:-82.45,y:155.875}).wait(1).to({graphics:mask_graphics_282,x:-82.15,y:155.875}).wait(1).to({graphics:mask_graphics_283,x:-81.65,y:155.875}).wait(1).to({graphics:mask_graphics_284,x:-80.9,y:155.875}).wait(1).to({graphics:mask_graphics_285,x:-79.9,y:155.875}).wait(1).to({graphics:mask_graphics_286,x:-78.65,y:155.875}).wait(1).to({graphics:mask_graphics_287,x:-77.1,y:155.875}).wait(1).to({graphics:mask_graphics_288,x:-75.25,y:155.875}).wait(1).to({graphics:mask_graphics_289,x:-73.05,y:155.875}).wait(1).to({graphics:mask_graphics_290,x:-70.5,y:155.875}).wait(1).to({graphics:mask_graphics_291,x:-67.525,y:155.875}).wait(1).to({graphics:mask_graphics_292,x:-64.15,y:155.875}).wait(1).to({graphics:mask_graphics_293,x:-60.325,y:155.875}).wait(1).to({graphics:mask_graphics_294,x:-56.025,y:155.875}).wait(1).to({graphics:mask_graphics_295,x:-51.275,y:155.875}).wait(1).to({graphics:mask_graphics_296,x:-46.025,y:155.875}).wait(1).to({graphics:mask_graphics_297,x:-40.325,y:155.875}).wait(1).to({graphics:mask_graphics_298,x:-34.2,y:155.875}).wait(1).to({graphics:mask_graphics_299,x:-27.725,y:155.875}).wait(1).to({graphics:mask_graphics_300,x:-21,y:155.875}).wait(1).to({graphics:mask_graphics_301,x:-14.125,y:155.875}).wait(1).to({graphics:mask_graphics_302,x:-7.225,y:155.875}).wait(1).to({graphics:mask_graphics_303,x:-0.475,y:155.875}).wait(1).to({graphics:mask_graphics_304,x:6.075,y:155.875}).wait(1).to({graphics:mask_graphics_305,x:12.325,y:155.875}).wait(1).to({graphics:mask_graphics_306,x:18.15,y:155.875}).wait(1).to({graphics:mask_graphics_307,x:23.55,y:155.875}).wait(1).to({graphics:mask_graphics_308,x:28.5,y:155.875}).wait(1).to({graphics:mask_graphics_309,x:33,y:155.875}).wait(1).to({graphics:mask_graphics_310,x:37.05,y:155.875}).wait(1).to({graphics:mask_graphics_311,x:40.7,y:155.875}).wait(1).to({graphics:mask_graphics_312,x:43.9,y:155.875}).wait(1).to({graphics:mask_graphics_313,x:46.775,y:155.875}).wait(1).to({graphics:mask_graphics_314,x:49.275,y:155.875}).wait(1).to({graphics:mask_graphics_315,x:51.45,y:155.875}).wait(1).to({graphics:mask_graphics_316,x:53.3,y:155.875}).wait(1).to({graphics:mask_graphics_317,x:54.9,y:155.875}).wait(1).to({graphics:mask_graphics_318,x:56.2,y:155.875}).wait(1).to({graphics:mask_graphics_319,x:57.3,y:155.875}).wait(1).to({graphics:mask_graphics_320,x:58.15,y:155.875}).wait(1).to({graphics:mask_graphics_321,x:58.75,y:155.875}).wait(1).to({graphics:mask_graphics_322,x:59.2,y:155.875}).wait(1).to({graphics:mask_graphics_323,x:59.45,y:155.875}).wait(1).to({graphics:mask_graphics_324,x:59.5507,y:131.4718}).wait(39).to({graphics:mask_graphics_363,x:59.5507,y:131.4718}).wait(1).to({graphics:mask_graphics_364,x:59.45,y:155.875}).wait(1).to({graphics:mask_graphics_365,x:59.15,y:155.875}).wait(1).to({graphics:mask_graphics_366,x:58.65,y:155.875}).wait(1).to({graphics:mask_graphics_367,x:57.85,y:155.875}).wait(1).to({graphics:mask_graphics_368,x:56.75,y:155.875}).wait(1).to({graphics:mask_graphics_369,x:55.3,y:155.875}).wait(1).to({graphics:mask_graphics_370,x:53.4,y:155.875}).wait(1).to({graphics:mask_graphics_371,x:51.1,y:155.875}).wait(1).to({graphics:mask_graphics_372,x:48.2,y:155.875}).wait(1).to({graphics:mask_graphics_373,x:44.65,y:155.875}).wait(1).to({graphics:mask_graphics_374,x:40.35,y:155.875}).wait(1).to({graphics:mask_graphics_375,x:35.35,y:155.875}).wait(1).to({graphics:mask_graphics_376,x:29.6,y:155.875}).wait(1).to({graphics:mask_graphics_377,x:23.35,y:155.875}).wait(1).to({graphics:mask_graphics_378,x:17.1,y:155.875}).wait(1).to({graphics:mask_graphics_379,x:11.2,y:155.875}).wait(1).to({graphics:mask_graphics_380,x:6,y:155.875}).wait(1).to({graphics:mask_graphics_381,x:1.6,y:155.875}).wait(1).to({graphics:mask_graphics_382,x:-2.05,y:155.875}).wait(1).to({graphics:mask_graphics_383,x:-4.95,y:155.875}).wait(1).to({graphics:mask_graphics_384,x:-7.25,y:155.875}).wait(1).to({graphics:mask_graphics_385,x:-9,y:155.875}).wait(1).to({graphics:mask_graphics_386,x:-10.35,y:155.875}).wait(1).to({graphics:mask_graphics_387,x:-11.3,y:155.875}).wait(1).to({graphics:mask_graphics_388,x:-11.95,y:155.875}).wait(1).to({graphics:mask_graphics_389,x:-12.3,y:155.875}).wait(1).to({graphics:mask_graphics_390,x:-12.4041,y:131.4718}).wait(19).to({graphics:mask_graphics_409,x:-12.4041,y:131.4718}).wait(1).to({graphics:mask_graphics_410,x:-12.45,y:155.875}).wait(1).to({graphics:mask_graphics_411,x:-12.625,y:155.9}).wait(1).to({graphics:mask_graphics_412,x:-12.9,y:155.9}).wait(1).to({graphics:mask_graphics_413,x:-13.3,y:155.925}).wait(1).to({graphics:mask_graphics_414,x:-13.825,y:155.975}).wait(1).to({graphics:mask_graphics_415,x:-14.425,y:156}).wait(1).to({graphics:mask_graphics_416,x:-15.175,y:156.025}).wait(1).to({graphics:mask_graphics_417,x:-16.025,y:156.075}).wait(1).to({graphics:mask_graphics_418,x:-16.95,y:156.125}).wait(1).to({graphics:mask_graphics_419,x:-18.025,y:156.175}).wait(1).to({graphics:mask_graphics_420,x:-19.225,y:156.25}).wait(1).to({graphics:mask_graphics_421,x:-20.525,y:156.3}).wait(1).to({graphics:mask_graphics_422,x:-21.9,y:156.4}).wait(1).to({graphics:mask_graphics_423,x:-23.45,y:156.475}).wait(1).to({graphics:mask_graphics_424,x:-25.075,y:156.575}).wait(1).to({graphics:mask_graphics_425,x:-26.775,y:156.65}).wait(1).to({graphics:mask_graphics_426,x:-28.4,y:156.75}).wait(1).to({graphics:mask_graphics_427,x:-29.95,y:156.825}).wait(1).to({graphics:mask_graphics_428,x:-31.325,y:156.925}).wait(1).to({graphics:mask_graphics_429,x:-32.625,y:156.975}).wait(1).to({graphics:mask_graphics_430,x:-33.825,y:157.05}).wait(1).to({graphics:mask_graphics_431,x:-34.9,y:157.1}).wait(1).to({graphics:mask_graphics_432,x:-35.825,y:157.15}).wait(1).to({graphics:mask_graphics_433,x:-36.675,y:157.2}).wait(1).to({graphics:mask_graphics_434,x:-37.425,y:157.225}).wait(1).to({graphics:mask_graphics_435,x:-38.025,y:157.25}).wait(1).to({graphics:mask_graphics_436,x:-38.55,y:157.3}).wait(1).to({graphics:mask_graphics_437,x:-38.95,y:157.325}).wait(1).to({graphics:mask_graphics_438,x:-39.225,y:157.325}).wait(1).to({graphics:mask_graphics_439,x:-39.4,y:157.35}).wait(1).to({graphics:mask_graphics_440,x:-39.45,y:157.35}).wait(236));

	// Mac
	this.instance = new lib.Mac();
	this.instance.parent = this;
	this.instance.setTransform(151.6,376.95,0.8331,0.8331,0,0,0,144.2,120.2);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({regX:144,regY:120,x:151.4,y:362.05},0).wait(1).to({y:346.55},0).wait(1).to({y:330.45},0).wait(1).to({y:314.05},0).wait(1).to({y:297.75},0).wait(1).to({y:281.95},0).wait(1).to({y:267},0).wait(1).to({y:253.1},0).wait(1).to({y:240.4},0).wait(1).to({y:228.95},0).wait(1).to({y:218.6},0).wait(1).to({y:209.4},0).wait(1).to({y:201.25},0).wait(1).to({y:194},0).wait(1).to({y:187.6},0).wait(1).to({y:182},0).wait(1).to({y:177},0).wait(1).to({y:172.7},0).wait(1).to({y:168.9},0).wait(1).to({y:165.65},0).wait(1).to({y:162.85},0).wait(1).to({y:160.45},0).wait(1).to({y:158.45},0).wait(1).to({y:156.75},0).wait(1).to({y:155.45},0).wait(1).to({y:154.4},0).wait(1).to({y:153.6},0).wait(1).to({y:153.1},0).wait(1).to({regX:144.2,regY:120.2,x:151.6},0).wait(378).to({regX:144.1,regY:120.3,scaleX:0.6687,scaleY:0.6686,x:92.2,y:155.25},31,cjs.Ease.quadInOut).wait(236));

	// MacBookMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_170 = new cjs.Graphics().p("AjaUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_171 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_172 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_173 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_174 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_175 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_176 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_177 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_178 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_179 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_180 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_181 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_182 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_183 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_184 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_185 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_186 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_187 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_188 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_189 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_190 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_191 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_192 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_193 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_194 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_195 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_198 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_203 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_204 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_208 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_209 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_210 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_280 = new cjs.Graphics().p("AzKUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_281 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_282 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_283 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_284 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_285 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_286 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_287 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_288 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_289 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_290 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_291 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_292 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_295 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_296 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_297 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_298 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_299 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_302 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_304 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_306 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_308 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_309 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_312 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_313 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_314 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_315 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_316 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_317 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_318 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_319 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_320 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_321 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_322 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_323 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_324 = new cjs.Graphics().p("AoDUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_363 = new cjs.Graphics().p("AoDUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_364 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_366 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_367 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_368 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_369 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_372 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_374 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_375 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_376 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_377 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_378 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_379 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_380 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_381 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_382 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_383 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_384 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_385 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_386 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_387 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_388 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_389 = new cjs.Graphics().p("A5bQvMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_390 = new cjs.Graphics().p("AtrUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_409 = new cjs.Graphics().p("AtrUjMAAAghdMAy3AAAMAAAAhdg");
	var mask_1_graphics_410 = new cjs.Graphics().p("A5aQuMAAAghbMAy1AAAMAAAAhbg");
	var mask_1_graphics_411 = new cjs.Graphics().p("A5YQtMAAAghZMAyxAAAMAAAAhZg");
	var mask_1_graphics_412 = new cjs.Graphics().p("A5VQrMAAAghVMAyrAAAMAAAAhVg");
	var mask_1_graphics_413 = new cjs.Graphics().p("A5QQoMAAAghPMAyhAAAMAAAAhPg");
	var mask_1_graphics_414 = new cjs.Graphics().p("A5KQkMAAAghHMAyWAAAMAAAAhHg");
	var mask_1_graphics_415 = new cjs.Graphics().p("A5DQfMAAAgg9MAyHAAAMAAAAg9g");
	var mask_1_graphics_416 = new cjs.Graphics().p("A46QZMAAAggxMAx1AAAMAAAAgxg");
	var mask_1_graphics_417 = new cjs.Graphics().p("A4wQTMAAAgglMAxhAAAMAAAAglg");
	var mask_1_graphics_418 = new cjs.Graphics().p("A4lQLMAAAggVMAxLAAAMAAAAgVg");
	var mask_1_graphics_419 = new cjs.Graphics().p("A4YQDMAAAggFMAwxAAAMAAAAgFg");
	var mask_1_graphics_420 = new cjs.Graphics().p("A4KP6IAA/yMAwVAAAIAAfyg");
	var mask_1_graphics_421 = new cjs.Graphics().p("A37PvIAA/eMAv3AAAIAAfeg");
	var mask_1_graphics_422 = new cjs.Graphics().p("A3qPkIAA/HMAvVAAAIAAfHg");
	var mask_1_graphics_423 = new cjs.Graphics().p("A3YPZIAA+xMAuxAAAIAAexg");
	var mask_1_graphics_424 = new cjs.Graphics().p("A3EPMIAA+XMAuJAAAIAAeXg");
	var mask_1_graphics_425 = new cjs.Graphics().p("A2wO/IAA98MAthAAAIAAd8g");
	var mask_1_graphics_426 = new cjs.Graphics().p("A2dOxIAA9iMAs7AAAIAAdig");
	var mask_1_graphics_427 = new cjs.Graphics().p("A2LOmIAA9LMAsWAAAIAAdLg");
	var mask_1_graphics_428 = new cjs.Graphics().p("A16ObIAA81MAr1AAAIAAc1g");
	var mask_1_graphics_429 = new cjs.Graphics().p("A1qORIAA8hMArVAAAIAAchg");
	var mask_1_graphics_430 = new cjs.Graphics().p("A1cOIIAA8PMAq5AAAIAAcPg");
	var mask_1_graphics_431 = new cjs.Graphics().p("A1QN/IAA79MAqhAAAIAAb9g");
	var mask_1_graphics_432 = new cjs.Graphics().p("A1EN3IAA7tMAqJAAAIAAbtg");
	var mask_1_graphics_433 = new cjs.Graphics().p("A06NxIAA7hMAp1AAAIAAbhg");
	var mask_1_graphics_434 = new cjs.Graphics().p("A0xNrIAA7VMApjAAAIAAbVg");
	var mask_1_graphics_435 = new cjs.Graphics().p("A0qNmIAA7MMApVAAAIAAbMg");
	var mask_1_graphics_436 = new cjs.Graphics().p("A0kNjIAA7EMApJAAAIAAbEg");
	var mask_1_graphics_437 = new cjs.Graphics().p("A0fNfIAA69MAo/AAAIAAa9g");
	var mask_1_graphics_438 = new cjs.Graphics().p("A0cNdIAA65MAo5AAAIAAa5g");
	var mask_1_graphics_439 = new cjs.Graphics().p("A0aNcIAA63MAo1AAAIAAa3g");
	var mask_1_graphics_440 = new cjs.Graphics().p("A0ZNbIAA62MAozAAAIAAa2g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(170).to({graphics:mask_1_graphics_170,x:303.6594,y:131.4718}).wait(1).to({graphics:mask_1_graphics_171,x:425.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_172,x:407.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_173,x:390.525,y:155.875}).wait(1).to({graphics:mask_1_graphics_174,x:375.225,y:155.875}).wait(1).to({graphics:mask_1_graphics_175,x:361.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_176,x:348.225,y:155.875}).wait(1).to({graphics:mask_1_graphics_177,x:336.375,y:155.875}).wait(1).to({graphics:mask_1_graphics_178,x:325.575,y:155.875}).wait(1).to({graphics:mask_1_graphics_179,x:315.725,y:155.875}).wait(1).to({graphics:mask_1_graphics_180,x:306.775,y:155.875}).wait(1).to({graphics:mask_1_graphics_181,x:298.675,y:155.875}).wait(1).to({graphics:mask_1_graphics_182,x:291.425,y:155.875}).wait(1).to({graphics:mask_1_graphics_183,x:284.875,y:155.875}).wait(1).to({graphics:mask_1_graphics_184,x:278.975,y:155.875}).wait(1).to({graphics:mask_1_graphics_185,x:273.775,y:155.875}).wait(1).to({graphics:mask_1_graphics_186,x:269.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_187,x:265.075,y:155.875}).wait(1).to({graphics:mask_1_graphics_188,x:261.475,y:155.875}).wait(1).to({graphics:mask_1_graphics_189,x:258.325,y:155.875}).wait(1).to({graphics:mask_1_graphics_190,x:255.625,y:155.875}).wait(1).to({graphics:mask_1_graphics_191,x:253.275,y:155.875}).wait(1).to({graphics:mask_1_graphics_192,x:251.275,y:155.875}).wait(1).to({graphics:mask_1_graphics_193,x:249.625,y:155.875}).wait(1).to({graphics:mask_1_graphics_194,x:248.175,y:155.875}).wait(1).to({graphics:mask_1_graphics_195,x:247.025,y:155.875}).wait(1).to({graphics:mask_1_graphics_196,x:246.075,y:155.875}).wait(1).to({graphics:mask_1_graphics_197,x:245.275,y:155.875}).wait(1).to({graphics:mask_1_graphics_198,x:244.675,y:155.875}).wait(1).to({graphics:mask_1_graphics_199,x:244.175,y:155.875}).wait(1).to({graphics:mask_1_graphics_200,x:243.825,y:155.875}).wait(1).to({graphics:mask_1_graphics_201,x:243.525,y:155.875}).wait(1).to({graphics:mask_1_graphics_202,x:243.325,y:155.875}).wait(1).to({graphics:mask_1_graphics_203,x:243.225,y:155.875}).wait(1).to({graphics:mask_1_graphics_204,x:243.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_205,x:243.075,y:155.875}).wait(1).to({graphics:mask_1_graphics_206,x:243.025,y:155.875}).wait(1).to({graphics:mask_1_graphics_207,x:243.025,y:155.875}).wait(1).to({graphics:mask_1_graphics_208,x:243.025,y:155.875}).wait(1).to({graphics:mask_1_graphics_209,x:243.025,y:155.875}).wait(1).to({graphics:mask_1_graphics_210,x:243.025,y:155.875}).wait(70).to({graphics:mask_1_graphics_280,x:202.8992,y:131.4718}).wait(1).to({graphics:mask_1_graphics_281,x:243.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_282,x:243.425,y:155.875}).wait(1).to({graphics:mask_1_graphics_283,x:243.925,y:155.875}).wait(1).to({graphics:mask_1_graphics_284,x:244.675,y:155.875}).wait(1).to({graphics:mask_1_graphics_285,x:245.675,y:155.875}).wait(1).to({graphics:mask_1_graphics_286,x:246.925,y:155.875}).wait(1).to({graphics:mask_1_graphics_287,x:248.475,y:155.875}).wait(1).to({graphics:mask_1_graphics_288,x:250.325,y:155.875}).wait(1).to({graphics:mask_1_graphics_289,x:252.525,y:155.875}).wait(1).to({graphics:mask_1_graphics_290,x:255.075,y:155.875}).wait(1).to({graphics:mask_1_graphics_291,x:258.075,y:155.875}).wait(1).to({graphics:mask_1_graphics_292,x:261.425,y:155.875}).wait(1).to({graphics:mask_1_graphics_293,x:265.275,y:155.875}).wait(1).to({graphics:mask_1_graphics_294,x:269.55,y:155.875}).wait(1).to({graphics:mask_1_graphics_295,x:274.325,y:155.875}).wait(1).to({graphics:mask_1_graphics_296,x:279.55,y:155.875}).wait(1).to({graphics:mask_1_graphics_297,x:285.25,y:155.875}).wait(1).to({graphics:mask_1_graphics_298,x:291.375,y:155.875}).wait(1).to({graphics:mask_1_graphics_299,x:297.85,y:155.875}).wait(1).to({graphics:mask_1_graphics_300,x:304.575,y:155.875}).wait(1).to({graphics:mask_1_graphics_301,x:311.475,y:155.875}).wait(1).to({graphics:mask_1_graphics_302,x:318.35,y:155.875}).wait(1).to({graphics:mask_1_graphics_303,x:325.125,y:155.875}).wait(1).to({graphics:mask_1_graphics_304,x:331.675,y:155.875}).wait(1).to({graphics:mask_1_graphics_305,x:337.9,y:155.875}).wait(1).to({graphics:mask_1_graphics_306,x:343.75,y:155.875}).wait(1).to({graphics:mask_1_graphics_307,x:349.15,y:155.875}).wait(1).to({graphics:mask_1_graphics_308,x:354.1,y:155.875}).wait(1).to({graphics:mask_1_graphics_309,x:358.6,y:155.875}).wait(1).to({graphics:mask_1_graphics_310,x:362.65,y:155.875}).wait(1).to({graphics:mask_1_graphics_311,x:366.3,y:155.875}).wait(1).to({graphics:mask_1_graphics_312,x:369.5,y:155.875}).wait(1).to({graphics:mask_1_graphics_313,x:372.35,y:155.875}).wait(1).to({graphics:mask_1_graphics_314,x:374.85,y:155.875}).wait(1).to({graphics:mask_1_graphics_315,x:377.05,y:155.875}).wait(1).to({graphics:mask_1_graphics_316,x:378.9,y:155.875}).wait(1).to({graphics:mask_1_graphics_317,x:380.5,y:155.875}).wait(1).to({graphics:mask_1_graphics_318,x:381.8,y:155.875}).wait(1).to({graphics:mask_1_graphics_319,x:382.9,y:155.875}).wait(1).to({graphics:mask_1_graphics_320,x:383.75,y:155.875}).wait(1).to({graphics:mask_1_graphics_321,x:384.35,y:155.875}).wait(1).to({graphics:mask_1_graphics_322,x:384.8,y:155.875}).wait(1).to({graphics:mask_1_graphics_323,x:385.05,y:155.875}).wait(1).to({graphics:mask_1_graphics_324,x:273.9663,y:131.4718}).wait(39).to({graphics:mask_1_graphics_363,x:273.9663,y:131.4718}).wait(1).to({graphics:mask_1_graphics_364,x:385.05,y:155.875}).wait(1).to({graphics:mask_1_graphics_365,x:384.75,y:155.875}).wait(1).to({graphics:mask_1_graphics_366,x:384.25,y:155.875}).wait(1).to({graphics:mask_1_graphics_367,x:383.45,y:155.875}).wait(1).to({graphics:mask_1_graphics_368,x:382.35,y:155.875}).wait(1).to({graphics:mask_1_graphics_369,x:380.9,y:155.875}).wait(1).to({graphics:mask_1_graphics_370,x:379,y:155.875}).wait(1).to({graphics:mask_1_graphics_371,x:376.7,y:155.875}).wait(1).to({graphics:mask_1_graphics_372,x:373.8,y:155.875}).wait(1).to({graphics:mask_1_graphics_373,x:370.25,y:155.875}).wait(1).to({graphics:mask_1_graphics_374,x:365.95,y:155.875}).wait(1).to({graphics:mask_1_graphics_375,x:360.95,y:155.875}).wait(1).to({graphics:mask_1_graphics_376,x:355.2,y:155.875}).wait(1).to({graphics:mask_1_graphics_377,x:348.95,y:155.875}).wait(1).to({graphics:mask_1_graphics_378,x:342.7,y:155.875}).wait(1).to({graphics:mask_1_graphics_379,x:336.8,y:155.875}).wait(1).to({graphics:mask_1_graphics_380,x:331.6,y:155.875}).wait(1).to({graphics:mask_1_graphics_381,x:327.2,y:155.875}).wait(1).to({graphics:mask_1_graphics_382,x:323.55,y:155.875}).wait(1).to({graphics:mask_1_graphics_383,x:320.65,y:155.875}).wait(1).to({graphics:mask_1_graphics_384,x:318.35,y:155.875}).wait(1).to({graphics:mask_1_graphics_385,x:316.6,y:155.875}).wait(1).to({graphics:mask_1_graphics_386,x:315.25,y:155.875}).wait(1).to({graphics:mask_1_graphics_387,x:314.3,y:155.875}).wait(1).to({graphics:mask_1_graphics_388,x:313.65,y:155.875}).wait(1).to({graphics:mask_1_graphics_389,x:313.3,y:155.875}).wait(1).to({graphics:mask_1_graphics_390,x:237.9889,y:131.4718}).wait(19).to({graphics:mask_1_graphics_409,x:237.9889,y:131.4718}).wait(1).to({graphics:mask_1_graphics_410,x:313.025,y:155.875}).wait(1).to({graphics:mask_1_graphics_411,x:312.425,y:155.9}).wait(1).to({graphics:mask_1_graphics_412,x:311.5,y:155.9}).wait(1).to({graphics:mask_1_graphics_413,x:310.175,y:155.925}).wait(1).to({graphics:mask_1_graphics_414,x:308.45,y:155.975}).wait(1).to({graphics:mask_1_graphics_415,x:306.35,y:156}).wait(1).to({graphics:mask_1_graphics_416,x:303.875,y:156.025}).wait(1).to({graphics:mask_1_graphics_417,x:301.025,y:156.075}).wait(1).to({graphics:mask_1_graphics_418,x:297.825,y:156.125}).wait(1).to({graphics:mask_1_graphics_419,x:294.2,y:156.175}).wait(1).to({graphics:mask_1_graphics_420,x:290.2,y:156.25}).wait(1).to({graphics:mask_1_graphics_421,x:285.825,y:156.3}).wait(1).to({graphics:mask_1_graphics_422,x:281.075,y:156.4}).wait(1).to({graphics:mask_1_graphics_423,x:275.925,y:156.475}).wait(1).to({graphics:mask_1_graphics_424,x:270.425,y:156.575}).wait(1).to({graphics:mask_1_graphics_425,x:264.65,y:156.65}).wait(1).to({graphics:mask_1_graphics_426,x:259.15,y:156.75}).wait(1).to({graphics:mask_1_graphics_427,x:254,y:156.825}).wait(1).to({graphics:mask_1_graphics_428,x:249.25,y:156.925}).wait(1).to({graphics:mask_1_graphics_429,x:244.875,y:156.975}).wait(1).to({graphics:mask_1_graphics_430,x:240.875,y:157.05}).wait(1).to({graphics:mask_1_graphics_431,x:237.25,y:157.1}).wait(1).to({graphics:mask_1_graphics_432,x:234.05,y:157.15}).wait(1).to({graphics:mask_1_graphics_433,x:231.2,y:157.2}).wait(1).to({graphics:mask_1_graphics_434,x:228.725,y:157.225}).wait(1).to({graphics:mask_1_graphics_435,x:226.65,y:157.25}).wait(1).to({graphics:mask_1_graphics_436,x:224.9,y:157.3}).wait(1).to({graphics:mask_1_graphics_437,x:223.575,y:157.325}).wait(1).to({graphics:mask_1_graphics_438,x:222.65,y:157.325}).wait(1).to({graphics:mask_1_graphics_439,x:222.05,y:157.35}).wait(1).to({graphics:mask_1_graphics_440,x:221.875,y:157.35}).wait(236));

	// Macbook
	this.instance_1 = new lib.Macbook_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(151.35,155.35,0.8284,0.8284,0,0,0,150.3,125.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(170).to({_off:false},0).wait(239).to({regX:150.1,regY:125.2,scaleX:0.6649,scaleY:0.6649,x:91.95,y:156.95},31,cjs.Ease.quadInOut).wait(236));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.4,51.1,294,425.7);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSFT Logo
	this.logo = new lib.logos();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(56.9,19.15,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(284.1,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(237.9,221.05,0.4964,0.4964);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// Main Text
	this.smallPrint = new lib.txt_6();
	this.smallPrint.name = "smallPrint";
	this.smallPrint.parent = this;
	this.smallPrint.setTransform(181.1,239.95,0.4965,0.4965,0,0,0,0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.smallPrint).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(257.6,219.65,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Intro
	this.anim = new lib.Intro();
	this.anim.name = "anim";
	this.anim.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3vT0MAAAgnnMAvfAAAMAAAAnng");
	this.shape.setTransform(150.025,124.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-1.9,-1.9,344.5,478.59999999999997), null);


// stage content:
(lib.O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "smal" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "flag" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillFlag(data[keys[i]], parseInt(keys[i].substr((keys[i].length-1), keys[i].length)))
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				stage.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillFlag = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.anim.screen["flag"+aVar].flag.addChild(mc);
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		this.runBanner = function() {
		
			exportRoot.tlH1 = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				if(i==0)exportRoot.tlH1.from(exportRoot.headline1[i], 0.7, {y: "+=35", alpha: 0, ease: Power4.easeOut});
				if(i!=0)exportRoot.tlH1.from(exportRoot.headline1[i], 0.7, {y: "+=35", alpha: 0, ease: Power4.easeOut}, "-=0.6");
			}
			exportRoot.tlH1.stop()
			
			exportRoot.tlH1m = new TimelineLite();
			for (var i = 0; i < exportRoot.headline1.length; i++) {
				exportRoot.tlH1m.to(exportRoot.headline1[i], 1, {x: "-=30", ease: Power2.easeInOut});
			}
			exportRoot.tlH1m.stop()
			
			exportRoot.tlH2 = new TimelineLite();
			for (var i = 0; i < exportRoot.headline2.length; i++) {
				if(i==0)exportRoot.tlH2.from(exportRoot.headline2[i], 0.7, {x: "+=4", alpha: 0, ease: Power4.easeInOut});
				if(i!=0)exportRoot.tlH2.from(exportRoot.headline2[i], 0.7, {x: "+=40", alpha: 0, ease: Power4.easeInOut}, "-=0.6");
			}
			exportRoot.tlH2.stop()
			
			exportRoot.tlH3 = new TimelineLite();
			for (var i = 0; i < exportRoot.headline3.length; i++) {
				if(i==0)exportRoot.tlH3.from(exportRoot.headline3[i], 0.7, {x: "+=40", alpha: 0, ease: Power4.easeInOut});
				if(i!=0)exportRoot.tlH3.from(exportRoot.headline3[i], 0.7, {x: "+=40", alpha: 0, ease: Power4.easeInOut}, "-=0.6");
			}
			exportRoot.tlH3.stop()
		
			exportRoot.tl1 = new TimelineLite();
		
			exportRoot.tl1.from(mc.replay_btn, 0.7, {alpha: 0,	x: "+=300",ease: Power4.easeOut})
			exportRoot.tl1.from(mc.txtCta, 0.7, {alpha: 0,	x: "+=300", ease: Power4.easeOut}, "+=0.2");
			exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0,	x: "+=350",	ease: Power4.easeOut}, "-=0.7");
				
			exportRoot.tl1.stop()
		
			mc.logo.gotoAndPlay(1)
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(148.1,123.1,194.50000000000003,353.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_.png?1542127218956", id:"O365_MacUsrs_USA_300x250_BAN_Retargeting_NA_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;